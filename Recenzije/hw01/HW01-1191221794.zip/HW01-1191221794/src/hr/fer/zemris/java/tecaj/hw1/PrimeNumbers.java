package hr.fer.zemris.java.tecaj.hw1;

/**
 * prosti brojevi
* @author Andrej Ciganj
*/
public class PrimeNumbers {

	/**
	 * main ispisuje prvih n prostih brojeva
	 * @param args prima broj n
	 */
	public static void main(String[] args) {
		
		int n=Integer.parseInt(args[0]);		
		
		int[] prostiBrojevi = eratostenovoSito(n);
		System.out.println("You requested calculation of " + n + " prime numbers. Here they are:");
		
		for(int i=0; i<n; i++){
				System.out.println(i+1 + ". " + prostiBrojevi[i]);
		}
	}
	/**
	* Metoda racuna prvih n prostih brojeva
	* @param n broj zeljenih prostih brojeva
	* @return vraca array integera
	*/
	static int[] eratostenovoSito(int n){
		int limit;
		if(n>5)	{
			//gornja granica koja dobro ogranicava n-ti prost broj
			limit=(int) (n*(Math.log(n) + Math.log(Math.log(n))))+1; 
		}
		else
			limit=15;
		
		
		
		boolean[] nijeProst=new boolean[limit]; 
		int[] prosti=new int[limit];
		
		//prvo se rijesim dvojke da mogu kasnije promatrati samo neparne
		int indeks=0;
		prosti[indeks]=2;
		
		
		for(int kandidat=3; kandidat<limit; kandidat+=2){ 
			
			if(nijeProst[kandidat]==false) {
				
				prosti[++indeks]=kandidat;
				//petlja oznacava visekratnike kandidata kao slozene
				for(int j=2*kandidat;j<limit;j+=kandidat) 
					nijeProst[j]=true;
			}		
		}
		
		return prosti;
	}
}
