package hr.fer.zemris.java.tecaj.hw1;
/**
* @author Andrej Ciganj
* lista 
*/
class ProgramListe {
	
	static class CvorListe {
		CvorListe sljedeci;
		String podatak;
	}
	/**
	 * main koristi listu, poziva metode za ubacivanje cvora, sortiranje 
	 * liste i velicinu liste 
	 * ne prima argumente
	 */
	public static void main(String[] args) {
		CvorListe cvor = null;
		cvor = ubaci (cvor, "Jasna");
		cvor = ubaci (cvor, "Ana");
		cvor = ubaci (cvor, "Ivana");
		
		System.out.println("Ispisujem listu uz originalni poredak:");
		ispisiListu(cvor);
		
		cvor = sortirajListu(cvor);
		System.out.println("Ispisujem listu nakon sortiranja:");
		ispisiListu(cvor);
		
		int vel = velicinaListe(cvor);
		System.out.println("Lista sadrzi " + vel + " elemenata.");
	}
	/**
	* Metoda racuna broj elemenata u listi
	* @param cvor pocetak liste
	* @return vraca broj elemenata liste
	*/
	static int velicinaListe(CvorListe cvor){
		
		if(cvor==null){
			return 0;
		}
		else{
			int velicina=1;
			while (cvor.sljedeci!=null){
				cvor=cvor.sljedeci;
				velicina++;
			}
			return velicina;
		}		
	}
	/**
	* Metoda ubacuje element na kraj liste
	* @param prvi pocetak liste
	* @param podatak string koji se dodaje u listu
	* @return vraca pocetak liste
	*/
	static CvorListe ubaci(CvorListe prvi, String podatak){
		
		CvorListe noviCvor=new CvorListe();
		noviCvor.podatak=podatak;
		noviCvor.sljedeci=null;
		
		if(prvi==null) {
			return noviCvor;
		}
		else{
			CvorListe temp=prvi;
			while(temp.sljedeci!=null){
				temp=temp.sljedeci;
			}			
			temp.sljedeci=noviCvor;
			return prvi;
		}
		
	}
	/**
	* Metoda koja ispisuje listu
	* @param cvor pocetak liste
	*/
	static void ispisiListu(CvorListe cvor){
		while(cvor!=null){
			System.out.println(cvor.podatak);
			cvor=cvor.sljedeci;
		}
	}
	/**
	* Metoda sortira listu u slozenosti O(n^2)
	* @param cvor pocetak liste
	* @return vraca pocetak sortirane liste
	*/
	static CvorListe sortirajListu(CvorListe cvor){
		
		CvorListe cvorPrethodnik=cvor;
		CvorListe cvorIterator=cvor;
		CvorListe najmanjiCvor=cvor;
		
		//petlja pronalazi cvor s leksikografski najmanjim podatkom i cvor koji pokazuje na njega
		while(cvorIterator.sljedeci!=null){
			
			if(cvorIterator.sljedeci.podatak.compareTo(najmanjiCvor.podatak)<0){
				
				najmanjiCvor=cvorIterator.sljedeci;
				cvorPrethodnik=cvorIterator;
			}
			
			cvorIterator=cvorIterator.sljedeci;
		}
		
		//ako je najmanji prvi, sortiram ostatak liste
		if(najmanjiCvor==cvor){
			
			if (cvor.sljedeci!=null) {
				cvor.sljedeci=sortirajListu(cvor.sljedeci);
			}
			return cvor;
		}
		else{
			//inace izbacim najmanji iz liste, on pokazuje na ostatak liste koji sortiram
			cvorPrethodnik.sljedeci=najmanjiCvor.sljedeci;
			najmanjiCvor.sljedeci=sortirajListu(cvor);
			return najmanjiCvor;
		}						
	}
	
}