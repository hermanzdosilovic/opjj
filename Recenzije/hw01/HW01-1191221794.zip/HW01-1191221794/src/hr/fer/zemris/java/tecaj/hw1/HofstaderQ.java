package hr.fer.zemris.java.tecaj.hw1;

/**
* Hofsadter Q sequence
* @author Andrej Ciganj
*/
public class HofstaderQ {

	/**
	 * main nalazi n-ti clan hofstatderovog Q niza
	 * @param args prima broj n
	 */
	public static void main(String[] args) {
		
		int n=Integer.parseInt(args[0]);
		if(n<1){
			System.err.println("Potreban je pozitivan broj");
			System.exit(1);
		}
		
		System.out.println("You requested calculation of " + n + 
				". number of Hofstader's Q sequence. The requested number is " 
				+ hof(n) + ".");
		
				
	}
	/**
	* Metoda racuna a-ti element Hofstadterovog niza
	* @param a pozitivni integer
	* @return vraca vrijednost Q(a)
	*/
	static long hof(long a) {
		/* nije efikasno, ali memoizacija je (barem meni) 
		 * tesko ostvariva zbog toga sto parametar mora biti long 
		*/
		if (a==1 || a==2) return 1;
		else 
			return hof(a-hof(a-1))+hof(a-hof(a-2));
	}
}
