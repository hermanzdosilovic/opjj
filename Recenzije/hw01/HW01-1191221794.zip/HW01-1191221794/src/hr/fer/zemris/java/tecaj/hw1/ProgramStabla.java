package hr.fer.zemris.java.tecaj.hw1;

/**
* binarno stablo trazenja
* @author Andrej Ciganj
*/
public class ProgramStabla {

	static class CvorStabla {
		CvorStabla lijevi;
		CvorStabla desni;
		String podatak;
	}
	/**
	* main koristi binarno stablo, poziva metode za ispis, obrtanje poretka, 
	* trazenje podatka u stablu i velicinu stabla
	* ne prima argumente 
	*/
	public static void main(String[] args) {
		CvorStabla cvor = null;
		
		cvor = ubaci(cvor, "Jasna");
		cvor = ubaci(cvor, "Ana");
		cvor = ubaci(cvor, "Ivana");
		cvor = ubaci(cvor, "Anamarija");
		cvor = ubaci(cvor, "Vesna");
		cvor = ubaci(cvor, "Kristina");
		
		System.out.println("Ispisujem stablo inorder:");
		ispisiStablo(cvor);
		cvor = okreniPoredakStabla(cvor);
		System.out.println("Ispisujem okrenuto stablo inorder:");
		ispisiStablo(cvor);
		
		int vel = velicinaStabla(cvor);
		System.out.println("Stablo sadrzi elemenata: " + vel);
		boolean pronaden = sadrziPodatak(cvor, "Ivana");
		System.out.println("Trazeni podatak je pronaden: " + pronaden);
	}
	/**
	* Metoda ispituje da li stablo sadrzi neki podatak
	* @param korijen korijen stabla
	* @param podatak string koji trazi
	* @return vraca true ako je nasao, a false ako nije
	*/
	static boolean sadrziPodatak(CvorStabla korijen, String podatak){
		if(korijen==null) {
			return false;
		}
		else if(korijen.podatak==podatak) {
			return true;
		}
		else{
			
			//pretrazuje podstabla
			return (sadrziPodatak(korijen.lijevi,podatak) || sadrziPodatak(korijen.desni, podatak));
		}
	}
	/**
	* Metoda racuna velicinu stabla
	* @param cvor korijen stabla
	* @return vraca broj elemenata stabla
	*/
	static int velicinaStabla(CvorStabla cvor) {
		if (cvor==null) {
			
			return 0;
		}
		else {
			
			//dodaje 1 i prebrojava podstabla
			return 1+velicinaStabla(cvor.lijevi)+velicinaStabla(cvor.desni);			
		}
	}
	/**
	* Metoda ubacuje novi cvor u stablo na odgovarajuce mjesto
	* @param korijen korijen stabla
	* @param podatak string koji se ubacuje
	* @return vraca korijen stabla
	*/
	static CvorStabla ubaci(CvorStabla korijen, String podatak) {
		
		CvorStabla noviCvor = new CvorStabla();
		noviCvor.desni=null;
		noviCvor.lijevi=null;
		noviCvor.podatak=podatak;
		
		if(korijen==null) {
			
			return noviCvor;
		}
		else {
			
			//ubacuje u lijevo podstablo ako je podatak manji, desno ako je veci
			if(korijen.podatak.compareTo(podatak)>0) {
				korijen.lijevi=ubaci(korijen.lijevi, podatak);
			}
			else {
				korijen.desni=ubaci(korijen.desni, podatak);
			}
			
		}	
		return korijen;
	}
	
	
	/**
	* Metoda ispisuje elemente stabla inorder
	* @param cvor korijen stabla
	*/
	static void ispisiStablo(CvorStabla cvor) {
		//ispisuje lijevo postablo pa podatak pa desno podstablo
		if(cvor.lijevi!=null) {
			ispisiStablo(cvor.lijevi);
		}
		System.out.println(cvor.podatak);
		if(cvor.desni!=null)
			ispisiStablo(cvor.desni);
	}
	
	
	/**
	* Metoda okrece stablo(lijevo leksikografski veci string)
	* @param korijen korijen stabla
	* @return vraca korijen stabla
	*/
	static CvorStabla okreniPoredakStabla(CvorStabla korijen) {
		if (korijen==null) return korijen;
		else{
		
			CvorStabla temp=korijen.desni;
	
			korijen.desni = okreniPoredakStabla(korijen.lijevi);
			korijen.lijevi = okreniPoredakStabla(temp);
			return korijen;
		}
	}
}
