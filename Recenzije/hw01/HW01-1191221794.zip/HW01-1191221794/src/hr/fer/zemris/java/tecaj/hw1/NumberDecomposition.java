package hr.fer.zemris.java.tecaj.hw1;

/**
 * dekompozicija prirodnog broja
* @author Andrej Ciganj
*/
public class NumberDecomposition {

	/**
	 * main racuna dekompozciju broj n na proste brojeve
	 * @param args prima broj n
	 */
	public static void main(String[] args) {
		int n=Integer.parseInt(args[0]);
		System.out.println("You requested decomposition of number " + n + " onto prime factors. Here they are:");
		
		int[] faktori = dekompozicija(n);
		
		int brojFaktora=faktori[0];
		
		for(int i=1; i<brojFaktora; i++) {
			System.out.println(i + ". " + faktori[i]);
		}	
	
	}
	/**
	* Metoda racuna dekompoziciju broja
	* @param a pozitivni integer
	* @return vraca uzlazni array faktora od prvog elementa, nulti sadrzi broj faktora
	*/
	static int[] dekompozicija(int a){
		int[] niz = new int[a];
		
		int djelitelj=2,index=1;
		
		/* a dijelim brojevima od 2 prema vecima 
		 * ako je djeljiv, zapisem ga u niz i probam opet
		 * inace povecam
		 */
		while(a>1){
			
			if (a%djelitelj==0) {
				niz[index]=djelitelj;
				index++;
				a/=djelitelj;				
			}
			
			else djelitelj++;
			
		}
		niz[0]=index; //broj prostih faktora
		
		return niz;
	}

}
