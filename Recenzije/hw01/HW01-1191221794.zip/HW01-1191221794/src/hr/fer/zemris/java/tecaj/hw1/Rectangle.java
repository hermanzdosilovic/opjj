package hr.fer.zemris.java.tecaj.hw1;

import   java.io.BufferedInputStream;
import   java.io.BufferedReader;
import   java.io.InputStreamReader;
import   java.io.IOException;

/**
 * pravokutnik
* @author Andrej Ciganj
*/
public class Rectangle {
	/**
	 * main racuna opseg i povrsinu
	* @param args prima dva double-a: visinu i sirinu
	*/
	public static void main(String[] args) throws IOException {
		if(args.length==2){
			double visina=Double.parseDouble(args[0]);
			double sirina=Double.parseDouble(args[1]);

			System.out.println(povrsina(visina,sirina) + " " + opseg(visina,sirina));
		}
		else if (args.length>0){
			System.out.println("krivi broj argumenata");
		}
		else{
			
			double visina = ucitajPozitivniDouble("Upisi visinu:");
			double sirina = ucitajPozitivniDouble("Upisi sirinu:");
			
			System.out.println(povrsina(visina,sirina) + " " + opseg(visina,sirina));
		}	
	}
	/**
	* Metoda racuna povrsinu pravokutnika
	* @param a visina
	* @param b sirina
	* @return vraca povrsinu
	*/
	static double povrsina(double a, double b){
		return a*b;
	}
	/**
	* Metoda racuna opseg pravokutnika
	* @param a visina
	* @param b sirina
	* @return vraca opseg
	*/
	static double opseg(double a, double b){
		return 2*(a+b);
	}
	/**
	* Metoda pokusava ucitati jedan double, provjerava da 
	* li je nesto upisano i da li je pozitivno
	* @param ispis string koji metoda ispisuje prije svakog pokusaja ucitavanja
	* @return ucitani double
	*/
	static double ucitajPozitivniDouble(String ispis) throws IOException {
		BufferedReader reader = new BufferedReader(new InputStreamReader(new BufferedInputStream(System.in)));
	    double ucitano=0;
	    boolean nijeDobroUnesen=true;
	    
	    while (nijeDobroUnesen){
	    	
	    	System.out.println(ispis);
	    	
	    	String redak = reader.readLine();
	    	redak.trim();
	    	
	    
	    	if (!redak.isEmpty()){
	    	   	//ako string nije prazan, provjeri da li je nenegativan
	    		ucitano = Double.parseDouble(redak);
	    	   	
	    	   	if(ucitano<0){
	    	   		System.out.println("Broj je negativan.");
	    	   		nijeDobroUnesen=true;
	    	   	}
	    	   	
	    	   	else{
	    	   		//dobro je uneseno, možemo izaci iz petlje
	    	   		nijeDobroUnesen=false;
	    	   	}
	    	}
	    	else{
	    	  	System.out.println("Nista nije uneseno.");
	    	}	    	    	
	    }
	    
	    return  ucitano;
	}
}

