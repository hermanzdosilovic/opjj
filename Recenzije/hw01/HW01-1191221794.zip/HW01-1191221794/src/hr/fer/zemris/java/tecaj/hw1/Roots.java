package hr.fer.zemris.java.tecaj.hw1;
import java.lang.Math;
/**
*klasa racuna korijene kompleksnog broja 
*@author Andrej Ciganj
*/
public class Roots {
	static class KompleksniBroj {
		double realniDio,imaginarniDio;
	}
	/**
	* Metoda racuna korijene kompleksnog broja i ispisuje ih
	* @param args prima tri stringa: realni dio kompleksnog broja(double), imaginarni dio(double) i koji korijen(int) zelimo
	*/
	public static void main(String[] args) {
		
		KompleksniBroj broj= new KompleksniBroj();
		
		broj.realniDio=Double.parseDouble(args[0]);			
		broj.imaginarniDio=Double.parseDouble(args[1]);
		int korijen=Integer.parseInt(args[2]);
		
		ispisiKorijene(broj,korijen); 
		
			
	}
	/**
	* Metoda racuna korijene kompleksnog broja i ispisuje ih
	* @param broj kompleksni broj kojem racuna korijene
	* @param korijen metoda ce racunati n-ti korijen iz broja
	*/
	static void ispisiKorijene(KompleksniBroj broj, int n) {

		double r=Math.sqrt(broj.realniDio*broj.realniDio+broj.imaginarniDio*broj.imaginarniDio);
		r=Math.pow(r,1.0/n);
		
		System.out.println("You requested calculation of " + n +". roots. Solutions are:");
		
		//ako je r=0 onda ispisem samo 0+0i
		if(Math.abs(r)<0.0000000001) 
			System.out.println("0+0i");
		else {
		
			double kut=Math.atan(broj.imaginarniDio/broj.realniDio);
	
			KompleksniBroj kKorijen=new KompleksniBroj();
			
			for(int k=0;k<n;k++) {  					
				//nalazenje k rjesenja
				double kutRjesenja=kut/n+2*Math.PI*k/n;
			
				kKorijen.realniDio=r*Math.cos(kutRjesenja);
				kKorijen.imaginarniDio=r*Math.sin(kutRjesenja);
			
				System.out.print((k+1) + ") ");
				ispis(kKorijen);
			}
		}
	}
	
	
	/**
	* Metoda ispisuje kompleksni broj
	* @param broj kompleksni broj
	*/
	static void ispis(KompleksniBroj broj) {
		
		if(broj.imaginarniDio<0) {
			
			broj.imaginarniDio=Math.abs(broj.imaginarniDio);
			
			System.out.println(broj.realniDio + " - " + broj.imaginarniDio + "i");
		
		}
		else
			System.out.println(broj.realniDio + " + " + broj.imaginarniDio + "i");
	
	}
	
}
