package hr.fer.zemris.java.tecaj.hw1;


/**
 * The class <code>PrimeNumbers</code> contains methods used to calculate 
 * the first n prime numbers.
 * 
 * @author Matej Djerdji
 *
 */
public class PrimeNumbers {
	
	/**
	 * Program entry point. Prints the first n prime numbers, starting from the number 2.
	 * 
	 * @param args Number of primes to be printed. Must be positive integer. 
	 */
	public static void main(String[] args){
		if(args.length != 1){
			System.err.println("Invalid number of arguments was provided.");
			System.exit(1);
		}else{
			int n = Integer.parseInt(args[0]);
			if(n>0){
				System.out.println("You requested calculation of " + n + 
								   " prime numbers. Here they are: ");
				int[] primes = firstNPrimes(n);
				for(int i = 0 ; i < primes.length ; i++){
					System.out.println((i+1) + ". " + primes[i]);
				}	
				
			}else{
				System.err.println("Argument must be positive.");
				System.exit(1);
			}
		}
	}
	
	/**
	 * Calculates the first n prime numbers, starting from the number 2.
	 * 
	 * @param n Number of primes to be calculated.
	 * @return Returns an integer array of size n, containing prime numbers.
	 */
	static int[] firstNPrimes(int n){
		int[] primes = new int[n];
		primes[0] = 2;
		int i = 1, current = 1;
		Boolean isPrime;
		
		while(i < n){
			current += 2;
			isPrime = true;
											
			for(int j = 0 ; primes[j] < current/2 ; j++){
				if(current % primes[j] == 0){
					isPrime = false;
					break;
				}
			}
			
			if(isPrime){
				primes[i] = current;
				i++;
			}
			
		}		
		return primes;		
	}

}
