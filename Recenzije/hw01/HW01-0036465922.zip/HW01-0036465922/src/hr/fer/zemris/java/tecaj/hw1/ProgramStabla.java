package hr.fer.zemris.java.tecaj.hw1;


/**
 * The class <code>ProgramStabla</code> contains methods used for 
 * adding nodes to a binary tree, searching for values in the binary
 * tree, calculating the size of the tree, printing values contained within 
 * the tree and reversing the tree order.
 * 
 * @author Matej Djerdji
 *
 */
class ProgramStabla {
	
	/**
	 * The class <code>CvorStabla</code> is used as a 
	 * structure representing elements of a binary tree.
	 * Each node is capable of storing a single <code>String</code> type object. 
	 * 
	 * @author Matej Djerdji
	 *
	 */
	static class CvorStabla {
		CvorStabla lijevi;
		CvorStabla desni;
		String podatak;
	}
	
	
	/**
	 * Class entry point. Creates a sample binary tree, prints it, reverses its order,
	 * prints again and prints the size of the tree.
	 * 
	 * @param args Not used.
	 */
	public static void main(String[] args) {
		CvorStabla cvor = null;
		cvor = ubaci(cvor, "Jasna");
		cvor = ubaci(cvor, "Ana");
		cvor = ubaci(cvor, "Ivana");
		cvor = ubaci(cvor, "Anamarija");
		cvor = ubaci(cvor, "Vesna");
		cvor = ubaci(cvor, "Kristina");
				
		System.out.println("Ispisujem stablo inorder:");
		ispisiStablo(cvor);
		
		cvor = okreniPoredakStabla(cvor);
		System.out.println("Ispisujem okrenuto stablo inorder:");
		ispisiStablo(cvor);
		
		int vel = velicinaStabla(cvor);
		System.out.println("Stablo sadrzi elemenata: "+vel);
		
		boolean pronaden = sadrziPodatak(cvor, "Ivana");
		System.out.println("Trazeni podatak je pronaden: "+pronaden);
	}
	
	/**
	 * Searches the given binary tree for the first occurrence of the given string.
	 * Works only on sorted trees.
	 * 
	 * @param korijen Tree root node.
	 * @param podatak String that is being searched for.
	 * @return Returns true if the given string is found within the tree, false otherwise.
	 */
	static boolean sadrziPodatak(CvorStabla korijen, String podatak) {
			if (korijen == null) return false;
			else if(podatak.equals(korijen.podatak)) return true;
			else if(podatak.compareTo(korijen.podatak) <= 0) return sadrziPodatak(korijen.lijevi, podatak);
			else return sadrziPodatak(korijen.desni, podatak);
	}
	
	/**
	 * Calculates the size of a binary tree.
	 * 
	 * @param cvor Tree root node.
	 * @return Returns number of nodes within the tree.
	 */
	static int velicinaStabla(CvorStabla cvor) {
		if(cvor == null) return 0;
		else return (1 + velicinaStabla(cvor.lijevi) + velicinaStabla(cvor.desni));
	}
	
	/**
	 * Inserts a new node into a binary tree.
	 * 
	 * @param korijen Tree root node.
	 * @param podatak String value to be added to the new node.
	 * @return Returns a <code>CvorStabla</code> object referencing the newly created node.
	 */
	static CvorStabla ubaci(CvorStabla korijen, String podatak) {
		if (korijen == null){
			CvorStabla novi = new CvorStabla();
			novi.desni = novi.lijevi = null;
			novi.podatak = podatak;
			
			return novi;
		}else{
			if (podatak.compareTo(korijen.podatak) <= 0){
				korijen.lijevi = ubaci(korijen.lijevi, podatak);
			}else{
				korijen.desni = ubaci(korijen.desni, podatak);
			}
		
			return korijen;
		}
	}
	
	/**
	 * Prints tree nodes inorder.
	 * 
	 * @param cvor Tree root node.
	 */
	static void ispisiStablo(CvorStabla cvor) {
		if(cvor == null){
			return;
		}else{
			ispisiStablo(cvor.lijevi);
			System.out.println(cvor.podatak);
			ispisiStablo(cvor.desni);
		}
	}
	
	/**
	 * Reverses tree order.
	 * 
	 * @param korijen Tree root node.
	 * @return Returns tree root node.
	 */
	static CvorStabla okreniPoredakStabla(CvorStabla korijen) {
		if (korijen == null) {
			return null;
		}else{
			CvorStabla tmp = korijen.lijevi;
			korijen.lijevi = okreniPoredakStabla(korijen.desni);
			korijen.desni = okreniPoredakStabla(tmp);
			
			return korijen;
		}
	}
	
	
}






















