package hr.fer.zemris.java.tecaj.hw1;


/**
 * The class <code>ProgramListe</code> contains methods used for 
 * adding elements into a singly linked list, printing elements of the list,
 * calculating list size and list sorting.
 * 
 * @author Matej Djerdji
 *
 */
class ProgramListe {
	
	/**
	 * The class <code>CvorListe</code> is used as a 
	 * structure representing elements of a singly linked list.
	 * Each element is capable of storing a single <code>String</code> type object. 
	 * 
	 * @author Matej Djerdji
	 *
	 */
	static class CvorListe {
		CvorListe sljedeci;
		String podatak;
	}
	
	/**
	 * Program entry point.
	 * Creates a sample list, prints its content, sorts the elements and prints again.
	 * Also prints list length.
	 * 
	 * @param args Not used.
	 */
	public static void main(String[] args) {
		CvorListe cvor = null;
		cvor = ubaci(cvor, "Jasna");
		cvor = ubaci(cvor, "Ana");
		cvor = ubaci(cvor, "Ivana");
	
		
		System.out.println("Ispisujem listu uz originalni poredak:");
		ispisiListu(cvor);
		
		cvor = sortirajListu(cvor);
		System.out.println("Ispisujem listu nakon sortiranja:");
		ispisiListu(cvor);
		
		int vel = velicinaListe(cvor);
		System.out.println("Lista sadrzi elemenata: "+vel);
	}
	
	/**
	 * Iteratively calculates list length (number of elements in list).
	 * 
	 * @param cvor List head.
	 * @return	Returns number of elements present in the list.
	 */
	static int velicinaListe(CvorListe cvor) {
		int size = 0;
				
		while (cvor != null){
			size++;
			cvor = cvor.sljedeci;
		}
		
		return size;
	}
	
	/**
	 * Adds new element to a linked list.
	 * The new element is added to the beginning of the list. 
	 * 
	 * @param prvi List head.
	 * @param podatak String to be added to the list.
	 * @return Returns the new list head.
	 */
	static CvorListe ubaci(CvorListe prvi, String podatak) {
		CvorListe novi = new CvorListe();
		
		novi.sljedeci = prvi;
		novi.podatak = podatak;
		return novi;
	}
	
	/**
	 * Prints all elements of the given list.
	 * 
	 * @param cvor List head.
	 */
	static void ispisiListu(CvorListe cvor) {
		while (cvor != null){
			System.out.println(cvor.podatak);
			cvor = cvor.sljedeci;
		}
	}
	
	/**
	 * Swaps the data of two list elements.
	 * 	
	 * @param cvor1 First element. 
	 * @param cvor2 Second element.
	 */
	static void zamijeniPodatke(CvorListe cvor1, CvorListe cvor2){
		if(cvor1 != null && cvor2 != null){
			String tmp = cvor1.podatak;
			cvor1.podatak = cvor2.podatak;
			cvor2.podatak = tmp;
		}
	}
	
	/**
	 * Sorts the given list using the Bubble sort algorithm.
	 * 
	 * @param cvor List head.
	 * @return Returns list head.
	 */
	static CvorListe sortirajListu(CvorListe cvor) {
		CvorListe tmp = cvor;
		Boolean imaZamjene = true;
		int duljinaListe = velicinaListe(cvor);
		
		if(duljinaListe > 1){
			while(imaZamjene){
				imaZamjene = false;
				while (tmp != null){
					if(tmp.sljedeci != null && tmp.podatak.compareTo(tmp.sljedeci.podatak) > 0){
						zamijeniPodatke(tmp, tmp.sljedeci);
						imaZamjene = true;
					}
					tmp = tmp.sljedeci;
				}
				tmp = cvor;
			}
			
		}
		
		return cvor;
	}	

}