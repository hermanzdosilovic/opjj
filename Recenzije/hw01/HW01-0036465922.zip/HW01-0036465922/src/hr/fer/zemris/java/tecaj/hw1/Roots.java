package hr.fer.zemris.java.tecaj.hw1;

import java.text.DecimalFormat;


/**
 * The class <code>Roots</code> contains methods used to calculate 
 * roots of complex numbers. 
 * 
 * @author Matej Djerdji
 *
 */
public class Roots {
	
	/**
	 * Class entry point. Prints all n-th roots for a given complex number.
	 * 
	 * @param args Accepts three arguments: real part of a complex number, imaginary part of complex a number, 
	 * and a non-negative integer - n denoting the n-th root to be calculated. Real and complex parts may be real numbers.
	 */
	public static void main(String[] args) {
		if(args.length != 3){
			System.err.println("Invalid number of arguments was provided.");
			System.exit(1);
		}else{
			double re = Double.parseDouble(args[0]);
			double im = Double.parseDouble(args[1]);
			int nRoot = Integer.parseInt(args[2]);
			
			if(nRoot <= 0){
				System.err.println("Root n must be non-negative.");
				System.exit(1);
			}
			
			String imSign;
			if (im >= 0) imSign = " + ";
			else imSign = " - ";
			
			System.out.println("You requested calculation of " + 
								nRoot + ". roots of the complex number (" + 
								re + imSign + Math.abs(im) + "i). Solutions are:");
			calculateCplxRoots(re, im, nRoot);
		}
		
	}
	
	/**
	 * Calculates and prints all n-th roots of a given complex number. 
	 * 
	 * @param re Real part of the complex number.
	 * @param im Imaginary part of the complex number.
	 * @param n n-th root to be calculated.
	 */
	static void calculateCplxRoots(double re, double im, int n){
		double abs = Math.hypot(re, im);
		double arg = Math.atan2(im, re);
		
		abs = Math.pow(abs, 1.0/n);
		for (int i = 0 ; i < n ; i++){
			arg += 2.0 * i * Math.PI;
			System.out.print((i+1) + ") ");
			printCplx(abs, arg/n);
		}
		
		
	}
	
	/**
	 * Accepts a complex number in its polar form, and prints its real and imaginary components.
	 * 
	 * @param abs Absolute value of the complex number.
	 * @param arg Argument of the complex number.
	 */
	static void printCplx(double abs, double arg){
		double re = abs * Math.cos(arg);
		double im = abs * Math.sin(arg);
		
		DecimalFormat reFormat = new DecimalFormat("0.####");
		DecimalFormat imFormat = new DecimalFormat(" + 0.####i; - 0.####i");
		
		System.out.println(reFormat.format(re) + imFormat.format(im));
	}

}
