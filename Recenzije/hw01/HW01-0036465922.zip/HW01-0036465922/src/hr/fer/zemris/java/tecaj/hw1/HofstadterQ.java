package hr.fer.zemris.java.tecaj.hw1;

/**
 * The class <code>HofstadterQ</code> contains methods for calculating
 * the values of the Hofstadter Q-series, Q(n), which is defined as follows:
 * <ul>
 * <li>Q(1) = 1, Q(2) = 1<li>
 * <li>Q(n) = Q(n - Q(n-1)) + Q(n - Q(n-2)), n>2<li>
 * <ul>
 * 
 * @author Matej Djerdji
 *
 */
public class HofstadterQ {
	
	/**
	 * Program entry point. Prints n-th element of Hofstadter's Q-series.
	 * 
	 * @param args Accepts one positive integer n, the n-th element of the Q-series to be calculated.
	 */
	public static void main(String[] args) {
		if(args.length != 1){
			System.err.println("Invalid number of arguments was provided.");
			System.exit(1);
		}else{
			long n = Long.parseLong(args[0]);
			if(n>0){
				System.out.println("You requested calculation of " + n + 
								   ". number of Hofstadter's Q-sequence. The requested number is " + HofsQIter(n) + ".");
			}else{
				System.err.println("Argument must be positive.");
				System.exit(1);
			}
		}
	}
	
	/**
	 * Iterative implementation of a function calculation elements of Hofstadter's Q-sequence.
	 * 
	 * @param n The element of Hofstdter's Q-sequence to be calculated. Must be positive.
	 * @return Returns the n-th element of Hofstadter's Q-sequence.
	 */
	static long HofsQIter(long n){
		long[] sequence = new long[(int) n + 2];
		sequence[0] = 0;								// The sequence starts at index 1 
		sequence[1] = sequence[2] = 1;
		
		for(int i = 3 ; i <= n ; i++){
			sequence[i] = sequence[(int) (i - sequence[i - 1])] + sequence[(int) (i - sequence[i - 2])];
		}
		
		return sequence[(int) n];
	}
	
	/**
	 * Recursive implementation of a function calculation elements of Hofstadter's Q-sequence.
	 * 
	 * @param n The element of Hofstdter's Q-sequence to be calculated. Must be positive.
	 * @return Returns the n-th element of Hofstadter's Q-sequence.
	 */
	static long HofsQRec(long n){
		if(n == 1 || n == 2) return 1;
		else return (HofsQRec(n - HofsQRec(n-1)) + HofsQRec(n - HofsQRec(n-2)));		
	}
}
