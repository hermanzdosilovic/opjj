package hr.fer.zemris.java.tecaj.hw1;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;

/**
 * The class <code>Rectangle</code> implements methods 
 * used for command-line input of rectangle dimensions
 * and calculation of area and perimeter for given dimensions.
 * 
 * @author Matej Djerdji
 *
 */
public class Rectangle {
	
	/**
	 * Main class method. The method either accepts arguments passed from the command-line or, alterantively,
	 * reads the arguments one-by-one from standard input during runtime. Only non-negative values are accepted.
	 * The method prints the resulting area and perimeter to standard input.
	 * 
	 * @param args Rectangle width and height. Must be non-negative real numbers.
	 * @throws IOException Throws IOException in case a given argument can't be parsed into a <code>double</code> value
	 */
	public static void main(String[] args) throws IOException {
		BufferedReader reader = new BufferedReader(new InputStreamReader(new BufferedInputStream(System.in)));
		double width, height;
		
		if(args.length == 2){
			width = Double.parseDouble(args[0]);
			height = Double.parseDouble(args[1]);
			
			if (width < 0){
				System.out.println("Width is negative.");
				width = readDimension(reader, "Width");
			}
			
			if (height < 0){
				System.out.println("Height is negative.");
				height = readDimension(reader, "Height");
			}			
		}else{
			if (args.length != 0){
				System.err.println("Invalid number of arguments was provided.");
				System.exit(1);
			}
			
			width = readDimension(reader, "Width");
			height = readDimension(reader, "Height");
		}
		
		System.out.println("You have specified a rectangle with width " + width + 
						   " and height " + height +
						   ". Its area is " + (width*height) + 
						   " and its perimeter is " + 2*(width + height) + ".");
		
		reader.close();		
	}	
	
	/**
	 * Method for obtaining a single dimension (non-negative real number) from a user.
	 * The user is prompted to input a value, if the given value is negative or no value is input,
	 * an appropriate complaint is printed, and the user is prompted again.
	 * 
	 * @param reader Initialized <code>BufferedReader</code> object used for value input.
	 * @param dimName String containing the name of the dimension that is being input. Must be in sentence-case ("Aaaaaa", ex.: "Width").
	 * @return Returns a single non-negative <code>double</code> value.
	 * @throws IOException Throws IOException in case a given argument can't be parsed into a <code>double</code> value
	 */
	static double readDimension(BufferedReader reader, String dimName) throws IOException {
		String lcDimName = dimName.toLowerCase();
		String line;
		double dim = -1;
		
		while (dim < 0){				
			System.out.print("Please provide " + lcDimName + ": ");
			line = reader.readLine().trim();
			if (line != null && !line.isEmpty()){
				dim = Double.parseDouble(line.trim());
				if (dim < 0) System.out.println(dimName + " is negative.");
			}else{
				System.out.println("Nothing was given.");
			}
		}
		
		return dim;		
	}
}





















