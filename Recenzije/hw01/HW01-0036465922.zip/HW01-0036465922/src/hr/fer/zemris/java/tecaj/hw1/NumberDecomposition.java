package hr.fer.zemris.java.tecaj.hw1;

/**
 * The class <code>NumberDecomposition</code> contains methods for number decomposition.
 * 
 * @author Matej Djerdji
 *
 */
public class NumberDecomposition {
	
	/**
	 * Program entry point. 
	 * 
	 * @param args Natural number to be factorized. Must be integer greater than 1.
	 */
	public static void main(String[] args){
		if(args.length != 1){
			System.err.println("Invalid number of arguments was provided.");
			System.exit(1);
		}else{
			int n = Integer.parseInt(args[0]);
			if(n>0){
				printPrimeFactors(n);					
			}else{
				System.err.println("Argument must be positive.");
				System.exit(1);
			}
		}
	}
	
	/**
	 * Prints all prime factors for a given natural number.
	 * 
	 * @param n Natural number to be factorized. Must be integer greater than 1.
	 */
	static void printPrimeFactors(int n){
		if(n == 1){
			System.err.println("The argument must be a natural number greater than 1.");
		}else if(n > 1){
			int[] primes = PrimeNumbers.firstNPrimes(n/2 + 1);
			int i = 0, j = 1;	
			
			System.out.println("You requested decomposition of number " + n + 
					           " onto prime numbers. Here they are: ");
			
			while(n > 1){
				while(n % primes[i] == 0){
					System.out.println(j + ". " + primes[i]);
					j++;
					n /= primes[i];
				}
				i++;
			}
		}		
	}
}
