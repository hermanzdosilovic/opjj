package hr.fer.zemris.java.custom.scripting.exec;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class ValueWrapperDecrementTest {

	private final double EPSILON = 10E-6;

	@Test
	public void decrementNullAndNullSuccess() {

		ValueWrapper vw = new ValueWrapper(null);
		vw.decrement(null);

		assertEquals("Object creation did not result in a proper value type.",
				true, (vw.getValue() instanceof Integer));
		assertEquals("Object creation did not result in a proper value.", 0,
				(Integer) vw.getValue(), EPSILON);
	}

	@Test
	public void decrementNullAndIntegerSuccess() {

		ValueWrapper vw = new ValueWrapper(null);
		vw.decrement(Integer.valueOf(20));

		assertEquals("Object creation did not result in a proper value type.",
				true, (vw.getValue() instanceof Integer));
		assertEquals("Object creation did not result in a proper value.", -20,
				(Integer) vw.getValue(), EPSILON);
	}

	@Test
	public void decrementNullAndDoubleSuccess() {

		ValueWrapper vw = new ValueWrapper(null);
		vw.decrement(Double.valueOf(20));

		assertEquals("Object creation did not result in a proper value type.",
				true, (vw.getValue() instanceof Double));
		assertEquals("Object creation did not result in a proper value.", -20,
				(Double) vw.getValue(), EPSILON);
	}

	@Test
	public void decrementNullAndIntegerStringSuccess() {

		ValueWrapper vw = new ValueWrapper(null);
		vw.decrement("20");

		assertEquals("Object creation did not result in a proper value type.",
				true, (vw.getValue() instanceof Integer));
		assertEquals("Object creation did not result in a proper value.", -20,
				(Integer) vw.getValue(), EPSILON);
	}

	@Test
	public void decrementNullAndDoubleStringSuccess() {

		ValueWrapper vw = new ValueWrapper(null);
		vw.decrement("20.0");

		assertEquals("Object creation did not result in a proper value type.",
				true, (vw.getValue() instanceof Double));
		assertEquals("Object creation did not result in a proper value.", -20,
				(Double) vw.getValue(), EPSILON);
	}

	@Test
	public void decrementIntegerAndDoubleSuccess() {

		ValueWrapper vw = new ValueWrapper(Integer.valueOf(32));
		vw.decrement(Double.valueOf(20));

		assertEquals("Object creation did not result in a proper value type.",
				true, (vw.getValue() instanceof Double));
		assertEquals("Object creation did not result in a proper value.", 12,
				(Double) vw.getValue(), EPSILON);
	}

	@Test
	public void decrementIntegerAndIntegerSuccess() {

		ValueWrapper vw = new ValueWrapper(Integer.valueOf(32));
		vw.decrement(Integer.valueOf(20));

		assertEquals("Object creation did not result in a proper value type.",
				true, (vw.getValue() instanceof Integer));
		assertEquals("Object creation did not result in a proper value.", 12,
				(Integer) vw.getValue(), EPSILON);
	}

	@Test(expected = IllegalArgumentException.class)
	public void decrementGivenInvalidTypeThrownException() {

		ValueWrapper vw = new ValueWrapper(Integer.valueOf(32));
		vw.decrement(Long.valueOf(20));
	}
}
