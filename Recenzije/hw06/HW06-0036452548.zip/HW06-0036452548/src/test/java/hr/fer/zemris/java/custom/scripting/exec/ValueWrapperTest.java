package hr.fer.zemris.java.custom.scripting.exec;

import org.junit.Test;
import static org.junit.Assert.*;

public class ValueWrapperTest {

	private final double EPSILON = 10E-6;

	@Test
	public void constructorGivenStringSuccess() {

		ValueWrapper vw = new ValueWrapper("String");

		assertEquals("Object creation did not result in a proper value type.",
				true, (vw.getValue() instanceof String));
		assertEquals("Object creation did not result in a proper value.",
				"String", ((String) vw.getValue()));
	}

	@Test
	public void constructorGivenDoubleSuccess() {

		ValueWrapper vw = new ValueWrapper(new Double(5));

		assertEquals("Object creation did not result in a proper value type.",
				true, (vw.getValue() instanceof Double));
		assertEquals("Object creation did not result in a proper value.", 5,
				((Double) vw.getValue()), EPSILON);
	}

	@Test
	public void constructorGivenIntegerSuccess() {

		ValueWrapper vw = new ValueWrapper(new Integer(5));

		assertEquals("Object creation did not result in a proper value type.",
				true, (vw.getValue() instanceof Integer));
		assertEquals("Object creation did not result in a proper value.", 5,
				vw.getValue());
	}

	@Test
	public void constructorGivenNullSuccess() {

		ValueWrapper vw = new ValueWrapper(null);

		assertEquals("Object creation did not result in a proper value type.",
				true, (vw.getValue() == null));
	}

	@Test(expected = IllegalArgumentException.class)
	public void constructorGivenInvalidTypeThrownException() {

		new ValueWrapper(new Long(4)); // legal types are: String, Double,
										// Integer, null
	}

	@Test
	public void setValueSuccess() {
		
		ValueWrapper vw = new ValueWrapper(Integer.valueOf(20));
		
		vw.setValue(Double.valueOf(12.3));
		
		assertEquals("Setting value did not result in a proper value type.",
				true, (vw.getValue() instanceof Double));
		assertEquals("Setting value did not result in a proper value.", 12.3,
				(Double)vw.getValue(), EPSILON);
	}
	
	@Test(expected = IllegalArgumentException.class)
	public void setValueGivenInvalidTypeExceptionThrown() {
		
		ValueWrapper vw = new ValueWrapper(Integer.valueOf(20));
		
		vw.setValue(Long.valueOf(12));
	}
}
