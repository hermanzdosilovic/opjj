package hr.fer.zemris.java.custom.scripting.exec;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class ObjectMultistackTest {

	private final double EPSILON = 10E-6;

	@Test
	public void pushSuccess() {
		
		ObjectMultistack stack = new ObjectMultistack();
		stack.push("stog", new ValueWrapper("20"));
		
		// TODO
	}
	
	@Test(expected = IllegalArgumentException.class)
	public void pushGivenNameEmptyExceptionThrown() {
		
		ObjectMultistack stack = new ObjectMultistack();
		stack.push("", new ValueWrapper("20"));
	}
	
	@Test(expected = IllegalArgumentException.class)
	public void pushGivenNameNullExceptionThrown() {
		
		ObjectMultistack stack = new ObjectMultistack();
		stack.push(null, new ValueWrapper("20"));
	}
	
	@Test(expected = IllegalArgumentException.class)
	public void pushGivenValueEmptyExceptionThrown() {
		
		ObjectMultistack stack = new ObjectMultistack();
		stack.push("ime", null);
	}
	
	@Test
	public void popSuccess() {
		
		ObjectMultistack stack = new ObjectMultistack();
		stack.push("stog", new ValueWrapper("20"));
		stack.push("stog", new ValueWrapper(Double.valueOf(21.5)));
		
		assertEquals("The stack with the given name was not empty but the method says otherwise.", false, stack.isEmpty("stog"));
		
		stack.pop("stog");
		
		assertEquals("The stack with the given name was not empty but the method says otherwise.", false, stack.isEmpty("stog"));
		
		stack.pop("stog");
		
		assertEquals("The stack with the given name was empty but the method says otherwise.", true, stack.isEmpty("stog"));
	}
	
	
	@Test(expected = IllegalArgumentException.class)
	public void popGivenStringNullExceptionThrown() {
		
		ObjectMultistack stack = new ObjectMultistack();
		stack.pop(null);
	}
	
	@Test(expected = IndexOutOfBoundsException.class)
	public void popStackEmptyExceptionThrown() {
		
		ObjectMultistack stack = new ObjectMultistack();
		stack.pop("stog");
	}
	
	@Test
	public void peekSuccess() {
		
		ObjectMultistack stack = new ObjectMultistack();
		stack.push("stog", new ValueWrapper("20"));
		stack.push("stog", new ValueWrapper(Double.valueOf(21.5)));
		
		assertEquals("The stack with the given name was not empty but the method says otherwise.", false, stack.isEmpty("stog"));
		
		ValueWrapper obj = stack.peek("stog");
		assertEquals("Last element on stack was of the wrong type.", true, (obj.getValue() instanceof Double));
		assertEquals("Last element on stack was of the wrong value.", 21.5, (Double)obj.getValue(), EPSILON);
		
	}
	
	@Test(expected = IllegalArgumentException.class)
	public void peekGivenStringNullExceptionThrown() {
		
		ObjectMultistack stack = new ObjectMultistack();
		stack.peek(null);
	}
	
	@Test(expected = IndexOutOfBoundsException.class)
	public void peekStackEmptyExceptionThrown() {
		
		ObjectMultistack stack = new ObjectMultistack();
		stack.peek("stog");
	}

	@Test
	public void isEmptySuccess() {
		
		ObjectMultistack stack = new ObjectMultistack();
		
		assertEquals("The stack with the given name was empty but the method says otherwise.", 
				true, stack.isEmpty("stog"));
		
		stack.push("stog", new ValueWrapper("20"));
		
		assertEquals("The stack with the given name was not empty but the method says otherwise.", 
				false, stack.isEmpty("stog"));
	}
	
	@Test(expected = IllegalArgumentException.class)
	public void isEmptyNullGivenExceptionThrown() {
		
		ObjectMultistack stack = new ObjectMultistack();
		stack.isEmpty(null);
	}
}
