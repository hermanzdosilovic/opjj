package hr.fer.zemris.java.custom.scripting.exec;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class ValueWrapperIncrementTest {

	private final double EPSILON = 10E-6;

	@Test
	public void incrementNullAndNullSuccess() {

		ValueWrapper vw = new ValueWrapper(null);
		vw.increment(null);

		assertEquals("Object creation did not result in a proper value type.",
				true, (vw.getValue() instanceof Integer));
		assertEquals("Object creation did not result in a proper value.", 0,
				(Integer) vw.getValue(), EPSILON);
	}

	@Test
	public void incrementNullAndIntegerSuccess() {

		ValueWrapper vw = new ValueWrapper(null);
		vw.increment(Integer.valueOf(20));

		assertEquals("Object creation did not result in a proper value type.",
				true, (vw.getValue() instanceof Integer));
		assertEquals("Object creation did not result in a proper value.", 20,
				(Integer) vw.getValue(), EPSILON);
	}

	@Test
	public void incrementNullAndDoubleSuccess() {

		ValueWrapper vw = new ValueWrapper(null);
		vw.increment(Double.valueOf(20));

		assertEquals("Object creation did not result in a proper value type.",
				true, (vw.getValue() instanceof Double));
		assertEquals("Object creation did not result in a proper value.", 20,
				(Double) vw.getValue(), EPSILON);
	}

	@Test
	public void incrementNullAndIntegerStringSuccess() {

		ValueWrapper vw = new ValueWrapper(null);
		vw.increment("20");

		assertEquals("Object creation did not result in a proper value type.",
				true, (vw.getValue() instanceof Integer));
		assertEquals("Object creation did not result in a proper value.", 20,
				(Integer) vw.getValue(), EPSILON);
	}

	@Test
	public void incrementNullAndDoubleStringSuccess() {

		ValueWrapper vw = new ValueWrapper(null);
		vw.increment("20.0");

		assertEquals("Object creation did not result in a proper value type.",
				true, (vw.getValue() instanceof Double));
		assertEquals("Object creation did not result in a proper value.", 20,
				(Double) vw.getValue(), EPSILON);
	}

	@Test
	public void incrementIntegerAndDoubleSuccess() {

		ValueWrapper vw = new ValueWrapper(Integer.valueOf(32));
		vw.increment(Double.valueOf(20));

		assertEquals("Object creation did not result in a proper value type.",
				true, (vw.getValue() instanceof Double));
		assertEquals("Object creation did not result in a proper value.", 52,
				(Double) vw.getValue(), EPSILON);
	}

	@Test
	public void incrementDoubleAndIntegerSuccess() {

		ValueWrapper vw = new ValueWrapper(Double.valueOf(32));
		vw.increment(Integer.valueOf(20));

		assertEquals("Object creation did not result in a proper value type.",
				true, (vw.getValue() instanceof Double));
		assertEquals("Object creation did not result in a proper value.", 52,
				(Double) vw.getValue(), EPSILON);
	}
	
	@Test
	public void incrementIntegerAndIntegerSuccess() {

		ValueWrapper vw = new ValueWrapper(Integer.valueOf(32));
		vw.increment(Integer.valueOf(20));

		assertEquals("Object creation did not result in a proper value type.",
				true, (vw.getValue() instanceof Integer));
		assertEquals("Object creation did not result in a proper value.", 52,
				(Integer) vw.getValue(), EPSILON);
	}

	@Test(expected = IllegalArgumentException.class)
	public void incrementGivenInvalidTypeThrownException() {

		ValueWrapper vw = new ValueWrapper(Integer.valueOf(32));
		vw.increment(Long.valueOf(20));
	}

	@Test(expected = IllegalArgumentException.class)
	public void incrementGivenInvalidStringDoubleThrownException() {

		ValueWrapper vw = new ValueWrapper(Integer.valueOf(32));
		vw.increment("20.a");
	}
}
