package hr.fer.zemris.java.custom.scripting.exec;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class ValueWrapperDivideTest {

	private final double EPSILON = 10E-6;

	@Test(expected = IllegalArgumentException.class)
	public void divideNullAndNullThrownException() {

		ValueWrapper vw = new ValueWrapper(null);
		vw.divide(null);
	}

	@Test
	public void divideNullAndIntegerSuccess() {

		ValueWrapper vw = new ValueWrapper(null);
		vw.divide(Integer.valueOf(20));

		assertEquals("Object creation did not result in a proper value type.",
				true, (vw.getValue() instanceof Integer));
		assertEquals("Object creation did not result in a proper value.", 0,
				(Integer) vw.getValue(), EPSILON);
	}

	@Test
	public void divideNullAndDoubleSuccess() {

		ValueWrapper vw = new ValueWrapper(null);
		vw.divide(Double.valueOf(20));

		assertEquals("Object creation did not result in a proper value type.",
				true, (vw.getValue() instanceof Double));
		assertEquals("Object creation did not result in a proper value.", 0,
				(Double) vw.getValue(), EPSILON);
	}

	@Test
	public void divideNullAndIntegerStringSuccess() {

		ValueWrapper vw = new ValueWrapper(null);
		vw.divide("20");

		assertEquals("Object creation did not result in a proper value type.",
				true, (vw.getValue() instanceof Integer));
		assertEquals("Object creation did not result in a proper value.", 0,
				(Integer) vw.getValue(), EPSILON);
	}

	@Test
	public void divideNullAndDoubleStringSuccess() {

		ValueWrapper vw = new ValueWrapper(null);
		vw.divide("20.0");

		assertEquals("Object creation did not result in a proper value type.",
				true, (vw.getValue() instanceof Double));
		assertEquals("Object creation did not result in a proper value.", 0,
				(Double) vw.getValue(), EPSILON);
	}

	@Test
	public void divideIntegerAndDoubleSuccess() {

		ValueWrapper vw = new ValueWrapper(Integer.valueOf(32));
		vw.divide(Double.valueOf(20));

		assertEquals("Object creation did not result in a proper value type.",
				true, (vw.getValue() instanceof Double));
		assertEquals("Object creation did not result in a proper value.", 1.6,
				(Double) vw.getValue(), EPSILON);
	}

	@Test
	public void divideIntegerAndIntegerSuccess() {

		ValueWrapper vw = new ValueWrapper(Integer.valueOf(32));
		vw.divide(Integer.valueOf(20));

		assertEquals("Object creation did not result in a proper value type.",
				true, (vw.getValue() instanceof Integer));
		assertEquals("Object creation did not result in a proper value.", 1,
				(Integer) vw.getValue(), EPSILON);
	}

	@Test(expected = IllegalArgumentException.class)
	public void divideGivenInvalidTypeThrownException() {

		ValueWrapper vw = new ValueWrapper(Integer.valueOf(32));
		vw.divide(Long.valueOf(20));
	}
}
