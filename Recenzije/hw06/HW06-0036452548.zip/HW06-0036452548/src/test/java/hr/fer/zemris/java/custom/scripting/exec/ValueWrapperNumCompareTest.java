package hr.fer.zemris.java.custom.scripting.exec;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class ValueWrapperNumCompareTest {

	@Test
	public void numCompareNullAndNullSuccess() {

		ValueWrapper vw = new ValueWrapper(null);
		int result = vw.numCompare(null);

		assertEquals("Comparison of objects returned a wrong result.", true,
				(result == 0));
	}

	@Test
	public void numCompareNullAndIntegerSuccess() {

		ValueWrapper vw = new ValueWrapper(null);
		int result = vw.numCompare(Integer.valueOf(20));

		assertEquals("Comparison of objects returned a wrong result.", true,
				(result < 0));
	}

	@Test
	public void numCompareNullAndDoubleSuccess() {

		ValueWrapper vw = new ValueWrapper(Double.valueOf(20));
		int result = vw.numCompare(null);

		assertEquals("Comparison of objects returned a wrong result.", true,
				(result > 0));
	}

	@Test
	public void numCompareNullAndIntegerStringSuccess() {

		ValueWrapper vw = new ValueWrapper(null);
		int result = vw.numCompare("20");

		assertEquals("Comparison of objects returned a wrong result.", true,
				(result < 0));
	}

	@Test
	public void numCompareNullAndDoubleStringSuccess() {

		ValueWrapper vw = new ValueWrapper(null);
		int result = vw.numCompare("20.0");

		assertEquals("Comparison of objects returned a wrong result.", true,
				(result < 0));
	}

	@Test
	public void numCompareIntegerAndDoubleSuccess() {

		ValueWrapper vw = new ValueWrapper(Integer.valueOf(32));
		int result = vw.numCompare(Double.valueOf(20));

		assertEquals("Comparison of objects returned a wrong result.", true,
				(result > 0));
	}

	@Test
	public void numCompareIntegerAndIntegerSuccess() {

		ValueWrapper vw = new ValueWrapper(Integer.valueOf(-452));
		int result = vw.numCompare(Integer.valueOf(20));

		assertEquals("Comparison of objects returned a wrong result.", true,
				(result < 0));
	}

	@Test
	public void numCompareDoubleAndDoubleBothSameSuccess() {

		ValueWrapper vw = new ValueWrapper(Double.valueOf(20.45));
		int result = vw.numCompare(Double.valueOf(20.4500000004));

		assertEquals("Comparison of objects returned a wrong result.", true,
				(result == 0));
	}

	@Test
	public void numCompareDoubleAndDoubleOneGreaterSuccess() {

		ValueWrapper vw = new ValueWrapper(Double.valueOf(20.45));
		int result = vw.numCompare(Double.valueOf(20.5500000004));

		assertEquals("Comparison of objects returned a wrong result.", true,
				(result < 0));
	}

	@Test(expected = IllegalArgumentException.class)
	public void numCompareGivenInvalidTypeThrownException() {

		ValueWrapper vw = new ValueWrapper(Integer.valueOf(32));
		vw.numCompare(Long.valueOf(20));
	}
}
