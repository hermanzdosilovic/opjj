package hr.fer.zemris.java.custom.scripting.exec;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class ValueWrapperMultiplyTest {

	private final double EPSILON = 10E-6;

	@Test
	public void multiplyNullAndNullSuccess() {

		ValueWrapper vw = new ValueWrapper(null);
		vw.multiply(null);

		assertEquals("Object creation did not result in a proper value type.",
				true, (vw.getValue() instanceof Integer));
		assertEquals("Object creation did not result in a proper value.", 0,
				(Integer) vw.getValue(), EPSILON);
	}

	@Test
	public void multiplyNullAndIntegerSuccess() {

		ValueWrapper vw = new ValueWrapper(null);
		vw.multiply(Integer.valueOf(20));

		assertEquals("Object creation did not result in a proper value type.",
				true, (vw.getValue() instanceof Integer));
		assertEquals("Object creation did not result in a proper value.", 0,
				(Integer) vw.getValue(), EPSILON);
	}

	@Test
	public void multiplyNullAndDoubleSuccess() {

		ValueWrapper vw = new ValueWrapper(null);
		vw.multiply(Double.valueOf(20));

		assertEquals("Object creation did not result in a proper value type.",
				true, (vw.getValue() instanceof Double));
		assertEquals("Object creation did not result in a proper value.", 0,
				(Double) vw.getValue(), EPSILON);
	}

	@Test
	public void multiplyNullAndIntegerStringSuccess() {

		ValueWrapper vw = new ValueWrapper(null);
		vw.multiply("20");

		assertEquals("Object creation did not result in a proper value type.",
				true, (vw.getValue() instanceof Integer));
		assertEquals("Object creation did not result in a proper value.", 0,
				(Integer) vw.getValue(), EPSILON);
	}

	@Test
	public void multiplyNullAndDoubleStringSuccess() {

		ValueWrapper vw = new ValueWrapper(null);
		vw.multiply("20.0");

		assertEquals("Object creation did not result in a proper value type.",
				true, (vw.getValue() instanceof Double));
		assertEquals("Object creation did not result in a proper value.", 0,
				(Double) vw.getValue(), EPSILON);
	}

	@Test
	public void multiplyIntegerAndDoubleSuccess() {

		ValueWrapper vw = new ValueWrapper(Integer.valueOf(32));
		vw.multiply(Double.valueOf(20.8));

		assertEquals("Object creation did not result in a proper value type.",
				true, (vw.getValue() instanceof Double));
		assertEquals("Object creation did not result in a proper value.",
				665.6, (Double) vw.getValue(), EPSILON);
	}

	@Test
	public void multiplyIntegerAndIntegerSuccess() {

		ValueWrapper vw = new ValueWrapper(Integer.valueOf(32));
		vw.multiply(Integer.valueOf(20));

		assertEquals("Object creation did not result in a proper value type.",
				true, (vw.getValue() instanceof Integer));
		assertEquals("Object creation did not result in a proper value.", 640,
				(Integer) vw.getValue(), EPSILON);
	}

	@Test(expected = IllegalArgumentException.class)
	public void multiplyGivenInvalidTypeThrownException() {

		ValueWrapper vw = new ValueWrapper(Integer.valueOf(32));
		vw.multiply(Long.valueOf(20));
	}
}
