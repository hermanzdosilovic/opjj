package hr.fer.zemris.java.tecaj.hw6.shell;

import java.io.BufferedReader;
import java.io.BufferedWriter;

/**
 * Implementation of <code>ShellCommand</code>. This command represents an
 * 'exit' command which terminates the shell.
 * 
 * @author Domagoj Alagić
 * 
 */
public class ShellCommandExit implements ShellCommand {

	/**
	 * {@inheritDoc}
	 * 
	 * @throws <code>ShellCommandException</code> Thrown if there is a wrong
	 *         number of arguments (0 expected).
	 */
	@Override
	public ShellStatus executeCommand(BufferedReader in, BufferedWriter out,
			String[] arguments) {

		if (arguments.length != 0) {
			throw new ShellCommandException(
					"Invalid number of arguments: expected 0, was "
							+ arguments.length);
		}

		return ShellStatus.TERMINATE;
	}

}
