package hr.fer.zemris.java.tecaj.hw6.shell;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;

/**
 * Interface which defines what every <code>MyShell</code> command must
 * implement.
 * 
 * @author Domagoj Alagić
 * 
 */
public interface ShellCommand {

	/**
	 * Executes the command while accepting input and writing output to the
	 * given streams. Arguments are provided also.
	 * 
	 * @param in
	 *            Input stream.
	 * @param out
	 *            Output stream.
	 * @param arguments
	 *            User arguments.
	 * @return Shell status.
	 * @throws IOException
	 */
	public ShellStatus executeCommand(BufferedReader in, BufferedWriter out,
			String[] arguments) throws IOException;

}
