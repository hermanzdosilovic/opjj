package hr.fer.zemris.java.tecaj.hw6.shell;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

/**
 * Implementation of <code>ShellCommand</code>. This command represents an
 * 'hexdump' command which prints out the hexdump of the given file.
 * 
 * @author Domagoj Alagić
 * 
 */
public class ShellCommandHexDump implements ShellCommand {

	/**
	 * {@inheritDoc}
	 * 
	 * @throws <code>ShellCommandException</code> Thrown if there is a wrong
	 *         number of arguments (0 expected). Also if the given file does not
	 *         represent a file and if something went wrong in reading of the
	 *         giving file.
	 */
	@Override
	public ShellStatus executeCommand(BufferedReader in, BufferedWriter out,
			String[] arguments) throws IOException {

		if (arguments.length != 1) {
			throw new ShellCommandException(
					"Invalid number of arguments: expected 1, was "
							+ arguments.length);
		}

		File file = new File(arguments[0]);

		if (!file.isFile()) {
			throw new ShellCommandException(
					"Source path does not represent a file.");
		}

		try (BufferedInputStream inputStream = new BufferedInputStream(
				new FileInputStream(file));) {

			int lineCounter = 0;
			int byteCounter = 0;

			
			final int NUM_OF_BYTES_PER_LINE = 16;
			final int NUM_OF_BYTES_PER_LINE_HALF = NUM_OF_BYTES_PER_LINE/2;
			final int LOWER_BOUNDARY_BYTE_VALID = 32;
			final int UPPER_BOUNDARY_BYTE_VALID = 127;
			
			StringBuilder byteString = new StringBuilder();
			StringBuilder asciiString = new StringBuilder();

			int inputByte;
			while ((inputByte = inputStream.read()) != -1) {

				// beginning of the line, print memory address
				if (byteCounter == 0) {
					out.write(String.format("%08X: ", lineCounter * 16));
				}

				// byte was read, increase the counter
				byteCounter++;

				// write byte
				byteString.append(String.format("%02X", inputByte));

				// if we've reached the 8th byte, add a pipe
				if (byteCounter == NUM_OF_BYTES_PER_LINE_HALF) {
					byteString.append("|");
				} else {
					byteString.append(" ");
				}

				// store ascii representation of the current byte, replace
				// "weird" chars with '.'
				if (inputByte < LOWER_BOUNDARY_BYTE_VALID || inputByte > UPPER_BOUNDARY_BYTE_VALID) {
					asciiString.append(".");
				} else {
					asciiString.append((char) inputByte);
				}

				// we have hit the end, add pipe and print ascii
				if (byteCounter == NUM_OF_BYTES_PER_LINE) {

					out.write(byteString.toString());
					out.write(String.format("| %s%n", asciiString.toString()));

					// reset counters
					byteCounter = 0;
					lineCounter++;
					// reset string builders
					byteString.setLength(0);
					asciiString.setLength(0);
				}
			}
			// last parts are <16 bytes, need to pad with spaces
			out.write(String.format("%1$-48s", byteString.toString()));
			out.write(String.format("| %s%n", asciiString.toString()));

		} catch (IOException ex) {
			throw new ShellCommandException(
					"hexdump command was not successfully executed.");
		}

		out.flush();

		return ShellStatus.CONTINUE;
	}

}
