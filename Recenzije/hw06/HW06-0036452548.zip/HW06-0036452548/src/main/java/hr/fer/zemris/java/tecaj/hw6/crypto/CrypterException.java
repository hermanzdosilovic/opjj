package hr.fer.zemris.java.tecaj.hw6.crypto;

/**
 * Exception which encapsulates all the possible errors in <code>Crypter</code>.
 * 
 * @author Domagoj Alagić
 */
public class CrypterException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5835844771810050138L;

	/**
	 * Constructs a <code>CrypterException</code>.
	 */
	public CrypterException() {
		super();
	}

	/**
	 * Constructs a <code>CrypterException</code> with the given message and
	 * cause.
	 * 
	 * @param message
	 *            User message.
	 * @param cause
	 *            Error throwable.
	 */
	public CrypterException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * Constructs a <code>CrypterException</code> with the given message.
	 * 
	 * @param message
	 *            User message.
	 */
	public CrypterException(String message) {
		super(message);
	}

}
