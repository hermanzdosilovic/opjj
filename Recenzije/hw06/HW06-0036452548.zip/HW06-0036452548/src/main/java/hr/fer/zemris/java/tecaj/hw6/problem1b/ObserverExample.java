package hr.fer.zemris.java.tecaj.hw6.problem1b;

import hr.fer.zemris.java.tecaj.hw6.problem1a.ChangeCounter;
import hr.fer.zemris.java.tecaj.hw6.problem1a.DoubleValue;
import hr.fer.zemris.java.tecaj.hw6.problem1a.IntegerStorage;
import hr.fer.zemris.java.tecaj.hw6.problem1a.IntegerStorageObserver;
import hr.fer.zemris.java.tecaj.hw6.problem1a.LogValue;
import hr.fer.zemris.java.tecaj.hw6.problem1a.SquareValue;

import java.nio.file.Paths;

public class ObserverExample {

	public static void main(String[] args) {
		/*
		
		IntegerStorage istorage = new IntegerStorage(20);
		IntegerStorageObserver observer = new SquareValue();
		istorage.addObserver(observer);
		istorage.addObserver(new ChangeCounter());
		istorage.addObserver(new DoubleValue());
		istorage.addObserver(new LogValue(Paths.get("./log.txt")));
		istorage.setValue(5);
		istorage.setValue(2);
		istorage.setValue(25);
		//istorage.removeObserver(observer);
		istorage.setValue(13);
		istorage.setValue(22);
		istorage.setValue(15);*/
		
		IntegerStorage istorage = new IntegerStorage(20);
		  IntegerStorageObserver observer = new SquareValue();
		  istorage.addObserver(new LogValue(Paths.get("./log3.txt")));
		  istorage.addObserver(new ChangeCounter());
		  istorage.addObserver(new DoubleValue());
		  istorage.addObserver(observer);
		  istorage.setValue(5);
		  istorage.setValue(2);
		  istorage.setValue(25);
		  // istorage.removeObserver(observer);
		  istorage.setValue(13);
		  istorage.setValue(22);
		  istorage.setValue(15);
	}
}
