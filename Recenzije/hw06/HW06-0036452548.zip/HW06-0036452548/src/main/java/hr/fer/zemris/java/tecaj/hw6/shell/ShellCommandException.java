package hr.fer.zemris.java.tecaj.hw6.shell;

/**
 * Exception used in denoting handled errors in <code>MyShell</code> commands.
 * 
 * @author Domagoj Alagić
 * 
 */
public class ShellCommandException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6761965472869030098L;

	/**
	 * Constructs a <code>ShellCommandException</code>.
	 */
	public ShellCommandException() {
		super();
	}

	/**
	 * Constructs a <code>ShellCommandException</code> with the given user
	 * message.
	 * 
	 * @param message
	 *            User message.
	 */
	public ShellCommandException(String message) {
		super(message);
	}

}
