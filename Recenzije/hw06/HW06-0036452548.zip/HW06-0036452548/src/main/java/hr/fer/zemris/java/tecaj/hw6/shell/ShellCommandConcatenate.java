package hr.fer.zemris.java.tecaj.hw6.shell;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.UnsupportedCharsetException;

/**
 * Implementation of <code>ShellCommand</code>. This command represents an 'cat'
 * command which displays the content of the given file.
 * 
 * @author Domagoj Alagić
 * 
 */
public class ShellCommandConcatenate implements ShellCommand {

	/**
	 * {@inheritDoc}
	 * 
	 * @throws <code>ShellCommandException</code> Thrown if there is a wrong
	 *         number of arguments (1 or 2 expected). Also thrown if the invalid
	 *         charset is given. Thrown if the given file couldn't be found.
	 *         Finally, it is thrown if something went wrong with the IO.
	 */
	@Override
	public ShellStatus executeCommand(BufferedReader in, BufferedWriter out,
			String[] arguments) throws IOException {

		Charset charset = null;

		if (arguments.length == 1) {

			charset = Charset.defaultCharset();

		} else if (arguments.length == 2) {
			try {
				charset = Charset.forName(arguments[1]);
			} catch (UnsupportedCharsetException e) {
				throw new ShellCommandException("Unsupported charset given.");
			}
		} else {
			throw new ShellCommandException(
					"Invalid number of arguments: expected 1 or 2, was "
							+ arguments.length);
		}

		final int BUFFER_SIZE = 4096;

		try {
			BufferedInputStream inputFile = new BufferedInputStream(
					new FileInputStream(new File(arguments[0])));

			byte[] buffer = new byte[BUFFER_SIZE];
			while (true) {
				int numOfReadBytes = inputFile.read(buffer);
				if (numOfReadBytes < 1) {
					break;
				}

				out.write(new String(buffer, 0, numOfReadBytes, charset));
			}
			inputFile.close();

		} catch (FileNotFoundException e) {
			throw new ShellCommandException(
					"The given file could not be found.");
		} catch (IOException e) {
			throw new ShellCommandException(
					"cat command was not successfully executed.");
		}

		out.flush();

		return ShellStatus.CONTINUE;
	}

}
