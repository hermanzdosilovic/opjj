package hr.fer.zemris.java.tecaj.hw6.shell;

/**
 * Enumeration which holds <code>MyShell</code> status.
 * 
 * @author Domagoj Alagić
 * 
 */
public enum ShellStatus {

	CONTINUE, TERMINATE;
}
