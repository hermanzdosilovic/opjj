package hr.fer.zemris.java.tecaj.hw6.shell;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.Charset;
import java.util.Map;

/**
 * Implementation of <code>ShellCommand</code>. This command represents an
 * 'charsets' command which lists all the currently available charsets.
 * 
 * @author Domagoj Alagić
 * 
 */
public class ShellCommandCharsets implements ShellCommand {

	/**
	 * {@inheritDoc}
	 * 
	 * @throws IOException
	 * 
	 * @throws <code>ShellCommandException</code> Thrown if there is a wrong
	 *         number of arguments (0 expected).
	 */
	@Override
	public ShellStatus executeCommand(BufferedReader in, BufferedWriter out,
			String[] arguments) throws IOException {

		if (arguments.length != 0) {
			throw new ShellCommandException(
					"Invalid number of arguments: expected 0, was "
							+ arguments.length);
		}

		Map<String, Charset> charsets = Charset.availableCharsets();

		for (String charsetName : charsets.keySet()) {

			out.write(String.format("%s%n", charsetName));
		}

		out.flush();

		return ShellStatus.CONTINUE;
	}

}
