package hr.fer.zemris.java.tecaj.hw6.shell;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

/**
 * Implementation of <code>ShellCommand</code>. This command represents an
 * 'copy' command which copies the given file to another location.
 * 
 * @author Domagoj Alagić
 * 
 */
public class ShellCommandCopy implements ShellCommand {

	/**
	 * {@inheritDoc}
	 * 
	 * @throws <code>ShellCommandException</code> Thrown if there is a wrong
	 *         number of arguments (2 expected). Also thrown if the source path
	 *         does not represent a file. Finally, it is thrown if something
	 *         went wrong with the IO.
	 */
	@Override
	public ShellStatus executeCommand(BufferedReader in, BufferedWriter out,
			String[] arguments) throws IOException {

		if (arguments.length != 2) {
			throw new ShellCommandException(
					"Invalid number of arguments: expected 2, was "
							+ arguments.length);
		}

		File source = new File(arguments[0]);
		File destination = new File(arguments[1]);

		if (!source.isFile()) {
			throw new ShellCommandException(
					"Source path does not represent a file.");
		}

		if (destination.isDirectory()) {
			destination = new File(destination, source.getName());
		}

		if (destination.exists()) {
			out.write("Destination file already exists. Do you want to overwrite it? (Y/N): ");
			out.flush();

			String input = in.readLine();

			if (input == null) {
				throw new ShellCommandException(
						"copy command was not successfully executed.");
			}

			if (!input.equals("Y")) {
				return ShellStatus.CONTINUE;
			}
		}

		final int BUFFER_SIZE = 4096;
		
		try (BufferedInputStream inputStream = new BufferedInputStream(
				new FileInputStream(source));
				BufferedOutputStream outputStream = new BufferedOutputStream(
						new FileOutputStream(destination));) {

			byte[] buffer = new byte[BUFFER_SIZE];
			while (true) {
				int numOfReadBytes = inputStream.read(buffer);
				if (numOfReadBytes < 1) {
					break;
				}

				outputStream.write(buffer, 0, numOfReadBytes);
			}
		} catch (IOException ex) {
			throw new ShellCommandException(
					"copy command was not successfully executed.");
		}

		return ShellStatus.CONTINUE;
	}

}
