package hr.fer.zemris.java.tecaj.hw6.crypto;

import java.util.Scanner;

/**
 * Class which offers functionalities of encryption, decryption and calculating
 * of hash.
 * 
 * @author Domagoj Alagić
 * 
 */
public class Crypto {

	/**
	 * Main entry.
	 * 
	 * @param args
	 *            Array of arguments. At least two of them should be present -
	 *            command name and file path. If the encryption or decryption
	 *            tool is used, a destination path should also be presented.
	 */
	public static void main(String[] args) {

		if (args.length < 2) {
			System.err
					.println("At least two params should be presented - command and file path.");
			System.exit(-1);
		}

		Scanner scanner = new Scanner(System.in, "UTF-8");

		// check what command was entered
		try {
			if (args[0].equalsIgnoreCase("encrypt")
					|| args[0].equalsIgnoreCase("decrypt")) {

				if (args.length < 3) {
					System.err
							.println("At least three params should be presented - command, input file path and output file path.");
					System.exit(-1);
				}

				System.out
						.println("Please provide password as hex-encoded text (16 bytes, i.e. 32 hex-digits):");

				String password = scanner.nextLine().trim();

				System.out
						.println("Please provide initialization vector as hex-encoded text (32 hex-digits):");

				String ivector = scanner.nextLine().trim();

				try {
					Crypter crypter = new Crypter(args[1]);

					if (args[0].equalsIgnoreCase("encrypt")) {
						crypter.encrypt(password, ivector, args[2]);
						System.out.print("Encryption complete. ");
					} else {
						crypter.decrypt(password, ivector, args[2]);
						System.out.print("Decryption complete. ");
					}

					System.out.println("Generated file " + args[2]
							+ " based on file " + args[1] + ".");

				} catch (IllegalArgumentException | CrypterException e) {

					System.err.println("Error occured: " + e.getMessage());
				}

			} else if (args[0].equalsIgnoreCase("checksha")) {

				System.out.println("Please provide expected sha signature for "
						+ args[1] + ":");
				String expectedHash = scanner.nextLine().trim();

				HashCalculator hashCalc = null;
				boolean isSame = false;

				try {
					hashCalc = new HashCalculator(args[1]);

					isSame = hashCalc.isSameAsHashString(expectedHash);

				} catch (IllegalArgumentException | CrypterException e) {

					System.err.println("Error occured: " + e.getMessage());
				}

				System.out.print("Digesting completed. Digest of " + args[1]
						+ " ");

				if (isSame) {
					System.out.println("matches expected digest.");
				} else {
					System.out
							.println("does not match the expected digest. Digest was: "
									+ hashCalc.getHashString());
				}
			}
		} catch (Exception e) {
			System.err.println("Something went wrong. " + e.getMessage());
		}

		scanner.close();
	}

}
