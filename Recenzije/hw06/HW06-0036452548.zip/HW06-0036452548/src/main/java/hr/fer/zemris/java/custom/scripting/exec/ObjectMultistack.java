package hr.fer.zemris.java.custom.scripting.exec;

import java.util.HashMap;
import java.util.Map;

/**
 * Special kind of Map which offers a functionality of storing multiple values
 * for the same key, in a stack-like manner.
 * 
 * @author Domagoj Alagić
 * 
 */
public class ObjectMultistack {

	/**
	 * Inner map used for mapping between keys and stacks.
	 */
	private Map<String, MultistackEntry> map = new HashMap<>();

	/**
	 * Pushes the given <code>ValueWrapper</code> object to the stack stored
	 * under the given key.
	 * 
	 * @param name
	 *            Key under which the value will be stored on a stack. Must not
	 *            be null or empty.
	 * @param valueWrapper
	 *            Value to store. Must not be null.
	 * 
	 * @throws <code>IllegalArgumentException</code> Thrown if one of the
	 *         following occurs: name is empty, name is null, value is null
	 */
	public void push(String name, ValueWrapper valueWrapper) {

		if (name == null || name.trim().isEmpty()) {
			throw new IllegalArgumentException(
					"The given name must not be null or empty.");
		}

		if (valueWrapper == null) {
			throw new IllegalArgumentException(
					"The given value must not be null.");
		}

		MultistackEntry newEntry = new MultistackEntry();
		newEntry.value = valueWrapper;

		if (map.containsKey(name)) {
			newEntry.next = map.get(name);
		}

		map.put(name, newEntry);

	}

	/**
	 * Returns the last <code>ValueWrapper</code> (and also deletes it) from the
	 * stack stored under the given key.
	 * 
	 * @param name
	 *            Name of a stack from which is needed to pop the last element.
	 * @return Last element from the stack stored under the given key.
	 * 
	 * @throws <code>IndexOutOfBoundsException</code> Thrown if the stack with
	 *         the given name is empty. <code>IllegalArgumentException</code>
	 *         Thrown if the given name is null.
	 */
	public ValueWrapper pop(String name) {

		if (name == null) {
			throw new IllegalArgumentException(
					"The given name must not be null.");
		}

		if (map.containsKey(name)) {

			ValueWrapper returnValue = map.get(name).value;

			// remove the entry from the map if the stack is empty
			if (map.get(name).next != null) {
				map.put(name, map.get(name).next);
			} else {
				map.remove(name);
			}

			return returnValue;

		} else {

			throw new IndexOutOfBoundsException(
					"Stack with the given name is empty.");
		}

	}

	/**
	 * Returns the last <code>ValueWrapper</code> from the stack stored under
	 * the given key.
	 * 
	 * @param name
	 *            Name of a stack from which we want to get the last element.
	 * @return Last element from the stack stored under the given key.
	 * 
	 * @throws <code>IndexOutOfBoundsException</code> Thrown if the stack with
	 *         the given name is empty. <code>IllegalArgumentException</code>
	 *         Thrown if the given name is null.
	 */
	public ValueWrapper peek(String name) {

		if (name == null) {
			throw new IllegalArgumentException(
					"The given name must not be null.");
		}

		if (map.containsKey(name)) {

			return map.get(name).value;

		} else {

			throw new IndexOutOfBoundsException(
					"Stack with the given name is empty.");
		}
	}

	/**
	 * Checks whether the stack under the given name is empty.
	 * 
	 * @param name
	 *            Name of the stack to check.
	 * @return <code>true</code> if the stack under the given name is empty,
	 *         <code>false</code> otherwise.
	 * 
	 * @throws <code>IllegalArgumentException</code> Thrown if the given name is
	 *         null.
	 */
	public boolean isEmpty(String name) {

		if (name == null) {
			throw new IllegalArgumentException(
					"The given name must not be null.");
		}

		return (!map.containsKey(name));
	}

	/**
	 * Implementation of stack as a simple single-linked list.
	 * 
	 * @author Domagoj Alagić
	 * 
	 */
	public static class MultistackEntry {

		/**
		 * Current value.
		 */
		private ValueWrapper value;

		/**
		 * Next element in the list.
		 */
		private MultistackEntry next;

	}
}
