package hr.fer.zemris.java.tecaj.hw6.shell;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.IOException;
import java.nio.file.FileVisitResult;
import java.nio.file.FileVisitor;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.attribute.BasicFileAttributes;

/**
 * Implementation of <code>ShellCommand</code>. This command represents an
 * 'tree' command which recursively lists the given directory's children.
 * 
 * @author Domagoj Alagić
 * 
 */
public class ShellCommandTree implements ShellCommand {

	/**
	 * {@inheritDoc}
	 * 
	 * @throws <code>ShellCommandException</code> Thrown if there is a wrong
	 *         number of arguments (1 expected) or if provided path does not
	 *         represent a directory. Finally, it is thrown if something went
	 *         wrong with the IO.
	 */
	@Override
	public ShellStatus executeCommand(BufferedReader in, BufferedWriter out,
			String[] arguments) throws IOException {

		if (arguments.length != 1) {
			throw new ShellCommandException(
					"Invalid number of arguments: expected 1, was "
							+ arguments.length);
		}

		File file = new File(arguments[0]);

		if (!file.isDirectory()) {
			throw new ShellCommandException(
					"Source path does not represent a directory.");
		}

		// create a file visitor
		FileVisitor<Path> visitor = new Visitor(out);
		try {
			Files.walkFileTree(file.toPath(), visitor);
		} catch (IOException e) {
			throw new ShellCommandException(
					"tree command was not successfully executed.");
		}

		out.flush();

		return ShellStatus.CONTINUE;
	}

	/**
	 * Simple <code>FileVisitor</code> which traverses the directory structure
	 * and prints all files and directories in a structured manner.
	 * 
	 * @author Domagoj Alagić
	 * 
	 */
	private static class Visitor implements FileVisitor<Path> {

		/**
		 * Indent to use.
		 */
		private int indent = 0;

		/**
		 * Stream to print to.
		 */
		private BufferedWriter output;

		/**
		 * Constructs a <code>Visitor</code> with the given output stream.
		 * 
		 * @param output
		 *            Output stream to print to.
		 * 
		 * @throws <code>IllegalArgumentException</code> Thrown if the given
		 *         stream is null.
		 */
		public Visitor(BufferedWriter output) {

			if (output == null) {
				throw new IllegalArgumentException(
						"Given stream cannot be null.");
			}

			this.output = output;
		}

		/**
		 * {@inheritDoc}
		 */
		@Override
		public FileVisitResult preVisitDirectory(Path dir,
				BasicFileAttributes attrs) throws IOException {
			if (indent == 0) {
				dir.toString();
			} else {
				output.write(String.format("%" + indent + "s%s%n", "",
						dir.getName(dir.getNameCount() - 1)));
			}

			indent += 2;

			return FileVisitResult.CONTINUE;
		}

		/**
		 * {@inheritDoc}
		 */
		@Override
		public FileVisitResult visitFile(Path file, BasicFileAttributes attrs)
				throws IOException {
			output.write(String.format("%" + indent + "s%s%n", "",
					file.getName(file.getNameCount() - 1)));
			return FileVisitResult.CONTINUE;
		}

		/**
		 * {@inheritDoc}
		 */
		@Override
		public FileVisitResult visitFileFailed(Path file, IOException exc)
				throws IOException {
			indent -= 2;
			return FileVisitResult.CONTINUE;
		}

		/**
		 * {@inheritDoc}
		 */
		@Override
		public FileVisitResult postVisitDirectory(Path dir, IOException exc)
				throws IOException {
			indent -= 2;
			return FileVisitResult.CONTINUE;
		}

	}
}
