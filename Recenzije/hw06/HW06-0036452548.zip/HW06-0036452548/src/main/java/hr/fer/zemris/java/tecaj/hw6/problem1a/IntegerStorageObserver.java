package hr.fer.zemris.java.tecaj.hw6.problem1a;


/**
 * An interface which servers as an Observer interface. All classes which want to
 * become an observer of the <code>IntegerStorage</code> must implement this interface.
 * 
 * @author Domagoj Alagić
 *
 */
public interface IntegerStorageObserver {
	
	/**
	 * Method which signals that the current integer value (in the integer storage) has changed.
	 * 
	 * @param intStorage Instance of the changed integer storage.
	 */
	public void valueChanged(IntegerStorage intStorage);
}
