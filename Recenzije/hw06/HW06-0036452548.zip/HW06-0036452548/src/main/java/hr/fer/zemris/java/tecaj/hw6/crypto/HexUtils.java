package hr.fer.zemris.java.tecaj.hw6.crypto;

/**
 * Class which serves utility methods for conversion between byte arrays and hex
 * strings.
 * 
 * @author Domagoj Alagić
 * 
 */
public class HexUtils {

	/**
	 * Converts the given hex string to a byte array.
	 * 
	 * @param hexString
	 *            Hex string to convert.
	 * @return Byte array which represents the given hex string.
	 */
	public static byte[] fromHexStringToBytes(String hexString) {

		int length = hexString.length();
		byte[] bytes = new byte[length / 2];

		for (int i = 0; i < length; i += 2) {
			bytes[i / 2] = (byte) ((Character.digit(hexString.charAt(i), 16) << 4) + Character
					.digit(hexString.charAt(i + 1), 16));
		}

		return bytes;
	}

	/**
	 * Converts the given byte array to a hex string.
	 * 
	 * @param bytes
	 *            Byte array to convert.
	 * @return Hex string which represents the given byte array.
	 */
	public static String fromBytesToHexString(byte[] bytes) {

		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < bytes.length; i++) {
			sb.append(String.format("%02X", bytes[i]));
		}
		return sb.toString();
	}

}
