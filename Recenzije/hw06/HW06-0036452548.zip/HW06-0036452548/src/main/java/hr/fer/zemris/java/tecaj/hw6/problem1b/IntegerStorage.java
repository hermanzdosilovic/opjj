package hr.fer.zemris.java.tecaj.hw6.problem1b;

import hr.fer.zemris.java.tecaj.hw6.problem1b.IntegerStorageObserver;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * Class representing an integer storage. This storage acts as a Subject in the
 * Observer pattern.
 * 
 * @author Domagoj Alagić
 * 
 */
public class IntegerStorage {

	/**
	 * Current integer value.
	 */
	private int value;

	/**
	 * List of observers which need to be notified when the current value change
	 * occurs.
	 */
	private List<IntegerStorageObserver> observers = new ArrayList<>();

	/**
	 * Constructs a <code>IntegerStorage</code> with the given initial value.
	 * 
	 * @param initialValue
	 *            Initial integer value of the storage.
	 */
	public IntegerStorage(int initialValue) {
		this.value = initialValue;
	}

	/**
	 * Adds an observer which monitors this object's state (current integer
	 * value).
	 * 
	 * @param observer
	 *            Observer to add. Must not be null.
	 * 
	 * @throws <code>IllegalArgumentException</code> Thrown if the given
	 *         observer is null.
	 */
	public void addObserver(IntegerStorageObserver observer) {

		if (observer == null) {
			throw new IllegalArgumentException("Observer must not be null.");
		}

		// add the observer in observers if it is not already there
		if (!observers.contains(observer)) {
			observers.add(observer);
		}
	}

	/**
	 * Removes the given observer from the list of this object's observers. If
	 * the given observer is not in the list of this object's observers, this
	 * method does nothing.
	 * 
	 * @param observer
	 *            Observer to remove.
	 * 
	 * @throws <code>IllegalArgumentException</code> Thrown if the given
	 *         observer is null.
	 */
	public void removeObserver(IntegerStorageObserver observer) {

		if (observer == null) {
			throw new IllegalArgumentException("Given observer cannot be null.");
		}

		// remove the observer from observers if present
		if (observers.contains(observer)) {
			observers.remove(observer);
		}
	}

	/**
	 * Removes all the observers from this object's observer list.
	 */
	public void clearObservers() {

		observers.clear();
	}

	/**
	 * Gets the current integer value.
	 * 
	 * @return Current integer value.
	 */
	public int getValue() {
		return value;
	}

	/**
	 * Sets the current integer value.
	 * 
	 * @param value
	 *            A new integer value to set.
	 */
	public void setValue(int value) {
		// Only if new value is different than the current value:
		if (this.value != value) {

			IntegerStorageChange change = new IntegerStorageChange(this,
					this.value, value);

			// Update current value
			this.value = value;
			// Notify all registered observers
			if (observers != null) {

				CopyOnWriteArrayList<IntegerStorageObserver> observersList = new CopyOnWriteArrayList<>(
						observers);
				for (IntegerStorageObserver observer : observersList) {
					observer.valueChanged(change);
				}
			}
		}
	}
}
