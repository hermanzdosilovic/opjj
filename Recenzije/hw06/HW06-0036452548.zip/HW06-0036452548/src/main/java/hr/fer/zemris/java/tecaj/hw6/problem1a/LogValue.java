package hr.fer.zemris.java.tecaj.hw6.problem1a;

import java.io.BufferedOutputStream;
import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.nio.file.Path;

/**
 * Class which is a concrete implementation of
 * <code>IntegerStorageObserver</code> so it offers a certain action on
 * <code>valueChanged</code>.
 * 
 * This class stores all the current integer value changes in the integer
 * storage. Those changes are logged to the path denoted by the constructor
 * argument.
 * 
 * @author Domagoj Alagić
 * 
 */
public class LogValue implements IntegerStorageObserver {

	/**
	 * Log path.
	 */
	private Path logPath;

	/**
	 * Constructs a <code>LogValue</code> with the given log path.
	 * 
	 * @param path
	 *            Path to log the changes to. Must not be null.
	 * 
	 * @throws <code>IllegalArgumentException</code> Thrown if the given path is
	 *         null or if the given path does not represent a file.
	 */
	public LogValue(Path logPath) {

		if (logPath == null) {
			throw new IllegalArgumentException(
					"The given path must not be null.");
		}

		if (!logPath.toFile().isFile()) {
			throw new IllegalArgumentException(
					"The given path must represent file.");
		}

		this.logPath = logPath;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @throws <code>IllegalArgumentException</code> Thrown if the given
	 *         intStorage is null.
	 * @throws <code>LogException</code> Thrown in case of log IO errors.
	 */
	@Override
	public void valueChanged(IntegerStorage intStorage) {

		if (intStorage == null) {
			throw new IllegalArgumentException(
					"Integer storage must not be null.");
		}

		writeValueToFile(intStorage.getValue());
	}

	/**
	 * Stores the given value to the log defined by the <code>logPath</code>
	 * member.
	 * 
	 * @param value
	 *            Value to store.
	 * @throws <code>LogException</code> Thrown in case of log IO errors.
	 */
	private void writeValueToFile(int value) {

		try (Writer writer = new BufferedWriter(new OutputStreamWriter(
				new BufferedOutputStream(new FileOutputStream(logPath.toFile(),
						true)), "UTF-8"))) {

			String line = String.valueOf(value);
			writer.append(String.format("%s%n", line));

		} catch (IOException e) {
			throw new LogException("Log could not be saved.", e);
		}
	}
}
