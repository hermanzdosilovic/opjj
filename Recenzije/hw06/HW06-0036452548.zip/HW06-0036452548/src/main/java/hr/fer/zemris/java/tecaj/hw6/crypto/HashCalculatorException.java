package hr.fer.zemris.java.tecaj.hw6.crypto;

/**
 * Exception which encapsulates all the possible errors in
 * <code>HashCalculator</code>.
 * 
 * @author Domagoj Alagić
 * 
 */
public class HashCalculatorException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7193487707726496166L;

	/**
	 * Constructs a <code>HashCalculatorException</code>.
	 */
	public HashCalculatorException() {
		super();
	}

	/**
	 * Constructs a <code>HashCalculatorException</code> with the given message
	 * and cause.
	 * 
	 * @param message
	 *            User message.
	 * @param cause
	 *            Error throwable.
	 */
	public HashCalculatorException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * Constructs a <code>HashCalculatorException</code> with the given message.
	 * 
	 * @param message
	 *            User message.
	 */
	public HashCalculatorException(String message) {
		super(message);
	}
}
