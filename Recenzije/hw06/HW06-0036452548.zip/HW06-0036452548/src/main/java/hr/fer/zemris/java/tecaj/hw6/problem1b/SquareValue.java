package hr.fer.zemris.java.tecaj.hw6.problem1b;

/**
 * Class which is a concrete implementation of
 * <code>IntegerStorageObserver</code> so it offers a certain action on
 * <code>valueChanged</code>.
 * 
 * This class prints out square of the current integer value in the integer
 * storage.
 * 
 * @author Domagoj Alagić
 * 
 */
public class SquareValue implements IntegerStorageObserver {

	/**
	 * {@inheritDoc}
	 * 
	 * @throws <code>IllegalArgumentException</code> Thrown if the given
	 *         intStorageChange is null.
	 */
	@Override
	public void valueChanged(IntegerStorageChange intStorageChange) {

		if (intStorageChange == null) {
			throw new IllegalArgumentException(
					"Integer storage change must not be null.");
		}

		System.out.println("Provided new value: " + intStorageChange.getNewValue()
				+ ", square is " + (int)Math.pow(intStorageChange.getNewValue(), 2));
	}

}
