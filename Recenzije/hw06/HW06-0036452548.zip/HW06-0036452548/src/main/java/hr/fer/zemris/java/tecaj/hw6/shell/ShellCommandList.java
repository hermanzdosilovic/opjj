package hr.fer.zemris.java.tecaj.hw6.shell;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.attribute.BasicFileAttributeView;
import java.nio.file.attribute.BasicFileAttributes;
import java.nio.file.attribute.FileTime;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Implementation of <code>ShellCommand</code>. This command represents an 'ls'
 * command which lists all the files in the given directory along with some of
 * their attributes.
 * 
 * @author Domagoj Alagić
 * 
 */
public class ShellCommandList implements ShellCommand {

	/**
	 * {@inheritDoc}
	 * 
	 * @throws <code>ShellCommandException</code> Thrown if there is a wrong
	 *         number of arguments (1 expected). Also thrown if the source path
	 *         does not represent a directory. Finally, it is thrown if
	 *         something went wrong with the IO.
	 */
	@Override
	public ShellStatus executeCommand(BufferedReader in, BufferedWriter out,
			String[] arguments) throws IOException {

		if (arguments.length != 1) {
			throw new ShellCommandException(
					"Invalid number of arguments: expected 1, was "
							+ arguments.length);
		}

		File dir = new File(arguments[0]);

		if (!dir.isDirectory()) {
			throw new ShellCommandException(
					"Source path does not represent a directory.");
		}

		File[] files = dir.listFiles();

		try {

			for (File singleFile : files) {
				out.write(String.format("%s%n", getFileDescription(singleFile)));
			}

		} catch (IOException e) {
			throw new ShellCommandException(
					"ls command was not successfully executed.");
		}

		out.flush();

		return ShellStatus.CONTINUE;
	}

	/**
	 * Gets a description of the given file in form: attributes size
	 * creation_time name
	 * 
	 * @param file
	 *            File to get the description of.
	 * @return File description.
	 * @throws IOException
	 */
	private String getFileDescription(File file) throws IOException {

		// rough estimate (line length)
		StringBuilder description = new StringBuilder(60);

		if (file.isDirectory()) {
			description.append("d");
		} else {
			description.append("-");
		}

		if (file.canRead()) {
			description.append("r");
		} else {
			description.append("-");
		}

		if (file.canWrite()) {
			description.append("w");
		} else {
			description.append("-");
		}

		if (file.canExecute()) {
			description.append("x");
		} else {
			description.append("-");
		}

		description.append(String.format(" %10s ", file.length()));

		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		BasicFileAttributeView faView = Files.getFileAttributeView(
				file.toPath(), BasicFileAttributeView.class,
				LinkOption.NOFOLLOW_LINKS);
		BasicFileAttributes attributes = null;
		attributes = faView.readAttributes();
		FileTime fileTime = attributes.creationTime();
		String formattedDateTime = sdf.format(new Date(fileTime.toMillis()));

		description.append(formattedDateTime);

		description.append(" " + file.getName());

		return description.toString();
	}

}
