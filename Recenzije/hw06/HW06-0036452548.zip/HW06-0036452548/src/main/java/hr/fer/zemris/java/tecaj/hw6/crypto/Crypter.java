package hr.fer.zemris.java.tecaj.hw6.crypto;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.AlgorithmParameterSpec;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

/**
 * Class which offers a functionality of encrpytion and decryption.
 * 
 * @author Domagoj Alagić
 * 
 */
public class Crypter {

	/**
	 * File used in encryption/decryption.
	 */
	private File file;

	/**
	 * Used cipher algorithm.
	 */
	private String cipherAlgorithm = "AES/CBC/PKCS5Padding";

	/**
	 * Used secret key algorithm.
	 */
	private String secretKeySpecAlgorithm = "AES";

	/**
	 * Buffer size.
	 */
	private static final int BUFFER_SIZE = 4096;

	/**
	 * Constructs a <code>Crypter</code> with the given file path.
	 * 
	 * @param filePath
	 *            File which needs to be encrypted/decrypted. Must not be null
	 *            or empty.
	 * 
	 * @throws <code>IllegalArgumentException</code> Thrown if the given file
	 *         path is null or empty of if it doesn't represent a file.
	 */
	public Crypter(String filePath) {

		if (filePath == null || filePath.trim().isEmpty()) {

			throw new IllegalArgumentException(
					"File path must not be empty or null.");
		}

		File file = new File(filePath);

		if (!file.isFile()) {
			throw new IllegalArgumentException(
					"Given path does not represent a file.");
		}

		this.file = file;
	}

	/**
	 * Does encryption or decryption based on the isDecrypt flag. Hex password
	 * and hex init vectors should be also provided.
	 * 
	 * @param hexPassword
	 *            Password hexString.
	 * @param hexInitVector
	 *            Init vector hexString.
	 * @param outputPath
	 *            Destination path (for encrypted, decrypted input file).
	 * @param isDecrypt
	 *            Denotes whether the encryption or decryption should be
	 *            performed. <code>true</code> for decryption,
	 *            <code>false</code> otherwise.
	 * 
	 * @throws <code>IllegalArgumentException</code> Thrown if any of the string
	 *         arguments is null or empty and if the given path does not
	 *         represent a file.
	 */
	private void doOperation(String hexPassword, String hexInitVector,
			String outputPath, boolean isDecrypt) {

		if (hexPassword == null || hexPassword.trim().isEmpty()) {
			throw new IllegalArgumentException(
					"Password should not be null or empty.");
		}

		if (hexInitVector == null || hexInitVector.trim().isEmpty()) {
			throw new IllegalArgumentException(
					"Init vector should not be null or empty.");
		}

		if (outputPath == null || outputPath.trim().isEmpty()) {
			throw new IllegalArgumentException(
					"Output path should not be null or empty.");
		}

		File outFile = new File(outputPath);

		if (outFile.isDirectory()) {
			throw new IllegalArgumentException(
					"Given path does not represent a file.");
		}

		try (BufferedInputStream inputStream = new BufferedInputStream(
				new FileInputStream(file));
				BufferedOutputStream outputStream = new BufferedOutputStream(
						new FileOutputStream(outFile));) {

			SecretKeySpec keySpec = new SecretKeySpec(
					HexUtils.fromHexStringToBytes(hexPassword),
					secretKeySpecAlgorithm);
			AlgorithmParameterSpec paramSpec = new IvParameterSpec(
					HexUtils.fromHexStringToBytes(hexInitVector));

			Cipher cipher = Cipher.getInstance(cipherAlgorithm);
			cipher.init(!isDecrypt ? Cipher.ENCRYPT_MODE : Cipher.DECRYPT_MODE,
					keySpec, paramSpec);

			byte[] buffer = new byte[BUFFER_SIZE];
			while (true) {
				int numOfReadBytes = inputStream.read(buffer);
				if (numOfReadBytes < 1) {
					break;
				}

				byte[] ret = cipher.update(buffer, 0, numOfReadBytes);
				outputStream.write(ret);
			}

			byte[] result = cipher.doFinal();
			outputStream.write(result);

		} catch (NoSuchAlgorithmException | NoSuchPaddingException e) {
			throw new CrypterException("Wrong algorithm or padding given.", e);
		} catch (InvalidKeyException e) {
			throw new CrypterException("Invalid key.", e);
		} catch (InvalidAlgorithmParameterException e) {
			throw new CrypterException("Invalid algorithm parameter.", e);
		} catch (FileNotFoundException e1) {
			throw new CrypterException("File not found.", e1);
		} catch (IOException e1) {
			throw new CrypterException("IO problem.", e1);
		} catch (IllegalBlockSizeException e) {
			throw new CrypterException("Illegal block size.", e);
		} catch (BadPaddingException e) {
			throw new CrypterException("Bad padding.", e);
		}

	}

	/**
	 * Encrypts the current file using the given arguments.
	 * 
	 * @param hexPassword
	 *            Password hexString.
	 * @param hexInitVector
	 *            Init vector hexString.
	 * @param outputPath
	 *            Destination path (for decrypted input file).
	 * 
	 * @throws <code>IllegalArgumentException</code> Thrown if any of the string
	 *         arguments is null or empty and if the given path does not
	 *         represent a file.
	 */
	public void encrypt(String hexPassword, String hexInitVector,
			String outputPath) {
		doOperation(hexPassword, hexInitVector, outputPath, false);
	}

	/**
	 * Decrypts the current file using the given arguments.
	 * 
	 * @param hexPassword
	 *            Password hexString.
	 * @param hexInitVector
	 *            Init vector hexString.
	 * @param outputPath
	 *            Destination path (for decrypted input file).
	 * 
	 * @throws <code>IllegalArgumentException</code> Thrown if any of the string
	 *         arguments is null or empty and if the given path does not
	 *         represent a file.
	 */
	public void decrypt(String hexPassword, String hexInitVector,
			String outputPath) {
		doOperation(hexPassword, hexInitVector, outputPath, true);
	}
}
