package hr.fer.zemris.java.tecaj.hw6.problem1a;

/**
 * Exception which covers the IO errors in runtime.
 * 
 * @author Domagoj Alagić
 *
 */
public class LogException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5840065857508691811L;

	/**
	 * Constructs a <code>LogException</code>.
	 */
	public LogException() {
		super();
	}

	/**
	 * Constructs a <code>LogException</code> with the given message
	 * and cause.
	 * 
	 * @param message User message.
	 * @param cause Exception throwable.
	 */
	public LogException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * Constructs a <code>LogException</code> with the given message.
	 * 
	 * @param message User message.
	 */
	public LogException(String message) {
		super(message);
	}

	
}
