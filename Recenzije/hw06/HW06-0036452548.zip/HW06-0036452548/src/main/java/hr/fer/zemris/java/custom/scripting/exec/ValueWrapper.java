package hr.fer.zemris.java.custom.scripting.exec;

/**
 * Wrapper for the values of <code>ObjectMultistack</code>.
 * 
 * @author Domagoj Alagić
 * 
 */
public class ValueWrapper {

	/**
	 * Value object.
	 */
	private Object value;

	/**
	 * Threshold used in double comparisons.
	 */
	private static final double EPSILON = 10E-6;

	/**
	 * Constructs a <code>ValueWrapper</code> with the given initial value.
	 * 
	 * @param initialValue
	 *            Initial value. Must not be null.
	 * 
	 * @throws <code>IllegalArgumentException</code> Thrown if the given value
	 *         is not of a valid type.
	 */
	public ValueWrapper(Object initialValue) {

		checkForValidType(initialValue);
		this.value = initialValue;
	}

	/**
	 * @return the value
	 */
	public Object getValue() {
		return value;
	}

	/**
	 * @param value
	 *            the value to set
	 * @throws <code>IllegalArgumentException</code> Thrown if the given value
	 *         is not of a valid type.
	 */
	public void setValue(Object value) {

		checkForValidType(value);
		this.value = value;
	}

	/**
	 * Adds the value of the given object to the current instance's value.
	 * 
	 * @param incValue
	 *            Object which value will be added to the current instance's
	 *            value.
	 * 
	 * @throws <code>IllegalArgumentException</code> Thrown if the given value
	 *         is not of a valid type.
	 */
	public void increment(Object incValue) {

		checkForValidType(incValue);

		Number arg1 = convertToAppropriateType(value);
		Number arg2 = convertToAppropriateType(incValue);

		Double result = arg1.doubleValue() + arg2.doubleValue();
		value = castToIntegerIfNeeded(result, arg1, arg2);
	}

	/**
	 * Reduces the current instance's value by the value of the given object.
	 * 
	 * @param decValue
	 *            Object to reduce the current instance's value by.
	 * 
	 * @throws <code>IllegalArgumentException</code> Thrown if the given value
	 *         is not of a valid type.
	 */
	public void decrement(Object decValue) {

		checkForValidType(decValue);

		Number arg1 = convertToAppropriateType(value);
		Number arg2 = convertToAppropriateType(decValue);

		Double result = arg1.doubleValue() - arg2.doubleValue();
		value = castToIntegerIfNeeded(result, arg1, arg2);
	}

	/**
	 * Multiplies the current instance's value by the value of the given object.
	 * 
	 * @param mulValue
	 *            Object to multiply the current instance's value by.
	 * 
	 * @throws <code>IllegalArgumentException</code> Thrown if the given value
	 *         is not of a valid type.
	 */
	public void multiply(Object mulValue) {

		checkForValidType(mulValue);

		Number arg1 = convertToAppropriateType(value);
		Number arg2 = convertToAppropriateType(mulValue);

		Double result = arg1.doubleValue() * arg2.doubleValue();
		value = castToIntegerIfNeeded(result, arg1, arg2);
	}

	/**
	 * Divides the current instance's value by the value of the given object.
	 * 
	 * @param divValue
	 *            Object to divide the current instance's value by.
	 * 
	 * @throws <code>IllegalArgumentException</code> Thrown if the given value
	 *         is not of a valid type of if the given value is <code>0</code>,
	 *         resulting in dividing by <code>0</code>.
	 */
	public void divide(Object divValue) {

		checkForValidType(divValue);

		Number arg1 = convertToAppropriateType(value);
		Number arg2 = convertToAppropriateType(divValue);

		Double doubleArg2 = arg2.doubleValue();

		if (Math.abs(doubleArg2) < EPSILON) {
			throw new IllegalArgumentException("Divisor is 0");
		}

		Double result = arg1.doubleValue() / arg2.doubleValue();
		value = castToIntegerIfNeeded(result, arg1, arg2);

	}

	/**
	 * Compares the current instance with the given object based on the
	 * numerical values of both. Positive value is returned if the current
	 * instance is greater than the given one, negative otherwise.
	 * <code>0</code> is returned if their numerical values are the same.
	 * 
	 * @param withValue
	 *            Object to compare the current instance with.
	 * @return Positive value is returned if the current instance is greater
	 *         than the given one, negative otherwise. <code>0</code> is
	 *         returned if their numerical values are the same.
	 * 
	 * @throws <code>IllegalArgumentException</code> Thrown if the given value
	 *         is not of a valid type.
	 */
	public int numCompare(Object withValue) {

		checkForValidType(withValue);

		Number arg1 = convertToAppropriateType(value);
		Number arg2 = convertToAppropriateType(withValue);

		Double doubleArg1 = arg1.doubleValue();
		Double doubleArg2 = arg2.doubleValue();

		if (Math.abs(doubleArg1 - doubleArg2) < EPSILON) {
			return 0;
		} else if (doubleArg1 > doubleArg2) {
			return 1;
		} else {
			return -1;
		}
	}

	/**
	 * This method converts the given object to the numerical one (
	 * <code>Integer</code> or <code>Double</code> if <code>Integer</code> if
	 * not possible). <code>String</code> is parsed into a <code>Double</code>
	 * or <code>Integer</code> while <code>null</code> is treated as
	 * <code>Integer</code> with value <code>0</code>. <code>Integer</code> and
	 * <code>Double</code> objects are just returned.
	 * 
	 * @param obj
	 *            Object to convert to a numerical type.
	 * @return Numerical object created from the given one.
	 * 
	 * @throws <code>IllegalArgumentException</code> Thrown if the given object
	 *         cannot be converted to a numerical type (in case of handing over
	 *         a <code>String</code>).
	 */
	private Number convertToAppropriateType(Object obj) {

		if (obj == null) {

			return Integer.valueOf(0);

		} else if (obj instanceof String) {

			String stringObj = (String) obj;

			// first try to parse an integer, and if it is not possible, do the
			// same for double. If that's not
			// possible, throw an exception.

			// this is done via exception (even though very costly) because of
			// the
			// absence of the tryParse method.
			// should be refactored to use regular expressions (parsing is done
			// via valueOf).
			try {

				Integer integerObj = Integer.parseInt(stringObj);
				return integerObj;

			} catch (NumberFormatException nexInteger) {

				try {

					Double doubleObj = Double.parseDouble(stringObj);
					return doubleObj;

				} catch (NumberFormatException nexDouble) {

					throw new IllegalArgumentException(
							"Invalid object value was given. String couldn't be parsed into a number.");
				}
			}
		} else {

			return (Number) obj;
		}

	}

	/**
	 * This method returns the first argument as a <code>Double</code> or as an
	 * <code>Integer</code>, depending on the other two given arguments. If
	 * either of them is <code>Double</code>, first argument will be returned as
	 * a <code>Double</code>. If both of them are <code>Integer</code>, an
	 * <code>Integer</code> will be returned.
	 * 
	 * @param result
	 *            Result argument which will be converted to
	 *            <code>Integer</code> if needed.
	 * @param arg1
	 *            First argument.
	 * @param arg2
	 *            Second argument.
	 * @return Result argument as a <code>Double</code> or as a
	 *         <code>Integer</code>.
	 */
	private Object castToIntegerIfNeeded(Number result, Number arg1, Number arg2) {

		if (!(arg1 instanceof Double) && !(arg2 instanceof Double)) {
			return result.intValue();
		} else {
			return result.doubleValue();
		}
	}

	/**
	 * Method which checks whether the given object is of a valid type.
	 * Currently, valid types are: null, Integer, Double and String. If the
	 * given object of a wrong type, an <code>IllegalArgumentException</code> is
	 * thrown.
	 * 
	 * @param obj
	 *            Object to check the type of.
	 * 
	 * @throws <code>IllegalArgumentException</code> Thrown if the given object
	 *         is of a wrong type.
	 */
	private void checkForValidType(Object obj) {

		// valid types are: null, Integer, Double, String
		if (!(obj instanceof Double) && !(obj instanceof Integer)
				&& !(obj instanceof String) && !(obj == null)) {

			throw new IllegalArgumentException(
					"The given value is not of a valid type - use Integer, Double or null.");

		}
	}
}
