package hr.fer.zemris.java.tecaj.hw6.shell;

import java.util.HashMap;
import java.util.Map;

/**
 * This class represent a shell state. It stores all the supported commands and
 * symbols. It also offers some methods to alter the used symbols.
 * 
 * @author Domagoj Alagić
 * 
 */
public class ShellState {

	/**
	 * Supported commands.
	 */
	private Map<String, ShellCommand> commands = new HashMap<>();

	/**
	 * Used symbols.
	 */
	private Map<String, String> symbols = new HashMap<>();

	/**
	 * Constructs a <code>ShellState</code>.
	 */
	public ShellState() {
		initState();
	}

	/**
	 * Initializes the state.
	 */
	private void initState() {

		// init symbols
		symbols.put("PROMPT", ">");
		symbols.put("MORELINES", "/");
		symbols.put("MULTILINE", "!");

		// init commands
		commands.put("cat", new ShellCommandConcatenate());
		commands.put("copy", new ShellCommandCopy());
		commands.put("charsets", new ShellCommandCharsets());
		commands.put("exit", new ShellCommandExit());
		commands.put("hexdump", new ShellCommandHexDump());
		commands.put("ls", new ShellCommandList());
		commands.put("mkdir", new ShellCommandMakeDir());
		commands.put("symbol", new ShellCommandSymbol(this)); // symbol command
																// must have
																// access to
																// symbol map
		commands.put("tree", new ShellCommandTree());

	}

	/**
	 * Gets the command stored under the given command key.
	 * 
	 * @param commandKey
	 *            Command key to retrieve the command for.
	 * @return Retrieved command.
	 * 
	 * @throws <code>IllegalArgumentException</code> Thrown if the given command
	 *         key does not match with any of the supported commands.
	 */
	public ShellCommand getCommand(String commandKey) {

		if (commands.containsKey(commandKey)) {
			return commands.get(commandKey);
		} else {
			throw new IllegalArgumentException("Invalid command given.");
		}
	}

	/**
	 * Gets the symbol stored under the given symbol key.
	 * 
	 * @param symbolKey
	 *            Symbol key to retrieve the symbol for.
	 * @return Retrieved symbol.
	 * 
	 * @throws <code>IllegalArgumentException</code> Thrown if the given symbol
	 *         key does not match with any of the used symbols.
	 */
	public String getSymbol(String symbolKey) {

		if (symbols.containsKey(symbolKey)) {
			return symbols.get(symbolKey);
		} else {
			throw new IllegalArgumentException("Invalid symbol given.");
		}
	}

	/**
	 * Changes the symbol used with the given symbol key.
	 * 
	 * @param symbolKey
	 *            Symbol key which represents a symbol which needs to be
	 *            changed.
	 * @param newSymbol
	 *            A new symbol to replace the current symbol under the given
	 *            symbol key.
	 * 
	 * @throws <code>IllegalArgumentException</code> Thrown if the given symbol
	 *         key does not match with any of the used commands. Also thrown if
	 *         the new symbol is already used elsewhere.
	 */
	public void changeSymbol(String symbolKey, String newSymbol) {

		if (symbols.containsValue(newSymbol)) {
			throw new IllegalArgumentException(
					"Given new symbol is already being used by another symbol key.");
		}

		if (symbols.containsKey(symbolKey)) {

			symbols.put(symbolKey, newSymbol);

		} else {

			throw new IllegalArgumentException(
					"Given symbol key does not exist.");
		}
	}

}
