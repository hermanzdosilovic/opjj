package hr.fer.zemris.java.tecaj.hw6.shell;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Represents a simple shell implementation. This shell offers several commands:
 * 
 * cat [filepath] [charset] - displays the content of the given file with the
 * given charset (optional; if not specified, machine's default is used)
 * 
 * copy [sourcepath] [destpath] - copies the file from source to destination
 * 
 * charsets - lists all currently available charsets
 * 
 * exit - exits the application
 * 
 * hexdump [filepath] - displays hexdump of the given file
 * 
 * ls [folderpath] - displays folder contents
 * 
 * mkdir [folderpath] - creates directory at the given path
 * 
 * symbol [symbolkey] [newsymbol] - displays the symbol for the given symbol key
 * and replaces it (optional) with the new symbol
 * 
 * tree [folderpath] - recursively displays folder hierarchy with given folder
 * acting as a root folder
 * 
 * @author Domagoj Alagić
 * 
 */
public class MyShell {

	/**
	 * Main entry.
	 * 
	 * @param args
	 *            Array of string arguments. Not used in this program.
	 */
	public static void main(String[] args) {

		BufferedReader input = null;
		BufferedWriter output = null;

		try {
			ShellState state = new ShellState();

			input = new BufferedReader(
					new InputStreamReader(System.in, "UTF-8"));
			output = new BufferedWriter(new OutputStreamWriter(System.out,
					"UTF-8"));

			output.write(String.format("%s%n", "Welcome to MyShell v 1.0"));

			ShellStatus status = ShellStatus.CONTINUE;

			// this flag denotes whether the shell is in multiline mode or not
			boolean multiline = false;

			// list for arguments
			List<String> arguments = new ArrayList<>();

			while (status != ShellStatus.TERMINATE) {

				try {

					// if the shell is in multiline mode, don't display prompt
					// symbol, display multiline symbol
					if (multiline) {
						output.write(state.getSymbol("MULTILINE") + " ");
					} else {
						output.write(state.getSymbol("PROMPT") + " ");
					}

					output.flush();

					// read line and split by spaces but not those in between
					// quotation marks
					String line = input.readLine();

					if (line == null) {
						System.err
								.println("Something went wrong with the I/O.");
						System.exit(-1);
					}

					line = line.trim();
					Matcher m = Pattern.compile("([^\"]\\S*|\".+?\")\\s*")
							.matcher(line);
					while (m.find()) {
						arguments.add(m.group(1).replace("\"", ""));
					}

					// check for morelines symbol (it's always last)
					if (arguments.get(arguments.size() - 1).equals(
							state.getSymbol("MORELINES"))) {

						// if the user said that he wants to use multiline mode,
						// set the corresponding flag to 'true'
						multiline = true;
						continue;

					} else {

						// otherwise, multiline mode has ended
						multiline = false;
					}

					String commandName = arguments.get(0);

					// convert list to array while removing the first argument
					// (previously extracted command name)
					String[] commandArgs = new String[arguments.size() - 1];
					arguments.subList(1, arguments.size()).toArray(commandArgs);

					try {

						// execute command
						ShellCommand command = state.getCommand(commandName);
						status = command.executeCommand(input, output,
								commandArgs);

					} catch (ShellCommandException | IllegalArgumentException ie) {

						output.write(String.format("%s%n", ie.getMessage()));
					}

					// make sure to clear the list of arguments
					arguments.clear();

				} catch (IOException e) {
					System.err.println("Something went wrong with the I/O.");
				}

			}

			input.close();
			output.close();

		} catch (IOException e) {

			System.err.println("Something went wrong with the I/O.");

		}
	}

}
