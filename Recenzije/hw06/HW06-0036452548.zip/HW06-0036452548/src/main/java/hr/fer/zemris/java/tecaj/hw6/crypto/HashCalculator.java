package hr.fer.zemris.java.tecaj.hw6.crypto;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;

/**
 * Class which offers a functionality of calculating the hash of a file. Default
 * algorithm is SHA-1. Hash can be fetched as a string or as an array of bytes.
 * 
 * @author Domagoj Alagić
 * 
 */
public class HashCalculator {

	/**
	 * File for which the hash needs to be calculated.
	 */
	private File file;

	/**
	 * Used hashing algorithm.
	 */
	private String algorithm;

	/**
	 * Constructs a <code>HashCalculator</code> with the given file path. This
	 * constructor presumes a SHA-1 hashing algorithm.
	 * 
	 * @param filePath
	 *            Path to the file.
	 * 
	 * @throws <code>IllegalArgumentException</code> Thrown if the file path is
	 *         empty or null. Also if the given file path does not represent a
	 *         file.
	 */
	public HashCalculator(String filePath) {
		this(filePath, "SHA-1");
	}

	/**
	 * Constructs a <code>HashCalculator</code> with the given file path and the
	 * given algorithm.
	 * 
	 * @param filePath
	 *            Hashing algorithm
	 * @param algorithm
	 *            Path to the file.
	 * 
	 * @throws <code>IllegalArgumentException</code> Thrown if the file path is
	 *         empty or null. Also if the given file path does not represent a
	 *         file.
	 */
	public HashCalculator(String filePath, String algorithm) {

		if (filePath == null || filePath.trim().isEmpty()) {

			throw new IllegalArgumentException(
					"File path must not be empty or null.");
		}

		if (algorithm == null || algorithm.trim().isEmpty()) {

			throw new IllegalArgumentException(
					"Hashing algorithm must not be null or empty.");
		}

		File file = new File(filePath);

		if (!file.isFile()) {
			throw new IllegalArgumentException(
					"Given path does not represent a file.");
		}

		this.file = file;

		// validity of the algorithm is checked in the process later on
		this.algorithm = algorithm;
	}

	/**
	 * Calculates the hash of the current file with the current algorithm and
	 * returns it as a byte array.
	 * 
	 * @return Hash in the form of a byte array.
	 */
	private byte[] calculateHash() {

		try (BufferedInputStream inputStream = new BufferedInputStream(
				new FileInputStream(file))) {

			MessageDigest digest = MessageDigest.getInstance(algorithm);

			int inputByte;

			while ((inputByte = inputStream.read()) != -1) {

				digest.update((byte) inputByte);
			}

			byte[] hash = digest.digest();

			return hash;

		} catch (FileNotFoundException e) {
			throw new HashCalculatorException("File not found.", e);
		} catch (IOException e) {
			throw new HashCalculatorException("IO problem.", e);
		} catch (NoSuchAlgorithmException e) {
			throw new HashCalculatorException("Invalid algorithm given.", e);
		}
	}

	/**
	 * Calculates the hash of the current file with the current algorithm and
	 * returns it as a string.
	 * 
	 * @return Hash in the form of a string.
	 */
	public String getHashString() {

		byte[] hash = calculateHash();

		StringBuffer sb = new StringBuffer();

		for (byte b : hash) {

			sb.append(String.format("%02x", b));
		}

		return sb.toString();
	}

	/**
	 * Checks whether the given hash (in the form of a string) is equal to the
	 * hash of the current file.
	 * 
	 * @param hashString
	 *            Hash to check.
	 * @return <code>true</code> if the given hash matches the current one,
	 *         <code>false</code> otherwise.
	 * 
	 * @throws <code>IllegalArgumentException</code> Thrown if the given hash
	 *         string is null.
	 */
	public boolean isSameAsHashString(String hashString) {

		if (hashString == null) {
			throw new IllegalArgumentException("Given hash must not be null.");
		}

		return getHashString().equals(hashString);
	}

	/**
	 * Checks whether the given hash (in the form of a byte array) is equal to
	 * the hash of the current file.
	 * 
	 * @param hashByteArray
	 *            Hash to check.
	 * @return <code>true</code> if the given hash matches the current one,
	 *         <code>false</code> otherwise.
	 * 
	 * @throws <code>IllegalArgumentException</code> Thrown if the given hash
	 *         (byte array) is null.
	 */
	public boolean isSameAsHashByteArray(byte[] hashByteArray) {

		if (hashByteArray == null) {
			throw new IllegalArgumentException("Given hash must not be null.");
		}

		byte[] hash = calculateHash();

		return Arrays.equals(hash, hashByteArray);
	}

}
