package hr.fer.zemris.java.tecaj.hw6.problem1a;

/**
 * Class which is a concrete implementation of
 * <code>IntegerStorageObserver</code> so it offers a certain action on
 * <code>valueChanged</code>.
 * 
 * This class prints out double of the current integer value in the integer
 * storage. However, it does that action only twice after which it unregisters
 * itself from the subject.
 * 
 * @author Domagoj Alagić
 * 
 */
public class DoubleValue implements IntegerStorageObserver {

	/**
	 * Counter which denotes the number of current integer value changes in the
	 * integer storage.
	 */
	private int counter = 0;

	/**
	 * Variable which denotes how many times a change must occur in order for
	 * this observer to unregister from the integer storage.
	 */
	private static final int NUM_OF_CHANGES = 2;

	/**
	 * {@inheritDoc}
	 * 
	 * @throws <code>IllegalArgumentException</code> Thrown if the given
	 *         intStorage is null.
	 */
	@Override
	public void valueChanged(IntegerStorage intStorage) {

		if (intStorage == null) {
			throw new IllegalArgumentException(
					"Integer storage must not be null.");
		}

		counter++;
		System.out.println("Double value: " + intStorage.getValue() * 2);

		if (counter >= NUM_OF_CHANGES) {
			intStorage.removeObserver(this);
		}

	}

}
