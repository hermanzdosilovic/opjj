package hr.fer.zemris.java.tecaj.hw6.shell;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;

/**
 * Implementation of <code>ShellCommand</code>. This command represents an
 * 'symbol' command which lists the symbol under the given symbol key (and maybe
 * changes it).
 * 
 * @author Domagoj Alagić
 * 
 */
public class ShellCommandSymbol implements ShellCommand {

	/**
	 * Instance of the shell state.
	 */
	private ShellState state;

	/**
	 * Constructs a <code>ShellCommandSymbol</code> with the given
	 * <code>ShellState</code> instance.
	 * 
	 * @param state
	 *            <code>ShellState</code> instance. Must not be null.
	 * 
	 * @throws <code>IllegalArgumentException</code> Thrown if the given state
	 *         instance is null.
	 */
	public ShellCommandSymbol(ShellState state) {

		if (state == null) {
			throw new IllegalArgumentException("Shell state must not be null.");
		}

		this.state = state;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @throws <code>ShellCommandException</code> Thrown if there is a wrong
	 *         number of arguments (1 or 2 expected).
	 */
	@Override
	public ShellStatus executeCommand(BufferedReader in, BufferedWriter out,
			String[] arguments) throws IOException {

		if (arguments.length == 1) {

			out.write(String.format("Symbol for %s is '%s'%n", arguments[0],
					state.getSymbol(arguments[0])));

		} else if (arguments.length == 2) {

			String oldSymbol = state.getSymbol(arguments[0]);
			state.changeSymbol(arguments[0], arguments[1]);

			out.write(String.format(
					"Symbol for %s changed from '%s' to '%s'%n", arguments[0],
					oldSymbol, arguments[1]));

		} else {
			throw new ShellCommandException(
					"Invalid number of arguments: expected 1 or 2, was "
							+ arguments.length);
		}

		return ShellStatus.CONTINUE;
	}

}
