package hr.fer.zemris.java.tecaj.hw6.shell;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

/**
 * Implementation of <code>ShellCommand</code>. This command represents an
 * 'mkdir' command which creates a directory (at the given path).
 * 
 * @author Domagoj Alagić
 * 
 */
public class ShellCommandMakeDir implements ShellCommand {

	/**
	 * {@inheritDoc}
	 * 
	 * @throws IOException
	 * 
	 * @throws <code>ShellCommandException</code> Thrown if there is a wrong
	 *         number of arguments (1 expected) or if the directory could not be
	 *         created. Finally, it is thrown if something went wrong with the
	 *         IO.
	 */
	@Override
	public ShellStatus executeCommand(BufferedReader in, BufferedWriter out,
			String[] arguments) throws IOException {

		if (arguments.length != 1) {
			throw new ShellCommandException(
					"Invalid number of arguments: expected 1, was "
							+ arguments.length);
		}

		try {
			Files.createDirectories(Paths.get(arguments[0]));
		} catch (IOException ex) {
			throw new ShellCommandException(
					"mkdir command was not successfully executed.");
		}

		return ShellStatus.CONTINUE;
	}

}
