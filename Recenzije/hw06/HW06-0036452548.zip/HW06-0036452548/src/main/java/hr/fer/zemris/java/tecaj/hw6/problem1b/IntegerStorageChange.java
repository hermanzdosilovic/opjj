package hr.fer.zemris.java.tecaj.hw6.problem1b;

/**
 * Class denoting a change in <code>IntegerStorage</code>.
 * 
 * @author Domagoj Alagić
 * 
 */
public class IntegerStorageChange {

	/**
	 * <code>IntegerStorage</code> instance.
	 */
	private IntegerStorage intStorage;

	/**
	 * Integer storage's value before the change.
	 */
	private int oldValue;

	/**
	 * Integer storage's value after the change.
	 */
	private int newValue;

	/**
	 * Constructs a <code>IntegerStorageChange</code> with the given arguments -
	 * instance of the integer storage, value before and after the change.
	 * 
	 * @param intStorage
	 *            <code>IntegerStorage</code> instance. Must not be null.
	 * @param oldValue
	 *            Integer storage's value before the change.
	 * @param newValue
	 *            Integer storage's value after the change.
	 * 
	 * @throws <code>IllegalArgumentException</code> Thrown if the given integer
	 *         storage instance is null.
	 */
	public IntegerStorageChange(IntegerStorage intStorage, int oldValue,
			int newValue) {

		if (intStorage == null) {
			throw new IllegalArgumentException(
					"Integer storage must not be null.");
		}

		this.intStorage = intStorage;
		this.oldValue = oldValue;
		this.newValue = newValue;
	}

	/**
	 * @return the intStorage
	 */
	public IntegerStorage getIntStorage() {
		return intStorage;
	}

	/**
	 * @return the oldValue
	 */
	public int getOldValue() {
		return oldValue;
	}

	/**
	 * @return the newValue
	 */
	public int getNewValue() {
		return newValue;
	}

}
