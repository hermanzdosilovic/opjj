package hr.fer.zemris.java.tecaj.hw6.problem1a;

/**
 * Class which is a concrete implementation of
 * <code>IntegerStorageObserver</code> so it offers a certain action on
 * <code>valueChanged</code>.
 * 
 * This class counts the number of current integer value changes in the integer
 * storage and prints it out.
 * 
 * @author Domagoj Alagić
 * 
 */
public class ChangeCounter implements IntegerStorageObserver {

	/**
	 * Counter which denotes the number of current integer value changes in the
	 * integer storage.
	 */
	private int counter = 0;

	/**
	 * {@inheritDoc}
	 * 
	 * @throws <code>IllegalArgumentException</code> Thrown if the given
	 *         intStorage is null.
	 */
	@Override
	public void valueChanged(IntegerStorage intStorage) {

		if (intStorage == null) {
			throw new IllegalArgumentException(
					"Integer storage must not be null.");
		}

		System.out.println("Number of value changes since tracking: "
				+ ++counter);

	}

}
