package hr.fer.zemris.java.custom.scripting.execTests;

import static org.junit.Assert.assertEquals;
import hr.fer.zemris.java.custom.scripting.exec.ObjectMultistack;
import hr.fer.zemris.java.custom.scripting.exec.ValueWrapper;

import java.util.ArrayList;
import java.util.EmptyStackException;

import org.junit.Test;

public class Testovi {

	private final ValueWrapper s = new ValueWrapper("56");
	private final ValueWrapper i = new ValueWrapper(56);
	private final ValueWrapper d = new ValueWrapper(56.0);

	/*
	 * Pravila za testove:provjera funkcija prviargument drugiargument (ako je
	 * drugi string, onda kakv broj predstavlja)
	 */

	@Test
	public void provjeraIncrementIntegerStringInt() {
		i.increment("2");
		assertEquals("Krivo zbraja brojeve", Integer.valueOf(58), i.getValue());
	}

	@Test
	public void provjeraIncrementIntegerStringDouble() {
		i.increment("2.");
		assertEquals("Krivo zbraja brojeve", Double.valueOf(58.), i.getValue());
	}

	@Test
	public void provjeraIncrementIntegerInt() {
		i.increment(2);
		assertEquals("Krivo zbraja brojeve", Integer.valueOf(58), i.getValue());
	}

	@Test
	public void provjeraIncrementIntegerDouble() {
		i.increment(2.);
		assertEquals("Krivo zbraja brojeve", Double.valueOf(58.), i.getValue());
	}

	@Test
	public void provjeraIncrementIntegerNull() {
		i.increment(null);
		assertEquals("Krivo zbraja brojeve", Integer.valueOf(56), i.getValue());
	}

	@Test(expected = RuntimeException.class)
	public void provjeraIncrementIntegerGreska() {
		i.increment(new ArrayList<>());

	}

	// ---------------------------------------------------------
	@Test
	public void provjeraIncrementDoubleStringInt() {
		d.increment("2");
		assertEquals("Krivo zbraja brojeve", Double.valueOf(58.), d.getValue());
	}

	@Test
	public void provjeraIncrementDoubleStringDouble() {
		d.increment("2.");
		assertEquals("Krivo zbraja brojeve", Double.valueOf(58.), d.getValue());
	}

	@Test
	public void provjeraIncrementDoubleInt() {
		d.increment(2);
		assertEquals("Krivo zbraja brojeve", Double.valueOf(58.), d.getValue());
	}

	@Test
	public void provjeraIncrementDoubleDouble() {
		d.increment(2.);
		assertEquals("Krivo zbraja brojeve", Double.valueOf(58.), d.getValue());
	}

	@Test
	public void provjeraIncrementDoubleNull() {
		d.increment(null);
		assertEquals("Krivo zbraja brojeve", Double.valueOf(56.), d.getValue());
	}

	@Test(expected = RuntimeException.class)
	public void provjeraIncrementDoubleGreska() {
		d.increment(new ArrayList<>());

	}

	// ----------------------------------------------------------

	@Test
	public void provjeraIncrementStringStringInt() {
		s.increment("2");
		assertEquals("Krivo zbraja brojeve", Integer.valueOf(58), s.getValue());
	}

	@Test
	public void provjeraIncrementStringStringDouble() {
		s.increment("2.");
		assertEquals("Krivo zbraja brojeve", Double.valueOf(58.), s.getValue());
	}

	@Test
	public void provjeraIncrementStringInt() {
		s.increment(2);
		assertEquals("Krivo zbraja brojeve", Integer.valueOf(58), s.getValue());
	}

	@Test
	public void provjeraIncrementStringDouble() {
		s.increment(2.);
		assertEquals("Krivo zbraja brojeve", Double.valueOf(58.), s.getValue());
	}

	@Test
	public void provjeraIncrementStringNull() {
		s.increment(null);
		assertEquals("Krivo zbraja brojeve", Integer.valueOf(56), s.getValue());
	}

	@Test(expected = RuntimeException.class)
	public void provjeraIncrementStringGreska() {
		s.increment(new ArrayList<>());

	}

	// ----------------------------------------------------------
	// ----------------------------------------------------------

	@Test
	public void provjeradecrementIntegerStringInt() {
		i.decrement("2");
		assertEquals("Krivo oduzima brojeve", Integer.valueOf(54), i.getValue());
	}

	@Test
	public void provjeradecrementIntegerStringDouble() {
		i.decrement("2.");
		assertEquals("Krivo oduzima brojeve", Double.valueOf(54.), i.getValue());
	}

	@Test
	public void provjeradecrementIntegerInt() {
		i.decrement(2);
		assertEquals("Krivo oduzima brojeve", Integer.valueOf(54), i.getValue());
	}

	@Test
	public void provjeradecrementIntegerDouble() {
		i.decrement(2.);
		assertEquals("Krivo oduzima brojeve", Double.valueOf(54.), i.getValue());
	}

	@Test
	public void provjeradecrementIntegerNull() {
		i.decrement(null);
		assertEquals("Krivo oduzima brojeve", Integer.valueOf(56), i.getValue());
	}

	@Test(expected = RuntimeException.class)
	public void provjeradecrementIntegerGreska() {
		i.increment(new ArrayList<>());

	}

	// ----------------------------------------------------------

	@Test
	public void provjeradecrementDoubleStringInt() {
		d.decrement("2");
		assertEquals("Krivo oduzima brojeve", Double.valueOf(54.), d.getValue());
	}

	@Test
	public void provjeradecrementDoubleStringDouble() {
		d.decrement("2.");
		assertEquals("Krivo oduzima brojeve", Double.valueOf(54.), d.getValue());
	}

	@Test
	public void provjeradecrementDoubleInt() {
		d.decrement(2);
		assertEquals("Krivo oduzima brojeve", Double.valueOf(54.), d.getValue());
	}

	@Test
	public void provjeradecrementDoubleDouble() {
		d.decrement(2.);
		assertEquals("Krivo oduzima brojeve", Double.valueOf(54.), d.getValue());
	}

	@Test
	public void provjeradecrementDoubleNull() {
		d.decrement(null);
		assertEquals("Krivo oduzima brojeve", Double.valueOf(56.), d.getValue());
	}

	@Test(expected = RuntimeException.class)
	public void provjeradecrementDoubleGreska() {
		d.decrement(new ArrayList<>());

	}

	// ----------------------------------------------------------

	@Test
	public void provjeradecrementStringStringInt() {
		s.decrement("2");
		assertEquals("Krivo oduzima brojeve", Integer.valueOf(54), s.getValue());
	}

	@Test
	public void provjeradecrementStringStringDouble() {
		s.decrement("2.");
		assertEquals("Krivo oduzima brojeve", Double.valueOf(54.), s.getValue());
	}

	@Test
	public void provjeradecrementStringInt() {
		s.decrement(2);
		assertEquals("Krivo oduzima brojeve", Integer.valueOf(54), s.getValue());
	}

	@Test
	public void provjeradecrementStringDouble() {
		s.decrement(2.);
		assertEquals("Krivo oduzima brojeve", Double.valueOf(54.), s.getValue());
	}

	@Test
	public void provjeradecrementStringNull() {
		s.decrement(null);
		assertEquals("Krivo oduzima brojeve", Integer.valueOf(56), s.getValue());
	}

	@Test(expected = RuntimeException.class)
	public void provjeradecrementStringGreska() {
		s.decrement(new ArrayList<>());

	}

	// ----------------------------------------------------------
	// ----------------------------------------------------------

	@Test
	public void provjeramultiplyIntegerStringInt() {
		i.multiply("2");
		assertEquals("Krivo množi brojeve", Integer.valueOf(112), i.getValue());
	}

	@Test
	public void provjeramultiplyIntegerStringDouble() {
		i.multiply("2.");
		assertEquals("Krivo množi brojeve", Double.valueOf(112.), i.getValue());
	}

	@Test
	public void provjeramultiplyIntegerInt() {
		i.multiply(2);
		assertEquals("Krivo množi brojeve", Integer.valueOf(112), i.getValue());
	}

	@Test
	public void provjeramultiplyIntegerDouble() {
		i.multiply(2.);
		assertEquals("Krivo množi brojeve", Double.valueOf(112.), i.getValue());
	}

	@Test
	public void provjeramultiplyIntegerNull() {
		i.multiply(null);
		assertEquals("Krivo množi brojeve", Integer.valueOf(0), i.getValue());
	}

	@Test(expected = RuntimeException.class)
	public void provjeramultiplyIntegerGreska() {
		i.increment(new ArrayList<>());

	}

	// ----------------------------------------------------------

	@Test
	public void provjeramultiplyDoubleStringInt() {
		d.multiply("2");
		assertEquals("Krivo množi brojeve", Double.valueOf(112.), d.getValue());
	}

	@Test
	public void provjeramultiplyDoubleStringDouble() {
		d.multiply("2.");
		assertEquals("Krivo množi brojeve", Double.valueOf(112.), d.getValue());
	}

	@Test
	public void provjeramultiplyDoubleInt() {
		d.multiply(2);
		assertEquals("Krivo množi brojeve", Double.valueOf(112.), d.getValue());
	}

	@Test
	public void provjeramultiplyDoubleDouble() {
		d.multiply(2.);
		assertEquals("Krivo množi brojeve", Double.valueOf(112.), d.getValue());
	}

	@Test
	public void provjeramultiplyDoubleNull() {
		d.multiply(null);
		assertEquals("Krivo množi brojeve", Double.valueOf(0.), d.getValue());
	}

	@Test(expected = RuntimeException.class)
	public void provjeramultiplyDoubleGreska() {
		d.multiply(new ArrayList<>());

	}

	// ----------------------------------------------------------

	@Test
	public void provjeramultiplyStringStringInt() {
		s.multiply("2");
		assertEquals("Krivo množi brojeve", Integer.valueOf(112), s.getValue());
	}

	@Test
	public void provjeramultiplyStringStringDouble() {
		s.multiply("2.");
		assertEquals("Krivo množi brojeve", Double.valueOf(112.), s.getValue());
	}

	@Test
	public void provjeramultiplyStringInt() {
		s.multiply(2);
		assertEquals("Krivo množi brojeve", Integer.valueOf(112), s.getValue());
	}

	@Test
	public void provjeramultiplyStringDouble() {
		s.multiply(2.);
		assertEquals("Krivo množi brojeve", Double.valueOf(112.), s.getValue());
	}

	@Test
	public void provjeramultiplyStringNull() {
		s.multiply(null);
		assertEquals("Krivo množi brojeve", Integer.valueOf(0), s.getValue());
	}

	@Test(expected = RuntimeException.class)
	public void provjeramultiplyStringGreska() {
		s.multiply(new ArrayList<>());

	}

	// ----------------------------------------------------------
	// ----------------------------------------------------------

	@Test
	public void provjeradivideIntegerStringInt() {
		i.divide("2");
		assertEquals("Krivo dijeli brojeve", Integer.valueOf(28), i.getValue());
	}

	@Test
	public void provjeradivideIntegerStringDouble() {
		i.divide("2.");
		assertEquals("Krivo dijeli brojeve", Double.valueOf(28.), i.getValue());
	}

	@Test
	public void provjeradivideIntegerInt() {
		i.divide(2);
		assertEquals("Krivo dijeli brojeve", Integer.valueOf(28), i.getValue());
	}

	@Test
	public void provjeradivideIntegerDouble() {
		i.divide(2.);
		assertEquals("Krivo dijeli brojeve", Double.valueOf(28.), i.getValue());
	}

	@Test(expected = RuntimeException.class)
	public void provjeradivideIntegerGreska() {
		i.increment(new ArrayList<>());

	}

	// ----------------------------------------------------------

	@Test
	public void provjeradivideDoubleStringInt() {
		d.divide("2");
		assertEquals("Krivo dijeli brojeve", Double.valueOf(28.), d.getValue());
	}

	@Test
	public void provjeradivideDoubleStringDouble() {
		d.divide("2.");
		assertEquals("Krivo dijeli brojeve", Double.valueOf(28.), d.getValue());
	}

	@Test
	public void provjeradivideDoubleInt() {
		d.divide(2);
		assertEquals("Krivo dijeli brojeve", Double.valueOf(28.), d.getValue());
	}

	@Test
	public void provjeradivideDoubleDouble() {
		d.divide(2.);
		assertEquals("Krivo dijeli brojeve", Double.valueOf(28.), d.getValue());
	}

	@Test(expected = RuntimeException.class)
	public void provjeradivideDoubleGreska() {
		d.divide(new ArrayList<>());

	}

	// ----------------------------------------------------------

	@Test
	public void provjeradivideStringStringInt() {
		s.divide("2");
		assertEquals("Krivo dijeli brojeve", Integer.valueOf(28), s.getValue());
	}

	@Test
	public void provjeradivideStringStringDouble() {
		s.divide("2.");
		assertEquals("Krivo dijeli brojeve", Double.valueOf(28.), s.getValue());
	}

	@Test
	public void provjeradivideStringInt() {
		s.divide(2);
		assertEquals("Krivo dijeli brojeve", Integer.valueOf(28), s.getValue());
	}

	@Test
	public void provjeradivideStringDouble() {
		s.divide(2.);
		assertEquals("Krivo dijeli brojeve", Double.valueOf(28.), s.getValue());
	}

	@Test(expected = RuntimeException.class)
	public void provjeradivideStringGreska() {
		s.divide(new ArrayList<>());

	}

	// ----------------------------------------------------------
	// -----------------------------------------------------------

	@Test
	public void provjeraSetValueString() {
		s.setValue("59");
		assertEquals("Krivo postavlja vrijednost", "59", s.getValue());
	}

	@Test
	public void provjeraSetValueInteger() {
		i.setValue(59);
		assertEquals("Krivo postavlja vrijednost", 59, i.getValue());
	}

	@Test
	public void provjeraSetValueDouble() {
		d.setValue(59.1);
		assertEquals("Krivo postavlja vrijednost", 59.1, d.getValue());
	}

	@Test
	public void provjeraNumCompareManji() {

		final int i = s.numCompare(99);
		assertEquals("krivo usporeduje s vecim", -1, i);
	}

	@Test
	public void provjeraNumCompareVeci() {

		final int i = s.numCompare(-99);
		assertEquals("krivo usporeduje s manjim", 1, i);
	}

	@Test
	public void provjeraNumCompareIsti() {

		final int i = s.numCompare(56);
		assertEquals("krivo usporeduje s istim", 0, i);
	}

	// ----------------------------------------------------------
	// -----------------------------------------------------------

	// ----------------------------------------------------------
	// -----------------------------------------------------------

	// ----------------------------------------------------------
	// -----------------------------------------------------------

	final private ObjectMultistack multistack = new ObjectMultistack();

	@Test
	public void provjeraPushPeekPop1() {

		final ValueWrapper year = new ValueWrapper(2000);
		final String name = "year";
		multistack.push(name, year);

		assertEquals("ne radi dobro sa stogom", 2000, multistack.peek(name)
				.getValue());

	}

	@Test
	public void provjeraPushPeekPop2() {

		final ValueWrapper year = new ValueWrapper(2000);
		final String name = "year";
		multistack.push(name, year);

		assertEquals("ne radi dobro sa stogom", 2000, multistack.pop(name)
				.getValue());

	}

	@Test(expected = EmptyStackException.class)
	public void provjeraPeekNaPrazan() {

		final String name = "year";
		final ValueWrapper year = new ValueWrapper(2000);
		multistack.push(name, year);
		multistack.pop(name);
		multistack.peek(name);

	}

	@Test(expected = EmptyStackException.class)
	public void provjeraPopNaPrazan() {

		final String name = "year";
		final ValueWrapper year = new ValueWrapper(2000);
		multistack.push(name, year);
		multistack.pop(name);
		multistack.pop(name);

	}

	@Test(expected = EmptyStackException.class)
	public void provjeraPopNaNepostojecuMapu() {

		final String name = "year";
		multistack.pop(name);

	}

	@Test(expected = EmptyStackException.class)
	public void provjeraPeekNaNepostojecuMapu() {

		final String name = "year";
		multistack.peek(name);

	}

}
