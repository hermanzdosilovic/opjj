package hr.fer.zemris.java.tecaj.hw6.problem1b;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Path;

/**
 * Operacija koja otvara file zadan konsturktorom, apendira trenutnu 
 * vrijednost u novi redak, i zatvara file. Implementira {@link IntegerStorageObserver
 * @author Luka Zuanović
 * @version 1.0
 *
 */
public class LogValue implements IntegerStorageObserver {

	/**
	 * path datoteke u koju apendamo
	 */
	private final Path path;

	/**
	 * Konstruktor koji prima stazu do datoteke u koju ce se zapisivati podatci
	 * 
	 * @param path
	 *            Staza do datoteke.
	 */
	public LogValue(final Path path) {
		this.path = path;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void valueChanged(final IntegerStorageChange istorage) {

		try {
			final File file = path.toFile();
			final FileWriter fw = new FileWriter(file, true);
			fw.write(istorage.getNewValue() + "\n");
			fw.close();
		} catch (final IOException ioe) {
			System.err.println("pogreška pri pisanju u file");
			ioe.printStackTrace();
		}

	}

}
