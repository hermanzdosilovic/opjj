package hr.fer.zemris.java.custom.scripting.exec;

/**
 * Razred koji obavija bilokoji tip objekta.
 * 
 * @author Luka Zuanović
 * @version 1.0
 */
public class ValueWrapper {

	/**
	 * Vrijednost pohranjena u omotu.
	 */
	private Object value;

	/**
	 * Konstruktor koji prima pocetnu vrijednost.
	 * 
	 * @param value
	 *            Pocetna vrijednost.
	 */
	public ValueWrapper(final Object value) {
		super();
		this.value = value;
	}

	/**
	 * Metoda za dohvat pohranjene vrijednosti.
	 * 
	 * @return Pohranjena vrijednost.
	 */
	public Object getValue() {
		return value;
	}

	/**
	 * Metoda za postavljanje vrijednosti.
	 * 
	 * @param value
	 *            Željena vrijednost.
	 */
	public void setValue(final Object value) {
		this.value = value;
	}

	/**
	 * Metoda koja provjerava ispravnost tipova podataka. Podaatci su trenutna
	 * vrijednost i predana vrijednost. Tipovi podataka smiju biri Integer,
	 * Double, String i null vrijednost. Dodatno se za string vrijednosti
	 * provjerava mogu li predstavljati broj.
	 * 
	 * @param xValue
	 *            Podatak za koji se provjerava ispravnost tipa.
	 */
	private void provjera(final Object xValue) {
		if (!((value == null || value instanceof String
				|| value instanceof Integer || value instanceof Double) && (xValue == null
				|| xValue instanceof String || xValue instanceof Double || xValue instanceof Integer))) {
			throw new RuntimeException(
					"Nepodržani tipo podataka za numericke operacije");
		}

		if (value instanceof String) {

			try {
				Double.parseDouble((String) value);
			} catch (final NumberFormatException e) {
				throw new RuntimeException(
						"Pocetni string nije pretvoriv u broj");

			}
		}

		if (xValue instanceof String) {

			try {
				Double.parseDouble((String) xValue);
			} catch (final NumberFormatException e) {
				throw new RuntimeException(
						"Predani string nije pretvoriv u broj");

			}
		}

	}

	/**
	 * Privatni razred u kojem se nalaze tipovi operacija. Moguci tipovi su
	 * {@linkplain #ADD},{@linkplain #SUB},{@linkplain #MUL},{@linkplain #DIV}
	 * 
	 * @author Luka Zuanović
	 * @version 1.0
	 */
	private class Tipovi {

		/**
		 * Tip za obavljanje zbrajanja.
		 */
		final static int ADD = 0;

		/**
		 * Tip za obavljanje oduzimanja
		 */
		final static int SUB = 1;

		/**
		 * Tip za obavljanje množenja
		 */
		final static int MUL = 2;

		/**
		 * Tip za obavljanje dijeljenja
		 */
		final static int DIV = 3;

	}

	/**
	 * Metoda koja obavlja sav posao.
	 * 
	 * @param xValue
	 *            Druga vrijednost
	 * @param tip
	 *            Tip posla, moze biti jedna iz {@linkplain Tipovi}:
	 * 
	 */
	private void radi(final Object xValue, final int tip) {

		provjera(xValue);

		final Double a = uDouble(value);
		final Double b = uDouble(xValue);

		final double rez = zadanaFja(a, b, tip);

		if (value instanceof Double || xValue instanceof Double) {
			// ako je barme jedan double
			value = rez;
		} else if (value instanceof String || xValue instanceof String) {

			boolean imaD = false;

			if (value instanceof String) {

				if (((String) value).contains(".")
						|| ((String) value).toUpperCase().contains("E")) {

					imaD = true;

				}

			}

			if (xValue instanceof String) {

				if (((String) xValue).contains(".")
						|| ((String) xValue).toUpperCase().contains("E")) {
					imaD = true;
				}
			}

			if (imaD) {
				value = rez;
			} else {
				value = (int) rez;
			}
		} else {
			value = (int) rez;
		}

	}

	/**
	 * Metoda koja obavlja željenu f-ju
	 * 
	 * @param a
	 *            Prvi argument f-je
	 * @param b
	 *            Drugi argument f-je
	 * @param tip
	 *            Tip koji odreduje operaciju, detaljniji opis tipova dan je u
	 *            {@linkplain Tipovi}
	 * @return Vrijednost koja se dobije nakon sto se obavi zeljena f-ja
	 */
	private Double zadanaFja(final Double a, final Double b, final int tip) {

		switch (tip) {

		case Tipovi.ADD:
			return a + b;
		case Tipovi.SUB:
			return a - b;
		case Tipovi.MUL:
			return a * b;
		case Tipovi.DIV:
			return a / b;
		default:
			return null;
		}

	}

	/**
	 * Metoda koja pretvara Integer, String, Double u Double vrijednost kao
	 * najopcenitju od njih
	 * 
	 * @param xValue
	 *            Vrijednost koju pretvaramoa u Double
	 * @return Double vrijednost zadanog ulaza.
	 */
	private Double uDouble(final Object xValue) {
		if (xValue == null) {
			return 0.;
		}
		if (xValue instanceof String) {
			return Double.parseDouble((String) xValue);
		}
		if (xValue instanceof Integer) {
			return 1.0 * ((Integer) xValue);
		}

		return (Double) xValue;

	}

	/**
	 * Metoda za uvečavanje vrijednosti.
	 * 
	 * @param incValue
	 *            Vrijednost ZA koju se uvecava.
	 */
	public void increment(final Object incValue) {

		radi(incValue, Tipovi.ADD);

	}

	/**
	 * Metoda za umanjivanje vrijednosti.
	 * 
	 * @param decValue
	 *            Vrijednost ZA koju se umanjuje.
	 */
	public void decrement(final Object decValue) {

		radi(decValue, Tipovi.SUB);

	}

	/**
	 * Metoda za množenje vrijednosti.
	 * 
	 * @param mulValue
	 *            Vrijednost kojom se množi.
	 */
	public void multiply(final Object mulValue) {

		radi(mulValue, Tipovi.MUL);

	}

	/**
	 * Metoda za dijeljenje vrijednosti.
	 * 
	 * @param divValue
	 *            Vrijednost kojom se dijeli
	 */
	public void divide(final Object divValue) {

		radi(divValue, Tipovi.DIV);
	}

	/**
	 * Metoda za uspoređivanje vrijednosti.
	 * 
	 * @param withValue
	 *            Vrijednost s kojom se uspoređuje
	 * @return negativan broj ako je trenutna vrijednost manja, nula ako je
	 *         jednaka ili pozitivan broj ako je veca od predanog argumenta
	 */
	public int numCompare(final Object withValue) {

		provjera(withValue);

		final Double a = uDouble(value);
		final Double b = uDouble(withValue);
		return a.compareTo(b);
	}

}
