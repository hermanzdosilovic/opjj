package hr.fer.zemris.java.tecaj.hw6.problem1a;

/**
 * Sučelje koje implementiraju svi razredi koji predstavljaju neku operaciju.
 * 
 * @author Luka Zuanović
 * @version 1.0
 */
public interface IntegerStorageObserver {

	/**
	 * Metoda koja određuje što napraviti kada se promjeni vrijednost.
	 * 
	 * @param istorage
	 *            Subjekt.
	 */
	public void valueChanged(IntegerStorage istorage);
}
