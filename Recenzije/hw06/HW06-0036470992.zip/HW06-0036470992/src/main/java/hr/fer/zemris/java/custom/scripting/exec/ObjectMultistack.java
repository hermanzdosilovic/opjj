package hr.fer.zemris.java.custom.scripting.exec;

import java.util.ArrayList;
import java.util.EmptyStackException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Razred kojime modeliramo multimapu, mapu koja za jedna kljuc pohranjuje vise
 * vrijednosti.
 * 
 * @author Luka Zuanović
 * @version 1.0
 */
public class ObjectMultistack {

	/**
	 * Razred koji modelira vrijednost multimape
	 * 
	 * @author Luka Zuanović
	 * @version 1.0
	 */
	private static class MultistackEntry {

		/**
		 * lista koja modelira stog
		 */
		private List<ValueWrapper> stog;

		/**
		 * broj elemenata na stogu, 0 oznacava prazan stog
		 */
		private int broj = 0;

		/**
		 * Metoda koja stavlja željenu vrijednost na stog
		 * 
		 * @param value
		 *            Vrijednost
		 */
		public void push(final ValueWrapper value) {
			if (broj == 0) {
				stog = new ArrayList<>();
			}

			stog.add(value);
			broj++;

		}

		/**
		 * Metoda koja skida vrijednost sa stoga
		 * 
		 * @return skinuta vrijednost
		 */
		public ValueWrapper pop() {
			if (broj == 0) {
				throw new EmptyStackException();
			}
			broj--;

			final ValueWrapper popani = stog.get(broj);
			stog.remove(broj);

			return popani;
		}

		/**
		 * Metoda koja pokazuje vrijednost na stogu
		 * 
		 * @return vrijednost na vrhu stoga
		 */
		public ValueWrapper peek() {
			if (broj == 0) {
				throw new EmptyStackException();
			}

			return stog.get(broj - 1);
		}

		public boolean isEmpty() {

			return broj == 0;
		}
	}

	/**
	 * mapa koja predstavlja zeljenu strukturu
	 */
	private final Map<String, MultistackEntry> multistack = new HashMap<>();

	/**
	 * Metoda koja na zadani stog stavlja zadanu vrijednost
	 * 
	 * @param name
	 *            Zadani stog
	 * @param valueWrapper
	 *            Zadana vrijednost
	 */
	public void push(final String name, final ValueWrapper valueWrapper) {

		if (multistack.containsKey(name)) {
			multistack.get(name).push(valueWrapper);
		} else {
			final MultistackEntry stog = new MultistackEntry();
			stog.push(valueWrapper);
			multistack.put(name, stog);
		}

	}

	/**
	 * Metoda koja sa zadanog stoga uzima vrijednost
	 * 
	 * @param name
	 *            Zadani stog
	 * @return Uzeta vrijednost
	 */
	public ValueWrapper pop(final String name) {
		if (!multistack.containsKey(name)) {
			throw new EmptyStackException();
		}
		return multistack.get(name).pop();

	}

	/**
	 * Metoda koja sa zadanog stoga pokazuje vrijednost
	 * 
	 * @param name
	 *            Zadani stog
	 * @return Vrijednost koja se pokazuje
	 */
	public ValueWrapper peek(final String name) {
		if (!multistack.containsKey(name)) {
			throw new EmptyStackException();
		}
		return multistack.get(name).peek();

	}

	/**
	 * Metoda koja provjerva je li zadani stog prazan
	 * 
	 * @param name
	 *            Zadani stog
	 * @return <code>true</code> ako je <code>false</code> inače
	 */
	public boolean isEmpty(final String name) {

		return multistack.get(name).isEmpty();

	}
}
