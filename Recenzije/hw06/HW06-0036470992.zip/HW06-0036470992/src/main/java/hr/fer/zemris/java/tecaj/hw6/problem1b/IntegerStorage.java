package hr.fer.zemris.java.tecaj.hw6.problem1b;

import java.util.ArrayList;
import java.util.List;

/**
 * Razred koji sluzi za pohranu cijelobrojnih vrijednosti. Razred u sebi sadrži
 * listu promatrača koja se može smanjivati ili uvecavati.
 * 
 * @author Luka Zuanović
 * @version 1.0
 */
public class IntegerStorage {

	/**
	 * Cijelobrojna vrijednost.
	 */
	private int value;

	/**
	 * Lista promatrača.
	 */
	private List<IntegerStorageObserver> observers;

	/**
	 * Konstruktor koji prima int vrijednost.
	 * 
	 * @param initialValue
	 *            Pocetna vrijednost.
	 */
	public IntegerStorage(final int initialValue) {
		value = initialValue;
	}

	/**
	 * Metoda za dodavanje promatrača. Promatrač se dodaje samo ako vec nije
	 * prisutan.
	 * 
	 * @param observer
	 *            Novi promatrač.
	 */
	public void addObserver(final IntegerStorageObserver observer) {
		// add the observer in observers if not already there ...
		if (observers == null) {
			observers = new ArrayList<>();
			observers.add(observer);
		} else if (!observers.contains(observer)) {
			observers.add(observer);
		}

	}

	/**
	 * Metoda koja uklanja promatrača. Naravno ako je prisutan.
	 * 
	 * @param observer
	 *            Promatrač kojeg želimo ukloniti.
	 */
	public void removeObserver(final IntegerStorageObserver observer) {
		// remove the observer from observers if present ...
		if (observers != null) {
			observers.remove(observer);
		}

	}

	/**
	 * Metoda koja uklanja sve promatrače.
	 */
	public void clearObservers() {
		// remove all observers from observers list ...
		if (observers != null) {

			observers = null;
		}
	}

	/**
	 * Metoda za dohvacanje pohranjene int vrijednosti.
	 * 
	 * @return Pohranjenu vrijednost.
	 */
	public int getValue() {
		return value;
	}

	/**
	 * Metoda koja postavlja vrijednost na željenu. Ako je vrijednost
	 * promjenjena onda se o tome obavještavaju svi promatrači. Ako takvi i
	 * postoje.
	 * 
	 * @param value
	 *            Vrijednost na koju postavljamo.
	 */
	public void setValue(final int value) {
		// Only if new value is different than the current value:
		if (this.value != value) {
			// Update current value
			this.value = value;
			// Notify all registered observers
			if (observers != null) {
				final IntegerStorageChange iSC = new IntegerStorageChange(this,
						value, value);
				for (final IntegerStorageObserver observer : new ArrayList<>(
						observers)) {
					observer.valueChanged(iSC);
					if (observer instanceof DoubleValue) {
						if (((DoubleValue) observer).brisi) {
							removeObserver(observer);
						}

					}
				}
			}
		}
	}
}
