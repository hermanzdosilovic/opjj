package hr.fer.zemris.java.tecaj.hw6.problem1a;

/**
 * Operacija koja ispisuje kvadrat broja na standardni izlaz. Implementira
 * {@link IntegerStorageObserver}
 * 
 * @author Luka Zuanović
 * @version 1.0
 */
public class SquareValue implements IntegerStorageObserver {

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void valueChanged(final IntegerStorage istorage) {
		final int v = istorage.getValue();
		System.out.println("Provided new value: " + v + ", square is " + v * v);

	}

}
