package hr.fer.zemris.java.tecaj.hw6.problem1b;

/**
 * Operacija koja ispisuje kvadrat broja na standardni izlaz. Implementira
 * {@link IntegerStorageObserver}
 * 
 * @author Luka Zuanović
 * @version 1.0
 */
public class SquareValue implements IntegerStorageObserver {

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void valueChanged(final IntegerStorageChange istorage) {
		final int v = istorage.getNewValue();
		System.out.println("Provided new value: " + v + ", square is " + v * v);

	}

}
