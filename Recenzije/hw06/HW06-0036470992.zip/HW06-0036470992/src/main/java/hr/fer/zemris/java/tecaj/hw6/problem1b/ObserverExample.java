package hr.fer.zemris.java.tecaj.hw6.problem1b;

import java.nio.file.Paths;

/**
 * Program koji sluzi kao primjer za rad s promatračima.
 * 
 * @author Luka Zuanović
 * @version 1.0
 */
public class ObserverExample {

	/**
	 * Metoda koja se poziva prilikom pokretanja programa ...
	 * 
	 * @param args
	 *            Argumenti komandne linije, ovdje se ne koriste.
	 */
	public static void main(final String[] args) {

		final IntegerStorage istorage = new IntegerStorage(20);
		final IntegerStorageObserver observer = new SquareValue();

		istorage.addObserver(observer);
		istorage.addObserver(new ChangeCounter());
		istorage.addObserver(new DoubleValue());
		istorage.addObserver(new LogValue(Paths.get("./log.txt")));

		istorage.setValue(5);
		istorage.setValue(2);
		istorage.setValue(25);
		istorage.setValue(13);
		istorage.setValue(22);
		istorage.setValue(15);

	}

}
