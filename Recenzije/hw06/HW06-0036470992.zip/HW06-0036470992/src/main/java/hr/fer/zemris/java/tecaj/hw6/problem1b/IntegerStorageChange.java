package hr.fer.zemris.java.tecaj.hw6.problem1b;

/**
 * 
 * @author Windows
 * 
 */
public class IntegerStorageChange {

	/**
	 * Referenca na IntegerStorage
	 */
	private final IntegerStorage referenca;

	/**
	 * Stara vrijednost
	 */
	private final int oldValue;

	/**
	 * Nova vrijednost
	 */
	private final int newValue;

	/**
	 * Konstruktor koji prima {@link IntegerStorage}, staru vrijednost i novu
	 * vrijednost.
	 * 
	 * @param referenca
	 *            referenca na Objekt tipa IntegerStorage
	 * @param oldValue
	 *            Stara vrijednost
	 * @param newValue
	 *            Nova vrijednost
	 */
	public IntegerStorageChange(final IntegerStorage referenca,
			final int oldValue, final int newValue) {
		super();
		this.referenca = referenca;
		this.oldValue = oldValue;
		this.newValue = newValue;
	}

	/**
	 * getter za novu vrijednost
	 * 
	 * @return nova vrijednost
	 */
	public int getNewValue() {
		return newValue;
	}

	/**
	 * getter za staru vrijednost
	 * 
	 * @return stara vrijednost
	 */
	public int getOldValue() {
		return oldValue;
	}

	/**
	 * getter za referencu
	 * 
	 * @return referenca na {@link IntegerStorage}
	 */
	public IntegerStorage getReferenca() {
		return referenca;
	}

}
