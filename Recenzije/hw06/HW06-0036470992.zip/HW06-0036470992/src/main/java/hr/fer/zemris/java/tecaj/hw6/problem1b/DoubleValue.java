package hr.fer.zemris.java.tecaj.hw6.problem1b;

/**
 * Operacija koja ispisuje dobule vrijednost subjekta, ali smao prva dva puta.
 * Implementira {@link IntegerStorageObserver}
 * 
 * @author Luka Zuanović
 * @version 1.0
 */
public class DoubleValue implements IntegerStorageObserver {

	/**
	 * Broj ispisa
	 */
	int brojilo = 0;

	/**
	 * Treba li ga ukloniti iz liste promatraca;
	 */
	boolean brisi = false;

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void valueChanged(final IntegerStorageChange istorage) {
		brojilo++;

		final int v = istorage.getNewValue();
		System.out.println("Double value: " + 2 * v);

		if (brojilo == 2) {
			brisi = true;
			brojilo = 0;
		}

	}

}
