package hr.fer.zemris.java.custom.scripting.nodes;

/**
 * Sučelje koje predstavlja posjetioca čvorova.
 * 
 * @author Luka Ruklić
 *
 */

public interface INodeVisitor {

	/**
	 * Metoda čijim pozivom posjetioc "posjećuje" tekstualni čvor te
	 * obavlja odgovorajuće operacije nad njim.
	 * 
	 * @param node tekstualni čvor
	 */
	public void visitTextNode(TextNode node);
	/**
	 * Metoda čijim pozivom posjetioc "posjećuje" čvor petlje te
	 * obavlja odgovorajuće operacije nad njim.
	 * 
	 * @param node čvor petlje
	 */
	public void visitForLoopNode(ForLoopNode node);
	/**
	 * Metoda čijim pozivom posjetioc "posjećuje" Echo čvor te
	 * obavlja odgovorajuće operacije nad njim.
	 * 
	 * @param node Echo čvor
	 */
	public void visitEchoNode(EchoNode node);
	/**
	 * Metoda čijim pozivom posjetioc "posjećuje" dokument čvor te
	 * obavlja odgovorajuće operacije nad njim.
	 * 
	 * @param node dokument čvor
	 */
	public void visitDocumentNode(DocumentNode node);

}
