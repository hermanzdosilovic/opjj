package hr.fer.zemris.java.custom.scripting.nodes;

import hr.fer.zemris.java.custom.scripting.tokens.Token;

/**
 * Druga domaća zadaća, treći zadatak
 * Razred koji realizira EchoNode s pripadajućim konstruktorom.
 * 
 * @author Luka Ruklić, 0036456440
 */

public class EchoNode extends Node {

	/**
	 * Tokeni sadržani u čvoru.
	 */
	private final Token[] tokens;

	/**
	 * Konstruktor.
	 * @param tokens tokeni
	 */
	public EchoNode(Token[] tokens) {
		super();
		this.tokens = tokens;
	}

	@Override
	public String getText() {

		String elements;

		int notNull = 0;
		while(tokens[notNull] != null) {
			notNull++;
		}

		elements = "{$= ";
		for (int i = 0; i < notNull; i++) {
			elements += tokens[i].asText() + " ";
		}
		elements += "$}";

		return elements;
	}

	@Override
	public void accept(INodeVisitor visitor) {
		visitor.visitEchoNode(this);
	}

	/**
	 * Getter za tokene unutar čvora.
	 * @return polje tokena unutar čvora
	 */
	public Token[] getTokens() {
		return tokens;
	}


}
