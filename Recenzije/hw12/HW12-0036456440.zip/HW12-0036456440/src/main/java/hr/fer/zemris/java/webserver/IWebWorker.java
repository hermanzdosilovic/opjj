package hr.fer.zemris.java.webserver;

/**
 * Sučelje koje predstavlja razred "radnika" na internetskom poslužitelju.
 * 
 * @author Luka Ruklić
 *
 */

public interface IWebWorker {

	/**
	 * Naredba koju implementira svaki radnik sa sučeljem IWebWorker, prima kontekst
	 * te pokreće obavljanje zahtjeva.
	 * 
	 * @param context kontekst zahtjeva
	 */

	public void processRequest(RequestContext context);

}
