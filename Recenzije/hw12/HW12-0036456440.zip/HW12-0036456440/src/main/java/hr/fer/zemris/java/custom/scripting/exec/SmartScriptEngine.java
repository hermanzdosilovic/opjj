package hr.fer.zemris.java.custom.scripting.exec;

import java.io.IOException;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.Locale;
import java.util.Stack;

import hr.fer.zemris.java.custom.scripting.nodes.DocumentNode;
import hr.fer.zemris.java.custom.scripting.nodes.EchoNode;
import hr.fer.zemris.java.custom.scripting.nodes.ForLoopNode;
import hr.fer.zemris.java.custom.scripting.nodes.INodeVisitor;
import hr.fer.zemris.java.custom.scripting.nodes.TextNode;
import hr.fer.zemris.java.custom.scripting.tokens.Token;
import hr.fer.zemris.java.custom.scripting.tokens.TokenConstantDouble;
import hr.fer.zemris.java.custom.scripting.tokens.TokenConstantInteger;
import hr.fer.zemris.java.custom.scripting.tokens.TokenFunction;
import hr.fer.zemris.java.custom.scripting.tokens.TokenOperator;
import hr.fer.zemris.java.custom.scripting.tokens.TokenString;
import hr.fer.zemris.java.custom.scripting.tokens.TokenVariable;
import hr.fer.zemris.java.webserver.RequestContext;

/**
 * Razred koji obavlja izvršavanje pametne skripte.
 * 
 * @author Luka Ruklić
 *
 */

public class SmartScriptEngine {

	/**
	 * Glavni čvor dokumenta dobivenog parsiranjem.
	 */
	private final DocumentNode documentNode;
	/**
	 * Kontekst zahtjeva.
	 */
	private final RequestContext requestContext;
	/**
	 * Instanca mape koja sprema primjerke stogova.
	 */
	private final ObjectMultistack multistack = new ObjectMultistack();

	/**
	 * Promatrač nad razredom koji izvršava "pametnu" skriptu.
	 */
	private final INodeVisitor visitor = new INodeVisitor() {

		@Override
		public void visitTextNode(TextNode node) {
			try {
				requestContext.write(node.getText());
			} catch (final IOException e) {
				System.out.println("Could not open stream for writing.");
			}
		}

		@Override
		public void visitForLoopNode(ForLoopNode node) {
			final ValueWrapper startExpression = new ValueWrapper(node.getStartExpression().asText());
			final ValueWrapper endExpression = new ValueWrapper(node.getEndExpression().asText());
			ValueWrapper stepExpression = new ValueWrapper(1);
			if (node.getStepExpression() != null) {
				stepExpression = new ValueWrapper(node.getStepExpression().asText());
			}

			multistack.push(node.getVariable().getName(), startExpression);

			while (endExpression.numCompare(startExpression) != -1) {
				for (int i = 0; i < node.numberofChildren(); i++) {
					node.getChild(i).accept(this);
				}
				multistack.peek(node.getVariable().getName()).increment(stepExpression);
			}
			multistack.pop(node.getVariable().getName());

		}

		@Override
		public void visitEchoNode(EchoNode node) {
			final Stack<ValueWrapper> temporaryStack = new Stack<>();

			for (final Token token : node.getTokens()) {
				if (token instanceof TokenConstantInteger || token instanceof TokenConstantDouble ||
						token instanceof TokenString) {
					temporaryStack.push(new ValueWrapper(token.asText()));
				}
				if (token instanceof TokenVariable) {
					final String variableName = ((TokenVariable) token).getName();
					if (variableName == null) {
						throw new IllegalArgumentException("Variable "+variableName+" does not exist in current context.");
					}
					final ValueWrapper currentValue = new ValueWrapper(multistack.peek(variableName).getValue());
					temporaryStack.push(currentValue);
				}
				if (token instanceof TokenOperator) {
					final ValueWrapper secondArgument = temporaryStack.pop();
					final ValueWrapper firstArgument = temporaryStack.pop();
					if (firstArgument == null || secondArgument == null) {
						throw new IllegalArgumentException("Not enough argument on stack for chosen operation.");
					}
					final String operator = ((TokenOperator) token).getName();

					operatorTokenChooser(temporaryStack, secondArgument, firstArgument, operator);
				}
				if (token instanceof TokenFunction) {
					final String functionName = ((TokenFunction) token).getName();
					if (functionName.equals("@sin")) {
						final ValueWrapper firstArgument = temporaryStack.pop();
						final Double firstArgDouble = firstArgument.toDoubleCast()*Math.PI/180;
						final double x = Math.sin(firstArgDouble);
						temporaryStack.push(new ValueWrapper(x));
					}
					else if (functionName.equals("@decfmt")) {
						final ValueWrapper formatArgument = temporaryStack.pop();
						final ValueWrapper firstArgument = temporaryStack.pop();
						final DecimalFormat df = new DecimalFormat(formatArgument.toStringCast(),
								new DecimalFormatSymbols(Locale.US));
						String x = df.format(firstArgument.toDoubleCast());
						x = x.replace("\"", "");
						temporaryStack.push(new ValueWrapper(x));
					}
					else if (functionName.equals("@paramGet")) {
						final ValueWrapper defaultValue = temporaryStack.pop();
						final String name = temporaryStack.pop().getValue().toString();
						final String value = requestContext.getParameter(name);
						if (value == null) {
							temporaryStack.push(defaultValue);
						} else {
							temporaryStack.push(new ValueWrapper(value));
						}
					}
					else if (functionName.equals("@dup")) {
						final Object value = temporaryStack.pop().getValue();
						temporaryStack.push(new ValueWrapper(value));
						temporaryStack.push(new ValueWrapper(value));
					}
					else if (functionName.equals("@swap")) {
						final ValueWrapper a = temporaryStack.pop();
						final ValueWrapper b = temporaryStack.pop();
						temporaryStack.push(a);
						temporaryStack.push(b);
					}
					else if (functionName.equals("@setMimeType")) {
						final String type = temporaryStack.pop().getValue().toString();
						requestContext.setMimeType(type);
					}
					else if (functionName.equals("@pparamGet")) {
						final ValueWrapper defaultValue = temporaryStack.pop();
						final String name = temporaryStack.pop().getValue().toString();
						final String value = requestContext.getPersistentParameter(name);
						if (value == null) {
							temporaryStack.push(defaultValue);
						} else {
							temporaryStack.push(new ValueWrapper(value));
						}
					}
					else if (functionName.equals("@tparamGet")) {
						final ValueWrapper defaultValue = temporaryStack.pop();
						final String name = temporaryStack.pop().getValue().toString();
						final String value = requestContext.getTemporaryParameter(name);
						if (value == null) {
							temporaryStack.push(defaultValue);
						} else {
							temporaryStack.push(new ValueWrapper(value));
						}
					}
					else if (functionName.equals("@pparamSet")) {
						final String name = temporaryStack.pop().getValue().toString();
						final String value = temporaryStack.pop().getValue().toString();
						requestContext.setPersistentParameter(name, value);
					}
					else if (functionName.equals("@tparamSet")) {
						final String name = temporaryStack.pop().getValue().toString();
						final String value = temporaryStack.pop().getValue().toString();
						requestContext.setTemporaryParameter(name, value);
					}
					else if (functionName.equals("@pparamDel")) {
						final String name = temporaryStack.pop().getValue().toString();
						requestContext.removePersistentParameter(name);
					}
					else if (functionName.equals("@tparamDel")) {
						final String name = temporaryStack.pop().getValue().toString();
						requestContext.removeTemporaryParameter(name);
					}
				}
			}

			for (final ValueWrapper wrapper : temporaryStack) {
				try {
					requestContext.write(wrapper.getValue().toString());
				} catch (final IOException e) {
					System.out.println("Could not open stream for writing.");
				}
			}
		}

		/**
		 * Metoda koja izvršava računsku operaciju u ovisnosti o sadržaju primljenog tokena.
		 * 
		 * @param temporaryStack privremeni stog s argumentima
		 * @param secondArgument prvi argument primljen sa stoga
		 * @param firstArgument drugi argument primljen sa stoga
		 * @param operator token koji određuje računsku operaciju
		 */

		private void operatorTokenChooser(Stack<ValueWrapper> temporaryStack,
				ValueWrapper secondArgument, ValueWrapper firstArgument,
				String operator) {
			if (operator.equals("+")) {
				firstArgument.increment(secondArgument);
				temporaryStack.push(firstArgument);
			}
			else if (operator.equals("-")) {
				firstArgument.decrement(secondArgument);
				temporaryStack.push(firstArgument);
			}
			else if (operator.equals("*")) {
				firstArgument.multiply(secondArgument);
				temporaryStack.push(firstArgument);
			}
			else if (operator.equals("/")) {
				firstArgument.divide(secondArgument);
				temporaryStack.push(firstArgument);
			}
		}

		@Override
		public void visitDocumentNode(DocumentNode node) {
			for (int i = 0; i < node.numberofChildren(); i++) {
				node.getChild(i).accept(this);
			}
		}
	};

	/**
	 * Konstruktor.
	 * 
	 * @param documentNode glavni čvor dokumenta dobivenog parsiranjem
	 * @param requestContext kontekst zahtjeva
	 */
	public SmartScriptEngine(DocumentNode documentNode, RequestContext requestContext) {
		this.documentNode = documentNode;
		this.requestContext = requestContext;
	}

	/**
	 * Izvršna metoda koja poziva promatrača nad glavni čvor.
	 */
	public void execute() {
		documentNode.accept(visitor);
	}

}
