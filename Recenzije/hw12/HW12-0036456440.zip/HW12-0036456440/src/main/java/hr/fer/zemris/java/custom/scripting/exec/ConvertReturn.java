package hr.fer.zemris.java.custom.scripting.exec;

/**
 * Pomoćni razred koji prima objekte i boolean vrijednost koja govori da li su obadvije
 * primljene vrijednosti Integer.
 * 
 * @author Luka Ruklić
 *
 */

public class ConvertReturn {

	private final Object first;
	private final Object second;
	private final boolean bothInt;

	/**
	 * Konstruktor razreda ConvertReturn.
	 * 
	 * @param first prvi objekt
	 * @param second drugi objekt
	 * @param bothInt vrijednost koja govori da li su oba primljena objekta Integer
	 */

	public ConvertReturn(Object first, Object second, boolean bothInt) {
		this.first = first;
		this.second = second;
		this.bothInt = bothInt;
	}

	/**
	 * Getter objekta first
	 * @return objekt first
	 */

	public Object getFirst() {
		return first;
	}

	/**
	 * Getter objekta first
	 * @return objekt first
	 */

	public Object getSecond() {
		return second;
	}

	/**
	 * Getter boolean vrijednosti bothInt
	 * @return boolean vrijednost bothInt
	 */

	public boolean getBothInt() {
		return bothInt;
	}

}
