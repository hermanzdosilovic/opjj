package hr.fer.zemris.java.custom.scripting.tokens;

/**
 * Druga domaća zadaća, treći zadatak
 * Razred koji realizira TokenString.
 * 
 * @author Luka Ruklić, 0036456440
 */


public class TokenString extends Token {

	private final String value;

	/**
	 * Konstruktor razreda TokenString
	 */

	public TokenString(String value) {
		super();
		final String newValue = value.substring(1, value.length()-1);
		this.value = newValue;
	}

	/**
	 * Metoda koja vraća vrijednost privatne varijable value.
	 */

	public String getvalue() {

		return this.value;
	}

	/**
	 * Nadjačana metoda razreda Token koja vraća vrijednost privatne varijable value.
	 */

	@Override
	public String asText() {

		return this.value;
	}

}
