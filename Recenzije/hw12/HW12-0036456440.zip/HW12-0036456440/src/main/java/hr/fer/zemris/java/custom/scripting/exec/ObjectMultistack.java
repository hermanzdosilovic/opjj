package hr.fer.zemris.java.custom.scripting.exec;

import java.util.EmptyStackException;
import java.util.HashMap;
import java.util.Map;

/**
 * <p>Razred koji implementira ObjectMultistack, posebnu vrstu mape koja sprema instance stogova.</p>
 * <p>U sklopu ovog razreda podržane su standardne metode rada sa stogovima: <code>push, peek, pop
 * </code> i <code>isEmpty</code>.
 * 
 * @author Luka Ruklić
 *
 */

public class ObjectMultistack {

	Map<String, MultistackEntry> multistack = new HashMap<>();

	/**
	 * Push metoda koja stavlja vrijednost ValueWrapper na MultistackEntry implementaciju stoga
	 * koja se u mapi nalazi pod imenom <code>name</code>. Ukoliko stog s tim imenom ne postoji,
	 * stvara se novi.
	 * 
	 * @param name naziv stoga na koji se dodaje
	 * @param valueWrapper vrijednost koja se stavlja na stog
	 */

	public void push(String name, ValueWrapper valueWrapper) {

		if (multistack.containsKey(name)) {
			final MultistackEntry entry = this.multistack.get(name);
			entry.stackImpl.add(valueWrapper);
		}
		else {
			final MultistackEntry entry = new MultistackEntry();
			entry.stackImpl.add(valueWrapper);
			this.multistack.put(name, entry);
		}

	}

	/**
	 * Pop metoda koja miče vrijednost ValueWrapper sa MultistackEntry implementacije stoge
	 * koja se u mapi nalazi pod imenom <code>name</code>. Kao povratna vrijednost vraća se
	 * vrijednost ValueWrapper skinuta sa stoga.
	 * 
	 * @param name naziv stoga na koji se dodaje
	 * @return vrijednost ValueWrapper skinuta sa stoga
	 */

	public ValueWrapper pop(String name) {
		Integer topOfStack;
		try {
			topOfStack = multistack.get(name).stackImpl.size();
		}
		catch (final NullPointerException e) {
			throw e;
		}
		if (topOfStack == 0) {
			throw new EmptyStackException();
		}
		final ValueWrapper popReturn = peek(name);

		this.multistack.get(name).stackImpl.remove(topOfStack-1);
		if (this.multistack.get(name).stackImpl.size() == 0) {
			multistack.remove(name);
		}

		return popReturn;

	}

	/**
	 * Peek metoda koja vraća vrijednost ValueWrapper sa MultistackEntry implementacije stoge
	 * koja se u mapi nalazi pod imenom <code>name</code>. Kao povratna vrijednost vraća se
	 * vrijednost ValueWrapper skinuta sa stoga. Razlika od metoda Pop je u tome što Peek ne
	 * miče element koji gleda sa stoga. Ukoliko takav element ne postoji, metoda vraća
	 * <i>null</i> vrijednost.
	 * 
	 * @param name naziv stoga na koji se dodaje
	 * @return vrijednost ValueWrapper s vrha stoga
	 */

	public ValueWrapper peek(String name) {
		final Integer topOfStack = multistack.get(name).stackImpl.size();
		if (topOfStack == null) {
			System.out.println("No entries with that name.");
			return null;
		}

		if (topOfStack == 0) {
			System.out.println("Given entry is empty.");
			return null;
		}

		return this.multistack.get(name).stackImpl.get(topOfStack-1);
	}

	/**
	 * Metoda koja provjerava da li u mapi postoji stog s odgovarajućim imenom
	 * @param name naziv stoga koji se traži
	 * @return true ukoliko stog ne postoji, false inače
	 */

	public boolean isEmpty(String name) {
		return !multistack.containsKey(name);
	}

}
