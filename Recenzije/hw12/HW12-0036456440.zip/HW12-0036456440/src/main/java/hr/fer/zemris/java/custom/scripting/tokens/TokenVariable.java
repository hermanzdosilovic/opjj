package hr.fer.zemris.java.custom.scripting.tokens;

/**
 * Druga domaća zadaća, treći zadatak
 * Razred koji realizira TokenVariable.
 * 
 * @author Luka Ruklić, 0036456440
 */


public class TokenVariable extends Token{

	private final String name;

	/**
	 * Konstruktor razreda TokenVariable
	 */

	public TokenVariable(String name) {
		super();
		if (name.length() > 2) {
			final String newName = name.substring(1, name.length()-2);
			name = newName;
		}
		this.name = name;
	}

	/**
	 * Metoda koja vraća vrijednost privatne varijable name.
	 */

	public String getName() {

		return this.name;
	}

	/**
	 * Nadjačana metoda razreda Token koja vraća vrijednost privatne varijable name.
	 */

	@Override
	public String asText() {

		return this.name;
	}

}
