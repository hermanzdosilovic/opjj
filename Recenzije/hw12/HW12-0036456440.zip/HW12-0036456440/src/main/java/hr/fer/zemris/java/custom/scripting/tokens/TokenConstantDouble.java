package hr.fer.zemris.java.custom.scripting.tokens;

/**
 * Druga domaća zadaća, treći zadatak
 * Razred koji realizira TokenConstantDouble.
 * 
 * @author Luka Ruklić, 0036456440
 */


public class TokenConstantDouble extends Token {
	
	private double value;
	
	/**
	 * Konstruktor razreda TokenConstantDouble
	 */
	
	public TokenConstantDouble(double value) {
		super();
		this.value = value;
	}

	/**
	 * Metoda koja vraća vrijednost privatne varijable value.
	 */
	
	public double getvalue() {
		
		return this.value;
	}
	
	/**
	 * Nadjačana metoda razreda Token koja vraća vrijednost privatne varijable value.
	 */
	
	@Override
	public String asText() {
		
		return String.valueOf(value);
	}

}
