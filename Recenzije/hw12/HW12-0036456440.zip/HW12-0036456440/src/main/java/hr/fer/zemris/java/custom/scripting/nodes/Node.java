package hr.fer.zemris.java.custom.scripting.nodes;

import hr.fer.zemris.java.custom.collections.ArrayBackedIndexedCollection;

/**
 * Druga domaća zadaća, treći zadatak
 * Razred koji realizira Node.
 * 
 * @author Luka Ruklić, 0036456440
 */

public abstract class Node {

	ArrayBackedIndexedCollection nodeRepresentation = new ArrayBackedIndexedCollection();

	/**
	 * Metoda koja dodaje dijete čvoru.
	 * @param child dijete koje se dodaje čvoru
	 */

	public void addChildNode(Node child) {

		nodeRepresentation.add(child);

	}

	/**
	 * Metoda koja broji koliko djece ima dani čvor.
	 * @return broj djece danog čvora
	 */

	public int numberofChildren() {

		return nodeRepresentation.size();

	}

	/**
	 * Metoda koja dohvaća dijete čvora.
	 * @param index indeks djeteta kojeg dohvaćamo
	 * @return vrijednost čvora djeteta
	 */

	public Node getChild(int index) {

		return (Node) nodeRepresentation.get(index);

	}

	/**
	 * Metoda koja vraća prazan string, nadjačana u drugim metodama podklasa.
	 */

	public abstract String getText();

	/**
	 * Metoda koja omogućava posjetioce nad čvorom.
	 * 
	 * @param visitor instanca posjetioca koja se prolazi nad čvorom
	 */

	public abstract void accept(INodeVisitor visitor);

}
