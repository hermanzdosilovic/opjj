package hr.fer.zemris.java.custom.scripting.nodes;

import hr.fer.zemris.java.custom.scripting.tokens.Token;
import hr.fer.zemris.java.custom.scripting.tokens.TokenVariable;

/**
 * Druga domaća zadaća, treći zadatak
 * Razred koji realizira ForLoopNode s pripadajućim konstruktorom i getterima za svaku pojedinu privatnu varijablu.
 * 
 * @author Luka Ruklić, 0036456440
 */

public class ForLoopNode extends Node {

	private final TokenVariable variable;
	private final Token startExpression;
	private final Token endExpression;
	private final Token stepExpression;

	/**
	 * Metoda koja vraća varijablu for petlje po kojoj se iterira.
	 * @return token koji predstavlja varijablu for petlje
	 */
	public TokenVariable getVariable() {
		return variable;
	}
	/**
	 * Metoda koja vraća token koji predstavlja početnu vrijednost for petlje.
	 * @return početna vrijednost for petlje
	 */
	public Token getStartExpression() {
		return startExpression;
	}
	/**
	 * Metoda koja vraća token koji predstavlja konačnu vrijednost for petlje.
	 * @return konačna vrijednost for petlje
	 */
	public Token getEndExpression() {
		return endExpression;
	}
	/**
	 * Metoda koja vraća token koji predstavlja pomak prilikom svake iteracije for petlje.
	 * @return vrijednost za koju for petlja iterira
	 */
	public Token getStepExpression() {
		return stepExpression;
	}

	public ForLoopNode(TokenVariable variable, Token startExpression,
			Token endExpression, Token stepExpression) {
		super();
		this.variable = variable;
		this.startExpression = startExpression;
		this.endExpression = endExpression;
		this.stepExpression = stepExpression;
	}

	@Override
	public String getText() {

		if (stepExpression == null) {
			return "{$ FOR " + getVariable().asText() + " " + getStartExpression().asText() + " " + getEndExpression().asText() + " $}";
		}
		else {
			return "{$ FOR " + getVariable().asText() + " " + getStartExpression().asText() + " " + getEndExpression().asText() + " " + getStepExpression().asText() + " $}";
		}


	}
	@Override
	public void accept(INodeVisitor visitor) {
		visitor.visitForLoopNode(this);
	}


}
