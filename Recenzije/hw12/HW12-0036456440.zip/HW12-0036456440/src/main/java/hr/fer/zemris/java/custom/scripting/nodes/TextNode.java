package hr.fer.zemris.java.custom.scripting.nodes;

/**
 * Druga domaća zadaća, treći zadatak
 * Razred koji realizira TextNode s pripadajućim konstruktorom i getterom za vrijednost privatne varijable text.
 * 
 * @author Luka Ruklić, 0036456440
 */

public class TextNode extends Node{

	/**
	 * Tekst tekstualnog čvora.
	 */
	private final String text;

	/**
	 * Konstruktor.
	 * 
	 * @param text tekst
	 */
	public TextNode (String text) {
		this.text = text;
	}

	@Override
	public String getText() {
		return text;
	}

	@Override
	public void accept(INodeVisitor visitor) {
		visitor.visitTextNode(this);
	}

}
