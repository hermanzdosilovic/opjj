package hr.fer.zemris.java.custom.scripting.tokens;

/**
 * Druga domaća zadaća, treći zadatak
 * Razred koji realizira TokenConstantInteger.
 * 
 * @author Luka Ruklić, 0036456440
 */

public class TokenConstantInteger extends Token{
	
	private int value;
	
	/**
	 * Konstruktor razreda TokenConstantInteger
	 */
	
	public TokenConstantInteger(int value) {
		super();
		this.value = value;
	}
	
	/**
	 * Metoda koja vraća vrijednost privatne varijable value.
	 */
	
	public int getvalue() {
		
		return this.value;
	}
	
	/**
	 * Nadjačana metoda razreda Token koja vraća vrijednost privatne varijable value.
	 */
	
	@Override
	public String asText() {
		
		return String.valueOf(value);
	}

}
