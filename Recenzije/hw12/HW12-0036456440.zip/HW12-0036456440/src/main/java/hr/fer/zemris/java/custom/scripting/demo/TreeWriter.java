package hr.fer.zemris.java.custom.scripting.demo;

import hr.fer.zemris.java.custom.scripting.nodes.DocumentNode;
import hr.fer.zemris.java.custom.scripting.nodes.EchoNode;
import hr.fer.zemris.java.custom.scripting.nodes.ForLoopNode;
import hr.fer.zemris.java.custom.scripting.nodes.INodeVisitor;
import hr.fer.zemris.java.custom.scripting.nodes.TextNode;
import hr.fer.zemris.java.custom.scripting.parser.SmartScriptParser;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

/**
 * Razred za testiranje posjetitelj obrasca nad razredom SmartScriptParser.
 * 
 * @author Luka Ruklić
 *
 */

public class TreeWriter {

	public static void main(String[] args) throws IOException {

		if (args.length != 1) {
			throw new IllegalArgumentException("One argument expected: pathToSmartScriptTxt");
		}

		String docBody = readFile(args[0]);
		SmartScriptParser p = new SmartScriptParser(docBody);
		WriterVisitor visitor = new WriterVisitor();
		p.getDocumentNode().accept(visitor);

	}

	/**
	 * Razred koji implementira posjetioca koji prolazi po strukturi dobivenoj od parsera
	 * te ispisuje stablo.
	 *
	 * @author Luka Ruklić
	 *
	 */

	public static class WriterVisitor implements INodeVisitor {

		@Override
		public void visitTextNode(TextNode node) {
			System.out.print(node.getText());
		}

		@Override
		public void visitForLoopNode(ForLoopNode node) {
			System.out.print(node.getText());
			for (int i = 0; i < node.numberofChildren(); i++) {
				node.getChild(i).accept(this);
			}
			System.out.print("{$ END $}");
		}

		@Override
		public void visitEchoNode(EchoNode node) {
			System.out.print(node.getText());
		}

		@Override
		public void visitDocumentNode(DocumentNode node) {
			System.out.print(node.getText());
			for (int i = 0; i < node.numberofChildren(); i++) {
				node.getChild(i).accept(this);
			}
		}

	}

	/**
	 * Metoda koja učitava datoteku u string.
	 * 
	 * @param fileName naziv datoteke koja se učitava
	 * @return string u koji je datoteka učitana
	 * @throws IOException ukoliko metoda nije uspjela otvoriti datoteku
	 */
	public static String readFile(String fileName) throws IOException {
		BufferedReader br = new BufferedReader(new FileReader(fileName));
		try {
			StringBuilder sb = new StringBuilder();
			String line = br.readLine();

			while (line != null) {
				sb.append(line);
				sb.append("\n");
				line = br.readLine();
			}
			return sb.toString();
		} finally {
			br.close();
		}
	}

}
