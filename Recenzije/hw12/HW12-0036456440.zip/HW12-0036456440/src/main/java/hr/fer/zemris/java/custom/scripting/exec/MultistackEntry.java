package hr.fer.zemris.java.custom.scripting.exec;

import java.util.ArrayList;
import java.util.List;

/**
 * Razred koji predstavlja unose u mapu <code>multistack</code> definiranu u razred ObjectMultistack.
 * Lista <code>stackImpl</code> predstavlja stog te sadrži zapise tipa ValueWrapper.
 * 
 * @author Luka Ruklić
 *
 */

public class MultistackEntry {

	List<ValueWrapper> stackImpl = new ArrayList<>();

	/**
	 * Getter metoda koja dohvaća člansku listu stackImpl
	 * @return članska lista stackImpl
	 */

	public List<ValueWrapper> getStackImpl() {
		return stackImpl;
	}

}
