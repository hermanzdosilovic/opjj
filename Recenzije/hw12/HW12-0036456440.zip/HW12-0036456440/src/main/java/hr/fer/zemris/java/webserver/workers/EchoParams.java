package hr.fer.zemris.java.webserver.workers;

import java.io.IOException;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

import hr.fer.zemris.java.webserver.IWebWorker;
import hr.fer.zemris.java.webserver.RequestContext;

/**
 * Razred koji implementira poslužiteljskog radnika koji ispisuje
 * primljene argumente.
 * 
 * @author Luka Ruklić
 *
 */

public class EchoParams implements IWebWorker {

	@Override
	public void processRequest(RequestContext context) {

		context.setMimeType("text/plain");
		Iterator<Entry<String, String>> it = context.getParameters().entrySet().iterator();
		while (it.hasNext()) {
			Map.Entry<String,String> pairs = it.next();
			try {
				context.write(pairs.getKey() + " = " + pairs.getValue()+"\n");
			} catch (IOException e) {
				e.printStackTrace();
			}
			it.remove();
		}

	}

}
