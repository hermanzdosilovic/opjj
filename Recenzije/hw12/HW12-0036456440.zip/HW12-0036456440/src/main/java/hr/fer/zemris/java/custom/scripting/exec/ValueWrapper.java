package hr.fer.zemris.java.custom.scripting.exec;

/**
 * Razred koji implementira omotač oko vrijednosti nekog objekta. Implementiran je na način da
 * je u njega moguće spremiti vrijednosti tipa Integer, Double ili String. Također su podržane
 * osnovne aritmetičke operacije nad njim, kao i metoda NumCompare.
 * 
 * @author Luka Ruklić
 *
 */

public class ValueWrapper {

	private Object value;

	/**
	 * Konstruktor razreda ValueWrapper, sprema primljeni objekt u člansku varijablu <code>value</code>.
	 * Ukoliko je objekt null, smatra se da je primljen Integer vrijednosti 0.
	 * 
	 * @param value vrijednost koja se sprema u člansku varijablu <code>value</code>
	 */

	public ValueWrapper(Object value) {
		this.setValue(value);
	}

	/**
	 * Getter za varijablu value.
	 * 
	 * @return vrijednost varijable value
	 */

	public Object getValue() {
		return value;
	}

	/**
	 * Setter za varijablu value.
	 * 
	 * @param value vrijednost na koju se postavlja članska varijabla value
	 */

	public void setValue(Object value) {

		if (value instanceof Integer || value instanceof Double || value instanceof String || value == null) {
			if (value == null) {
				this.value = new Integer(0);
			}
			else {
				this.value = value;
			}
		}
		else {
			throw new IllegalArgumentException("Value can be only Integer, Double, String or null.");
		}

	}

	public double toDoubleCast() {

		if (value instanceof Double) {
			return (Double) value;
		}
		else if (value instanceof Integer) {
			return ((Integer)value).doubleValue();
		}
		else if (value instanceof String) {
			return Double.parseDouble((String) value);
		}
		else {
			System.out.println("Cannot parse "+value+" to double");
			return 0;
		}
	}

	public double toIntegerCast() {
		Integer valueInteger;

		try {
			valueInteger = (Integer)value;
		} catch (final ClassCastException ex) {
			System.out.println("Failure while casting "+value+" to Integer.");
			return 0;
		}
		return valueInteger;
	}

	public String toStringCast() {
		String valueString;

		try {
			valueString = (String)value;
		} catch (final ClassCastException ex) {
			System.out.println("Failure while casting "+value+" to String.");
			return "";
		}
		return valueString;
	}


	/**
	 * Metoda koja prima dva objekta te određuje njihov tip (String, Integer ili Double).
	 * Kao povratnu vrijednost vraća instancu pomoćnog razreda ConvertReturn. Metoda
	 * također pretvara String tipove u odgovarajuću Integer ili Double vrijednost.
	 * 
	 * @param value1 prvi primljeni objekt kojem se određuje tip
	 * @param value2 drugi primljeni objekt kojem se određuje tip
	 * @return instanca razreda ConvertReturn
	 */

	private static ConvertReturn valueConverter(Object value1, Object value2) {

		if (value1 == null) {
			value1 = new Integer(0);
		}

		if (value2 == null) {
			value2 = new Integer(0);
		}

		if (value1 instanceof ValueWrapper) {
			value1 = ((ValueWrapper) value1).getValue();
		}

		if (value2 instanceof ValueWrapper) {
			value2 = ((ValueWrapper) value2).getValue();
		}

		if (value1 instanceof String) {
			try {
				value1 = Integer.parseInt((String) value1);
			}
			catch (final NumberFormatException e) {
				try {
					value1 = Double.parseDouble((String) value1);
				}
				catch (final NumberFormatException f) {
					throw new IllegalArgumentException("String cannot be parse to Integer or Double.");
				}
			}
		}

		if (value2 instanceof String) {
			try {
				value2 = Integer.parseInt((String) value2);
			}
			catch (final NumberFormatException e) {
				try {
					value2 = Double.parseDouble((String) value2);
				}
				catch (final NumberFormatException f) {
					throw new IllegalArgumentException("String cannot be parse to Integer or Double.");
				}
			}
		}

		if (value1 instanceof Integer && value2 instanceof Integer) {
			return new ConvertReturn(value1, value2, true);
		}
		else {
			return new ConvertReturn(value1, value2, false);
		}

	}

	/**
	 * Metoda koja obavlja aritmetičku operaciju nad dva objekta ukoliko je prvi
	 * objekt izvorno tipa Integer, a drugi tipa Double.
	 * 
	 * @param values vrijednosti dobivenih objekata
	 * @param firstD prvi objekt, izvorno tipa Integer
	 * @param operator numerički operator koji određuje tip operacije
	 * @return objekt dobiven aritmetičkom operacijom
	 */

	private Object calculateFirst(ConvertReturn values, double firstD, char operator) {
		if (operator == '+') {
			return this.value = firstD + (Double)values.getSecond();
		}
		else if (operator == '-') {
			return this.value = firstD - (Double)values.getSecond();
		}
		else if (operator == '*') {
			return this.value = firstD * (Double)values.getSecond();
		}
		else {
			return this.value = firstD / (Double)values.getSecond();
		}
	}

	/**
	 * Metoda koja obavlja aritmetičku operaciju nad dva objekta ukoliko je prvi
	 * objekt izvorno tipa Double, a drugi tipa Integer.
	 * 
	 * @param values vrijednosti dobivenih objekata
	 * @param secondD drugi objekt, izvorno tipa Integer
	 * @param operator numerički operator koji određuje tip operacije
	 * @return objekt dobiven aritmetičkom operacijom
	 */

	private Object calculateSecond(ConvertReturn values, double secondD, char operator) {
		if (operator == '+') {
			return this.value = (Double)values.getFirst() + secondD;
		}
		else if (operator == '-') {
			return this.value = (Double)values.getFirst() - secondD;
		}
		else if (operator == '*') {
			return this.value = (Double)values.getFirst() * secondD;
		}
		else {
			return this.value = (Double)values.getFirst() / secondD;
		}
	}

	/**
	 * Metoda koja obavlja aritmetičku operaciju ukoliko su oba objekta istog tipa, Integer
	 * ili Double.
	 * 
	 * @param values vrijednosti objekata
	 * @param operator numerički operator koji određuje tip aritmetičke operacije
	 * @param isInteger boolean vrijednost koja određuje da li se operacija obavlja nad
	 * Integerima ili Doubleovima
	 * @return objekt dobiven aritmetičkom operacijom
	 */

	private Object calculateIntegerOrDouble(ConvertReturn values, char operator, boolean isInteger) {
		if (isInteger) {
			if (operator == '+') {
				return this.value = (Integer)values.getFirst() + (Integer)values.getSecond();
			}
			else if (operator == '-') {
				return this.value = (Integer)values.getFirst() - (Integer)values.getSecond();
			}
			else if (operator == '*') {
				return this.value = (Integer)values.getFirst() * (Integer)values.getSecond();
			}
			else {
				return this.value = (Integer)values.getFirst() / (Integer)values.getSecond();
			}
		}

		else {
			if (operator == '+') {
				return this.value = (Double)values.getFirst() + (Double)values.getSecond();
			}
			else if (operator == '-') {
				return this.value = (Double)values.getFirst() - (Double)values.getSecond();
			}
			else if (operator == '*') {
				return this.value = (Double)values.getFirst() * (Double)values.getSecond();
			}
			else {
				return this.value = (Double)values.getFirst() / (Double)values.getSecond();
			}
		}


	}

	/**
	 * Metoda koja prima veličinu s kojom vrši računsku operaciju i operator koji određuje vrstu operacije
	 * te vraća objekt dobiven tom računskom operacijom.
	 * @param numValue vrijednost s kojom vrši računsku operaciju
	 * @param operator operator koji određuje vrstu računske operacije
	 * @return objekt dobiven računskom operacijom
	 */

	private Object numericOperation(Object numValue, char operator) {
		final ConvertReturn values = valueConverter(this.value, numValue);
		if (values.getBothInt()) {
			return calculateIntegerOrDouble(values, operator, true);
		}
		else {
			try {
				final int first = (Integer)values.getFirst();
				final double firstD = first;
				return calculateFirst(values, firstD, operator);
			}
			catch (final ClassCastException e) {
			}
			try {
				final int second = (Integer)values.getSecond();
				final double secondD = second;
				return calculateSecond(values, secondD, operator);
			}
			catch (final ClassCastException e) {
			}

			return calculateIntegerOrDouble(values, operator, false);
		}
	}

	/**
	 * Metoda koja početnom objektu pribraja zadani objekt incValue.
	 * 
	 * @param incValue vrijednost koja se pribraja novom objektu
	 */

	public void increment(Object incValue) {
		this.setValue(numericOperation(incValue, '+'));
	}

	/**
	 * Metoda koja od početnog objekta oduzima zadani objekt decValue.
	 * 
	 * @param devValue vrijednost koja se pribraja novom objektu
	 */

	public void decrement(Object decValue) {
		this.setValue(numericOperation(decValue, '-'));
	}

	/**
	 * Metoda koja početni objekt množi sa zadani objektom mulValue.
	 * 
	 * @param mulValue vrijednost s kojom se množi početni objekt
	 */

	public void multiply(Object mulValue) {
		this.setValue(numericOperation(mulValue, '*'));
	}

	/**
	 * Metoda koja početni objekt dijeli sa zadani objektom divValue.
	 * 
	 * @param divValue vrijednost s kojom se dijeli početni objekt
	 */

	public void divide(Object divValue) {
		this.setValue(numericOperation(divValue, '/'));
	}

	/**
	 * Metoda koja uspoređuje dva broja numerički po veličini.
	 * 
	 * @param firstValue prvi broj koji se uspoređuje
	 * @param secondValue drugi broj koji se uspoređuje
	 * @return 0 ukoliko su brojevi isti, 1 ukoliko je početni broj veći, -1 inače
	 */

	public int comparison(double firstValue, double secondValue) {
		if (firstValue < secondValue) {
			return -1;
		}
		else if (firstValue > secondValue) {
			return 1;
		}
		else {
			return 0;
		}
	}

	/**
	 * Metoda koja početni objekt uspoređuje sa zadanim objektom withValue.
	 * 
	 * @param withValue vrijednost s kojom se uspoređuje početni objekt
	 */

	public int numCompare(Object withValue) {
		final ConvertReturn values = valueConverter(this.value, withValue);

		if (values.getBothInt()) {
			final int firstValue = (Integer)values.getFirst();
			final int secondValue = (Integer)values.getSecond();
			return comparison(firstValue, secondValue);
		}

		else {
			try {
				final int first = (Integer)values.getFirst();
				final double firstD = first;
				return comparison(firstD, (double)values.getSecond());
			}
			catch (final ClassCastException e) {
			}
			try {
				final int second = (Integer)values.getSecond();
				final double secondD = second;
				return comparison((double)values.getFirst(), secondD);
			}
			catch (final ClassCastException e) {
			}

			final double firstValue = (double)values.getFirst();
			final double secondValue = (double)values.getSecond();
			return comparison(firstValue, secondValue);
		}

	}

}
