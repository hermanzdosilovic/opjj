package hr.fer.zemris.java.custom.collections;

/**
 * Druga domaća zadaća, drugi zadatak
 * Razred koji realizira funkcionalnost stoga, temeljen na razredu iz prvog zadatka.
 * 
 * @author Luka Ruklić, 0036456440
 */

public class ObjectStack {

	ArrayBackedIndexedCollection stack = new ArrayBackedIndexedCollection();

	/**
	 * Metoda koja provjerava da li je stog prazan.
	 * @return true/false vrijednost da li je stog prazan
	 */

	public boolean isEmpty() {

		return stack.isEmpty();
	}

	/**
	 * Metoda koja mjeri veličinu stoga.
	 * @return integer vrijednost veličine stoga
	 */

	public int size() {

		return stack.size();
	}

	/**
	 * Metoda koja stavlja objekt na vrh stoga.
	 * @param vrijednost objekta kojeg stavljamo na stog
	 */

	public void push(Object value) {

		stack.add(value);
	}

	/**
	 * Metoda koja skida objekt s vrha stoga te ga vraća kao povratnu vrijednost.
	 * @return vrijednost objekta koji je maknut sa stoga
	 */

	public Object pop() {

		if (stack.size() == 0) {
			throw new EmptyStackException();
		}
		final Object popElement = stack.get(stack.size()-1);
		stack.remove(stack.size()-1);
		return popElement;
	}

	/**
	 * Metoda koja prikazuje objekta na vrhu stoga. Za razliku od metode pop(), ne miče ga sa stoga.
	 * @return vrijednost prikazanog objekta
	 */

	public Object peek() {

		if (stack.size() == 0) {
			throw new EmptyStackException();
		}
		return stack.get(stack.size()-1);
	}

	/**
	 * Metoda koja čisti stog.
	 */

	public void clear() {
		stack.clear();
	}

	/**
	 * Glavna metoda razreda.
	 * Služi za pokretanje i testiranje ostalih metoda.
	 */

	public static void main(String[] args) {
		final ObjectStack stog = new ObjectStack();
		System.out.println(stog.isEmpty());

		// stog.pop(); // EmptyStackException

		stog.push("New Jersey");
		stog.push("Cleveland");
		stog.push("Clevel");
		stog.push("Clev");
		stog.pop();
		System.out.println(stog.peek());	// ispise Cleveland
		System.out.println(stog.size());    // ispise 2

		stog.push("Sacramento");
		System.out.println(stog.size());	// ispise 3
		System.out.println(stog.pop());		// ispise Sacramento
		System.out.println(stog.size());    // ispise 2
		System.out.println(stog.pop());     // ispise Cleveland

		stog.push("Santa Fe");
		stog.push("Philadelphia");
		System.out.println(stog.peek());	// ispise Philadelphia
		System.out.println(stog.size());    // ispise 3
		stog.clear();
		System.out.println(stog.size());    // ispise 0
	}
}
