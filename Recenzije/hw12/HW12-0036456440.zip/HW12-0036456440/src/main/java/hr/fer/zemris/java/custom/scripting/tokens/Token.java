package hr.fer.zemris.java.custom.scripting.tokens;

/**
 * Druga domaća zadaća, treći zadatak
 * Razred koji realizira Token.
 * 
 * @author Luka Ruklić, 0036456440
 */

public class Token {

	/**
	 * Metoda koja vraća prazan string.
	 */

	public String asText() {

		final String emptyString = new String();
		return emptyString;
	}
}
