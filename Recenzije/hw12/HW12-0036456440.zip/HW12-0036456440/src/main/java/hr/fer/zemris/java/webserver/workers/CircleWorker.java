package hr.fer.zemris.java.webserver.workers;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.IOException;

import javax.imageio.ImageIO;

import hr.fer.zemris.java.webserver.IWebWorker;
import hr.fer.zemris.java.webserver.RequestContext;

/**
 * Razred koji implementira poslužiteljskog radnika koji iscrtava
 * sliku dimenzija 200x200 na kojoj je krug crvene boje.
 * 
 * @author Luka Ruklić
 *
 */

public class CircleWorker implements IWebWorker {

	@Override
	public void processRequest(RequestContext context) {

		BufferedImage bim = new BufferedImage(200, 200, BufferedImage.TYPE_3BYTE_BGR);

		context.setMimeType("images/png");

		Graphics2D g = bim.createGraphics();

		g.setColor(Color.WHITE);

		g.fillRect(0, 0, 200, 200);

		g.setColor(Color.RED);
		g.drawOval(0, 0, 200, 200);
		g.setColor(Color.RED);
		g.fillOval(0, 0, 200, 200);
		g.dispose();

		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		try {
			ImageIO.write(bim, "png", bos);
			context.write(bos.toByteArray());
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

}
