package hr.fer.zemris.java.custom.scripting.tokens;

/**
 * Druga domaća zadaća, treći zadatak
 * Razred koji realizira TokenFunction.
 * 
 * @author Luka Ruklić, 0036456440
 */


public class TokenFunction extends Token {

	private String name;

	/**
	 * Konstruktor razreda TokenFunction
	 */

	public TokenFunction(String name) {
		super();
		this.name = name;
	}

	/**
	 * Metoda koja vraća vrijednost privatne varijable name.
	 */

	public String getName() {

		return this.name;
	}

	/**
	 * Nadjačana metoda razreda Token koja vraća vrijednost privatne varijable name.
	 */

	@Override
	public String asText() {

		return this.name;
	}


}
