package hr.fer.zemris.java.custom.scripting.tokens;

/**
 * Druga domaća zadaća, treći zadatak
 * Razred koji realizira TokenOperator.
 * 
 * @author Luka Ruklić, 0036456440
 */


public class TokenOperator extends Token {

	private String symbol;

	/**
	 * Konstruktor razreda TokenOperator
	 */

	public TokenOperator(String symbol) {
		super();
		this.symbol = symbol;
	}

	/**
	 * Metoda koja vraća vrijednost privatne varijable symbol.
	 */

	public String getName() {

		return this.symbol;
	}

	/**
	 * Nadjačana metoda razreda Token koja vraća vrijednost privatne varijable symbol.
	 */

	@Override
	public String asText() {

		return this.symbol;
	}

}
