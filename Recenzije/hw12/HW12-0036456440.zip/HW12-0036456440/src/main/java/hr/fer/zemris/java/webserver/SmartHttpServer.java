package hr.fer.zemris.java.webserver;

import hr.fer.zemris.java.custom.scripting.exec.SmartScriptEngine;
import hr.fer.zemris.java.custom.scripting.parser.SmartScriptParser;
import hr.fer.zemris.java.webserver.RequestContext.RCCookie;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PushbackInputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Random;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Razred koji predstavlja mrežni poslužitelj koji može izvršavati "pametne" skripte
 * (engl. <i>Smartscript</i>).
 * 
 * @author Luka Ruklić
 *
 */

public class SmartHttpServer {

	/**
	 * IP adresa poslužitelja.
	 */
	private String address;
	/**
	 * Pristupna točka na kojoj je poslužitelj dostupan.
	 */
	private int port;
	/**
	 * Broj dretvi radnika.
	 */
	private int workerThreads;
	/**
	 * Vrijeme koliko jedna sjednica traje; u sekundama.
	 */
	private int sessionTimeout;
	/**
	 * Putanja do datoteke koja sadrži parove ekstenzija i <i>mime</i>-a.
	 */
	private String mimeTypesPath;
	/**
	 * Putanja do datoteke koja sadrži parove imena i razreda radnika.
	 */
	private String workerPath;
	/**
	 * Mapa s listama <i>mime</i>-a.
	 */
	private final Map<String, String> mimeTypes = new HashMap<String, String>();
	/**
	 * Poslužiteljska dretva.
	 */
	private ServerThread serverThread;
	/**
	 * Spremnik za dretve.
	 */
	private ExecutorService threadPool;
	/**
	 * Glavni "čvor" u kojem se nalazi sadržaj poslužitelja.
	 */
	private Path documentRoot;
	/**
	 * Mapa s instancama razreda radnika.
	 */
	private Map<String, IWebWorker> workersMap = new HashMap<String, IWebWorker>();
	/**
	 * Mapa s instancama sjednica.
	 */
	private Map<String, SessionMapEntry> sessions = new HashMap<String, SmartHttpServer.SessionMapEntry>();
	/**
	 * Instanca razreda koja generira nasumične brojeve.
	 */
	private Random sessionRandom = new Random();

	/**
	 * Glavna metoda koja pokreće poslužitelja.
	 * @param args ne prima nikakve argumente
	 * @throws IOException ukoliko nije moguće otvoriti datoteke.
	 */
	public static void main(String[] args) throws IOException {
		final SmartHttpServer server = new SmartHttpServer(args[0]);
		server.start();
	}

	/**
	 * Konstruktor.
	 * 
	 * @param configFileName putanja do datoteke sa poslužiteljskim postavkama
	 */
	public SmartHttpServer(String configFileName) {
		try {
			getProperties(configFileName);
			getMimeTypes(mimeTypesPath);
			getWorkersMap(workerPath);
		} catch (final IOException ex) {
			System.out.println("Reading config with server properties failed.");
		}
	}

	/**
	 * Metoda koja pokreće rad servera.
	 */
	protected synchronized void start() {

		if (serverThread == null) {
			final ExecutorService pool = Executors.newFixedThreadPool(workerThreads);
			this.threadPool = pool;
			final ServerThread sThread = new ServerThread();
			this.serverThread = sThread;
			this.serverThread.start();
			final CleanupThread cThread = new CleanupThread();
			cThread.start();
		}
	}

	/**
	 * Metoda koja zaustavlja rad servera.
	 */

	protected synchronized void stop() {
		this.threadPool.shutdownNow();
	}

	/**
	 * Metoda koja dohvaća <i>mime</i> postavke iz vanjske datoteke.
	 * @param propPath putanja do datoteke
	 * @throws IOException ukoliko nije moguće otvoriti datoteku s postavkama
	 */

	public void getMimeTypes(String mimePath) throws IOException {

		final Properties prop = new Properties();
		final InputStream inputStream = new FileInputStream(mimePath);
		prop.load(inputStream);

		for(final String key : prop.stringPropertyNames()) {
			final String value = prop.getProperty(key);
			this.mimeTypes.put(key, value);
		}
	}

	/**
	 * Metoda koja dohvaća postavke za poslužiteljske radnike iz vanjske datoteke.
	 * @param workerPath putanja do datoteke
	 * @throws IOException ukoliko nije moguće otvoriti datoteku s postavkama
	 */
	public void getWorkersMap(String workerPath) throws IOException {

		final Properties prop = new Properties();
		final InputStream inputStream = new FileInputStream(workerPath);
		prop.load(inputStream);

		for(final String path : prop.stringPropertyNames()) {
			final String fqcn = prop.getProperty(path);
			try {
				Class<?> referenceToClass = this.getClass().getClassLoader().loadClass(fqcn);
				Object newObject = referenceToClass.newInstance();
				IWebWorker iww = (IWebWorker)newObject;
				workersMap.put(path, iww);
			} catch (ClassNotFoundException | IllegalAccessException | InstantiationException ex) {
				System.out.println("Failed to add new worker to map.");
			}
		}
	}

	/**
	 * Metoda koja dohvaća poslužiteljske postavke iz vanjske datoteke.
	 * @param mimePath putanja do datoteke
	 * @throws IOException ukoliko nije moguće otvoriti datoteku s postavkama
	 */

	public void getProperties(String propPath) throws IOException {

		final Properties prop = new Properties();
		final InputStream inputStream = new FileInputStream(propPath);
		prop.load(inputStream);

		address = prop.getProperty("server.address", "127.0.0.1");
		port = Integer.parseInt(prop.getProperty("server.port", "80"));
		workerThreads = Integer.parseInt(prop.getProperty("server.workerThreads", "1"));
		sessionTimeout = Integer.parseInt(prop.getProperty("server.timeout", "1000"));
		documentRoot = Paths.get(prop.getProperty("server.documentRoot", "./root"));
		mimeTypesPath = prop.getProperty("server.mimeConfig", ".");
		workerPath = prop.getProperty("server.workers", ".");


	}

	/**
	 * Razred koji predstavlja glavnu poslužiteljsku dretvu. Ova dretva inicijalizira te pokreće sve
	 * ostale dretve.
	 * 
	 * @author Luka Ruklić
	 *
	 */

	protected class ServerThread extends Thread {

		@Override
		public void run() {
			System.out.println("Initializing server thread, server socket...");
			ServerSocket ssocket = null;
			try {
				ssocket = new ServerSocket(port);
			} catch (final IOException e) {
				System.out.println("Could not create socket on port "+port+".");
				return;
			}

			while (true) {
				try {
					final Socket client = ssocket.accept();
					final ClientWorker cw = new ClientWorker(client);
					threadPool.submit(cw);

				} catch (final IOException e) {
					System.out.println("Failed to create client socket.");
					try {
						ssocket.close();
					} catch (final IOException e1) {
						System.out.println("Unable to close server socket.");
						return;
					}
				}
			}
		}
	}

	protected class CleanupThread extends Thread {

		@Override
		public synchronized void run() {
			while (true) {
				try {
					Thread.sleep(30000);
				} catch (final InterruptedException ignorable) {
				}
				System.out.println("Cleanup thread started...");
				for (final String key : sessions.keySet()) {
					if (sessions.get(key).validUntil < System.currentTimeMillis()) {
						sessions.remove(key);
					}
				}
			}
		}
	};

	/**
	 * Razred koji predstavlja unos sjedničke mape.
	 * 
	 * @author Luka Ruklić
	 *
	 */
	public static class SessionMapEntry {

		String sid;
		long validUntil;
		Map<String,String> map;

	}

	/**
	 * Razred koji predstavlja dretvu koja obrađuje zahtjeve i obavlja posao koji klijent zatraži.
	 * 
	 * @author Luka Ruklić
	 *
	 */

	private class ClientWorker implements Runnable {

		/**
		 * Klijentska pristupna točka.
		 */
		private final Socket csocket;
		/**
		 * Ulazni tok podataka.
		 */
		private PushbackInputStream istream;
		/**
		 * Izlazni tok podataka.
		 */
		private OutputStream ostream;
		/**
		 * Mapa s parametrima.
		 */
		private final Map<String,String> params = new HashMap<String, String>();
		/**
		 * Mapa s trajnim parametrima.
		 */
		private Map<String,String> permPrams = new HashMap<String, String>();
		/**
		 * List s izlaznim "kolačićima"
		 */
		private final List<RCCookie> outputCookies = new ArrayList<RequestContext.RCCookie>();

		/**
		 * Konstruktor.
		 * 
		 * @param csocket priključna točka nad kojom se stvara klijentski radnik
		 */
		public ClientWorker(Socket csocket) {
			super();
			this.csocket = csocket;
		}

		@Override
		public void run() {

			try {
				this.istream = new PushbackInputStream(csocket.getInputStream());
				this.ostream = csocket.getOutputStream();
			} catch (final IOException e) {
				System.out.println("Failed to get input/output streams.");
			}

			System.out.println("Executing client worker thread "+Thread.currentThread().getName()+"...");

			List<String> request = new ArrayList<>();
			try {
				request = readRequest();
				if (request.size() < 1) {
					returnError(csocket, 400, "text/plain", "Request type not supported.");
					csocket.close();
					return;
				}
			} catch (final IOException ex) {
				System.out.println("Failed to read request.");
				try {
					returnError(csocket, 404, "text/plain", "Failed to instantiate worker.");
					csocket.close();
					return;
				} catch (IOException ex2) {
					System.out.println("Failed to close client socket.");
					return;
				}
			}

			final String firstLine = request.get(0);
			final String[] parts = firstLine.split(" ");

			String sidCandidate = null;

			for (String line : request) {
				if(line.startsWith("Cookie:")) {
					String cookieString = line.substring(7).trim();
					final String[] cookies = cookieString.split(";");
					for (String cookie : cookies) {
						String[] cookieParsed = cookie.split("=");
						if(cookieParsed[0].equals("sid")) {
							sidCandidate = cookieParsed[1].substring(1, cookieParsed[1].length()-1);
							break;
						}
					}
				}
			}

			if (sidCandidate == null) {
				newCookieGeneration();
			} else {
				SessionMapEntry entry = sessions.get(sidCandidate);
				if (entry != null) {
					if (entry.validUntil > System.currentTimeMillis()) {
						updateValidTime(entry);
						permPrams = entry.map;
					} else {
						newCookieGeneration();
					}
				} else {
					newCookieGeneration();
				}
			}

			try {

				if(!"GET".equals(parts[0]) || !"HTTP/1.1".equals(parts[2]) && !"HTTP/1.0".equals(parts[2])) {
					returnError(csocket, 400, "text/plain", "Invalid request.");
					csocket.close();
					return;
				}

				String path;
				String paramString = null;
				String[] requestPathSplit;
				if (parts[1].contains("?")) {
					requestPathSplit = parts[1].split("\\?");
					path = requestPathSplit[0];
					paramString = requestPathSplit[1];
				} else {
					path = parts[1];
				}

				final Path requestedPath = documentRoot.resolve("."+path);

				System.out.println("Path to requested data: " + path);

				if(!requestedPath.startsWith(documentRoot)) {
					returnError(csocket, 403, "text/plain", "Restricted access.");
					csocket.close();
					return;
				}

				if (paramString != null) {
					parseParameters(paramString);
				}

				if (path.startsWith("/ext/")) {
					final int slashPosition = path.lastIndexOf('/');
					final String workerName = path.substring(slashPosition+1);


					try {
						Class<?> referenceToClass = this.getClass().getClassLoader().loadClass(
								"hr.fer.zemris.java.webserver.workers."+workerName);
						Object newObject = referenceToClass.newInstance();
						IWebWorker iww = (IWebWorker)newObject;
						iww.processRequest(new RequestContext(ostream, params, permPrams, outputCookies));
						csocket.close();
						return;
					} catch (ClassNotFoundException | IllegalAccessException | InstantiationException ex) {
						System.out.println("Failed to instatiate hr.fer.zemris.java.webserver.workers."+workerName);
						returnError(csocket, 400, "text/plain", "Failed to instantiate worker.");
						csocket.close();
						return;

					}

				}

				if (workersMap.containsKey(path)) {
					IWebWorker worker = workersMap.get(path);
					worker.processRequest(new RequestContext(ostream, params, permPrams, outputCookies));
					csocket.close();
					return;
				}

				if (isSmscr(requestedPath.toString())) {

					String documentBody;

					final BufferedReader br = new BufferedReader(new FileReader(requestedPath.toString()));
					try {
						final StringBuilder sb = new StringBuilder();
						String line = br.readLine();

						while (line != null) {
							sb.append(line);
							sb.append("\n");
							line = br.readLine();
						}
						documentBody = sb.toString();
					} finally {
						br.close();
					}

					final RequestContext rc = new RequestContext(ostream, params, permPrams, outputCookies);
					rc.setMimeType("text/plain");
					new SmartScriptEngine(
							new SmartScriptParser(documentBody).getDocumentNode(),
							rc
							).execute();

					csocket.close();
					return;
				}

				if(!Files.exists(Paths.get(requestedPath.toString()))) {
					returnError(csocket, 404, "text/plain", "File not found.");
					csocket.close();
					return;
				}

				final String currentMimeType = getMime(path.toString());

				final RequestContext rc = new RequestContext(ostream, params, permPrams, outputCookies);
				rc.setMimeType(currentMimeType);
				rc.setStatusCode(200);

				final byte[] data = Files.readAllBytes(Paths.get(requestedPath.toString()));

				rc.write(data);

				csocket.close();
			}
			catch (final IOException ex) {
				System.out.println("Run operation failed.");
				try {
					returnError(csocket, 404, "text/plain", "Operation unsuccessful.");
					csocket.close();
					return;
				} catch (IOException e) {
					System.out.println("Failed to close client socket after failed operation.");
				}
			}

		}

		/**
		 * Višedretevno sigurna metoda koja ažurira preostalo vrijeme koliko zapis vrijedi.
		 * 
		 * @param entry zapis koji predstavlja "kolačić"
		 */
		private synchronized void updateValidTime(SessionMapEntry entry) {
			entry.validUntil = System.currentTimeMillis() + sessionTimeout*1000;
		}

		/**
		 * Višedretveno sigurna metoda koja stvara novi SessionMapEntry te novi kolačić.
		 */
		private synchronized void newCookieGeneration() {
			String sidCandidate;
			StringBuilder sb = new StringBuilder();
			for (int i = 0; i < 20; i++) {
				sb.append(Character.toChars(65 + (int)(sessionRandom.nextDouble() * (90 - 65 + 1))));
			}
			sidCandidate = sb.toString();
			SessionMapEntry entry = new SessionMapEntry();
			entry.sid = sidCandidate;
			updateValidTime(entry);
			entry.map = new ConcurrentHashMap<>();
			sessions.put(sidCandidate, entry);
			RCCookie cookie = new RCCookie("sid", entry.sid, null, address, "/");
			cookie.setHttpOnlyOn();
			outputCookies.add(cookie);
		}

		/**
		 * Metoda koja iz stringa primljenog preko adresne trake parsira varijable te ih
		 * sprema u lokalnu mapu razreda SmartHttpServer.
		 * 
		 * @param paramString string koji se parsira
		 */
		private void parseParameters(String paramString) {
			final String[] variables = paramString.split("&");
			for (final String string : variables) {
				final String[] paramValuePairs = string.split("=");
				params.put(paramValuePairs[0], paramValuePairs[1]);
			}
		}

		/**
		 * Metoda koja provjerava da li je primljena datoteka tipa <i>SmartScript</i>, odnosno
		 * da li joj je ekstenzija .smscr
		 * 
		 * @param path putanja do datoteke
		 * @return <code>true</code> ukoliko je ekstenzija .smscr, <code>false</code> inače
		 */
		private boolean isSmscr(String path) {
			final int dotPosition = path.lastIndexOf('.');
			if(dotPosition != -1) {
				final String ext = path.substring(dotPosition+1).toLowerCase();
				if (ext.equals("smscr")) {
					return true;
				}
			}
			return false;
		}

		/**
		 * Metoda koja u postojećoj mapi traži odgovarajući <i>mime</i> za dobivenu putanju do datoteke.
		 * Ukoliko odgovarajući <i>mime</i> ne postoji u mapi, podrazumijevani <i>mime</i> je
		 * <i>"application/octet-stream"</i>.
		 * 
		 * @param requestWantedPath putanja do datoteke čiji se <i>mime</i> traži
		 * @return odgovarajući <i></i> mime
		 */
		private String getMime(String requestWantedPath) {
			final int dotPosition = requestWantedPath.lastIndexOf('.');
			if(dotPosition != -1) {
				final String ext = requestWantedPath.substring(dotPosition+1).toLowerCase();
				final String mimeType = mimeTypes.get(ext);
				if (mimeType != null) {
					return mimeType;
				}
			}
			return "application/octet-stream";
		}

		private void returnError(Socket client, int status, String mime, String message) throws IOException {
			final byte[] data = message.getBytes(StandardCharsets.UTF_8);
			final String header =
					"HTTP/1.1"+status+" ERROR\r\n" +
							"Content-Length: "+data.length+"\r\n" +
							"Content-Type: "+mime+";charset=utf-8\r\n" +
							"Server: java-server\r\n" +
							"\r\n";

			ostream.write(header.getBytes(StandardCharsets.ISO_8859_1));
			ostream.write(data);
			ostream.flush();

		}

		/**
		 * Metoda koja čita primljeni zahtjev te ga po retcima sprema u listu.
		 * 
		 * @return primljeni zahtjev u obliku liste
		 * @throws IOException ukoliko nije moguće otvoriti novi tok podataka
		 */
		private List<String> readRequest() throws IOException {

			final List<String> request = new ArrayList<>();
			final BufferedReader r = new BufferedReader(
					new InputStreamReader(
							new BufferedInputStream(
									istream
									),
									StandardCharsets.ISO_8859_1
							)
					);
			String line;
			while ((line = r.readLine()) != null) {
				request.add(line);
				if(line.isEmpty()) {
					break;
				}
			}

			return request;
		}

	}
}
