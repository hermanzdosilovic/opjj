package hr.fer.zemris.java.custom.scripting.parser;

/**
 * Druga domaća zadaća, treći zadatak
 * Razred koji nasljeđuje RuntimeException te baca iznimke u slučaju nedozvoljenog ulaza u program.
 * 
 * @author Luka Ruklić, 0036456440
 */

public class SmartScriptParserException extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Metoda koja ispisuje poruku o greški u slučaju RuntimeExceptiona
	 */

	public SmartScriptParserException(String errorMessage) {
		super(errorMessage);
	}

}
