package hr.fer.zemris.java.webserver;

import java.io.IOException;
import java.io.OutputStream;
import java.nio.charset.Charset;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Razred koji predstavlja kontekst zahtjeva koji vraća poslužitelj.
 * 
 * @author Luka Ruklić
 *
 */

public class RequestContext {

	/**
	 * Izlazni tok podataka.
	 */
	private final OutputStream outputStream;
	/**
	 * Znakovni skup koji se koristi.
	 */
	private Charset charset;
	/**
	 * Kodiranje znakova koje se koristi.
	 */
	private String encoding = "UTF-8";
	/**
	 * Statusni kod.
	 */
	private int statusCode = 200;
	/**
	 * Statusni tekst.
	 */
	private String statusText = "OK";
	/**
	 * Vrsta mime-a.
	 */
	private String mimeType = "text/html";
	/**
	 * Mapa s parametrima.
	 */
	private final Map<String, String> parameters;
	/**
	 * Mapa s trajnim parametrima.
	 */
	private Map<String, String> persistentParameters;
	/**
	 * Mapa s privremenim parametrima.
	 */
	private Map<String, String> temporaryParameters = new HashMap<>();
	/**
	 * Lista s "kolačićima".
	 */
	private final List<RCCookie> outputCookies;
	/**
	 * Boolean vrijednost koja govori da li je zaglavlje već generirano.
	 */
	private boolean headerGenerated = false;

	/**
	 * Konstruktor.
	 * 
	 * @param outputStream izlazni tok podataka
	 * @param parameters mapa s parametrima
	 * @param persistentParameters mapa s trajnim parametrima
	 * @param outputCookies lista s "kolačićima"
	 */
	public RequestContext(OutputStream outputStream, Map<String, String> parameters,
			Map<String, String> persistentParameters, List<RCCookie> outputCookies) {
		super();
		if (outputStream == null) {
			throw new IllegalArgumentException("Output stream must not be null");
		}
		this.outputStream = outputStream;
		this.parameters = parameters;
		this.persistentParameters = persistentParameters;
		this.outputCookies = outputCookies;
	}

	/**
	 * Setter.
	 * @param encoding vrsta kodiranja znakova
	 */
	public void setEncoding(String encoding) {
		headerCheck();
		this.encoding = encoding;
	}

	/**
	 * Setter.
	 * @param statusCode statusni kod
	 */
	public void setStatusCode(int statusCode) {
		headerCheck();
		this.statusCode = statusCode;
	}

	/**
	 * Setter.
	 * @param statusText statusni tekst
	 */
	public void setStatusText(String statusText) {
		headerCheck();
		this.statusText = statusText;
	}

	/**
	 * Setter.
	 * @param mimeType vrsta mime-a
	 */
	public void setMimeType(String mimeType) {
		headerCheck();
		this.mimeType = mimeType;
	}

	/**
	 * Metoda koja provjerava da li je zaglavlje već postavljeno.
	 */
	private void headerCheck(){
		if (headerGenerated) {
			throw new IllegalArgumentException("Header already generated.");
		}
	}

	/**
	 * Razred koji predstavlja "kolačić" internetskog poslužitelja.
	 * 
	 * @author Luka Ruklić
	 *
	 */

	public static class RCCookie {

		/**
		 * Naziv "kolačića".
		 */
		private final String name;
		/**
		 * Vrijednost "kolačića".
		 */
		private final String value;
		/**
		 * Domena.
		 */
		private final String domain;
		/**
		 * Putanja.
		 */
		private final String path;
		/**
		 * Maksimalni životni vijek "kolačića".
		 */
		private final Integer maxAge;
		/**
		 * Boolean vrijednost da li je "kolačić" samo za HTTP.
		 */
		private boolean httpOnly = false;

		/**
		 * Konstruktor.
		 * 
		 * @param name ime
		 * @param value vrijednost
		 * @param maxAge maksimalna dob
		 * @param domain domena
		 * @param path putanja
		 */
		public RCCookie(String name, String value, Integer maxAge, String domain, String path) {
			super();
			this.name = name;
			this.value = value;
			this.domain = domain;
			this.path = path;
			this.maxAge = maxAge;
		}
		/**
		 * Getter.
		 * @return naziv
		 */
		public String getName() {
			return name;
		}
		/**
		 * Getter.
		 * @return vrijednost
		 */
		public String getValue() {
			return value;
		}
		/**
		 * Getter.
		 * @return domena
		 */
		public String getDomain() {
			return domain;
		}
		/**
		 * Getter.
		 * @return putanja
		 */
		public String getPath() {
			return path;
		}
		/**
		 * Getter.
		 * @return maksimalna dob
		 */
		public Integer getMaxAge() {
			return maxAge;
		}
		/**
		 * Setter za samo-HTTP vrijednost.
		 */
		public void setHttpOnlyOn() {
			this.httpOnly = true;
		}
		/**
		 * Getter
		 * @return boolean vrijednost da li je "kolačić" samo HTTP
		 */
		public boolean getHttpOnly() {
			return httpOnly;
		}
	}

	/**
	 * Getter.
	 * @return lista privremenih parametara
	 */
	public Map<String, String> getTemporaryParameters() {
		return temporaryParameters;
	}

	public void setTemporaryParameters(Map<String, String> temporaryParameters) {
		this.temporaryParameters = temporaryParameters;
	}
	/**
	 * Getter.
	 * @return lista trajnih parametara
	 */
	public Map<String, String> getPersistentParameters() {
		return persistentParameters;
	}

	public void setPersistentParameters(Map<String, String> persistentParameters) {
		this.persistentParameters = persistentParameters;
	}
	/**
	 * Getter.
	 * @return lista parametara
	 */
	public Map<String, String> getParameters() {
		return parameters;
	}

	/**
	 * Getter.
	 * @param name naziv parametra koji se traži
	 * @return parametar iz liste
	 */
	public String getParameter(String name) {
		return parameters.get(name);
	}
	/**
	 * Getter.
	 * @return skup parametara iz liste
	 */
	public Set<String> getParameterNames() {
		return parameters.keySet();
	}
	/**
	 * Getter.
	 * @param name naziv parametra koji se traži
	 * @return trajni parametar iz liste
	 */
	public String getPersistentParameter(String name) {
		return persistentParameters.get(name);
	}
	/**
	 * Getter.
	 * @return skup trajnih parametara iz liste
	 */
	public Set<String> getPersistentParameterNames() {
		return persistentParameters.keySet();
	}
	/**
	 * Setter.
	 * @param name naziv parametra
	 * @param value vrijednost parametra
	 */
	public void setPersistentParameter(String name, String value) {
		persistentParameters.put(name, value);
	}
	/**
	 * Metoda koja miče parametar iz liste.
	 * @param name parametar koji se miče
	 */
	public void removePersistentParameter(String name) {
		persistentParameters.remove(name);
	}
	/**
	 * Getter.
	 * @param name naziv parametra koji se traži
	 * @return parametar iz liste
	 */
	public String getTemporaryParameter(String name) {
		return temporaryParameters.get(name);
	}
	/**
	 * Getter.
	 * @return skup privremenih parametara iz liste
	 */
	public Set<String> getTemporaryParameterNames() {
		return temporaryParameters.keySet();
	}
	/**
	 * Setter.
	 * @param name naziv parametra
	 * @param value vrijednost parametra
	 */
	public void setTemporaryParameter(String name, String value) {
		temporaryParameters.put(name, value);
	}
	/**
	 * Metoda koja miče parametar iz liste.
	 * @param name parametar koji se miče
	 */
	public void removeTemporaryParameter(String name) {
		temporaryParameters.remove(name);
	}
	/**
	 * Metoda koja zapisuje polje okteta u izlazni tok.
	 * 
	 * @param data polje okteta
	 * @return kontekst zahtjeva nad kojim je metoda pozvana
	 * @throws IOException ukoliko ne može zapisati u tok
	 */
	public RequestContext write(byte[] data) throws IOException {
		if (!headerGenerated) {
			createHeader();
			headerGenerated = true;
		}
		outputStream.write(data);
		outputStream.flush();
		return this;
	}
	/**
	 * Metoda koja zapisuje string u izlazni tok.
	 * 
	 * @param text string koji se zapisuje
	 * @return kontekst zahtjeva nad kojim je metoda pozvana
	 * @throws IOException ukoliko ne može zapisati u tok
	 */
	public RequestContext write(String text) throws IOException {
		if (!headerGenerated) {
			charset = Charset.forName(encoding);
			createHeader();
			headerGenerated = true;
		}
		outputStream.write(text.getBytes(charset));
		outputStream.flush();
		return this;
	}
	/**
	 * Metoda koja stvara zaglavlje.
	 * @throws IOException ukoliko ne može zapisati u tok
	 */
	private void createHeader() throws IOException {
		final StringBuilder sb = new StringBuilder();
		sb.append("HTTP/1.1 "+statusCode+" "+statusText+"\r\n");
		if (mimeType.startsWith("text/")) {
			sb.append("Content-Type: "+mimeType+"; charset="+charset+"\r\n");
		}
		else {
			sb.append("Content-Type "+mimeType+"\r\n");
		}
		for (final RCCookie cookie : outputCookies) {
			sb.append("Set-Cookie: "+cookie.getName()+"=\""+cookie.getValue()+"\"");
			if (cookie.getDomain() != null) {
				sb.append("; Domain="+cookie.getDomain());
			}
			if (cookie.getPath() != null) {
				sb.append("; Path="+cookie.getPath());
			}
			if (cookie.getMaxAge() != null) {
				sb.append("; Max-Age="+cookie.getMaxAge());
			}
			if (cookie.getHttpOnly()) {
				sb.append("; HttpOnly");
			}
			sb.append("\r\n");
		}
		sb.append("\r\n");
		outputStream.write(sb.toString().getBytes());
	}

	/**
	 * Metoda koja dodaje "kolačić" u listu.
	 * @param rcCookie "kolačić" koji se dodaje
	 */
	public void addRCCookie(RCCookie rcCookie) {
		outputCookies.add(rcCookie);
	}

}
