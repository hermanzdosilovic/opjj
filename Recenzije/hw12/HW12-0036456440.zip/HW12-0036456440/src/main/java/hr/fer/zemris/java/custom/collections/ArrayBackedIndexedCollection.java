package hr.fer.zemris.java.custom.collections;

/**
 * Druga domaća zadaća, prvi zadatak
 * Razred koji realizira kolekciju zasnovanu na polju promjenjive veličine.
 * 
 * @author Luka Ruklić, 0036456440
 */

public class ArrayBackedIndexedCollection {

	private int size = 0;
	private int capacity;
	private Object[] elements;

	/**
	 * Metoda koje provjerava da li je primljeni objekt vrijednosti null.
	 * U afirmativnom slučaju baca iznimku.
	 * @param value vrijednost primljenog objekta
	 */

	private void provjeraNullVrijednosti(Object value) {
		if (value == null) {
			throw new IllegalArgumentException("Null elementi nisu podržani.");
		}
	}

	/**
	 * Metoda koje provjerava da li je poslani indeks u odgovarajućem rasponu.
	 * Ukoliko nije, baca iznimku.
	 * @param index primljeni indeks čiju valjanost treba provjeriti
	 */

	public void provjeraIndeksa(int index) {
		if ( index < 0 || index > size-1 ) {
			throw new IndexOutOfBoundsException("Vrijednost indeksa nije valjana.");
		}
	}

	/**
	 * Metoda koja alocira memoriju ukoliko je niz u koji dodajemo pun.
	 */

	private void alocirajMemoriju() {
		capacity = size * 2;
		final Object[] newElements = new Object[capacity];
		System.arraycopy(elements, 0, newElements, 0, elements.length);
		elements = newElements;
	}

	/**
	 * Konstruktor razreda koji inicijalizira polje na predodređenu veličinu.
	 */

	public ArrayBackedIndexedCollection() {

		this.capacity = 16;
		this.elements = new Object[16];

	}

	/**
	 * Konstruktor razreda koji inicijalizira polje na veličinu koju korisnik odabere.
	 * @param initialCapacity željeni kapacitet
	 */

	public ArrayBackedIndexedCollection(int initialCapacity) {

		if (initialCapacity < 1) {
			throw new IllegalArgumentException("Kapacitet mora biti veći od 1!");
		}

		this.capacity = initialCapacity;
		this.elements = new Object[initialCapacity];

	}

	/**
	 * Metoda koja provjerava da li je niz prazan.
	 * @return true/false vrijednost da li je niz prazan
	 */

	public boolean isEmpty() {

		if (size == 0) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * Metoda koja mjeri veličinu niza.
	 * @return integer vrijednost veličine niza
	 */

	public int size() {

		return size;
	}

	/**
	 * Metoda koja dodaje objekt na kraj niza.
	 * @param value objekt koji se dodaje
	 */

	public void add(Object value) {

		provjeraNullVrijednosti(value);

		if (size == capacity) {
			alocirajMemoriju();
		}

		elements[size] = value;
		size++;
	}

	/**
	 * Metoda koja traži objekt po indeksu.
	 * @param index indeks objekta kojeg dohvaćamo
	 * @return objekt na danom indeksu
	 */

	public Object get(int index) {

		provjeraIndeksa(index);
		return elements[index];

	}

	/**
	 * Metoda koja miče objekt iz niza.
	 * @param index indeks objekta kojeg želimo maknuti iz niza
	 */

	public void remove(int index) {

		provjeraIndeksa(index);

		if (index == size-1) {
			elements[index] = null;
		}
		else {
			for (int i = index; i < size-1; i++) {
				elements[i] = elements[i+1];
			}
		}
		size--;

	}

	/**
	 * Metoda koja ubacuje objekt u niz.
	 * @param value position vrijednost objekta koji želimo dodati te pozicija na koju ga želimo dodati
	 */

	public void insert(Object value, int position) {

		if ( position < 0 || position > size ) {
			throw new IndexOutOfBoundsException("Ne postoji tražena pozicija u nizu.");
		}

		provjeraNullVrijednosti(value);

		if (size == capacity) {
			alocirajMemoriju();
		}

		// Algoritam pomicanja starih članova unazad kako bi se mogao umetnuti novi član

		for (int i = size; i > position; i--) {
			elements[i] = elements[i-1];
		}
		elements[position] = value;
		size++;

	}

	/**
	 * Metoda koja vraća indeks prvog pojavljivanja željenog objekta.
	 * @param value vrijednost objekta
	 * @return indeks prvog pojavljivanja objekta
	 */

	public int indexOf(Object value) {

		provjeraNullVrijednosti(value);

		for (int i = 0; i < size; i++) {
			if (elements[i].equals(value)) {
				return i;
			}
		}
		return -1;

	}

	/**
	 * Metoda koja provjerava da li niz sadrži objekt.
	 * @param value vrijednost objekta kojeg tražimo
	 * @return true/false vrijedost da li se objekt nalazi u nizu
	 */

	public boolean contains(Object value) {

		provjeraNullVrijednosti(value);

		for (int i = 0; i < size; i++) {
			if (elements[i].equals(value)) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Metoda koja prazni niz.
	 */

	public void clear() {

		size = 0;
		for (int i = 0; i < size; i++) {
			elements[i] = null;
		}
	}

	/**
	 * Glavna metoda razreda.
	 * Služi za pokretanje i testiranje ostalih metoda.
	 */

	public static void main(String[] args)
	{
		final ArrayBackedIndexedCollection col = new ArrayBackedIndexedCollection(4);

		col.add("New York");
		col.add("San Francisco");
		col.add("Dallas");

		System.out.println(col.size()); // vraca 3

		col.add("Phoenix");
		col.add("Salt Lake City");	// ovdje alocira nova 4 polja (uk 8)
		col.add("Las Vegas");
		col.add("Chicago");

		System.out.println(col.contains("Dallas")); // vraća true

		System.out.println(col.get(4)); // dohvaca Salt Lake City
		System.out.println(col.get(6)); // dohvaca Chicago
		// System.out.println(col.get(7)); // out of bound exception

		col.remove(2);

		System.out.println(col.get(4)); // dohvaca Las Vegas
		// System.out.println(col.get(6)); // out of bound exception

		col.add("Seattle");

		System.out.println(col.get(6)); // dohvaca Seattle
		System.out.println(col.get(0)); // dohvaca New York

		System.out.println(col.indexOf("Seattle"));		// vraća 6
		System.out.println(col.indexOf("Vancouver"));		// vraća -1

		//		col.insert("Miami", 3);
		//		col.insert("Kansas City", 0);
		//		col.remove(2);
		col.add("Houston");		// tu alocira novih 8 polja (uk 16)
		col.remove(5);
		col.add("Cincinnatti");

		System.out.println(col.contains("Salt Lake City"));	// vraća false
		System.out.println(col.contains("Toronto"));		// vraća false

		System.out.println(col.indexOf("Phoenix"));		// vraća 3

		System.out.println(col.size());		// vraća 9

		col.clear();
		col.add("Washington");
		System.out.println(col.indexOf("Washington")); // 0


	}
}
