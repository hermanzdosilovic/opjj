package hr.fer.zemris.java.custom.scripting.nodes;

/**
 * Druga domaća zadaća, treći zadatak
 * Razred koji realizira DocumentNode.
 * 
 * @author Luka Ruklić, 0036456440
 */

public class DocumentNode extends Node {

	@Override
	public String getText() {
		return "";
	}

	@Override
	public void accept(INodeVisitor visitor) {
		visitor.visitDocumentNode(this);
	}

}
