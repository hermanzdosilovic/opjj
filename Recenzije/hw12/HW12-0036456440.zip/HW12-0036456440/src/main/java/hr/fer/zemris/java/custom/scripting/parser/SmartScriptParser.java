package hr.fer.zemris.java.custom.scripting.parser;

import hr.fer.zemris.java.custom.collections.ObjectStack;
import hr.fer.zemris.java.custom.scripting.nodes.DocumentNode;
import hr.fer.zemris.java.custom.scripting.nodes.EchoNode;
import hr.fer.zemris.java.custom.scripting.nodes.ForLoopNode;
import hr.fer.zemris.java.custom.scripting.nodes.Node;
import hr.fer.zemris.java.custom.scripting.nodes.TextNode;
import hr.fer.zemris.java.custom.scripting.tokens.Token;
import hr.fer.zemris.java.custom.scripting.tokens.TokenConstantDouble;
import hr.fer.zemris.java.custom.scripting.tokens.TokenConstantInteger;
import hr.fer.zemris.java.custom.scripting.tokens.TokenFunction;
import hr.fer.zemris.java.custom.scripting.tokens.TokenOperator;
import hr.fer.zemris.java.custom.scripting.tokens.TokenString;
import hr.fer.zemris.java.custom.scripting.tokens.TokenVariable;

/**
 * Druga domaća zadaća, treći zadatak
 * Razred koji realizira funkcionalnost parsera teksta.
 * 
 * @author Luka Ruklić, 0036456440
 */

public class SmartScriptParser {

	String docbody;

	private int maxSize = 50;

	String[] tagAndTextArray = new String[maxSize];
	int tagAndTextArrayPointer = 0;
	ObjectStack parsingTree = null;
	Object currentObject = new Object();

	static String originalText = new String();
	DocumentNode firstNode = null;

	/**
	 *  Metoda koja dohvaća osnovni čvor DocumentNode
	 */

	public DocumentNode getDocumentNode() {
		return this.firstNode;
	}

	/**
	 *  Metoda koja rekurzivno ispisuje sadržaj i formu stabla.
	 *  Nema ulaznih ni izlaznih argumenata.
	 */


	public void recursiveTreePrinter(Node first, int level) {

		for(int i = 0; i < level; i++) {
			System.out.print("     ");
		}
		System.out.print("+" + first.getClass());
		System.out.println("");

		if ( first.numberofChildren() > 0 ) {
			final int ChildrenNumber = first.numberofChildren();
			for (int i = 0; i < ChildrenNumber; i++) {
				recursiveTreePrinter(first.getChild(i), level+1);
			}
		}

	}

	/**
	 * Metoda koja rekonstruira originalni tekst parsera:
	 * @param first osnovni čvor stabla, DocumentNode
	 * @return rekonstruirani originalni tekst
	 */

	public static String createOriginalDocumentBody(Node first) {

		originalText += first.getText();

		if ( first.numberofChildren() > 0 ) {
			final int ChildrenNumber = first.numberofChildren();
			for (int i = 0; i < ChildrenNumber; i++) {
				createOriginalDocumentBody(first.getChild(i));
			}
			if (!(first instanceof DocumentNode)) {
				originalText += "{$ END $}";
			}
		}

		return originalText;
	}

	/**
	 * Konstruktor koji stvara string varijablu u koju će se spremiti ulazni string
	 * parsera te stvara DocumentNode koji je korijen parsirnog stabla.
	 * @param docbody ulazni niz znakova u parser
	 */

	public SmartScriptParser(String docbody) {

		this.docbody = docbody;
		this.parsingTree = new ObjectStack();

		firstNode = new DocumentNode();
		parsingTree.push(firstNode);

		currentObject = parsingTree;

		parsingFunction();
		tagOrTextSplitter();

		//System.out.println("Grafički prikaz stabla i njegovih razina: \n");
		//RecursiveTreePrinter(FirstNode, 0);
		System.out.println();

	}

	/**
	 *  Metoda koja dodaje TextNode u stablo.
	 *  Nema ulaznih ni izlaznih argumenata.
	 */

	public final void addTextNode() {

		final TextNode addingText = new TextNode(tagAndTextArray[tagAndTextArrayPointer]);
		final Node topOfStack = (Node) parsingTree.peek();
		topOfStack.addChildNode(addingText);

	}

	/**
	 * Metoda koja miče suvišna prazna polja s početka i kraja.
	 * @return kao izlaz se vraća "trimmani" string
	 */

	public final String tagTrimmer() {

		String tagTrimmed = new String();
		final int tagLength = tagAndTextArray[tagAndTextArrayPointer].length();

		// Miče whitespace s početka stringa
		int tagPointer = 2;
		while (tagAndTextArray[tagAndTextArrayPointer].charAt(tagPointer) == ' ') {
			tagPointer++;
		}

		// Miče whitespace s kraja stringa
		int tagPointerEnd = tagLength-2;

		while (tagAndTextArray[tagAndTextArrayPointer].charAt(tagPointerEnd) == ' ') {
			tagPointerEnd--;
		}

		// Sastavlja novi string
		for (int i = tagPointer; i < tagPointerEnd; i++) {
			tagTrimmed += tagAndTextArray[tagAndTextArrayPointer].charAt(i);
		}

		return tagTrimmed;

	}

	/**
	 * Metoda koja prolazi kroz string i traži idući element koji nije whitespace.
	 * @param TagPointer prima pokazivač na element u polji
	 * @return isti pokazivač koji je primila pomaknut vraća na izlaz
	 */

	public final int lookForNonWhitespace(int tagPointer) {
		while (tagAndTextArray[tagAndTextArrayPointer].charAt(tagPointer) == ' ' ||
				tagAndTextArray[tagAndTextArrayPointer].charAt(tagPointer) == '\n' ||
				tagAndTextArray[tagAndTextArrayPointer].charAt(tagPointer) == '\t' ||
				tagAndTextArray[tagAndTextArrayPointer].charAt(tagPointer) == '\r') {
			tagPointer++;
		}
		return tagPointer;
	}

	/**
	 * Metoda koja stvara TokenVariable.
	 * @param SomeTokenName znakovni sadržaj nepoznatog tokena
	 * @return novostvoreni token tipa varijabla
	 */

	public final TokenVariable createTokenVariable (String someTokenName) {

		final int tokenNameLength = someTokenName.length();
		for (int i = 0; i < tokenNameLength; i++) {
			if ( !(someTokenName.charAt(i) == '_' || Character.isLetter(someTokenName.charAt(i)) || Character.isDigit(someTokenName.charAt(i)) )) {
				throw new SmartScriptParserException("Token type is invalid.");
			}
		}
		final TokenVariable newToken = new TokenVariable(someTokenName);
		return newToken;
	}

	/**
	 * Metoda koja stvara TokenFunction.
	 * @param SomeTokenName znakovni sadržaj nepoznatog tokena
	 * @return novostvoreni token tipa funkcija
	 */

	public final TokenFunction createTokenFunction (String someTokenName) {

		final int tokenNameLength = someTokenName.length();
		for (int i = 1; i < tokenNameLength; i++) {
			if ( !(someTokenName.charAt(i) == '_' || Character.isLetter(someTokenName.charAt(i)) || Character.isDigit(someTokenName.charAt(i)) )) {
				throw new SmartScriptParserException("Token type is invalid.");
			}
		}
		final TokenFunction newToken = new TokenFunction(someTokenName);
		return newToken;

	}

	/**
	 * Metoda koja stvara TokenOperator.
	 * @param SomeTokenName znakovni sadržaj nepoznatog tokena
	 * @return novostvoreni token tipa operator
	 */

	public final TokenOperator createTokenOperator (String someTokenName) {

		final TokenOperator newToken = new TokenOperator(someTokenName);
		return newToken;
	}

	/**
	 * Metoda koja određuje da li je broj token integer ili double
	 * @param SomeTokenName znakovni sadržaj nepoznatog tokena
	 * @return novostvoreni generički token
	 */

	public final Token createTokenNumber(String someTokenName) {

		final int tokenNameLength = someTokenName.length();
		for (int i = 1; i < tokenNameLength; i++) {
			if ( !(Character.isDigit(someTokenName.charAt(i)) || someTokenName.charAt(i) == '.')) {
				throw new SmartScriptParserException("Token type is invalid.");
			}
		}
		boolean isInteger = true;
		for (int i = 0; i < tokenNameLength; i++) {
			if (!Character.isDigit(someTokenName.charAt(i))) {
				isInteger = false;
			}
		}

		if (isInteger) {
			return createTokenConstantInteger(someTokenName);
		}
		else {
			return createTokenConstantDouble(someTokenName);
		}
	}

	/**
	 * Metoda koja stvara TokenConstantInteger.
	 * @param SomeTokenName znakovni sadržaj nepoznatog tokena
	 * @return novostvoreni token tipa broj integer
	 */

	public final TokenConstantDouble createTokenConstantDouble(String someTokenName) {

		double tokenDoubleNumber = 0;
		final int tokenNameLength = someTokenName.length();
		int numberOfDots = 0;

		for (int i = 0; i < tokenNameLength; i++) {
			if ( someTokenName.charAt(i) == '.') {
				numberOfDots++;
			}
		}
		if (numberOfDots != 1) {
			throw new SmartScriptParserException("Token type is invalid.");
		}

		try {
			tokenDoubleNumber = Double.parseDouble(someTokenName);
		}
		catch (final SmartScriptParserException e) {
			throw new SmartScriptParserException("Token double to double conversion was not possible.");
		}

		final TokenConstantDouble newToken = new TokenConstantDouble(tokenDoubleNumber);
		return newToken;

	}

	public final TokenConstantInteger createTokenConstantInteger(String someTokenName) {

		int tokenIntNumber = 0;
		try {
			tokenIntNumber = Integer.parseInt(someTokenName);
		}
		catch (final SmartScriptParserException e) {
			throw new SmartScriptParserException("Token integer to integer conversion was not possible.");
		}

		final TokenConstantInteger newToken = new TokenConstantInteger(tokenIntNumber);
		return newToken;
	}

	/**
	 * Metoda koja stvara TokenString.
	 * @param SomeTokenName znakovni sadržaj nepoznatog tokena
	 * @return novostvoreni token tipa string
	 */

	public final TokenString createTokenString(String someTokenName) {

		final int tokenNameLength = someTokenName.length();
		String newString = new String();

		for (int i = 1; i < tokenNameLength-1; i++) {
			if (i+1 == tokenNameLength-1) {
				newString += someTokenName.charAt(i);
			}
			else if ( someTokenName.charAt(i) == '\\' && someTokenName.charAt(i+1) == '\"' ) {
				newString += "\"";
				i++;
			}
			else if ( someTokenName.charAt(i) == '\\' && someTokenName.charAt(i+1) == 't' ) {
				newString += "\t";
				i++;
			}
			else if ( someTokenName.charAt(i) == '\\' && someTokenName.charAt(i+1) == 'r' ) {
				newString += "\r";
				i++;
			}
			else if ( someTokenName.charAt(i) == '\\' && someTokenName.charAt(i+1) == 'n' ) {
				newString += "\n";
				i++;
			}
			else {
				newString += someTokenName.charAt(i);
			}
		}
		newString = "\"" + newString + "\"";
		final TokenString newToken = new TokenString(newString);
		return newToken;
	}

	/**
	 * Metoda koja određuje moguću vrstu tokena i poziva odgovarajuću metodu za stvaranje tokena.
	 * @param SomeTokenName znakovni sadržaj nepoznatog tokena
	 * @return novostvoreni generički token
	 */

	public final Token createToken(String someTokenName) {
		final int tokenNameLength = someTokenName.length();

		// Stvara token funkcije
		if ( someTokenName.charAt(0) == '@' && tokenNameLength > 1 ) {
			return createTokenFunction(someTokenName);
		}

		// Stvara token stringa
		else if ( someTokenName.charAt(0) == '\"' && tokenNameLength > 1) {
			return createTokenString(someTokenName);
		}

		// Stvara token variable
		else if ( Character.isLetter(someTokenName.charAt(0)) ) {
			return createTokenVariable(someTokenName);
		}

		// Stvara token operatora
		else if ( (someTokenName.charAt(0) == '+' || someTokenName.charAt(0) == '-' || someTokenName.charAt(0) == '*' || someTokenName.charAt(0) == '/') && tokenNameLength == 1) {
			return createTokenOperator(someTokenName);
		}

		// Stvara token broja
		else if ( Character.isDigit(someTokenName.charAt(0)) || someTokenName.charAt(0) == '-' && tokenNameLength > 1 ) {
			return createTokenNumber(someTokenName);
		}
		else {
			throw new SmartScriptParserException("Token type is not recognized!");
			//		}
		}
	}

	/**
	 * Metoda koje se poziva prilikom obrade For petlje.
	 * Nema ulaznih ni izlaznih argumenata.
	 */

	public final void forTagParser() {

		String someTokenName = new String();
		int tagPointer = 6;

		final int tokenContentLength = tagAndTextArray[tagAndTextArrayPointer].length();

		// Traženje i stvaranje prvog tokena For petlje
		tagPointer = lookForNonWhitespace(tagPointer);
		while (tagAndTextArray[tagAndTextArrayPointer].charAt(tagPointer) != ' ') {
			someTokenName += tagAndTextArray[tagAndTextArrayPointer].charAt(tagPointer);
			tagPointer++;
		}

		Token newToken = createToken(someTokenName);

		if (!(newToken instanceof TokenVariable)) {
			throw new SmartScriptParserException("First for loop member is not a variable!");
		}


		final TokenVariable forLoopToken1 = (TokenVariable) newToken;

		// Traženje i stvaranje drugog tokena For petlje
		someTokenName = "";
		tagPointer = lookForNonWhitespace(tagPointer);
		while (tagAndTextArray[tagAndTextArrayPointer].charAt(tagPointer) != ' ') {
			someTokenName += tagAndTextArray[tagAndTextArrayPointer].charAt(tagPointer);
			tagPointer++;
		}

		newToken = createToken(someTokenName);
		final Token forLoopToken2 = newToken;

		// Traženje i stvaranje trećeg tokena For petlje
		someTokenName = "";
		tagPointer = lookForNonWhitespace(tagPointer);
		while (tagAndTextArray[tagAndTextArrayPointer].charAt(tagPointer) != ' ') {

			someTokenName += tagAndTextArray[tagAndTextArrayPointer].charAt(tagPointer);
			tagPointer++;
		}

		newToken = createToken(someTokenName);
		final Token forLoopToken3 = newToken;

		// Traženje i (ukoliko postoji) stvaranje četvrtog tokena For petlje
		boolean forthMemberExists = true;
		someTokenName = "";
		tagPointer = lookForNonWhitespace(tagPointer);
		while (tagAndTextArray[tagAndTextArrayPointer].charAt(tagPointer) != ' ') {
			if (tokenContentLength-1 == tagPointer) {
				forthMemberExists = false;
				break;
			}
			someTokenName += tagAndTextArray[tagAndTextArrayPointer].charAt(tagPointer);
			tagPointer++;
		}

		if (forthMemberExists) {
			newToken = createToken(someTokenName);
			final Token forLoopToken4 = newToken;

			final ForLoopNode AddingLoop = new ForLoopNode(forLoopToken1, forLoopToken2, forLoopToken3, forLoopToken4);
			final Node TopOfStack = (Node) parsingTree.peek();
			TopOfStack.addChildNode(AddingLoop);
			parsingTree.push(AddingLoop);
		}
		else {
			final ForLoopNode AddingLoop = new ForLoopNode(forLoopToken1, forLoopToken2, forLoopToken3, null);
			final Node TopOfStack = (Node) parsingTree.peek();
			TopOfStack.addChildNode(AddingLoop);
			parsingTree.push(AddingLoop);
		}

	}

	/**
	 * Metoda koje se poziva prilikom obrade Echo vrste tagova.
	 * Nema ulaznih ni izlaznih argumenata.
	 */

	public final void echoTagParser() {

		String someTokenName = new String();

		int maxSize = 50;
		Token[] echoNodeArray = new Token[maxSize];
		int sizeEchoNodeArray = 0;
		boolean insideString = false;

		int tagPointer = 3;
		final int TokenContentLength = tagAndTextArray[tagAndTextArrayPointer].length();

		while (tagPointer < TokenContentLength) {

			tagPointer = lookForNonWhitespace(tagPointer);
			while (tagAndTextArray[tagAndTextArrayPointer].charAt(tagPointer) != ' ' &&
					tagAndTextArray[tagAndTextArrayPointer].charAt(tagPointer) != '\n' &&
					tagAndTextArray[tagAndTextArrayPointer].charAt(tagPointer) != '\t' || insideString) {
				final char currentChar = tagAndTextArray[tagAndTextArrayPointer].charAt(tagPointer);

				if (currentChar == '"' && insideString == false) {
					insideString = true;
				}
				else if (currentChar == '"' && insideString) {
					insideString = false;
				}

				if (TokenContentLength-2 == tagPointer) {
					break;
				}

				someTokenName += tagAndTextArray[tagAndTextArrayPointer].charAt(tagPointer);
				tagPointer++;
			}
			if (someTokenName.isEmpty()) {
				break;
			}
			if (someTokenName.charAt(0) == '$') {
				break;
			}
			final Token newToken = createToken(someTokenName);
			echoNodeArray[sizeEchoNodeArray] = newToken;
			sizeEchoNodeArray++;
			someTokenName = "";

			// Alocira novu memoriju u EchoNodeArrayju ukoliko ponestane
			if (sizeEchoNodeArray + 1 == maxSize) {
				maxSize *= 2;
				final Token[] new_EchoNodeArray = new Token[maxSize];
				System.arraycopy(echoNodeArray, 0, new_EchoNodeArray, 0, echoNodeArray.length);
				echoNodeArray = new_EchoNodeArray;
			}

		}

		final EchoNode addingEcho = new EchoNode(echoNodeArray);
		final Node topOfStack = (Node) parsingTree.peek();
		topOfStack.addChildNode(addingEcho);

	}

	/**
	 * Metoda koja prolazi kroz prethodno napravljeni niz Text-ova i Tag-ova te obrađuje svaki
	 * koristeći odgovarajuću metodu.
	 * Nema ulaznih ni izlaznih argumenata.
	 */

	public final void tagOrTextSplitter() {

		tagAndTextArrayPointer = 0;

		while(tagAndTextArray[tagAndTextArrayPointer] != null) {

			if ( tagAndTextArray[tagAndTextArrayPointer].charAt(0) == '{' && tagAndTextArray[tagAndTextArrayPointer].charAt(1) == '$' ) {

				String trimmedTag = "";
				trimmedTag = tagTrimmer();
				if (trimmedTag.length() > 2) {
					if (trimmedTag.toUpperCase().charAt(0) == 'F' && trimmedTag.toUpperCase().charAt(1) == 'O' && trimmedTag.toUpperCase().charAt(2) == 'R') {
						forTagParser();
					}
					if (trimmedTag.toUpperCase().charAt(0) == 'E' && trimmedTag.toUpperCase().charAt(1) == 'N' && trimmedTag.toUpperCase().charAt(2) == 'D') {
						parsingTree.pop();
					}
				}
				if (trimmedTag.length() > 1) {
					if (trimmedTag.charAt(0) == '=') {
						echoTagParser();
					}
				}
			}
			else {
				addTextNode();
			}
			tagAndTextArrayPointer++;
		}
	}



	/**
	 * Glavna metoda parsera, obrađuje varijablu s tekstualnim unosom te je dijeli na Text elemente
	 * i Tag elemente.
	 * Nema ulaznih ni izlaznih argumenata.
	 */

	public final void parsingFunction() {
		try {
			int stringPointer = 0;
			final int docbodyLength = docbody.length();
			String textElement = new String();
			char readCharNext = '\0';

			while(stringPointer < docbodyLength) {

				// Učitava idući znak te znak nakon njega (ako takav postoji)
				char readChar = docbody.charAt(stringPointer);
				if (stringPointer+1 != docbodyLength) {
					readCharNext = docbody.charAt(stringPointer + 1);
				}
				else {
					readCharNext = '\0';
					textElement += readChar;
					tagAndTextArray[tagAndTextArrayPointer] = textElement;
					break;
				}

				// Ako ne dolazi vitičasta zagrada ili backslash, konkatenira znakove na textElement
				if ( readChar != '{' && readChar != '\\' ) {
					textElement += readChar;
					stringPointer++;
					readChar = docbody.charAt(stringPointer);
				}

				// Provjerava da li se { nalazi kao znak
				else if ( readChar == '\\' && readCharNext == '{' ) {
					textElement += '\\';
					textElement += '{';
					stringPointer += 2;
					readChar = docbody.charAt(stringPointer);
				}

				else if ( readChar == '\\' && readCharNext != '{' ) {
					textElement += readChar;
					textElement += readCharNext;
					stringPointer += 2;
					readChar = docbody.charAt(stringPointer);
				}

				else if ( readChar == '{' && readCharNext == '$' ) {

					// Zapisuje dobiveni Text Token u textArray
					if(!textElement.isEmpty()) {
						tagAndTextArray[tagAndTextArrayPointer] = textElement;
						textElement = "";
						tagAndTextArrayPointer++;
					}

					// Alokacija memorije ukoliko niz nije dovoljno velik
					if (tagAndTextArrayPointer + 1 > maxSize) {
						maxSize *= 2;
						final String[] newTagAndTextArray = new String[maxSize];
						System.arraycopy(tagAndTextArray, 0, newTagAndTextArray, 0, tagAndTextArray.length);
						tagAndTextArray = newTagAndTextArray;
					}


					// Čita Tag Token
					textElement += "{$";
					stringPointer += 2;
					readChar = docbody.charAt(stringPointer);

					while (readChar != '}') {
						textElement += readChar;
						stringPointer++;
						readChar = docbody.charAt(stringPointer);

					}
					textElement += "}";
					stringPointer++;
					// Zapisuje dobiveni Tag Token u tagArray
					tagAndTextArray[tagAndTextArrayPointer] = textElement;
					textElement = "";
					tagAndTextArrayPointer++;

				}
			}
			System.out.println("Parsing Finished");
		}
		catch (final SmartScriptParserException e) {
			throw new SmartScriptParserException("Parsing failed!");
		}
	}

}
