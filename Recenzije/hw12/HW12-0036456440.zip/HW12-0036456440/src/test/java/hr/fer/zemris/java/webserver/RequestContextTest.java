package hr.fer.zemris.java.webserver;

import static org.junit.Assert.*;

import java.io.IOException;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import hr.fer.zemris.java.webserver.RequestContext.RCCookie;

import org.junit.Test;

public class RequestContextTest {

	@Test
	public void requestContextTest() throws IOException {

		OutputStream os = Files.newOutputStream(Paths.get("test1.txt"));

		RequestContext rc = new RequestContext(os, new HashMap<String, String>(),
				new HashMap<String, String>(),
				new ArrayList<RequestContext.RCCookie>());

		rc.setEncoding("ISO-8859-2");
		rc.setMimeType("text/plain");
		rc.setStatusCode(205);
		rc.setStatusText("Tekst");

		rc.write("Neki tekst.");

		assertEquals("Get parameter failed.", null, rc.getParameter("element"));
		rc.setPersistentParameter("element", "value");
		assertEquals("Get parameter failed.", "value", rc.getPersistentParameter("element"));
		rc.setTemporaryParameter("element", "value2");
		assertEquals("Get parameter failed.", "value2", rc.getTemporaryParameter("element"));
		rc.removePersistentParameter("element");
		rc.removeTemporaryParameter("element");

		os.close();

	}

	@Test
	public void requestContextTest2() throws IOException {

		OutputStream os = Files.newOutputStream(Paths.get("test1.txt"));

		RequestContext rc = new RequestContext(os, new HashMap<String, String>(),
				new HashMap<String, String>(),
				new ArrayList<RequestContext.RCCookie>());

		rc.setEncoding("ISO-8859-2");
		rc.setMimeType("images/png");
		rc.setStatusCode(205);
		rc.setStatusText("Tekst");


		byte[] bytes = {1, 2, 1, 2, 1};
		rc.write(bytes);

		os.close();

	}

	@Test
	public void rcCookieTest() throws IOException {

		RCCookie cookie = new RCCookie("cookie", "someValue", 1000, "127.0.0.1", "/");
		assertEquals("Name getter failed.", "cookie", cookie.getName());
		assertEquals("Value getter failed.", "someValue", cookie.getValue());
		assertEquals("MaxAge getter failed.", 1000, cookie.getMaxAge(), 2E-8);
		assertEquals("Domain getter failed.", "127.0.0.1", cookie.getDomain());
		assertEquals("Path getter failed.", "/", cookie.getPath());

	}

	@Test
	public void createHeaderTest() throws IOException {

		OutputStream os = Files.newOutputStream(Paths.get("test1.txt"));

		RCCookie cookie = new RCCookie("cookie", "someValue", 1000, "127.0.0.1", "/");
		cookie.setHttpOnlyOn();

		assertEquals("Http-only failed.", true, cookie.getHttpOnly());

		List<RCCookie> cookieList = new ArrayList<>();
		cookieList.add(cookie);

		RequestContext rc = new RequestContext(os, new HashMap<String, String>(),
				new HashMap<String, String>(),
				cookieList);

		rc.addRCCookie(cookie);

		rc.write("Tekst");

	}

	@Test (expected=IllegalArgumentException.class)
	public void headerCreatedTest() throws IOException {

		OutputStream os = Files.newOutputStream(Paths.get("test1.txt"));

		RequestContext rc = new RequestContext(os, new HashMap<String, String>(),
				new HashMap<String, String>(),
				new ArrayList<RequestContext.RCCookie>());

		rc.write("Čevapčići i Šiščevapčići.");
		rc.setStatusCode(205);
	}

	@Test (expected=IllegalArgumentException.class)
	public void streamNullTest() throws IOException {

		@SuppressWarnings("unused")
		RequestContext rc = new RequestContext(null, new HashMap<String, String>(),
				new HashMap<String, String>(),
				new ArrayList<RequestContext.RCCookie>());

	}

}
