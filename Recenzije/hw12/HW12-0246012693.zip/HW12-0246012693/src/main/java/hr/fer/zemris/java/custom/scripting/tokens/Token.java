package hr.fer.zemris.java.custom.scripting.tokens;

/**
 * 
 * @author Antun Sekulic 0246012693
 * 
 */

public class Token {
	
	/**
	 * Funkcija za ispis tokena
	 * @return String vrijednost sadrzaja tokena
	 */
	public String asText() {
		return "";
	}
}
