package hr.fer.zemris.java.webserver.workers;

import hr.fer.zemris.java.webserver.RequestContext;

/**
 * Suvelje za rad s workerima
 * 
 * @author Antun Sekulic 0246012693
 * 
 */
public interface IWebWorker {
	/**
	 * Metoda koja prosljedjuje posao generiranja odgovora odredjenom workeru
	 * 
	 * @param context
	 *            {@link RequestContext} objekt u koji treba pohraniti odgovor
	 */
	public void processRequest(RequestContext context);
}