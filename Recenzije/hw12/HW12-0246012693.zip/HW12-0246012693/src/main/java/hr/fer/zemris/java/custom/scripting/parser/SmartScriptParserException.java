package hr.fer.zemris.java.custom.scripting.parser;
/**
 * 
 * @author Antun Sekulic 0246012693
 *
 */

public class SmartScriptParserException extends RuntimeException{



	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public SmartScriptParserException() {
		super();
	}

	public SmartScriptParserException(String message) {
		super(message);
	}

}
