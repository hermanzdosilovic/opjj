package hr.fer.zemris.java.custom.scripting.nodes;

import hr.fer.zemris.java.custom.scripting.parser.SmartScriptParser;

/**
 * Sucelje za obilazak {@link Node} objekata koje je {@link SmartScriptParser}
 * generirao
 * 
 * @author Antun Sekulic 0246012693
 * @version
 */
public interface INodeVisitor {
	/**
	 * Obilazak {@link TextNode} objekta
	 * 
	 * @param node
	 */
	public void visitTextNode(TextNode node);

	/**
	 * Obilazak {@link ForLoopNode} objekata
	 * 
	 * @param node
	 */
	public void visitForLoopNode(ForLoopNode node);

	/**
	 * Obilazak {@link EchoNode} objekta
	 * 
	 * @param node
	 */
	public void visitEchoNode(EchoNode node);

	/**
	 * Obilazak {@link DocumentNode} objkata
	 * 
	 * @param node
	 */
	public void visitDocumentNode(DocumentNode node);
}
