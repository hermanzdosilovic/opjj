package hr.fer.zemris.java.custom.scripting.tokens;

/**
 * 
 * @author Antun Sekulic 0246012693
 * 
 */

public class TokenVariable extends Token {

	private String name;

	/**
	 * Konstruktor
	 * 
	 * @param name
	 *            String ime varijable
	 */
	public TokenVariable(String name) {
		super();
		this.name = name;
	}

	/**
	 * Vraca ime varijable
	 * 
	 * @return strings
	 */
	public String getName() {
		return name;
	}

	@Override
	public String asText() {
		return "TokenVariable: " + name;
	}

	@Override
	public String toString() {
		return name;
	}
}
