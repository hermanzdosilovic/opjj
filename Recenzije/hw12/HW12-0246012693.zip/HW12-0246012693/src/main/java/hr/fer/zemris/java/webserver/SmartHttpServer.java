package hr.fer.zemris.java.webserver;

import hr.fer.zemris.java.custom.scripting.exec.SmartScriptEngine;
import hr.fer.zemris.java.custom.scripting.parser.SmartScriptParser;
import hr.fer.zemris.java.webserver.RequestContext.RCCookie;
import hr.fer.zemris.java.webserver.workers.IWebWorker;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PushbackInputStream;
import java.math.BigInteger;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.NoSuchElementException;
import java.util.Properties;
import java.util.Random;
import java.util.Scanner;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Razred koji predstavlja implementaciju jednostavnog posluzitelja.
 * 
 * @author Antun Sekulic 0246012693
 * @version 1.0
 */
public class SmartHttpServer {

	private String address;
	private int port;
	private int workerThreads;
	private int sessionTimeout;
	private Map<String, String> mimeTypes = new HashMap<String, String>();
	private ServerThread serverThread;
	private ExecutorService threadPool;
	private Path documentRoot;
	private Properties properties;
	private Map<String, IWebWorker> workersMap;
	private Map<String, SessionMapEntry> sessions = new HashMap<String, SmartHttpServer.SessionMapEntry>();
	private Random sessionRandom = new Random();
	private Timer alarm;

	/**
	 * Konstrukto novog {@link SmartHttpServer} objekta. Predaje se putanja do
	 * config datotek.
	 * 
	 * @param configFileName
	 */
	public SmartHttpServer(String configFileName) {
		workersMap = new HashMap<String, IWebWorker>();
		setProperties(configFileName);
		serverThread = new ServerThread();
		alarm = new Timer();
	}

	/**
	 * Metoda koja ucitava postavke posluzitelja. Predaje se putanja do config
	 * datotke iz koje ucitavamo postavke.
	 * 
	 * @param configFileName
	 */
	private void setProperties(String configFileName) {
		properties = new Properties();
		try {
			properties.load(new FileInputStream(configFileName));
			address = properties.getProperty("server.address");
			port = Integer.parseInt(properties.getProperty("server.port"));
			workerThreads = Integer.parseInt(properties.getProperty("server.workerThreads"));
			documentRoot = Paths.get(properties.getProperty("server.documentRoot"));
			sessionTimeout = Integer.parseInt(properties.getProperty("session.timeout"));
			setMimeTypes(properties.getProperty("server.mimeConfig"));
			setWebWorkers(properties.getProperty("server.workers"));
		} catch (FileNotFoundException e) {

			e.printStackTrace();
		} catch (IOException e) {

			e.printStackTrace();
		}

	}

	/**
	 * Metoda koja ucitava podrzane Worker razrede iz config datoteke. Predaje
	 * se ime config datoteke
	 * 
	 * @param property
	 */
	private void setWebWorkers(String property) {
		Scanner scanner = null;
		try {
			scanner = new Scanner(new File(property));
		} catch (final FileNotFoundException e) {
			e.printStackTrace();
		}

		String line;
		while (scanner.hasNext()) {
			line = scanner.nextLine();

			if (line.startsWith("#") || line.isEmpty()) {
				continue;
			}
			final String[] parts = line.split("\\s*=\\s*");
			final String path = parts[0];
			final String fqcn = parts[1];

			if (workersMap.containsKey(path)) {
				throw new IllegalArgumentException("Worker already exist. " + path);
			}
			try {
				Class<?> referenceToClass = this.getClass().getClassLoader().loadClass(fqcn);
				Object newObject = referenceToClass.newInstance();
				IWebWorker iww = (IWebWorker) newObject;
				workersMap.put(path, iww);
			} catch (InstantiationException | IllegalAccessException | ClassNotFoundException e) {
				e.printStackTrace();
			}
		}
	}

	/**
	 * Metoda koja ucitava podrzane MIME tipove iz config datoteke. Predaje se
	 * ime config datotke.
	 * 
	 * @param property
	 */
	private void setMimeTypes(String property) {
		Properties mimeProperties = new Properties();
		try {
			mimeProperties.load(new FileInputStream(property));
			Enumeration<Object> mimeKeys = mimeProperties.keys();
			while (mimeKeys.hasMoreElements()) {
				String key = (String) mimeKeys.nextElement();
				mimeTypes.put(key, (String) mimeProperties.get(key));
			}
		} catch (final Exception e) {
			e.printStackTrace();
		}

	}

	/**
	 * Metoda koja pokrece posluzitelja
	 */
	protected synchronized void start() {
		if (!serverThread.isAlive()) {
			serverThread.start();
			threadPool = Executors.newFixedThreadPool(workerThreads);
			alarm.schedule(new TimerTask() {

				@Override
				public void run() {
					System.out.println("cistim Cookie");
					cleanCookies();
				}

			}, 300_000);
		}
	}

	/**
	 * Metoda koja zaustavlja posluzitelja
	 */
	protected synchronized void stop() {
		threadPool.shutdown();
		alarm.cancel();
		try {
			serverThread.join();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Pomocna metoda koja brise nevaljane sjednice iz mape sjednica
	 */
	private void cleanCookies() {
		long now = new Date().getTime();
		for (Entry<String, SessionMapEntry> entry : sessions.entrySet()) {
			if (entry.getValue().validUntil < now) {
				sessions.remove(entry.getKey());
				System.out.println("cistim Cookie " + entry.getKey());
			}
		}
	}

	/**
	 * Pomocni razred koji predstavlja glavnu ddretvu posluzitelja, koja
	 * prihvaca klijentske zahtjeve i prosljedjuje ih pomocnim dretvama koje
	 * obradjuju te zahtjeve.
	 * 
	 * @author Antun Sekulic 0246012693
	 * @version 1.0
	 */
	protected class ServerThread extends Thread {
		ServerSocket serverSocket;

		@Override
		public void run() {

			try {
				// open serverSocket on specified port
				serverSocket = new ServerSocket(port);
				System.out.println("server pokrenut " + port + " root " + documentRoot.toString());
				while (true) {
					Socket client;
					System.out.println("server radi");
					client = serverSocket.accept();
					ClientWorker cw = new ClientWorker(client);
					threadPool.submit(cw);
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	/**
	 * Privatni razred koji implementira {@link Runnable} sucelje i obradju
	 * korisnicki zahtijev u posebnoj dretvi.
	 * 
	 * @author Antun Sekulic 0246012693
	 * @version 1.0
	 */
	private class ClientWorker implements Runnable {

		private Socket csocket;
		private PushbackInputStream istream;
		private OutputStream ostream;
		private String version;
		private String method;
		private Map<String, String> params = new HashMap<String, String>();
		private Map<String, String> permPrams = null;
		private List<RCCookie> outputCookies = new ArrayList<RequestContext.RCCookie>();
		private String SID;
		private RequestContext rc;

		/**
		 * Konstruktor novog {@link ClientWorker} objekta
		 * 
		 * @param csocket
		 */
		public ClientWorker(Socket csocket) {
			super();
			this.csocket = csocket;
		}

		// requestContext = new RequestContext(ostream, params, permPrams,
		// outputCookies);
		@Override
		public void run() {
			try {
				System.out.println("novi worker");
				String requestedPath;
				try {
					istream = new PushbackInputStream(csocket.getInputStream());
					ostream = csocket.getOutputStream();
				} catch (IOException e) {
					e.printStackTrace();
				}
				rc = new RequestContext(ostream, params, permPrams, outputCookies);
				List<String> request = readRequest();
				if (request.isEmpty()) {
					createErrorStatus(400);
					return;
				}
				String firstLine = request.get(0);
				// Extract (method, requestedPath, version) from firstLine
				// if method not GET or version not HTTP/1.0 or HTTP/1.1 return
				// response status 400
				String[] methodPathVersion = firstLine.split("\\s+");
				method = methodPathVersion[0];
				requestedPath = methodPathVersion[1];
				version = methodPathVersion[2];

				System.out.println("zatrazio si: " + requestedPath);

				if (!(method.equals("GET") && (version.equals("HTTP/1.0") || version.equals("HTTP/1.1")))) {
					createErrorStatus(400);
					return;
				}

				checkSesion(request);

				String path;
				String paramString;
				String[] pathArgs = requestedPath.split("\\?");
				path = pathArgs[0].substring(1);
				Path resourcePath = documentRoot.resolve(path).normalize();
				// (path, paramString) = split requestedPath to path and
				// parameterString
				if (pathArgs.length > 1) {
					paramString = pathArgs[1];
					parseParameters(paramString);

				}
				// parameters
				// requestedPath = resolve path with respect to documentRoot
				// if requestedPath is not below documentRoot, return response
				// status 403 forbidden
				// check if requestedPath exists, is file and is readable; if
				// not,
				// return status 404

				// POZIVANJE WORKERA
				String extWorker = "ext/";
				String rootPath = "hr.fer.zemris.java.webserver.workers.";
				if (path.startsWith(extWorker)) {
					String className = rootPath + path.substring(extWorker.length());
					Object worker = getWorker(className);
					if (worker == null) {
						createErrorStatus(404);
					} else {
						IWebWorker iww = (IWebWorker) worker;
						iww.processRequest(rc);
					}
					return;
				}

				if (workersMap.containsKey("/" + path)) {
					workersMap.get("/" + path).processRequest(rc);
					return;
				}
				if (!resourcePath.startsWith(documentRoot)) {
					createErrorStatus(403);
					return;
				}

				if (!Files.exists(resourcePath)
						|| !(Files.isRegularFile(resourcePath) && Files.isReadable(resourcePath))) {
					createErrorStatus(404);
					System.out.println("404");
					return;
				}

				// else extract file extension
				String extension = getExtension(resourcePath);

				// find in mimeTypes map appropriate mimeType for current file
				// extension
				// (you filled that map during the construction of
				// SmartHttpServer
				// from mime.properties)
				// if no mime type found, assume application/octet-stream
				if (extension.equals("smscr")) {
					runScript(resourcePath);
				} else {
					String mime = mimeTypes.get(extension);
					if (null == mime) {
						mime = "application/octet-stream";
					}
					rc.setMimeType(mime);
					rc.setStatusCode(200);
					writeResponse(resourcePath);
				}
				// to 200
				// If you want, you can modify RequestContext to allow you to
				// add
				// additional headers
				// so that you can add “Content-Length: 12345” if you know that
				// file
				// has 12345 bytes
				// open file, read its content and write it to rc (that will
				// generate header and send
				// file bytes to client)
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				try {
					csocket.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}

		/**
		 * Metoda koja provjera da li vec postoji sjednica, i ako ne postoji
		 * stvara novu. Prima listu {@link String} objekta koji predstavljaju
		 * linije u HTTP upitu
		 * 
		 * @param request
		 *            {@link List} {@link String} objekta
		 */
		private synchronized void checkSesion(List<String> request) {
			String sidCandidate = getCookie(request);

			if (sidCandidate == null) {
				createSession(address);
			} else {
				SessionMapEntry session = sessions.get(sidCandidate);
				if (session == null) {
					createSession(address);
				} else if (session.validUntil < new Date().getTime()) {
					sessions.remove(sidCandidate);
					createSession(address);
				} else {
					SID = sidCandidate;
					session.validUntil = new Date().getTime() + (sessionTimeout * 1000);
					System.out.println(session.validUntil);
				}
			}

			permPrams = sessions.get(SID).map;
			System.out.println("parametri cookia: " + sessions.size());
			rc.setPersistentParameters(permPrams);
		}

		/**
		 * Metoda koja stvara novu sjednicu. Predaje se adresa koju je korisnik
		 * zatrazio.
		 * 
		 * @param hostAddress
		 */
		private synchronized void createSession(String hostAddress) {
			SID = nextSessionId();
			SessionMapEntry session = new SessionMapEntry();
			session.sid = SID;
			session.validUntil = new Date().getTime() + (sessionTimeout * 1000);
			System.out.println(session.validUntil);
			session.map = new ConcurrentHashMap<String, String>();
			sessions.put(SID, session);
			outputCookies.add(new RCCookie("sid", SID, null, address, "/"));
			System.out.println("radim novi cookie " + SID);
		}

		/**
		 * Metoda koja generira jedistveni random kljuc od 20 znakova, koji
		 * sluze kao jedinstveni identifikator sje.dnice
		 * 
		 * @return {@link String} objekt identifikator sjednice
		 */
		private synchronized String nextSessionId() {
			return new BigInteger(130, sessionRandom).toString(20).toUpperCase();
		}

		/**
		 * Metoda koja iz liste zahtjeva trazi parametre Cookia, i utvrdju da li
		 * postoji trenutno aktivna sjednica, i ako postoji vraca njezin ID, ako
		 * ne postoji vraca null
		 * 
		 * @param request
		 *            {@link List} {@link String} objekta koji predstavlja listu
		 *            zahtjeva
		 * @return {@link String} SID sjednice
		 */
		private synchronized String getCookie(List<String> request) {
			String sidCandidate = null;
			for (String line : request) {
				System.out.println("request line: " + line);
				if (!line.startsWith("Cookie:")) {
					continue;
				}
				String namesAndValues = line.substring("Cookie: ".length());
				final String[] cookies = namesAndValues.split(";");
				for (String cookie : cookies) {
					if (cookie.trim().startsWith("sid")) {
						sidCandidate = cookie.split("=")[1];
						sidCandidate = sidCandidate.substring(1, sidCandidate.length() - 1);
					}
				}
			}
			System.out.println("getCookie: " + sidCandidate);
			return sidCandidate;
		}

		/**
		 * Metoda koja s obzirom na ime klase vraca novi worker objekt
		 * 
		 * @param className
		 * @return worker
		 */
		private Object getWorker(String className) {
			Object worker = null;
			try {
				Class<?> referenceToClass = this.getClass().getClassLoader().loadClass(className);
				worker = referenceToClass.newInstance();
			} catch (InstantiationException | IllegalAccessException | ClassNotFoundException e) {
				e.printStackTrace();
			}
			return worker;
		}

		/**
		 * Metoda koja izvrsava skriptu. Predaje se putanja do skripte
		 * 
		 * @param resourcePath
		 */
		private void runScript(Path resourcePath) {
			System.out.println("izvrsavam skriptu " + resourcePath.toString());
			String documentBody = null;
			try {
				documentBody = new String(Files.readAllBytes(resourcePath));
			} catch (final IOException e) {
				e.printStackTrace();
			}
			new SmartScriptEngine(new SmartScriptParser(documentBody).getDocumentNode(), rc).execute();
		}

		/**
		 * Metoda koja s zapisuje zatrazeni sadrzaj u {@link RequestContext}
		 * {@link OutputStream}. Predaje se putanja do resursa kojeg treba
		 * zapisati.
		 * 
		 * @param resourcePath
		 */
		private void writeResponse(Path resourcePath) {
			FileInputStream input = null;
			try {
				input = new FileInputStream(resourcePath.toFile());
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}

			byte[] buf = new byte[1024];
			while (true) {
				int len;
				try {
					len = input.read(buf);
					if (len == -1) {
						break;
					}
					final byte[] buff = new byte[len];
					for (int i = 0; i < len; i++) {
						buff[i] = buf[i];
					}
					rc.write(buff);
				} catch (IOException e) {
					e.printStackTrace();
					try {
						input.close();
					} catch (IOException e1) {
						e1.printStackTrace();
					}
				}
			}

		}

		/**
		 * Metoda koja vraca ekstenziju iz zatrazenog resursa.
		 * 
		 * @param resourcePath
		 * @return ekstenzija
		 */
		private String getExtension(Path resourcePath) {
			String name = resourcePath.toFile().getName();
			final int dotPos = name.lastIndexOf('.');
			if (dotPos < 0) {
				return null;
			}
			String extension = name.substring(dotPos + 1);
			if (extension.isEmpty()) {
				return null;
			}
			return extension;
		}

		/**
		 * Metoda koja parsira parametre zahtjeva.
		 * 
		 * @param paramString
		 */
		private void parseParameters(String paramString) {
			String[] values = paramString.split("&");
			for (int i = 0; i < values.length; i++) {
				String[] valuePair = values[i].split("=");
				if (valuePair.length != 2) {
					createErrorStatus(400);
					return;
				}
				params.put(valuePair[0], valuePair[1]);
			}
		}

		/**
		 * Metoda koja generira odgovore ako je doslo do pogreske. Predaje se
		 * stustni kod pogreske.
		 * 
		 * @param statusCode
		 */
		private void createErrorStatus(int statusCode) {
			String message = "Error";
			switch (statusCode) {
			case 400:
				message = "Bad Request";
				break;
			case 403:
				message = "Forbidden";
				break;
			case 404:
				message = "Not Found";
				break;
			default:
				message = "Undescribed error";
			}

			rc.setStatusCode(statusCode);
			rc.setStatusText(message);
			try {
				// generiraj html opis greške
				rc.write("<!doctype html><html>" + "<head><title>SmartHttpServer</title></head>" + "<body><h1>Error "
						+ statusCode + "</h1><h2>" + message + "</h2></body>" + "</html>");
			} catch (final IOException e) {
				e.printStackTrace();
			}
		}

		/**
		 * Metoda koja vraca {@link List} {@link String} objekta. Svaki zapis u
		 * listi je jedan redak u HTTP zahtjevu kojeg obradjujemo
		 * 
		 * @return Lista redaka HTTP zhtjeva
		 */
		private List<String> readRequest() {
			@SuppressWarnings("resource")
			final Scanner sc = new Scanner(istream);
			final List<String> header = new ArrayList<String>();
			try {
				while (true) {
					String line = sc.nextLine();
					if (line.equals("\r\n") || line.isEmpty()) {
						break;
					}
					header.add(line);
				}
			} catch (final NoSuchElementException ignorable) {
			}
			return header;
		}

	}

	/**
	 * Pomocni razred koji sluzi za pohranjivanje sjednice. U njega se spremaju
	 * parametri sjednice.
	 * 
	 * @author Antun Sekulic 0246012693
	 * @version 1.0
	 */
	private static class SessionMapEntry {
		@SuppressWarnings("unused")
		String sid;
		long validUntil;
		Map<String, String> map;

	}

	/**
	 * Main metoda koja pokrece server. Predaje se putanja do config datoteke
	 * 
	 * @param args
	 * @throws IOException
	 */
	public static void main(final String[] args) throws IOException {
		if (args.length != 1) {
			System.err.println("Path to config file expected.");
			System.exit(-1);
		}
		final SmartHttpServer server = new SmartHttpServer(args[0]);
		server.start();
	}

}
