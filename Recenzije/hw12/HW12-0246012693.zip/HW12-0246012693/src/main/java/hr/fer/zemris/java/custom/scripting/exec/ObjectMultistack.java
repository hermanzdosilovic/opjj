package hr.fer.zemris.java.custom.scripting.exec;

import java.util.EmptyStackException;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

/**
 * Razred koji predstavlja listu stogova. Svaki stog se identificira sa
 * vlastitim kljucem tipa String. Na stog je moguce spremiti ValueWrapper
 * objekte
 * 
 * @author Antun Sekulic 0246012693
 * @version 1.0
 */
public class ObjectMultistack {
	/**
	 * Privatna mapa stogova
	 */
	private Map<String, MultistackEntry> stackWrapper;

	/**
	 * Stvara novu praznu instancu <tt>ObjectMultistack</tt> razreda.
	 */
	public ObjectMultistack() {
		stackWrapper = new HashMap<>();
	}

	/**
	 * Push na stoga odredjenog imena
	 * 
	 * @param name
	 *            ime stoga
	 * @param valueWrapper
	 *            objekt koji stavljamo na stog
	 */
	public void push(String name, ValueWrapper valueWrapper) {
		if (null == stackWrapper.get(name)) {
			stackWrapper.put(name, new MultistackEntry(valueWrapper));
		} else {
			stackWrapper.get(name).push(valueWrapper);
		}
	}

	/**
	 * Pop sa stoga. Vraca objekt i mice ga sa stoga.
	 * 
	 * @param name
	 *            ime stoga
	 * @return vraca se zadnji objekt na stogu,ValuWrapper
	 * @throws EmptyStackException
	 *             ako je stog prazan ili ne postoji stog s tim imenom
	 */
	public ValueWrapper pop(String name) {
		MultistackEntry stack = stackWrapper.get(name);
		if (null != stack) {
			return stack.pop();
		}
		throw new EmptyStackException();
	}

	/**
	 * Peek sa stoga. Vraca objekt sa stoga, ali ga ne mice sa stoga.
	 * 
	 * @param name
	 *            ime stoga
	 * @return vraca ValueWrapper
	 * @throws EmptyStackException
	 *             ako je stog prazan ili ne postoji stog s tim imenom
	 */
	public ValueWrapper peek(String name) {
		MultistackEntry stack = stackWrapper.get(name);
		if (null != stack) {
			return stack.peek();
		}
		throw new EmptyStackException();
	}

	/**
	 * Metoda koja proverava da li je odredjeni stog prazan Vraca true ako stog
	 * ne postoji s trazenim imenom.
	 * 
	 * @param name
	 *            ime stoga
	 * @return true ako je prazan, false suprotno
	 */
	public boolean isEmpty(String name) {
		MultistackEntry stack = stackWrapper.get(name);
		if (null != stack) {
			return stack.isEmpty();
		}
		return true;

	}

	/**
	 * Privatni razred koji predstavlja unutarnju stog koji se sprema pod
	 * odredjenim kljucem
	 * 
	 * @author Antun Sekulic 0246012693
	 * @version 1.0
	 */
	private static class MultistackEntry {
		/**
		 * lista koja predstavlja stog
		 */
		private List<ValueWrapper> linkedList;
		/**
		 * pokazivac na trenutnu poziciju stoga
		 */
		private int size;

		/**
		 * Stvara praznu instancu <tt>MultistackEntry</tt> objekta
		 */
		@SuppressWarnings("unused")
		public MultistackEntry() {
			this.linkedList = new LinkedList<>();
			this.size = 0;
		}

		/**
		 * Stvara novu instancu <tt>MultistackEntry</tt> objekta i u nju stavlja
		 * predani objekt
		 * 
		 * @param valueWrapper
		 *            objekt koji zelimo staviti na stog
		 */
		public MultistackEntry(ValueWrapper valueWrapper) {
			this.linkedList = new LinkedList<>();
			linkedList.add(valueWrapper);
			this.size = 1;
		}

		/**
		 * Implementacija pop metode.
		 * 
		 * @return vraca {@link ValueWrapper} objekt i brise ga sa stoga
		 * @throws EmptyStackException ako je stog prazan 
		 */
		private ValueWrapper pop() {
			if (size > 0) {
				ValueWrapper object = linkedList.get(size - 1);
				linkedList.remove(size - 1);
				size--;
				return object;
			}
			throw new EmptyStackException();
		}

		/**
		 * Implementacija peek metode.
		 * 
		 * @return vraca {@link ValueWrapper}
		 * @throws EmptyStackException ako je stog prazan
		 */
		private ValueWrapper peek() {
			if (size > 0) {
				return linkedList.get(size - 1);
			}
			throw new EmptyStackException();
		}

		/**
		 * Implementacija push metode
		 * 
		 * @param object
		 *            {@link ValueWrapper} objekt koji stavljamo na stog
		 */
		private void push(ValueWrapper object) {
			linkedList.add(object);
			size++;
		}

		/**
		 * Metoda za ispitivanje stanja stoga
		 * 
		 * @return vraxa true ako je stog prazan, false suprotno
		 */
		private boolean isEmpty() {
			if (null != linkedList) {
				return linkedList.isEmpty();
			}
			return true;
		}
	}
}
