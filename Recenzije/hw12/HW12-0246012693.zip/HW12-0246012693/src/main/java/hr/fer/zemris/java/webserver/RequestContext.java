package hr.fer.zemris.java.webserver;

import java.io.IOException;
import java.io.OutputStream;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Razred koji predstavlja odgovr header odgovora posluzitelja
 * 
 * @author Antun Sekulic 0246012693
 * @version 1.0
 */
public class RequestContext {

	private OutputStream outputStream;
	private Charset charset;
	private boolean containtsHeader;

	public String encoding = "UTF-8";
	public int statusCode = 200;
	public String statusText = "OK";
	public String mimeType = "text/html";

	private Map<String, String> parameters;
	private Map<String, String> temporaryParameters;
	private Map<String, String> persistentParameters;
	private List<RCCookie> outputCookies;

	/**
	 * Konstruktor novog {@link RequestContext} objekta, ocekuje
	 * {@link OutputStream} koji ne smije biti null, i opcionalno, mapu
	 * parametara, mapu parametara od sesije i lisu cookia
	 * 
	 * @param outputStream
	 * @param parameters
	 * @param persistentParameters
	 * @param outputCookies
	 * @throws IllegalArgumentException
	 *             ako je {@link OutputStream} null
	 */
	public RequestContext(OutputStream outputStream, Map<String, String> parameters,
			Map<String, String> persistentParameters, List<RCCookie> outputCookies) {
		if (null == outputStream) {
			throw new IllegalArgumentException("OutputStream can't be null");
		}

		this.outputStream = outputStream;

		if (null == parameters) {
			parameters = new HashMap<String, String>();
		}
		this.parameters = parameters;

		if (null == persistentParameters) {
			persistentParameters = new HashMap<>();
		}
		this.persistentParameters = persistentParameters;

		if (null == outputCookies) {
			outputCookies = new ArrayList<>();
		}
		this.outputCookies = outputCookies;
		containtsHeader = false;
		temporaryParameters = new HashMap<String, String>();
	}

	/**
	 * etter za mapu privremenih parametara
	 * 
	 * @return
	 */
	public Map<String, String> getTemporaryParameters() {
		return temporaryParameters;
	}

	/**
	 * Setter za mapu privremenih parametara
	 * 
	 * @param temporaryParameters
	 */
	public void setTemporaryParameters(Map<String, String> temporaryParameters) {
		this.temporaryParameters = temporaryParameters;
	}

	/**
	 * Getter za mapu parametara od sjednice
	 * 
	 * @return {@link Map}
	 */
	public Map<String, String> getPersistentParameters() {
		return persistentParameters;
	}

	/**
	 * Setter za mapu parametara od sjednice
	 * 
	 * @param persistentParameters
	 */
	public void setPersistentParameters(Map<String, String> persistentParameters) {
		this.persistentParameters = persistentParameters;
	}

	/**
	 * Getter za mapu parametara
	 * 
	 * @return {@link Map}
	 */
	public Map<String, String> getParameters() {
		return parameters;
	}

	/**
	 * Getter za vrijednost parametra odgovora
	 * 
	 * @param name
	 *            ime parametra
	 * @return {@link String} vrijednost paramaetra
	 */
	public String getParameter(String name) {
		return parameters.get(name);
	}

	/**
	 * Getter za {@link Set} kljuceva u mapi paramentara odgovora
	 * 
	 * @return
	 */
	public Set<String> getParameterNames() {
		return Collections.unmodifiableSet(parameters.keySet());

	}

	/**
	 * Getter za vrijednost
	 * 
	 * @param name
	 * @return
	 */
	public String getPersistentParameter(String name) {
		return persistentParameters.get(name);
	}

	/**
	 * Getter za {@link Set} kljuceva u mapi sesija
	 * 
	 * @return
	 */
	public Set<String> getPersistentParameterNames() {
		return Collections.unmodifiableSet(persistentParameters.keySet());
	}

	/**
	 * Setter za postaljvanje nove vrijednosti u mapu sesija. Predaje se kljuc i
	 * vrijednost
	 * 
	 * @param name
	 * @param value
	 */
	public void setPersistentParameter(String name, String value) {
		persistentParameters.put(name, value);
	}

	/**
	 * Metoda koja mice zahtjev iz mape sesija. Predaje se kljuc koji zelimo
	 * maknuti
	 * 
	 * @param name
	 */
	public void removePersistentParameter(String name) {
		persistentParameters.remove(name);
	}

	/**
	 * Getter za mapu privremenih parametara. Predaje se kljuci parametra kojeg
	 * zelimo dohvatit. Vraca String vrijendnost.
	 * 
	 * @param name
	 * @return
	 */
	public String getTemporaryParameter(String name) {
		return temporaryParameters.get(name);
	}

	/**
	 * Getter za {@link Set} kljuceva iz mape privremenih parametara
	 * 
	 * @return {@link Set}
	 */
	public Set<String> getTemporaryParameterNames() {
		return Collections.unmodifiableSet(temporaryParameters.keySet());
	}

	/**
	 * Metoda koja postavlja parametar u privremenu mapu parametara. Prime ime i
	 * vrijednost parametra kojeg ubacuje
	 * 
	 * @param name
	 * @param value
	 */
	public void setTemporaryParameter(String name, String value) {
		temporaryParameters.put(name, value);
	}

	/**
	 * Metoda koja brise zahtjev iz privremen mape parametara
	 * 
	 * @param name
	 */
	public void removeTemporaryParameter(String name) {
		temporaryParameters.remove(name);
	}

	/**
	 * Metoda koja postaljva encoding odgovora
	 * 
	 * @param encoding
	 */
	public void setEncoding(String encoding) {
		checkForHeader();
		this.encoding = encoding;

	}

	/**
	 * Metoda koja postavalj statu kod odgovora
	 * 
	 * @param statusCode
	 */
	public void setStatusCode(int statusCode) {
		checkForHeader();
		this.statusCode = statusCode;
	}

	/**
	 * Metoda koja postavlja status text odgovora
	 * 
	 * @param statusText
	 */
	public void setStatusText(String statusText) {
		checkForHeader();
		this.statusText = statusText;
	}

	/**
	 * Metoda koja postavlja MIME tip odgovora
	 * 
	 * @param mimeType
	 */
	public void setMimeType(String mimeType) {
		checkForHeader();
		this.mimeType = mimeType;
	}

	/**
	 * Metoda koja dodaje novi {@link RCCookie} objekt u odgovor
	 * 
	 * @param rcCookie
	 */
	public void addRCCookie(RCCookie rcCookie) {
		checkForHeader();
		outputCookies.add(rcCookie);
	}

	/**
	 * Metoda koja sapisuje podatke u odgovor. Prima polje {@link Byte} objekta
	 * koji predstavlju odgovor.
	 * 
	 * @param data
	 * @return
	 * @throws IOException
	 */
	public RequestContext write(byte[] data) throws IOException {
		if (!containtsHeader) {
			writeHeader();
		}
		outputStream.write(data);

		return this;
	}

	/**
	 * Metoda koja zapisuje podatke u odgovor. Prima {@link String} koji
	 * zapisuje kao odgovor
	 * 
	 * @param text
	 * @return
	 * @throws IOException
	 */
	public RequestContext write(String text) throws IOException {
		if (!containtsHeader) {
			writeHeader();
		}
		byte[] data = text.getBytes(charset);
		return write(data);
	}

	/**
	 * Metoda koja zapisuje header odgovora
	 */
	private void writeHeader() {
		containtsHeader = true;
		charset = Charset.forName(encoding);
		StringBuilder sb = new StringBuilder();
		sb.append("HTTP/1.1 ").append(statusCode).append(" ").append(statusText + "\r\n");
		sb.append("Content-Type: ").append(mimeType).append("; ");
		if (mimeType.startsWith("text")) {
			sb.append("charset=").append(encoding);
		}
		sb.append("\r\n");
		if (!outputCookies.isEmpty()) {
			// 'Set-Cookie: ' name '=”' value '”; Domain=' domain '; Path=' path
			// '; Max-Age=' maxAge
			for (RCCookie cookie : outputCookies) {
				sb.append("Set-Cookie: ").append(cookie.getName()).append("=\"").append(cookie.getValue())
						.append("\"");
				if (null != cookie.getDomain()) {
					sb.append("; ").append("Domain= ").append(cookie.getDomain());
				}
				if (null != cookie.getPath()) {
					sb.append("; ").append("Path= ").append(cookie.getPath());
				}
				if (null != cookie.getMaxAge()) {
					sb.append("; ").append("Max-Age= ").append(cookie.getMaxAge());
				}
				sb.append("\r\n");
			}
		}
		sb.append("\r\n");
		System.out.println("Zapisujem header u odgovor: " + sb.toString());
		byte[] data = sb.toString().getBytes(StandardCharsets.ISO_8859_1);
		try {
			outputStream.write(data);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Metoda koja provjerava da li smo vec zapisali header odgovora, ako jesmo
	 * baca {@link RuntimeException}
	 */
	private void checkForHeader() {
		if (containtsHeader) {
			throw new RuntimeException("Can't modify header. Header is already added to response.");
		}

	}

	/**
	 * Pomocni razred koji predstavlja cookie
	 * 
	 * @author Antun Sekulic 0246012693
	 * @version 1.0
	 */
	public static class RCCookie {

		private String name;
		private String value;
		private String domain;
		private String path;
		private Integer maxAge;

		/**
		 * Konstruktor novog {@link RCCookie} objekta
		 * 
		 * @param name
		 * @param value
		 * @param maxAge
		 * @param domain
		 * @param path
		 */
		public RCCookie(String name, String value, Integer maxAge, String domain, String path) {
			super();
			this.name = name;
			this.value = value;
			this.domain = domain;
			this.path = path;
			this.maxAge = maxAge;
		}

		/**
		 * Getter za ime
		 * 
		 * @return
		 */
		public String getName() {
			return name;
		}

		/**
		 * Getter za vrijednst
		 * 
		 * @return
		 */
		public String getValue() {
			return value;
		}

		/**
		 * Geter za domenu.
		 * 
		 * @return
		 */
		public String getDomain() {
			return domain;
		}

		/**
		 * Getter za putanju
		 * 
		 * @return
		 */
		public String getPath() {
			return path;
		}

		/**
		 * Getter za max age
		 * 
		 * @return
		 */
		public Integer getMaxAge() {
			return maxAge;
		}

	}

}
