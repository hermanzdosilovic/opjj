package hr.fer.zemris.java.custom.scripting.demo;

import hr.fer.zemris.java.custom.scripting.exec.SmartScriptEngine;
import hr.fer.zemris.java.custom.scripting.nodes.DocumentNode;
import hr.fer.zemris.java.custom.scripting.parser.SmartScriptParser;
import hr.fer.zemris.java.webserver.RequestContext;
import hr.fer.zemris.java.webserver.RequestContext.RCCookie;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Razred koji izvrsava skriptni jezik koji je parsira {@link SmartScriptParser}
 * razred
 * 
 * @author Antun Sekulic 0246012693
 * @version 1.0
 */
public class SmartScriptEngineTest {
	/**
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		osnovni();
		zbrajanje();
		brojPoziva();
		fibonacci();
	}

	public static void fibonacci() {
		String documentBody = readFromDisk("./fibonacci.smscr");
		Map<String, String> parameters = new HashMap<String, String>();
		Map<String, String> persistentParameters = new HashMap<String, String>();
		List<RCCookie> cookies = new ArrayList<RequestContext.RCCookie>();
		DocumentNode node = new SmartScriptParser(documentBody).getDocumentNode();
		new SmartScriptEngine(node, new RequestContext(System.out, parameters, persistentParameters, cookies))
				.execute();

	}

	public static void brojPoziva() {
		String documentBody = readFromDisk("./brojPoziva.smscr");
		Map<String, String> parameters = new HashMap<String, String>();
		Map<String, String> persistentParameters = new HashMap<String, String>();
		List<RCCookie> cookies = new ArrayList<RequestContext.RCCookie>();
		persistentParameters.put("brojPoziva", "3");
		RequestContext rc = new RequestContext(System.out, parameters, persistentParameters, cookies);
		new SmartScriptEngine(new SmartScriptParser(documentBody).getDocumentNode(), rc).execute();
		System.out.println("Vrijednost u mapi: " + rc.getPersistentParameter("brojPoziva"));

	}

	public static void osnovni() {
		String documentBody = readFromDisk("./osnovni.smscr");
		Map<String, String> parameters = new HashMap<String, String>();
		Map<String, String> persistentParameters = new HashMap<String, String>();
		List<RCCookie> cookies = new ArrayList<RequestContext.RCCookie>();
		// put some parameter into parameters map
		parameters.put("broj", "4");

		new SmartScriptEngine(new SmartScriptParser(documentBody).getDocumentNode(), new RequestContext(System.out,
				parameters, persistentParameters, cookies)).execute();

	}

	public static void zbrajanje() {
		String documentBody = readFromDisk("./zbrajanje.smscr");
		Map<String, String> parameters = new HashMap<String, String>();
		Map<String, String> persistentParameters = new HashMap<String, String>();
		List<RCCookie> cookies = new ArrayList<RequestContext.RCCookie>();
		parameters.put("a", "4");
		parameters.put("b", "2");
		// create engine and execute it
		DocumentNode node = new SmartScriptParser(documentBody).getDocumentNode();
		new SmartScriptEngine(node, new RequestContext(System.out, parameters, persistentParameters, cookies))
				.execute();

	}

	private static String readFromDisk(String string) {
		StringBuilder builder = new StringBuilder();
		BufferedReader br = null;
		try {
			// Moguce da ne radi na windosima
			br = new BufferedReader(new FileReader(string));

			String line = br.readLine();

			while (line != null) {
				builder.append(line);
				builder.append(System.lineSeparator());
				line = br.readLine();
			}

		} catch (FileNotFoundException e) {
		} catch (IOException e) {

		} catch (NullPointerException e) {

		} finally {
			try {
				if (br != null) {
					br.close();
				}
			} catch (IOException e) {
			}
		}
		return builder.toString();

	}

}
