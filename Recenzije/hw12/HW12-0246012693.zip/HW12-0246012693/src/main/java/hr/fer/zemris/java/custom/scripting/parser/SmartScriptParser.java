package hr.fer.zemris.java.custom.scripting.parser;

/**
 * 
 * @author Antun Sekulic 0246012693
 *
 */

import hr.fer.zemris.java.custom.collections.ArrayBackedIndexedCollection;
import hr.fer.zemris.java.custom.collections.ObjectStack;
import hr.fer.zemris.java.custom.scripting.nodes.DocumentNode;
import hr.fer.zemris.java.custom.scripting.nodes.EchoNode;
import hr.fer.zemris.java.custom.scripting.nodes.EndNode;
import hr.fer.zemris.java.custom.scripting.nodes.ForLoopNode;
import hr.fer.zemris.java.custom.scripting.nodes.Node;
import hr.fer.zemris.java.custom.scripting.nodes.TextNode;
import hr.fer.zemris.java.custom.scripting.tokens.Token;
import hr.fer.zemris.java.custom.scripting.tokens.TokenConstantDouble;
import hr.fer.zemris.java.custom.scripting.tokens.TokenConstantInteger;
import hr.fer.zemris.java.custom.scripting.tokens.TokenFunction;
import hr.fer.zemris.java.custom.scripting.tokens.TokenOperator;
import hr.fer.zemris.java.custom.scripting.tokens.TokenString;
import hr.fer.zemris.java.custom.scripting.tokens.TokenVariable;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class SmartScriptParser {

	private ObjectStack stack;

	/**
	 * konstruktor parsera
	 * 
	 * @param document
	 *            string u kojem se nalazi dokument koji zelimo parsirati
	 * @throws SmartScriptParserException
	 */

	public SmartScriptParser(String document) throws SmartScriptParserException {
		try {
			parse(document);
		} catch (Exception e) {
			e.printStackTrace();
			throw new SmartScriptParserException("Parser Error");

		}
	}

	/**
	 * funkcija za dohvacanje izparsiranog dokumenta
	 * 
	 * @return objekt DocumenteNode u koje se nalazi dokument
	 */
	public DocumentNode getDocumentNode() {
		try {
			return (DocumentNode) stack.pop();
		} catch (Exception e) {
			throw new SmartScriptParserException("cant read document");
		}
	}

	/**
	 * Glavna funkcija za parsiranje u kojoj se dogadja sva magija
	 * 
	 * @param document
	 *            string u koje se nalazi dokument
	 * @throws SmartScriptParserException
	 */
	private void parse(String document) throws SmartScriptParserException {
		//
		stack = new ObjectStack();
		DocumentNode documentNode = new DocumentNode();
		stack.push(documentNode);
		// nadji sve tagove u tekstu
		String regex = "((?<!\\\\)(?>\\\\\\\\)*)\\{\\$[^\"]*?((?<!\\\\)(?:\\\\\\\\)*\\\".*?(?<!\\\\)(?:\\\\\\\\)*\\\")?((?<!\\\\)(?:\\\\\\\\)*\\\\\")?[^\"]*?\\$\\}";
		Pattern pattern = Pattern.compile(regex, Pattern.DOTALL);
		Matcher matcher = pattern.matcher(document);
		String workingString = document;
		while (matcher.find()) {
			// string u kojem se nalazi cijeli pronadjeni node
			String nodeString = matcher.group();
			// sve sto se nalazi ispred noda zelimo spremiti kao TextNode, pa
			// odredjujemo gdje pocinje node
			Matcher matcher2 = Pattern.compile("((?<!\\\\)(?>\\\\\\\\)*)\\{\\$", Pattern.DOTALL)
					.matcher(workingString);
			matcher2.find();
			// pozicija na kojoj cemo rezati
			int cutPosition = matcher2.start();

			// jedini problem sa gornjim regexom je taj sto nam selektira i
			// paran broj \ koji se nalaze ispre noda
			// tako da je moguce da dobijemo "\\{$ =nesto$}" sto je zapravo
			// krivo. Donji dio koda popravlja taj nedostatak
			// tako sto gleda da li se ispred noda nalazi paran broj \ i onda ih
			// mice
			if (checkForBackslash(nodeString)) {
				int cutFix = tagStart(nodeString);
				// popravljamo poziciju za rezanje
				cutPosition += cutFix;
				nodeString = nodeString.substring(cutFix);
			}
			// ako je pozocija ya rezanje veca od duzine stringa bacamo error
			if (cutPosition >= workingString.length()) {
				throw new SmartScriptParserException("working string cut on wrong place!");
			}

			String textNodeString = workingString.substring(0, cutPosition);
			// ako imao string za ubaciti
			if (textNodeString.length() != 0) {
				// ubacujemo ga
				addTextNode(textNodeString);
			}

			// za sve ostale nodove moramo gledati kojeg su tipa
			Node node = determineNode(nodeString);
			// ako nismo uspjeli odrediti tip noda error
			if (null == node) {
				throw new SmartScriptParserException("Cant find out node type!!");
			}
			// gledamo da li node moze imati djecu, i ovisno o tome ga dodajemo
			// na stog ili ne
			if (node.canHaveChildren()) {
				// ubacujemo ga kao dijete i stavljamo na stog
				((Node) stack.peek()).addChildNode(node);
				stack.push(node);
			} else if (node instanceof EndNode) {
				// ako je end node, micemo zadnji node sa stoga
				stack.pop();
			} else {
				// ako ne moze imati djecu, ubacujemo ga samo kao dijete zadnjeg
				// noda
				((Node) stack.peek()).addChildNode(node);
			}
			// radni string zelimo sada skratiti za duzinu noda kojeg smo
			// obradili i duzinu eventualnog textNoda koji se nalazio ispred
			// njega
			workingString = workingString.substring(cutPosition + nodeString.length());
			// i obradjujemo sljedeci node
		}
		// ako smo obradili sve nodove a nismo dosli do kraja pocetnog stringa u
		// koje je dokument, ono sto je ostalo ubacujemo u textNode
		if (workingString.length() > 0) {
			addTextNode(workingString);
		}
	}

	/**
	 * funkcija koja provjerava da li string u textNodu zadovoljava pravila i
	 * ubacuje ga u Document strukturu ako da
	 * 
	 * @param textNodeString
	 *            string koji zelimo provjeriti i ubaciti
	 */
	private void addTextNode(String textNodeString) {
		if (checkForIllegalBackSlashForText(textNodeString)) {
			throw new SmartScriptParserException("Illegal backslash in text");
		}
		textNodeString = textNodeString.replaceAll("\\\\\\{", "{");

		TextNode textNode = new TextNode(textNodeString);
		((Node) stack.peek()).addChildNode(textNode);
	}

	/**
	 * Funkcija koja odredjuje o kojem se nodu radi Ujedno i parsira tokene iz
	 * noda
	 * 
	 * @param nodeString
	 *            string noda kojeg zelimo obraditi
	 * @return
	 */
	private Node determineNode(String nodeString) {
		// zelimo maknuti {$ sa pocetaka i $} sa kraja stringa
		nodeString = nodeString.substring(2).trim();
		nodeString = nodeString.substring(0, nodeString.length() - 2).trim();
		// ono sto je ostalo podjelimo u dva dijela po razmaku
		String[] nodeParts = nodeString.split(" ", 2);
		// prvu rijec pretvorimo u mala slova
		String firstWord = nodeParts[0].toLowerCase();
		// i sada gledamo o koje se tipu radi
		if (firstWord.equals("end")) {
			return new EndNode();
		} else if (firstWord.equals("for")) {
			// for node moramo dodatno parsirati
			return parseForlLoopNode(nodeParts[1]);
		} else if (nodeString.substring(0, 1).equals("=")) {
			// echo node moramo dodatno parsirati
			Token[] tokens = parseEchoTokens(nodeString.substring(1));
			return new EchoNode(tokens);
		}
		throw new SmartScriptParserException("Cant parse token " + nodeString);
	}

	/**
	 * Funkcija koja parsira ForLoop node
	 * 
	 * @param forBody
	 *            string u koje se nalazi tijelo noda
	 * @return vraca ForLoop node
	 */
	private ForLoopNode parseForlLoopNode(String forBody) {
		// sve tokene cemo spremiti u jedan array
		ArrayBackedIndexedCollection forTokens = new ArrayBackedIndexedCollection();
		// funkcija koja stvarno parsira tokene i vraca array
		forTokens = parseToken(forBody);
		// postno nam je uvijet da prva parametra ne smiju biti null, i da prvi
		// mora biti varijabal, bacamo error ako nije tako
		if (forTokens.size() < 3 || !(forTokens.get(0) instanceof TokenVariable)) {
			throw new SmartScriptParserException("For loop wrong parameters");
		}
		// dodjeljujemo vrijednosti
		TokenVariable variable = (TokenVariable) forTokens.get(0);
		Token startExpresion = (Token) forTokens.get(1);
		Token endExpresion = (Token) forTokens.get(2);
		Token stepExpresion = null;
		try {
			stepExpresion = (Token) forTokens.get(3);
		} catch (IndexOutOfBoundsException e) {
			// this parameter can be null
		}
		// vracamo forloop node
		return new ForLoopNode(variable, startExpresion, endExpresion, stepExpresion);
	}

	/**
	 * Funkcija koja parsira EchoNode tokne
	 * 
	 * @param tokensString
	 * @return vraca polje tokena koje se koriste za stvaranje Ecoh noda
	 */
	private Token[] parseEchoTokens(String tokensString) {

		ArrayBackedIndexedCollection tokensArray;
		tokensArray = parseToken(tokensString);
		// ako nismo nasli niti jedan token bacamo error
		if (null == tokensArray || tokensArray.size() == 0) {
			throw new SmartScriptParserException("Error parsin echo tokens!");
		}
		// pretvaranje array liste u listu tokena
		Token[] tokensList = new Token[tokensArray.size()];
		for (int i = 0; i < tokensArray.size(); i++) {
			if (tokensArray.get(i) instanceof Token) {
				tokensList[i] = (Token) tokensArray.get(i);
			} else {
				throw new SmartScriptParserException("Token parser error!");
			}
		}
		return tokensList;
	}

	/**
	 * Funkcija u kojoj se zbilja odvija parsiranje tokena
	 * 
	 * @param tokenString
	 *            string u koje se nalaze tokeni koje zelimo parsirati
	 * @return vraca array listu tokena
	 */
	private ArrayBackedIndexedCollection parseToken(String tokenString) {
		ArrayBackedIndexedCollection tokensArray = new ArrayBackedIndexedCollection();

		String[] tokenizer = tokenString.trim().split(" ");
		// uzorak koji se korisit samo za parsiranje TokenStringa
		Pattern pattern = Pattern.compile("\\\"");
		// na pocetku rastavimo sve po razmaku
		for (int i = 0; i < tokenizer.length; i++) {

			String part = tokenizer[i];
			if (part.startsWith("\n")) {
				part = part.substring(1);
				if (part.length() == 0) {
					continue;
				}
			}
			Matcher matcher = pattern.matcher(part);
			// ako smo pronasli " u tokenu znaci da parsiramo Token string koji
			// se moze protezati kroz nekoliko tokena
			if (matcher.find()) {
				// ako zavrsava u jednom tokenu sretni smo i mozemo nastavit
				// dalje s poslom normalno
				if (part.endsWith("\"")) {
					// jedni moramo provjeriti da li sadrzi ilegalne \ znakove
					if (!checkForIllegalBackSlashForString(part)) {
						tokensArray.add(new TokenString(modifyString(part)));
					}

				} else {
					// ako se proteze kroz vise redaka moramo tome pristupiti
					// tako da preskocimo sve tokene koji su u stringu.
					i++;
					for (int j = i; j < tokenizer.length; j++) {
						part = part + " " + tokenizer[j];
						Matcher matcher2 = Pattern.compile("(?<!\\\\)\\\"").matcher(part);
						if (matcher2.find()) {
							i = j;
							break;
						}
					}
					// i kada smo ih sve preskocili mozemo iz originalnog
					// tokenStringa sa regexom izvuci van cijeli string unutar
					// navodnika;
					// time nismo narusili poredak tokena

					// provjerimo za ilegalne znakove i ubacimo ga
					if (!checkForIllegalBackSlashForString(part)) {
						tokensArray.add(new TokenString(modifyString(part)));
					}
				}

			} else {
				// svi ostali tokeni su jednostavni
				// da odmah napomenem, ako ce biti potrebe kasnije mora se
				// prepraviti tako da radi s razmakom izmedju tokena.
				if (part.matches("[+,-,*,/]")) {
					tokensArray.add(new TokenOperator(part));
				} else if (Pattern.compile("\\d+").matcher(part).matches()) {
					tokensArray.add(new TokenConstantInteger(Integer.valueOf(part)));
				} else if (Pattern.compile("\\d+\\.\\d+").matcher(part).matches()) {
					tokensArray.add(new TokenConstantDouble(Double.valueOf(part)));
				} else if (Pattern.compile("@[a-zA-Z][a-zA-Z0-9_]*").matcher(part).matches()) {
					tokensArray.add(new TokenFunction(part));
				} else if (checkTokenVariableName(part)) {
					tokensArray.add(new TokenVariable(part));
				} else {
					throw new SmartScriptParserException("cant parse token " + part);
				}
			}
		}

		return tokensArray;
	}

	/**
	 * Funkcija koja provjerava da li je pocetak nodeStringa jednak {$
	 * 
	 * @param tagString
	 *            node string
	 * @return vraca true ili false
	 */
	private boolean checkForBackslash(String tagString) {
		String firstTwo = tagString.substring(0, 2).trim();
		if (firstTwo.equals("{$")) {
			return false;
		} else {
			return true;
		}
	}

	/**
	 * Funkcija kojom odredjujemo pocetak node stringa ({$)
	 * 
	 * @param tagString
	 *            string koji provjeravamo
	 * @return broj na kojem pocinje node
	 */
	private int tagStart(String tagString) {
		Pattern pattern = Pattern.compile("(?<=\\\\)*\\{\\$");
		Matcher matcher = pattern.matcher(tagString);
		if (matcher.find()) {
			return matcher.start();
		}
		throw new SmartScriptParserException("Something is wrong with tag name!");

	}

	/**
	 * Funkcija za provjeru imana varijable
	 * 
	 * @param name
	 *            string koj provjeravamo
	 * @return true ili false
	 */
	private boolean checkTokenVariableName(String name) {
		if (name.matches("[^a-zA-Z][^a-zA-Z0-9_]*")) {
			return false;
		}
		return true;
	}

	/**
	 * Funkcija kojom provjeravamo da li string sadrzi ilegalne znakove
	 * 
	 * @param text
	 *            tekst koji provjeravamo
	 * @return true ili false
	 */
	private boolean checkForIllegalBackSlashForString(String text) {
		Matcher matcher = Pattern.compile(".*?\\\\[^rnt\\\\\"].*?", Pattern.DOTALL).matcher(text);
		if (matcher.find()) {
			return true;
		}

		return false;
	}

	/**
	 * Funkcija kojom provjeravamo da li string sadrzi ilegalne znakove
	 * 
	 * @param text
	 *            tekst koji provjeravamo
	 * @return true ili false
	 */
	private boolean checkForIllegalBackSlashForText(String text) {
		Matcher matcher = Pattern.compile(".*\\\\[^rnt\\\\\\{].*", Pattern.DOTALL).matcher(text);
		if (matcher.find()) {
			return true;
		}
		return false;
	}

	/**
	 * Metoda koja popravlja ispis specijlnih znakova u stringovima
	 * 
	 * @param s
	 *            string koji popravljamo
	 * @return vracamo string s popravljenim specijalnim znakovima
	 */
	private String modifyString(String s) {
		final StringBuilder pom = new StringBuilder();
		for (int i = 0; i < s.length(); i++) {
			switch (s.charAt(i)) {
			case '\\':
				if (i == (s.length() - 1)) {
					pom.append(s.charAt(i));
					break;
				}
				switch (s.charAt(i + 1)) {
				case 'n':
					pom.append('\n');
					break;
				case 't':
					pom.append('\t');
					break;
				case 'r':
					pom.append('\r');
					break;
				case '\"':
					pom.append('\"');
					break;
				case '\\':
					pom.append('\\');
					break;
				default:
					break;
				}
				i++;
				break;
			default:
				pom.append(s.charAt(i));
			}
		}
		return pom.toString();
	}

}
