package hr.fer.zemris.java.custom.scripting.nodes;

/**
 * Razred koji predsavlja vrsni node, nasjljedjuje {@link Node}
 * 
 * @author Antun Sekulic 0246012693
 * @version
 */

public class DocumentNode extends Node {
	/**
	 * {@inheritDoc} razred moze imati dijecu
	 */
	@Override
	public boolean canHaveChildren() {
		return true;
	}

	@Override
	public String toString() {
		return "DocumentNode\n";
	}

	@Override
	public void accept(INodeVisitor visitor) {
		visitor.visitDocumentNode(this);
	}
}
