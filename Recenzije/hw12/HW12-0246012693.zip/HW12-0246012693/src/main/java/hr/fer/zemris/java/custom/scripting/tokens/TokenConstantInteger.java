package hr.fer.zemris.java.custom.scripting.tokens;

/**
 * 
 * @author Antun Sekulic 0246012693
 * 
 */

public class TokenConstantInteger extends Token {

	private int value;

	/**
	 * Konstruktor
	 * 
	 * @param value
	 *            int
	 */
	public TokenConstantInteger(int value) {
		super();
		this.value = value;
	}

	/**
	 * Vraca vrijednost tokena
	 * 
	 * @return int
	 */
	public int getValue() {
		return value;
	}

	@Override
	public String asText() {
		return String.valueOf(value);
	}
	
	@Override
	public String toString() {
		return String.valueOf(value);
	}
}
