package hr.fer.zemris.java.custom.scripting.tokens;

/**
 * 
 * @author Antun Sekulic 0246012693
 * 
 */

public class TokenOperator extends Token {

	private String symbol;

	/**
	 * Konstruktor
	 * 
	 * @param symbol
	 *            String vrijesdnost operatora
	 */
	public TokenOperator(String symbol) {
		super();
		this.symbol = symbol;
	}

	/**
	 * Vraca string vrijednost operatora
	 * 
	 * @return Strings
	 */
	public String getSymbol() {
		return symbol;
	}

	@Override
	public String asText() {
		return "TokenOperator: "+symbol;
	}
	
	@Override
	public String toString() {
		return symbol;
	}
}
