package hr.fer.zemris.java.custom.scripting.tokens;

/**
 * 
 * @author Antun Sekulic 0246012693
 * 
 */

public class TokenConstantDouble extends Token {

	private double value;

	/**
	 * Konstruktor
	 * 
	 * @param value
	 *            dosuble vrijednost
	 */
	public TokenConstantDouble(double value) {
		super();
		this.value = value;
	}

	/**
	 * Vraca vrijednost tokena
	 * 
	 * @return double
	 */
	public double getValue() {
		return value;
	}

	@Override
	public String asText() {
		return String.valueOf(value);
	}

	@Override
	public String toString() {
		return String.valueOf(value);
	}
}
