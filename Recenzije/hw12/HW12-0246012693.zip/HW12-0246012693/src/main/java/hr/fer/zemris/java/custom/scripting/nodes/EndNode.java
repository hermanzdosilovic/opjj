package hr.fer.zemris.java.custom.scripting.nodes;

/**
 * 
 * @author Antun Sekulic 0246012693 razred koji samo sluzi za pravilno
 *         parsiranje
 */

public class EndNode extends Node {

	@Override
	public boolean canHaveChildren() {
		return false;
	}

	@Override
	public void accept(INodeVisitor visitor) {
		// do nothing
	}

}
