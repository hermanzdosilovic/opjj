package hr.fer.zemris.java.custom.scripting.nodes;

/**
 * 
 * @author Antun Sekulic 0246012693
 *
 */

import hr.fer.zemris.java.custom.collections.ArrayBackedIndexedCollection;

public abstract class Node {

	private ArrayBackedIndexedCollection childrenCollection;

	/**
	 * Funkcija za dodavanje djetata trenutnom cvoru
	 * 
	 * @param child
	 *            Node dijete koje zelimo dodati
	 */
	public void addChildNode(Node child) {
		checkCollection();
		childrenCollection.add(child);
	}

	/**
	 * Funkcija koja nam vraca broj djece trenutnog cvora
	 * 
	 * @return int vrijednost
	 */
	public int numberOfChildren() {
		checkCollection();
		return childrenCollection.size();
	}

	/**
	 * Funkcija za dohvat djeteta sa indexa
	 * 
	 * @param index
	 *            int vrijednost s koje dohvacamo dijete
	 * @return Node dijete
	 */
	public Node getChild(int index) {
		checkCollection();
		return (Node) childrenCollection.get(index);
	}

	/**
	 * Ako ne postoji privata array lista za dodavanje djece napravimo ju
	 */
	private void checkCollection() {
		if (null == childrenCollection) {
			childrenCollection = new ArrayBackedIndexedCollection();
		}
	}

	/**
	 * Funkcija koja nam sluzi za provjeru da li Node moze imati djecu ili nes
	 * 
	 * @return
	 */
	public boolean canHaveChildren() {
		return false;
	}
	
	public abstract void accept(INodeVisitor visitor);
}
