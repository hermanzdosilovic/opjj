package hr.fer.zemris.java.custom.collections;

/**
 * Razred koji predstavlja pogresku koja se moze dogoditi pri radu sa stogom
 * 
 * @author Antun Sekulic 0246012693
 * @version 1.0
 */

public class EmptyStackException extends RuntimeException {

	/**
	 * Nas exception
	 */
	private static final long serialVersionUID = 8649440350758699570L;

	public EmptyStackException() {
		super();
	}

	public EmptyStackException(String message) {
		super(message);
	}
}
