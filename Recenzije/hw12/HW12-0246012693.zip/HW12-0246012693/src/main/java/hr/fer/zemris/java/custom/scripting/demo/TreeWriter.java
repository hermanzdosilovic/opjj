package hr.fer.zemris.java.custom.scripting.demo;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import hr.fer.zemris.java.custom.scripting.nodes.DocumentNode;
import hr.fer.zemris.java.custom.scripting.nodes.EchoNode;
import hr.fer.zemris.java.custom.scripting.nodes.ForLoopNode;
import hr.fer.zemris.java.custom.scripting.nodes.INodeVisitor;
import hr.fer.zemris.java.custom.scripting.nodes.Node;
import hr.fer.zemris.java.custom.scripting.nodes.TextNode;
import hr.fer.zemris.java.custom.scripting.parser.SmartScriptParser;

/**
 * Razred koji sluzi za testiranje rada {@link SmartScriptParser} i kako parsira
 * podatke
 * 
 * @author Antun Sekulic 0246012693
 * @version 1.0
 */
public class TreeWriter {
	/**
	 * Main metoda, ocekuje jedan parametar, put do skripte koju treba parsirati
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		if (args.length != 1) {
			throw new IllegalArgumentException("Expected 1 argument, path to script.");
		}

		String docBody = null;
		StringBuilder builder = new StringBuilder();
		// kako se nebi morali zamarti sa silnim \\\\ znakovima, ucitavam
		// datoteku sa zadanim stringom

		BufferedReader br = null;
		try {
			// Moguce da ne radi na windosima
			br = new BufferedReader(new FileReader(args[0]));

			String line = br.readLine();

			while (line != null) {
				builder.append(line);
				builder.append(System.lineSeparator());
				line = br.readLine();
			}
			docBody = builder.toString();
		} catch (FileNotFoundException e) {
		} catch (IOException e) {

		} catch (NullPointerException e) {

		} finally {
			try {
				if (br != null) {
					br.close();
				}
			} catch (IOException e) {
			}
		}

		SmartScriptParser p = new SmartScriptParser(docBody);
		WriterVisitor visitor = new WriterVisitor();
		System.out.println("-----------------");
		p.getDocumentNode().accept(visitor);

	}

	/**
	 * Razred koji implemntira {@link INodeVisitor} sucelje
	 * 
	 * @author Antun Sekulic 0246012693
	 * @version 1.0
	 * 
	 */
	static class WriterVisitor implements INodeVisitor {
		/**
		 * {@inheritDoc}
		 */
		@Override
		public void visitTextNode(TextNode node) {
			System.out.println(node.toString());
		}

		/**
		 * {@inheritDoc} obilazi svu djecu {@link ForLoopNode} noda
		 */
		@Override
		public void visitForLoopNode(ForLoopNode node) {
			System.out.println(node.toString());
			for (int i = 0; i < node.numberOfChildren(); i++) {
				Node childNode = node.getChild(i);
				childNode.accept(this);
			}
		}

		/**
		 * {@inheritDoc}
		 */
		@Override
		public void visitEchoNode(EchoNode node) {
			System.out.println(node.toString());
		}

		/**
		 * {@inheritDoc} obilazi svu djecu {@link DocumentNode}
		 */
		@Override
		public void visitDocumentNode(DocumentNode node) {
			System.out.println(node.toString());
			for (int i = 0; i < node.numberOfChildren(); i++) {
				Node childNode = node.getChild(i);
				childNode.accept(this);
			}
		}

	}
}
