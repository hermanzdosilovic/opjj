package hr.fer.zemris.java.custom.collections;

/**
 * Razred koji predstavlja jednostavnu implementaciju hash mape stogova
 * 
 * @author Antun Sekulic 0246012693
 * @version 1.0
 */

public class ObjectStack {

	private ArrayBackedIndexedCollection stackImpl;

	/**
	 * Konstruktor stoga
	 */
	public ObjectStack() {
		stackImpl = new ArrayBackedIndexedCollection();
	}

	/**
	 * Dodavanje objekta na stog
	 * 
	 * @param value
	 *            Objekt koji dodajemo
	 */
	public void push(Object value) {
		if (null == value) {
			throw new IllegalArgumentException("Can't insert null in array");
		}
		stackImpl.add(value);
	}

	/**
	 * Funkcija za skidanje objetka s stoga
	 * 
	 * @return Vraca skinuti objekt sa stoga
	 */
	public Object pop() {
		checkSize();
		Object returnValue = stackImpl.get(stackImpl.size() - 1);
		stackImpl.remove(stackImpl.size() - 1);
		return returnValue;
	}

	/**
	 * Funkcija za pregled zadnje elementa na stogu Ne mice ga
	 * 
	 * @return zadnji objekt na stogu
	 */
	public Object peek() {
		checkSize();
		return stackImpl.get(stackImpl.size() - 1);
	}

	/**
	 * Brise sve elemente sa stoga
	 */
	public void clear() {
		stackImpl.clear();
	}

	/**
	 * vraca velicinu stoga
	 * 
	 * @return int vrijednosts
	 */
	public int size() {
		return stackImpl.size();
	}

	/**
	 * Vraca da li je stog prazan ili ne
	 * 
	 * @return true ili false
	 */
	public boolean isEmpty() {
		return stackImpl.isEmpty();
	}

	/**
	 * Provjerava da li je stog prazan Ako je baca iznimkus
	 */
	private void checkSize() {
		if (stackImpl.size() == 0) {
			throw new EmptyStackException("Stack is empty");
		}
	}
}
