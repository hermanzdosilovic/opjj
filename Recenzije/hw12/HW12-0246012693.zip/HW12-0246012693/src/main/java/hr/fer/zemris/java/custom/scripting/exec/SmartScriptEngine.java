package hr.fer.zemris.java.custom.scripting.exec;

import hr.fer.zemris.java.custom.collections.ObjectStack;
import hr.fer.zemris.java.custom.scripting.nodes.DocumentNode;
import hr.fer.zemris.java.custom.scripting.nodes.EchoNode;
import hr.fer.zemris.java.custom.scripting.nodes.ForLoopNode;
import hr.fer.zemris.java.custom.scripting.nodes.INodeVisitor;
import hr.fer.zemris.java.custom.scripting.nodes.TextNode;
import hr.fer.zemris.java.custom.scripting.parser.SmartScriptParser;
import hr.fer.zemris.java.custom.scripting.tokens.Token;
import hr.fer.zemris.java.custom.scripting.tokens.TokenConstantDouble;
import hr.fer.zemris.java.custom.scripting.tokens.TokenConstantInteger;
import hr.fer.zemris.java.custom.scripting.tokens.TokenFunction;
import hr.fer.zemris.java.custom.scripting.tokens.TokenOperator;
import hr.fer.zemris.java.custom.scripting.tokens.TokenString;
import hr.fer.zemris.java.custom.scripting.tokens.TokenVariable;
import hr.fer.zemris.java.webserver.RequestContext;

import java.io.IOException;
import java.text.DecimalFormat;

/**
 * Razred koji izvrsava skriptni jezik koji je parsira {@link SmartScriptParser}
 * razred
 * 
 * @author Antun Sekulic 0246012693
 * @version 1.0
 * 
 */
public class SmartScriptEngine {

	private DocumentNode documentNode;
	private RequestContext requestContext;
	private ObjectMultistack multistack = new ObjectMultistack();

	private INodeVisitor visitor = new INodeVisitor() {

		@Override
		public void visitTextNode(TextNode node) {
			try {
				requestContext.write(node.getText());
			} catch (IOException e) {
				e.printStackTrace();
			}

		}

		@Override
		public void visitForLoopNode(ForLoopNode node) {
			String varName = node.getVariable().getName();
			ValueWrapper start = new ValueWrapper(node.getStartExpresion().asText());
			ValueWrapper end = new ValueWrapper(node.getEndExpresion().asText());
			ValueWrapper step = new ValueWrapper(node.getStepExpresion().asText());
			multistack.push(varName, start);
			while (multistack.peek(varName).numCompare(end.getValue()) < 0) {
				for (int i = 0; i < node.numberOfChildren(); i++) {
					node.getChild(i).accept(this);
				}
				multistack.peek(varName).increment(step.getValue());
			}
			multistack.pop(varName);
		}

		@Override
		public void visitEchoNode(EchoNode node) {
			Token[] tokens = node.getTokens();
			ObjectStack tempStack = new ObjectStack();

			for (Token token : tokens) {
				if (token instanceof TokenConstantDouble) {
					TokenConstantDouble doubleToken = (TokenConstantDouble) token;
					tempStack.push(doubleToken.getValue());
				} else if (token instanceof TokenConstantInteger) {
					TokenConstantInteger integerToken = (TokenConstantInteger) token;
					tempStack.push(integerToken.getValue());
				} else if (token instanceof TokenString) {
					TokenString stringToken = (TokenString) token;
					// micemo navodnike sa pocetka i kraja stringa
					tempStack.push(stringToken.getValue().subSequence(1, stringToken.getValue().length() - 1));
				} else if (token instanceof TokenVariable) {
					TokenVariable variableToken = (TokenVariable) token;
					Object value = multistack.peek(variableToken.getName()).getValue();
					tempStack.push(value);
				} else if (token instanceof TokenOperator) {
					TokenOperator operatorTokenOperator = (TokenOperator) token;
					Object object1 = tempStack.pop();
					Object object2 = tempStack.pop();
					ValueWrapper result = new ValueWrapper(object1);
					if (operatorTokenOperator.getSymbol().equals("+")) {
						result.increment(object2);
					} else if (operatorTokenOperator.getSymbol().equals("-")) {
						result.decrement(object2);
					} else if (operatorTokenOperator.getSymbol().equals("*")) {
						result.multiply(object2);
					} else if (operatorTokenOperator.getSymbol().equals("/")) {
						result.divide(object2);
					}
					tempStack.push(result.getValue());
				} else if (token instanceof TokenFunction) {
					TokenFunction funToken = (TokenFunction) token;
					// micemo @ sa pocetka imena funkcije
					String functionName = funToken.getName().substring(1);

					if (functionName.equals("sin")) {
						Object x = tempStack.pop();
						double r = sin(x);
						tempStack.push(r);
					} else if (functionName.equals("decfmt")) {
						Object f = tempStack.pop();
						Object x = tempStack.pop();
						String r = decfmt(x, f);
						tempStack.push(r);
					} else if (functionName.equals("dup")) {
						Object x = tempStack.pop();
						tempStack.push(x);
						tempStack.push(x);

					} else if (functionName.equals("swap")) {
						Object a = tempStack.pop();
						Object b = tempStack.pop();
						tempStack.push(a);
						tempStack.push(b);
					} else if (functionName.equals("setMimeType")) {
						String x = tempStack.pop().toString();
						requestContext.setMimeType(x);
					} else if (functionName.equals("paramGet")) {
						String dv = tempStack.pop().toString();
						String name = tempStack.pop().toString();
						String value = requestContext.getParameter(name);
						tempStack.push(value == null ? dv : value);
					} else if (functionName.equals("pparamGet")) {
						String dv = tempStack.pop().toString();
						String name = tempStack.pop().toString();
						String value = requestContext.getPersistentParameter(name);
						tempStack.push(value == null ? dv : value);
					} else if (functionName.equals("pparamSet")) {
						String name = tempStack.pop().toString();
						String value = tempStack.pop().toString();
						requestContext.setPersistentParameter(name, value);
					} else if (functionName.equals("pparamDel")) {
						String name = tempStack.pop().toString();
						requestContext.removePersistentParameter(name);
					} else if (functionName.equals("tparamGet")) {
						String dv = tempStack.pop().toString();
						String name = tempStack.pop().toString();
						String value = requestContext.getTemporaryParameter(name);
						tempStack.push(value == null ? dv : value);
					} else if (functionName.equals("tparamSet")) {
						String name = tempStack.pop().toString();
						String value = tempStack.pop().toString();
						requestContext.setTemporaryParameter(name, value);
					} else if (functionName.equals("tparamDel")) {
						final String name = tempStack.pop().toString();
						requestContext.removeTemporaryParameter(name);
					}
				}
			}
			ObjectStack reverseStack = new ObjectStack();
			while (!tempStack.isEmpty()) {
				reverseStack.push(tempStack.pop());
			}

			while (!reverseStack.isEmpty()) {
				try {
					requestContext.write(reverseStack.pop().toString());
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}

		@Override
		public void visitDocumentNode(DocumentNode node) {
			for (int i = 0; i < node.numberOfChildren(); i++) {
				node.getChild(i).accept(this);
			}
		}
	};

	private double sin(Object arg) {
		double argument = Double.valueOf(arg.toString());
		return Math.sin((argument * Math.PI) / 180);
	}

	private String decfmt(Object value, final Object format) {
		String decformat = format.toString();
		DecimalFormat dformat = new DecimalFormat(decformat.substring(0, decformat.length() - 1));
		return dformat.format(value);
	}

	public SmartScriptEngine(DocumentNode documentNode, RequestContext requestContext) {
		this.requestContext = requestContext;
		this.documentNode = documentNode;
	}

	public void execute() {
		documentNode.accept(visitor);
	}

}
