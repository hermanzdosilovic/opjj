package hr.fer.zemris.java.custom.scripting.tokens;

/**
 * 
 * @author Antun Sekulic 0246012693
 * 
 */

public class TokenFunction extends Token {

	private String name;

	/**
	 * Konstruktor
	 * 
	 * @param name
	 *            String reprezentacija funkcije
	 */
	public TokenFunction(String name) {
		super();
		this.name = name;
	}

	/**
	 * Vraca vrijednost tokena
	 * 
	 * @return String
	 */
	public String getName() {
		return name;
	}

	@Override
	public String asText() {
		return name;
	}

	@Override
	public String toString() {
		return name;
	}
}
