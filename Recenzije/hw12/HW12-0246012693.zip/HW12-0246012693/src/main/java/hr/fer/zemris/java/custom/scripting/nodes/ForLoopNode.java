package hr.fer.zemris.java.custom.scripting.nodes;

/**
 * 
 * @author Antun Sekulic 0246012693
 *
 */

import hr.fer.zemris.java.custom.scripting.parser.SmartScriptParserException;
import hr.fer.zemris.java.custom.scripting.tokens.Token;
import hr.fer.zemris.java.custom.scripting.tokens.TokenVariable;

public class ForLoopNode extends Node {

	public static final boolean canHaveChildren = true;
	private TokenVariable variable;
	private Token startExpresion;
	private Token endExpresion;
	private Token stepExpresion;

	/**
	 * Konstruktor
	 * 
	 * @param variable
	 *            TokenVariable not null
	 * @param startExpresion
	 *            Token not null
	 * @param endExpresion
	 *            Token not null
	 * @param stepExpresion
	 *            Token smije biti null
	 */
	public ForLoopNode(TokenVariable variable, Token startExpresion, Token endExpresion, Token stepExpresion) {
		super();

		if (null == variable) {
			throw new SmartScriptParserException("for loop variable == null!");
		}
		this.variable = variable;

		if (null == startExpresion) {
			throw new SmartScriptParserException("for loop staartExpresion == null!");
		}
		this.startExpresion = startExpresion;

		if (null == endExpresion) {
			throw new SmartScriptParserException("for loop endExpresion == null!");
		}
		this.endExpresion = endExpresion;

		this.stepExpresion = stepExpresion;

	}

	/**
	 * Vraca ime varijable
	 * 
	 * @return TokenVariable
	 */
	public TokenVariable getVariable() {
		return variable;
	}

	/**
	 * Vraca startExpresion
	 * 
	 * @return Token
	 */
	public Token getStartExpresion() {
		return startExpresion;
	}

	/**
	 * Vraca end expresion
	 * 
	 * @return Token
	 */
	public Token getEndExpresion() {
		return endExpresion;
	}

	/**
	 * Vraca korak for petlje
	 * 
	 * @return Token
	 */
	public Token getStepExpresion() {
		return stepExpresion;
	}

	@Override
	public boolean canHaveChildren() {
		return true;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("ForLoopNode {$");
		builder.append(" FOR ");
		builder.append(" ");
		builder.append(getVariable().asText());
		builder.append(" ");
		builder.append(getStartExpresion().asText());
		builder.append(" ");
		builder.append(getEndExpresion().asText());
		builder.append(" ");
		builder.append(getStepExpresion().asText());
		builder.append(" ");
		builder.append("$}\n");
		return builder.toString();
	}

	@Override
	public void accept(INodeVisitor visitor) {
		visitor.visitForLoopNode(this);

	}
}
