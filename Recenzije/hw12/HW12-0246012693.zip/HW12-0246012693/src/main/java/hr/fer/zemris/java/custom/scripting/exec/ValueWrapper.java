package hr.fer.zemris.java.custom.scripting.exec;

/**
 * Razred koji predstavlja spremnik podtaka. Dozvoljeno je spremiti samo integer
 * ili double broj. Broj je moguce zadati i kao string Null se tretira kao
 * Integer s vriejdnosti 0
 * 
 * @author Antun Sekulic 0246012693
 * @version 1.0
 */
public class ValueWrapper {
	/**
	 * Vrijednost pohranjena u objekt
	 */
	private Object value;

	/**
	 * Vraca novi {@link ValueWrapper} objekt.
	 * 
	 * @param value
	 *            vrjjdnost na koju zelimo postavit objekt. Vrijedost moze biti
	 *            {@link Integer} ili {@link Double}. Dodatno se moze predati
	 *            {@link String} u kojem je zapisan broj kao Integer ili double.
	 *            <code>null</code> se tretira kao {@link Integer} s vrijdnosti
	 *            0
	 * @throws RuntimeException
	 *             ako je predana vrijednost koja se ne moze protumaciti
	 */
	public ValueWrapper(Object value) {
		checkValue(value);
		value = parseValue(value);
		this.value = value;
	}

	/**
	 * Metoda koja uvacava trenutnu vrijdnost objekta. Ako se bilo koja
	 * vrijednost protumaci kao {@link Double} rezultat ce se pohraniti kao
	 * Double.<code>null</code> se tretira kao Integer s vrijednosti 0
	 * 
	 * @param incValue
	 *            Vrijdnost za koju uvecavamo trenutni objekt
	 * @throws RuntimeException
	 *             ako se vrijednost ne moze ispravno protumaciti
	 */

	public void increment(Object incValue) {
		checkValue(value);
		incValue = parseValue(incValue);
		preformOperation(incValue, '+');
	}

	/**
	 * Metoda koja smanjuje trenutnu vrijdnost objekta. Ako se bilo koja
	 * vrijednost protumaci kao {@link Double} rezultat ce se pohraniti kao
	 * Double.<code>null</code> se tretira kao Integer s vrijednosti 0
	 * 
	 * @param decValue
	 *            Vrijdnost za koju smanjujemo trenutni objekt
	 * @throws RuntimeException
	 *             ako se vrijednost ne moze ispravno protumaciti
	 */

	public void decrement(Object decValue) {
		checkValue(value);
		decValue = parseValue(decValue);
		preformOperation(decValue, '-');
	}

	/**
	 * Metoda koja mnozi trenutnu vrijdnost objekta. Ako se bilo koja vrijednost
	 * protumaci kao {@link Double} rezultat ce se pohraniti kao Double.
	 * <code>null</code> se tretira kao Integer s vrijednosti 0
	 * 
	 * @param mulValue
	 *            Vrijdnost za koju mnozimo trenutni objekt
	 * @throws RuntimeException
	 *             ako se vrijednost ne moze ispravno protumaciti
	 */
	public void multiply(Object mulValue) {
		checkValue(value);
		mulValue = parseValue(mulValue);
		preformOperation(mulValue, '*');
	}

	/**
	 * Metoda koja dijeli trenutnu vrijdnost objekta. Ako se bilo koja
	 * vrijednost protumaci kao {@link Double} rezultat ce se pohraniti kao
	 * Double. <code>null</code> se tretira kao Integer s vrijednosti 0
	 * 
	 * @param divValue
	 *            Vrijdnost za koju dijelimo trenutni objekt
	 * @throws RuntimeException
	 *             ako se vrijednost ne moze ispravno protumaciti
	 */
	public void divide(Object divValue) {
		checkValue(value);
		divValue = parseValue(divValue);
		preformOperation(divValue, '/');
	}

	/**
	 * Metoda koja usporedjuje trenutnu vrijednost pohranjenu u objektu s
	 * predanom vrijednosti
	 * 
	 * @param withValue
	 *            vrijednost s kojom usporedjujemo
	 * @return 0 ako su vrijednosti jedanke, broj manji od 0 ako je trenutna
	 *         vrijednost manja ili broj veci od nule ako trenutna vrijednost
	 *         veca
	 */
	public int numCompare(Object withValue) {
		checkValue(value);
		withValue = parseValue(withValue);
		if (value instanceof Integer && withValue instanceof Integer) {
			return ((Integer) value).compareTo((Integer) withValue);
		} else {
			return ((Double) ((Number) value).doubleValue()).compareTo(((Number) withValue).doubleValue());
		}
	}

	/**
	 * Metoda koja vraca trenutnu vrijednost pohranjenu u objektu.
	 * 
	 * @return trnutna crijednost, {@link Double} ili {@link Integer}
	 */
	public Object getValue() {
		return value;
	}

	/**
	 * Metoda koja postavlja vrijednost objekta.
	 * 
	 * @param value
	 *            vrijdnost na koju postavljamo objekt.<code>null</code> se
	 *            tretira kao Integer s vrijednosti 0
	 * @throws RuntimeException
	 *             ako se vrijdnost ne moze protumaciti kao {@link Integer} ili
	 *             {@link Double}
	 */
	public void setValue(Object value) {
		checkValue(value);
		this.value = parseValue(value);
	}

	/**
	 * Metoda koja provjerava da li je objekt tipa {@link Integer} ili
	 * {@link Double} ili {@link String} ili <code>null</code>
	 * 
	 * @param value
	 *            objekt koji provjeravamo
	 * @throws RuntimeException
	 *             ako je predan objekt bilo kojg drugo tipa
	 */
	private void checkValue(Object value) {

		if (!(value instanceof Integer) && //
				!(value instanceof Double) && //
				!(value instanceof String) && //
				value != null) {

			throw new RuntimeException("Unknown type of object");
		}
	}

	/**
	 * Metoda koja parsira predanu vrijdenost u {@link Integer} ili
	 * {@link Double}. <code>null</code> se tretira kao Integer s vrijednsoti 0
	 * 
	 * @param value
	 *            vrijednost koji parsiramo
	 * @return vraca {@link Integer} ili {@link Object}
	 * @throws RuntimeException
	 *             ako se ne uspije ocitati vrijednost
	 */
	private Object parseValue(Object value) {
		if (null == value) {
			return new Integer(0);
		}
		if (value instanceof String) {
			if (((String) value).contains(".") || ((String) value).contains("E")) {
				try {
					return Double.parseDouble((String) value);
				} catch (NumberFormatException e) {
					throw new RuntimeException("Unkown value " + value);
				}
			} else {
				try {
					return Integer.parseInt((String) value);
				} catch (NumberFormatException e) {
					throw new RuntimeException("Unkown value " + value);
				}
			}
		}
		return value;
	}

	/**
	 * Metoda koja vrsi operacije zbrajanja oduzimanja, mnozenja i dijeljenja
	 * nad trenutnim objektom
	 * 
	 * @param operand
	 *            drugi operand
	 * @param c
	 *            char znak operacije '+' ili '-' ili '*' ili '/'
	 */
	private void preformOperation(Object operand, char c) {

		if (operand instanceof Double || value instanceof Double) {
			switch (c) {
			case '+':
				value = ((Number) value).doubleValue() + ((Number) operand).doubleValue();
				break;
			case '-':
				value = ((Number) value).doubleValue() - ((Number) operand).doubleValue();
				break;
			case '*':
				value = ((Number) value).doubleValue() * ((Number) operand).doubleValue();
				break;
			case '/':
				value = ((Number) value).doubleValue() / ((Number) operand).doubleValue();
				break;
			}
		} else {
			switch (c) {
			case '+':
				value = ((Number) value).intValue() + ((Number) operand).intValue();
				break;
			case '-':
				value = ((Number) value).intValue() - ((Number) operand).intValue();
				break;
			case '*':
				value = ((Number) value).intValue() * ((Number) operand).intValue();
				break;
			case '/':
				value = ((Number) value).intValue() / ((Number) operand).intValue();
				break;
			}
		}
	}
}
