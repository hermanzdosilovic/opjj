package hr.fer.zemris.java.webserver.workers;

import hr.fer.zemris.java.webserver.RequestContext;

import java.io.IOException;
import java.util.Set;

/**
 * Razred koji generira jednostavni HTML odgovor u kojem su predani parametri
 * poslozeni u HTML tablicu. Implementira {@link IWebWorker} sucelje.
 * 
 * @author Antun Sekulic 0246012693
 * @version 1.0
 */
public class EchoParams implements IWebWorker {
	/**
	 * {@inheritDoc}
	 */
	@Override
	public void processRequest(RequestContext context) {
		Set<String> params = context.getParameterNames();
		try {
			context.write("<html> "//
					+ "<head><titlePosluzitelj</title>"//
					+ "</head>"//
					+ "<body> <h1>EchoParams</h1> <p>Parametri zahtjeva</p>");

			context.write("<dl>");
			if (params.isEmpty()) {
				context.write("<dt>" + "No parameters" + "</dt><dd>");
			}
			for (String name : params) {
				context.write("<dt>" + name + "</dt><dd>" + context.getParameter(name) + "</dd>");
			}
			context.write("</dl></body></html>");
		} catch (final IOException e) {
			e.printStackTrace();
		}

	}

}
