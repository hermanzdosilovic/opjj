package hr.fer.zemris.java.custom.scripting.tokens;

/**
 * 
 * @author Antun Sekulic 0246012693
 * 
 */

public class TokenString extends Token {

	private String value;

	/**
	 * Konstruktor
	 * 
	 * @param value
	 *            String
	 */
	public TokenString(String value) {
		super();
		this.value = value;
	}

	/**
	 * Vraca string vrijednost tokean
	 * 
	 * @return
	 */
	public String getValue() {
		return value;
	}

	@Override
	public String asText() {
		return "TokenString: " + value;
	}

	@Override
	public String toString() {
		return value;
	}
}
