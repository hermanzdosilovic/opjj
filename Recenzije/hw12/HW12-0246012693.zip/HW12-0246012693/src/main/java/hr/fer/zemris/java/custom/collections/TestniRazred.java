package hr.fer.zemris.java.custom.collections;

/**
 * Pomocni razred za testiranje stoga
 * 
 * @author Antun Sekulic 0246012693 Testni razred za testiranje rada stoga i
 *         arrsay liste
 * @version 1.0
 */

public class TestniRazred {
	/**
	 * Testna funkcija za testiranje rada stoga i array liste
	 * 
	 * @param args
	 */
	public static void main(String[] args) {

		ObjectStack col = new ObjectStack();
		col.push(new Integer(1));
		System.out.println("size " + col.size());
		col.push(new Integer(2));
		System.out.println("size " + col.size());
		col.push(new Integer(3));
		System.out.println("size " + col.size());

		System.out.println("peek " + col.peek());
		System.out.println("size " + col.size());
		System.out.println("pop " + col.pop());
		System.out.println("isEmpty " + col.isEmpty());

		System.out.println("size " + col.size());
		System.out.println("peek " + col.peek());
		System.out.println("size " + col.size());
		System.out.println("pop " + col.pop());
		System.out.println("size " + col.size());
		System.out.println("pop " + col.pop());
		System.out.println("size " + col.size());
		System.out.println("isEmpty " + col.isEmpty());
	}

}
