package hr.fer.zemris.java.custom.scripting.nodes;

/**
 * 
 * @author Antun Sekulic 0246012693
 *
 */

import hr.fer.zemris.java.custom.scripting.parser.SmartScriptParserException;
import hr.fer.zemris.java.custom.scripting.tokens.Token;

public class EchoNode extends Node {

	private Token[] tokens;

	/**
	 * Konstruktor
	 * 
	 * @param tokens
	 *            lista tokena koje sadrzi ovaj node
	 */
	public EchoNode(Token[] tokens) {
		if (tokens == null) {
			throw new SmartScriptParserException("Echo node tokens == null!");
		}
		this.tokens = tokens;
	}

	/**
	 * Vraca sve tokene noda
	 * 
	 * @return lista tokena
	 */
	public Token[] getTokens() {
		return tokens;
	}

	@Override
	public boolean canHaveChildren() {
		return false;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("EchoNode {$");
		builder.append(" =");
		for (Token token : getTokens()) {
			builder.append(" ");
			builder.append(token.asText());
		}
		builder.append(" $}\n");
		return builder.toString();
	}

	@Override
	public void accept(INodeVisitor visitor) {
		visitor.visitEchoNode(this);

	}
}
