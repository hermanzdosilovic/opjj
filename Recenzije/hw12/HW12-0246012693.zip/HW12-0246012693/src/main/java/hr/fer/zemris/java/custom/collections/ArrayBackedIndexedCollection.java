package hr.fer.zemris.java.custom.collections;

/**
 * 
 * @author Antun Sekulic 0246012693
 *
 */

import java.util.Arrays;

/**
 * Razred koji predstavlja jednostavnu implementaciju ArrayList objekta
 * 
 * @author Antun Sekulic 0246012693
 * @version 1.0
 */
public class ArrayBackedIndexedCollection {

	private static final int defaultSize = 16;

	private int size;
	private int capacity;
	private Object[] elements;

	/**
	 * Konstruktor liste. Vraca listu elementa pocetne velicine 16
	 */
	public ArrayBackedIndexedCollection() {
		this(defaultSize);
	}

	/**
	 * Konstruktor liste
	 * 
	 * @param initialCapacity
	 *            pocetna velicina liste, int vrijednost veca od 1
	 * @throws IllegalArgumentException
	 *             iznimka ako je zadana pogresna velicina liste
	 */
	public ArrayBackedIndexedCollection(int initialCapacity) {
		if (initialCapacity < 1) {
			throw new IllegalArgumentException("Wrong size");
		}
		capacity = initialCapacity;
		elements = new Object[capacity];

	}

	/**
	 * Provjeravamo da li je lista prazna
	 * 
	 * @return true ako je prazna, inace false
	 */
	public boolean isEmpty() {
		return size == 0;
	}

	/**
	 * Vraca broj elemenata u listi kao int vrijednost
	 * 
	 * @return broj elementa
	 */
	public int size() {
		return size;
	}

	/**
	 * Dodavanje novog objekta u litu
	 * 
	 * @param value
	 *            ne null objekt koji zelimo ubaciti
	 */
	public void add(Object value) {
		checkValue(value);

		if (size == capacity) {
			doubleList();
		}
		elements[size] = value;
		size++;
	}

	/**
	 * dohvacamo objekt na trazenom indeksu
	 * 
	 * @param index
	 *            int vrijednost, veca od 0 i manje od velicine liste
	 * @return
	 */
	public Object get(int index) {
		checkIndex(index);
		return elements[index];
	}

	/**
	 * Brise element na poziciji iz liste
	 * 
	 * @param index
	 *            pozcija s koje zelimo obrisati element, int vrijednost veci od
	 *            0 i manji od velicine liste
	 */
	public void remove(int index) {
		checkIndex(index);
		int shift = size - index - 1;
		if (shift > 0)
			System.arraycopy(elements, index + 1, elements, index, shift);
		elements[--size] = null;

	}

	/**
	 * Ubacujemo element na tocno odredjenu poziciju u listi
	 * 
	 * @param value
	 *            ne null element koji ubacujemo u listu
	 * @param position
	 *            int vrijednost, veca od 0 i manja od velicine liste
	 */
	public void insert(Object value, int position) {
		checkValue(value);
		checkIndexInsert(position);

		if (size == capacity) {
			doubleList();
		}
		System.arraycopy(elements, position, elements, (position + 1), size - position);
		elements[position] = value;
		size++;
	}

	/**
	 * vraca poziciju trazenog elementa u listi ili -1 ako element nije
	 * pronadjen
	 * 
	 * @param value
	 *            povratna int vrijednost
	 * @return
	 */
	public int indexOf(Object value) {
		checkValue(value);
		for (int i = 0; i < size; i++) {
			if (value.equals(elements[i])) {
				return i;
			}
		}
		return -1;
	}

	/**
	 * ispituje da li se trazeni element nalazi u listi
	 * 
	 * @param value
	 *            ne null element koji trazimo
	 * @return true ako je element pornadjen, suprotno false
	 */
	public boolean contains(Object value) {
		checkValue(value);
		return indexOf(value) >= 0;
	}

	/**
	 * brise sve elemente iz liste
	 */
	public void clear() {
		for (int i = 0; i < size; i++) {
			elements[i] = null;
		}
		size = 0;
	}

	/**
	 * povecava listu elemanta za faktor 2
	 */
	private void doubleList() {
		capacity = capacity * 2;
		elements = Arrays.copyOf(elements, capacity);
	}

	/**
	 * ispitujemo da li je podatak razlicit od null
	 * 
	 * @param value
	 *            podatak koji ispitujemo
	 */
	private void checkValue(Object value) {
		if (null == value) {
			throw new IllegalArgumentException("Can't insert null in array");
		}
	}

	/**
	 * ispitujemo da li indeks zadovoljava kriterije liste
	 * 
	 * @param index
	 */
	private void checkIndexInsert(int index) {
		if (index < 0 || index > (size)) {
			throw new IndexOutOfBoundsException("Wrong index of list");
		}
	}

	/**
	 * ispitujemo da li indeks zadovoljava kriterije liste
	 * 
	 * @param index
	 */
	private void checkIndex(int index) {
		if (index < 0 || index > (size - 1)) {
			throw new IndexOutOfBoundsException("Wrong index of list");
		}
	}
}
