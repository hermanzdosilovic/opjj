package hr.fer.zemris.java.custom.scripting.nodes;

/**
 * 
 * @author Antun Sekulic 0246012693
 *
 */

import hr.fer.zemris.java.custom.scripting.parser.SmartScriptParserException;

public class TextNode extends Node {

	private String text;

	/**
	 * Konstruktor
	 * 
	 * @param text
	 *            String
	 */
	public TextNode(String text) {
		super();
		if (null == text) {
			throw new SmartScriptParserException("text node text == null!");
		}
		if (chekForIllegalChar(text)) {
			throw new SmartScriptParserException("texht node have illegal chars ");
		}
		this.text = text;
	}

	/**
	 * Vraca vrijednost tokena
	 * 
	 * @return String
	 */
	public String getText() {
		return text;
	}

	@Override
	public boolean canHaveChildren() {
		return false;
	}

	private boolean chekForIllegalChar(String text) {
		return false;
	}

	@Override
	public String toString() {
		return "TextNode  " + getText() + "\n";
	}

	@Override
	public void accept(INodeVisitor visitor) {
		visitor.visitTextNode(this);
	}

}
