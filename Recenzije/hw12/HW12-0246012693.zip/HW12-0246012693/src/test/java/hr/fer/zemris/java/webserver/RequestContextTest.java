package hr.fer.zemris.java.webserver;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import hr.fer.zemris.java.webserver.RequestContext.RCCookie;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Test;

/**
 * Razred za testiranje {@link RequestContext} objekta
 * 
 * @author Antun Sekulic 0246012693
 * @version 1.0
 */
public class RequestContextTest {

	@Test(expected = RuntimeException.class)
	public void constructorExceptionTest() {
		new RequestContext(null, new HashMap<String, String>(), new HashMap<String, String>(),
				new ArrayList<RequestContext.RCCookie>());
	}

	@Test(expected = RuntimeException.class)
	public void noEncodingChangeAfterWriting() throws IOException {
		RequestContext rc = getNewRC();
		rc.write("test");
		rc.setEncoding("UTF-8");
	}

	@Test(expected = RuntimeException.class)
	public void noStatusCodeChangeAfterWriting() throws IOException {
		RequestContext rc = getNewRC();
		rc.write("test");
		rc.setStatusCode(200);
	}

	@Test(expected = RuntimeException.class)
	public void noStattusTextChangeAfterWriting() throws IOException {
		RequestContext rc = getNewRC();
		rc.write("test");
		rc.setStatusText("OK");
	}

	@Test(expected = RuntimeException.class)
	public void noMimeTypeChangeAfterWriting() throws IOException {
		RequestContext rc = getNewRC();
		rc.write("test");
		rc.setMimeType("text/html");
	}

	@Test(expected = RuntimeException.class)
	public void noRCCookieAddingAfterWriting() throws IOException {
		RequestContext rc = getNewRC();
		rc.write("test");
		rc.addRCCookie(new RCCookie("name", "value", 0, "127.0.0.1", "/"));
	}

	@Test
	public void tempParamsTest() {
		RequestContext rc = getNewRC();
		Map<String, String> tmpParams = new HashMap<>();
		rc.setTemporaryParameters(tmpParams);
		Map<String, String> tmpParamsCpy = rc.getTemporaryParameters();
		assertTrue(tmpParams == tmpParamsCpy);
	}

	@Test
	public void tempParamTest() {
		final RequestContext rc = getNewRC();
		rc.setTemporaryParameter("param", "test");
		final String val = rc.getTemporaryParameter("param");
		assertTrue("test".equals(val));
	}

	@Test
	public void persParamsTest() {
		RequestContext rc = getNewRC();
		Map<String, String> pParams = new HashMap<>();
		rc.setPersistentParameters(pParams);
		Map<String, String> pParamsCpy = rc.getPersistentParameters();
		assertTrue(pParams == pParamsCpy);
	}

	@Test
	public void getParamsTest() {
		final RequestContext rc = getNewFilledRC();
		assertNotNull(rc.getParameters());
	}

	@Test
	public void getParamTest() {
		RequestContext rc = getNewFilledRC();
		String s = rc.getParameter("p");
		assertTrue(s.equals("P"));
	}

	@Test
	public void getParamsNamesTest() {
		RequestContext rc = getNewFilledRC();
		assertNotNull(rc.getParameterNames());
	}

	@Test
	public void getPParamTest() {
		final RequestContext rc = getNewFilledRC();
		final String s = rc.getPersistentParameter("pp");
		assertTrue(s.equals("PP"));
	}

	@Test
	public void getPParamsNamesTest() {
		final RequestContext rc = getNewFilledRC();
		assertNotNull(rc.getPersistentParameterNames());
	}

	@Test
	public void setPParamsNamesTest() {
		RequestContext rc = getNewFilledRC();
		rc.setPersistentParameter("name", "value");
		assertTrue(rc.getPersistentParameter("name").equals("value"));
		rc.removePersistentParameter("name");
		assertNull(rc.getPersistentParameter("name"));
	}

	@Test
	public void TParamsNamesTest() {
		final RequestContext rc = getNewFilledRC();
		rc.setTemporaryParameter("name", "value");
		assertTrue(rc.getTemporaryParameter("name").equals("value"));
		rc.removeTemporaryParameter("name");
		assertNull(rc.getTemporaryParameter("name"));
		assertNotNull(rc.getTemporaryParameterNames());
	}

	public void rcCookieTest() {
		final RCCookie cookie = new RCCookie("c", "C", 0, "127.0.0.1", "/");
		assertEquals("c", cookie.getName());
		assertEquals("C", cookie.getValue());
		assertEquals(0, cookie.getMaxAge().intValue());
		assertEquals("127.0.0.1", cookie.getDomain());
		assertEquals("/", cookie.getPath());
	}

	private RequestContext getNewRC() {
		return new RequestContext(new ByteArrayOutputStream(), new HashMap<String, String>(),
				new HashMap<String, String>(), new ArrayList<RequestContext.RCCookie>());
	}

	private RequestContext getNewFilledRC() {
		final Map<String, String> parameters = new HashMap<String, String>();
		final Map<String, String> persistentParameters = new HashMap<String, String>();
		final List<RCCookie> outputCookies = new ArrayList<RequestContext.RCCookie>();

		parameters.put("p", "P");
		persistentParameters.put("pp", "PP");
		outputCookies.add(new RCCookie("c", "C", 0, "127.0.0.1", "/"));

		return new RequestContext(new ByteArrayOutputStream(), parameters, persistentParameters, outputCookies);
	}
}
