package hr.fer.zemris.java.custom.scripting.nodes;

/**
 * Node representing part of text data. 
 * Inherits from Node class.
 * @author Mario Ćesić
 *
 */
public class TextNode extends Node {
	
	private String text;
	
	/**
	 * Default constructor for TextNode class.
	 * @param text string which represents text
	 */
	public TextNode(String text) {
		this.text = text;
	}
	
	/**
	 * @return text TextNode text
	 */
	public String getText() {
		return text;
	}
	
	/**
	 * Returns string representation of TextNode.
	 */
	@Override 
	public String toString() {
		return text;
	}
}
