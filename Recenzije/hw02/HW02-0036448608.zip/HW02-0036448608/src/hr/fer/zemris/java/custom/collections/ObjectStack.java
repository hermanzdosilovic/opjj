package hr.fer.zemris.java.custom.collections;

/**
 * Implementation of stack using custom ArrayBackedIndexedCollection class.
 * @author Mario Ćesić
 *
 */
public class ObjectStack {
	
	private ArrayBackedIndexedCollection col;
	
	/**
	 * Constructor for class.
	 * Creates new private instance of ArrayBackedIndexedCollection
	 * class.
	 */
	public ObjectStack() {
		col = new ArrayBackedIndexedCollection();
	}
	
	/**
	 * Checks whether stack is empty or not.
	 * @return True if empty, false otherwise
	 */
	public boolean isEmpty() {
		return col.isEmpty();
	}
	
	/**
	 * Returns stack size.
	 * @return Stack size
	 */
	public int size() {
		return col.size();
	}
	
	/**
	 * Pushes given value on the stack.
	 * @param value Given object, null is not allowed
	 */
	public void push(Object value) {
		col.add(value);
	}
	
	/**
	 * Removes last value placed on stack and
	 * returns it. Throws EmptyStackException exception
	 * if there are no elements on stack. 
	 * @return Last object on stack
	 */
	public Object pop() {
		if (col.size() < 1) {
			throw new EmptyStackException();
		}
		Object obj = col.get(col.size() - 1);
		col.remove(col.size() - 1);
		return obj;
	}
	
	/**
	 * Returns last element placed on stack.
	 * @return Last element on stack
	 */
	public Object peek() {
		return col.get(col.size() - 1);
	}
	
	/**
	 * Removes all elements from stack.
	 */
	public void clear() {
		col.clear();
	}
	
}
