package hr.fer.zemris.java.custom.scripting.nodes;

import hr.fer.zemris.java.custom.collections.ArrayBackedIndexedCollection;

/**
 * Class used for representation of structured documents.
 * @author Mario Ćesić
 *
 */
public class Node {
	
	private ArrayBackedIndexedCollection col;
	
	/**
	 * Constructor for class.
	 */
	public Node() {
		col = null;
	}
	
	/**
	 * Adds child node to internally managed collection
	 * of children.
	 * @param child node to add to node.
	 */
	public void addChildNode(Node child) {
		if (col == null) {
			col = new ArrayBackedIndexedCollection();
		}
		col.add((Node) child);
	}
	
	/**
	 * Returns number of children in node.
	 * @return size of collection
	 */
	public int numberOfChildren() {
		if (col == null) return 0;
		return col.size();
	}
	
	/**
	 * Returns child node given its index.
	 * @param index child node index 
	 * @return child node with given index
	 */
	public Node getChild(int index) {
		return (Node) col.get(index);
	}
	
	/**
	 * Returns string representation of node.
	 */
	@Override 
	public String toString() {
		return "";
	}
	
}
