package hr.fer.zemris.java.custom.scripting.tokens;

/**
 * Inherits Token and has single read-only double property.
 * @author Mario Ćesić
 *
 */
public class TokenConstantDouble extends Token {
	
	private double value;
	
	/**
	 * Constructor for this class.
	 * @param value double value 
	 */
	public TokenConstantDouble(double value) {
		this.value = value;
	}
	
	@Override
	public String asText() {
		return Double.toString(value);
	}
	
	/**
	 * @return token value
	 */
	public double getValue() {
		return value;
	}
	
}
