package hr.fer.zemris.java.custom.scripting.tokens;

import hr.fer.zemris.java.custom.scripting.parser.SmartScriptParserException;

/**
 * Inherits Token and has single read-only String property.
 * @author Mario Ćesić
 *
 */
public class TokenFunction extends Token {
	
	private String name;
	
	/**
	 * Default constructor for this class.
	 * Throws SmartScriptParserException if given invalid function name.
	 * @param name string to be saved
	 */
	public TokenFunction(String name) {
		// first character must start with letter
		if (Character.isLetter(name.charAt(0))) {
			this.name = name;
		}
		else {
			throw new SmartScriptParserException("Invalid name of the function!");
		}
	}
	
	@Override
	public String asText() {
		return name;
	}
	
	/**
	 * @return token name
	 */
	public String getName() {
		return name;
	}

}
