package hr.fer.zemris.java.custom.collections;

/**
 * Program for trying out created classes in this package.
 * @author Mario Ćesić
 *
 */
public class ProgramTester {
	
	/**
	 * Program starting point.
	 * @param args Unused
	 */
	public static void main(String[] args) {
		runTests();
	}
	
	/**
	 * Method which prints elements of given ArrayBackedIndexedCollection.
	 * @param col given ArrayBackedIndexedCollection
	 */
	public static void printCollection(ArrayBackedIndexedCollection col) {
		System.out.println("Printing collection:");
		for (int i = 0; i < col.size(); i++) {
			System.out.println(col.get(i));
		}
		System.out.println("Done!");
	}
	
	/**
	 * Method which tests behavior of ArrayBackedIndexedCollection and
	 * ObjectStack classes.
	 */
	public static void runTests() {
		
		ArrayBackedIndexedCollection col = new ArrayBackedIndexedCollection(2);
		System.out.println(col.isEmpty());
		System.out.println(col.size());
		
		col.add(new Integer(20));
		col.add(new Float(4.4));
		System.out.println(col.size());
		
		col.add(new String("nesto"));
		System.out.println(col.size());
		
		System.out.println(new Integer(20));
		System.out.println();
		System.out.println(col.get(0));
		System.out.println(col.get(1));
		System.out.println(col.get(2));
		System.out.println();
		
		col.remove(0);
		System.out.println(col.get(0));
		System.out.println(col.get(1));
		//System.out.println(col.get(2));
		
		col.add(new Integer(100));
		col.add(new Integer(255));
		printCollection(col);
		col.insert(new Boolean(false), 2);
		printCollection(col);
		
		System.out.println(col.indexOf(100));
		System.out.println(col.indexOf(-40));
		System.out.println(col.contains(100));
		System.out.println(col.contains("nesto"));
		col.clear();
		printCollection(col);
		
		System.out.println("Proba ObjectStack");
		ObjectStack obj = new ObjectStack();
		obj.push(new Integer(20));
		obj.push(new String("Kako mi je Darko"));
		obj.push(new Double(4.4));
		System.out.println(obj.size());
		System.out.println(obj.pop());
		System.out.println(obj.size());
		System.out.println(obj.peek());
		System.out.println(obj.pop());
		System.out.println(obj.pop());
		obj.clear();
		System.out.println(obj.size());
		//System.out.println(obj.pop());
	}

}
