package hr.fer.zemris.java.custom.scripting.nodes;

/**
 * Root node for document in parsed form.
 * @author Mario Ćesić
 *
 */
public class DocumentNode extends Node {

}
