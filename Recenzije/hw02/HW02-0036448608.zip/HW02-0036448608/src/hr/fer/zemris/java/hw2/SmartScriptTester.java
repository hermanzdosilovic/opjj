package hr.fer.zemris.java.hw2;

import hr.fer.zemris.java.custom.collections.ObjectStack;
import hr.fer.zemris.java.custom.scripting.nodes.DocumentNode;
import hr.fer.zemris.java.custom.scripting.nodes.EchoNode;
import hr.fer.zemris.java.custom.scripting.nodes.ForLoopNode;
import hr.fer.zemris.java.custom.scripting.nodes.Node;
import hr.fer.zemris.java.custom.scripting.nodes.TextNode;
import hr.fer.zemris.java.custom.scripting.parser.SmartScriptParser;
import hr.fer.zemris.java.custom.scripting.parser.SmartScriptParserException;
import hr.fer.zemris.java.custom.scripting.tokens.TokenConstantInteger;
import hr.fer.zemris.java.custom.scripting.tokens.TokenFunction;
import hr.fer.zemris.java.custom.scripting.tokens.TokenOperator;
import hr.fer.zemris.java.custom.scripting.tokens.TokenString;
import hr.fer.zemris.java.custom.scripting.tokens.TokenVariable;

/**
 * Class made for testing SmartScriptParser.
 * @author Mario Ćesić
 *
 */
public class SmartScriptTester {
	
	/**
	 * Program for trying out SmartScriptParser.
	 * @param args Unused
	 */
	public static void main(String[] args) {
		
		String docBody = "Example {$=1.7$}. Now actually write one {$=90$} "
				+ "Here comes echo {$= i i * 750 @decfmt \"0.000\"$} \r\n"
				+ "Kurt Vonnegut {$  FOR i 1   10 8 $} {$ FOR j 7 11 19 $} "
				+ "for loop inside for loop"
				+ " {$ FOR k 4 3 2 $} triple for loop{$END}{$END} "
				+ "end of inner for loop"
				+ " {$END$} after for loop"
				+ "\\{$=700$} ";
		
		SmartScriptParser parser = null;
		try {
		parser = new SmartScriptParser(docBody);
		
		} catch(SmartScriptParserException e) {
		//System.out.println("Unable to parse document!");
		System.out.println(e.getMessage());
		System.exit(-1);
		
		} catch(Exception e) {
		System.out.println("If this line ever executes, you have failed this class!");
		System.exit(-1);
		}
		
		DocumentNode document = parser.getDocumentNode();
		testingParser(document); // just various prints, can be commented
		
		String originalDocumentBody = createOriginalDocumentBody(document);
		System.out.println("Recovering original document:");
		System.out.println(originalDocumentBody); // writes original content of docbody
	}
	
	/**
	 * Recreates original document from given DocumentNode.
	 * @param node DocumentNode, result of parsing the document
	 * @return String representation of original document
	 */
	public static String createOriginalDocumentBody(DocumentNode document) {
		String buffer = "";
		for (int i = 0; i < document.numberOfChildren(); i++) {
			buffer += document.getChild(i).toString();
		}
		return buffer;
	}
	
	/**
	 * Method which tests DocumentNode representation created by 
	 * SmartScriptParser.
	 * @param n
	 */
	public static void testingParser(DocumentNode n) {
		System.out.println("TEST");
		
		//Node n = ((Node) myObjectStack.peek());
		TextNode tn1 = ((TextNode) n.getChild(0));
		System.out.println(tn1.getText());
		
		EchoNode en1 = ((EchoNode) n.getChild(1));
		System.out.println(en1.getTokens()[0].asText());
		
		TextNode tn2 = ((TextNode) n.getChild(2));
		System.out.println(tn2.getText());
		
		EchoNode en2 = ((EchoNode) n.getChild(3));
		System.out.println(en2.getTokens()[0].asText());
		
		TextNode tn3 = ((TextNode) n.getChild(4));
		System.out.println(tn3.getText());
		
		EchoNode en3 = ((EchoNode) n.getChild(5));
		System.out.println(en3.getTokens()[0].asText());
		System.out.println(en3.getTokens()[1].asText());
		System.out.println(en3.getTokens()[2].asText());
		System.out.println(en3.getTokens()[3].asText());
		System.out.println(en3.getTokens()[4].asText());
		System.out.println(en3.getTokens()[5].asText());
		// should print true for all
		System.out.println(en3.getTokens()[2] instanceof TokenOperator);
		System.out.println(en3.getTokens()[3] instanceof TokenConstantInteger);
		System.out.println(en3.getTokens()[4] instanceof TokenFunction);
		System.out.println(en3.getTokens()[5] instanceof TokenString);
		System.out.println(en3.getTokens()[0] instanceof TokenVariable);
		
		TextNode tn4 = ((TextNode) n.getChild(6));
		System.out.println(tn4.getText());
		
		System.out.println("ForLoopNode");
		ForLoopNode fln1 = ((ForLoopNode) n.getChild(7));
		// should print true
		System.out.println(fln1.getVariable() instanceof TokenVariable);
		System.out.println(fln1.getStartExpression() instanceof TokenConstantInteger);
		// elements of 1st ForLoopNode
		System.out.println(fln1.getVariable().asText());
		System.out.println(fln1.getStartExpression().asText());
		System.out.println(fln1.getEndExpression().asText());
		System.out.println(fln1.getStepExpression().asText());
		// testing 1st (outer) ForLoopNode
		TextNode tn5 = ((TextNode) fln1.getChild(0));
		System.out.println("for loop text"+tn5.getText());
		// testing 2nd (inner) ForLoopNode
		ForLoopNode fln2 = ((ForLoopNode) fln1.getChild(1));
		System.out.println("print fln2"+fln2.toString());
		// testing 3rd (inner-most) ForLoopNode
		ForLoopNode fln3 = ((ForLoopNode) fln2.getChild(1));
		System.out.println("print fln3"+fln3.toString());
		
		System.out.println("num of children: "+n.numberOfChildren());
		
		TextNode tn6 = ((TextNode) n.getChild(8));
		System.out.println("tn6"+tn6.getText());
		
		System.out.println(((Node) fln1).toString());
		System.out.println(en3.toString());
		System.out.println(tn6.toString());
		
		System.out.println("END TEST");
	}

}
