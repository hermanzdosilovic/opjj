package hr.fer.zemris.java.custom.scripting.tokens;

/**
 * Inherits Token and has single read-only String property.
 * @author Mario Ćesić
 *
 */
public class TokenOperator extends Token {
	
	private String symbol;
	
	/**
	 * Constructor for this class.
	 * @param symbol given symbol which this token represents
	 */
	public TokenOperator(String symbol) {
		this.symbol = symbol;
	}
	
	@Override
	public String asText() {
		return symbol;
	}
	
	/**
	 * @return token symbol
	 */
	public String getSymbol() {
		return symbol;
	}

}
