package hr.fer.zemris.java.custom.scripting.parser;

import hr.fer.zemris.java.custom.collections.ObjectStack;
import hr.fer.zemris.java.custom.scripting.nodes.DocumentNode;
import hr.fer.zemris.java.custom.scripting.nodes.EchoNode;
import hr.fer.zemris.java.custom.scripting.nodes.ForLoopNode;
import hr.fer.zemris.java.custom.scripting.nodes.Node;
import hr.fer.zemris.java.custom.scripting.nodes.TextNode;
import hr.fer.zemris.java.custom.scripting.tokens.Token;
import hr.fer.zemris.java.custom.scripting.tokens.TokenConstantDouble;
import hr.fer.zemris.java.custom.scripting.tokens.TokenConstantInteger;
import hr.fer.zemris.java.custom.scripting.tokens.TokenFunction;
import hr.fer.zemris.java.custom.scripting.tokens.TokenOperator;
import hr.fer.zemris.java.custom.scripting.tokens.TokenString;
import hr.fer.zemris.java.custom.scripting.tokens.TokenVariable;

/**
 * Parser for structured document format.
 * @author Mario Ćesić
 *
 */
public class SmartScriptParser {
	
	private ObjectStack myObjectStack;
	
	/**
	 * Constructor for this class. Parses given document and creates
	 * DocumentNode as the result of parsing.
	 * @param document given document as string
	 */
	public SmartScriptParser(String document) {
		try {
			myObjectStack = createDocumentModel(document);
		}
		catch(Exception e) {
			throw new SmartScriptParserException("Parsing error");
		}
	}
	
	/**
	 * @return DocumentNode which is the result of parsing a document
	 */
	public DocumentNode getDocumentNode() {
		return (DocumentNode) myObjectStack.peek();
	}
	
	/**
	 * Creates document model from given document.
	 * @param document given document
	 * @return reference to ObjectStack which represents document model
	 */
	private ObjectStack createDocumentModel(String document) {
		ObjectStack myObjectStack = new ObjectStack();
		myObjectStack.push(new DocumentNode());
		readDocument(document, myObjectStack);
		return myObjectStack;
	}
	
	/**
	 * Reads documents and builds tag/text nodes.
	 * @param document given document
	 * @param myObjectStack representation of document model
	 */
	private void readDocument(String document, ObjectStack myObjectStack) {
		String buffer = "";
		
		final int TEXT = 0;
		final int TAG = 1;
		int currentState = TEXT;
		
		for (int i = 0; i < document.length(); i++) {
			switch (currentState) {
				case TEXT:
					// '{' determines beginning of a tag
					if (document.charAt(i) == '{' && document.charAt(i - 1) != '\\'
						|| i == document.length() - 1) {
						currentState = TAG;
						((Node) myObjectStack.peek()).addChildNode(new TextNode(buffer));
						buffer = "";
						break;
					}
					buffer += document.charAt(i);
					break;
				case TAG:
					// '{' determines end of tag
					if (document.charAt(i) == '}') {
						currentState = TEXT;
						processTag(myObjectStack, buffer);
						buffer = "";
						break;
					}
					buffer += document.charAt(i);
					break;
			}
		}
	}
	
	/**
	 * Helper function for preparing string for token extraction.
	 * @param str string to be modified
	 * @return string with removed characters '=' and trailing whitespaces
	 */
	private String removeSpecialCharactersAndTrim(String str) {
		str = str.substring(1).trim();
		return str.substring(0, str.length() - 1);
	}
	
	/**
	 * Processes given tag.
	 * @param myObjectStack 
	 * @param buffer tag to process, given as string
	 */
	private void processTag(ObjectStack myObjectStack, String buffer) {
		buffer = buffer.substring(1).trim(); // removing first character '$'
		// processing FOR-tag
		if (buffer.substring(0, 3).toLowerCase().equals("for")) {
			ForLoopNode fln = createForLoopNode(buffer);
			((Node) myObjectStack.peek()).addChildNode(fln);
			myObjectStack.push(fln);
		}
		// processing END-tag
		else if (buffer.substring(0, 3).toLowerCase().equals("end")) {
			myObjectStack.pop();
		}
		// processing empty tag
		else if (buffer.charAt(0) == '=') { 
			EchoNode en = createEchoNode(buffer);
			((Node) myObjectStack.peek()).addChildNode(en);
		}
		else {
			throw new SmartScriptParserException("Invalid tag!");
		}
	}
	
	/**
	 * Creates ForLoopNode out of given string.
	 * @param buffer given string
	 * @return created ForLoopNode
	 */
	private ForLoopNode createForLoopNode(String buffer) {
		buffer = buffer.substring(3).trim();
		buffer = buffer.substring(0, buffer.length() - 1);
		Token[] tokenArray = makeTokens(buffer);
		ForLoopNode fln = new ForLoopNode((TokenVariable) tokenArray[0],
				tokenArray[1], tokenArray[2], tokenArray[3]);
		return fln;
	}
	
	/**
	 * Creates EchoNode out of given string
	 * @param buffer given string
	 * @return created EchoNode
	 */
	private EchoNode createEchoNode(String buffer) {
		buffer = removeSpecialCharactersAndTrim(buffer);
		Token[] tokenArray = makeTokens(buffer);
		EchoNode en = new EchoNode(tokenArray);
		return en;
	}
	
	/**
	 * Processes given expression and returns created tokens.
	 * @param expression given as string
	 * @return array of Tokens created from given expression
	 */
	private Token[] makeTokens(String expression) {
		expression = expression.replaceAll("\\s+", " "); // removing duplicate whitespaces
		String[] stringTokens = expression.split(" ");
		Token[] tokens = new Token[stringTokens.length];
		
		for (int i = 0; i < stringTokens.length; i++) {
			tokens[i] = makeOneToken(stringTokens[i]);
		}
		
		return tokens;
	}
	
	/**
	 * Makes token out of a given string.
	 * @param str given string
	 * @return Token (one of variants: TokenOperator, TokenFunction etc.)
	 */
	private Token makeOneToken(String str) {
		if (str.equals("*") || str.equals("/") || str.equals("+") || str.equals("-")) {
			return new TokenOperator(str);
		}
		
		if (str.charAt(0) == '@') {
			return new TokenFunction(str.substring(1));
		}
		
		if (str.charAt(0) == '\"') {
			return new TokenString(str.replace("\"", ""));
		}
		
		try {
			int value = Integer.parseInt(str);
			return new TokenConstantInteger(value);
		}
		catch (NumberFormatException e) {
		}
		
		try {
			double value = Double.parseDouble(str);
			return new TokenConstantDouble(value);
		}
		catch (NumberFormatException e) {
		}
		
		return new TokenVariable(str);
	}
	
}
