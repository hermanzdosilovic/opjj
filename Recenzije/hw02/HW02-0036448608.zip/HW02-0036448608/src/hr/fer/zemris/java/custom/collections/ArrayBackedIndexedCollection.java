package hr.fer.zemris.java.custom.collections;

/**
 * Implementation of list-like collection using array.
 * @author Mario Ćesić
 *
 */
public class ArrayBackedIndexedCollection {
	
	private int size;
	private int capacity;
	private Object[] elements;
	
	/**
	 * Default constructor for class.
	 * Sets capacity to 16.
	 */
	public ArrayBackedIndexedCollection() {
		this.capacity = 16;
		this.size = 0;
		elements = new Object[16];
	}
	
	/**
	 * Second constructor for class which allows 
	 * setting initial collection capacity to arbitrary size.
	 * @param initialCapacity Capacity of collection to set
	 */
	public ArrayBackedIndexedCollection(int initialCapacity) {
		if (initialCapacity < 1) {
			throw new IllegalArgumentException("Capacity cannot be set to less than 1!");
		}
		this.capacity = initialCapacity;
		this.size = 0;
		elements = new Object[this.capacity];
	}
	
	/**
	 * Returns true if collection is empty, false otherwise.
	 * @return True if collection is empty, false otherwise
	 */
	public boolean isEmpty() {
		if (size == 0) return true;
		return false;
	}
	
	/**
	 * Returns size of collection.
	 * @return size of collection
	 */
	public int size() {
		return size;
	}
	
	/**
	 * Helper method for copying array elements from one 
	 * array to another.
	 * @param source Source array to copy from
	 * @param destination Destination array to copy to
	 */
	private void copyArray(Object[] destination, Object[] source) {
		for (int i = 0; i < size; i++) {
			destination[i] = source[i];
		}
	}
	
	/**
	 * Expands collection if its size is too small for 
	 * adding new element.
	 */
	private void expandCollectionIfTooSmall() {
		if (size == capacity) {
			Object[] newElements = new Object[2 * size];
			copyArray(newElements, elements);
			elements = newElements;
			capacity *= 2;
		}
	}
	
	/**
	 * Adds given object to collection.
	 * Reallocates elements array if it's full.
	 * @param value Object to add to collection
	 */
	public void add(Object value) {
		if (value == null) {
			throw new IllegalArgumentException("Null cannot be "
										+ "added as an element!");
		}
		expandCollectionIfTooSmall();
		elements[size++] = value;		
	}
	
	/**
	 * Returns object with a given index
	 * @param index Given index
	 * @return Object at given index
	 */
	public Object get(int index) {
		if (index < 0 || index >= size) {
			throw new IndexOutOfBoundsException("Invalid index was passed!");
		}
		return elements[index];
	}
	
	/**
	 * Removes object at a given index.
	 * @param index Given index
	 */
	public void remove(int index) {
		for (int i = index; i < size - 1; i++) {
			elements[i] = elements[i + 1];
		}
		size--;
	}
	
	/** 
	 * Inserts object at a given position.
	 * @param value Object to insert to collection
	 * @param position Position at which to insert object
	 */
	public void insert(Object value, int position) {
		expandCollectionIfTooSmall();
		for (int i = size; i > position; i--) {
			elements[i] = elements[i - 1];
		}
		elements[position] = value;
		size++;
	}
	
	/**
	 * Returns index of a given object in collection.
	 * @param value Given object to search for in collection
	 * @return Index of a given object, -1 if not found
	 */
	public int indexOf(Object value) {
		for (int i = 0; i < size; i++) {
			if (elements[i].equals(value)) {
				return i;
			}
		}
		return -1;
	}
	
	/**
	 * Checks whether given object exists in collection.
	 * @param value Given object
	 * @return True if found in collection, false otherwise
	 */
	public boolean contains(Object value) {
		for (int i = 0; i < size; i++) {
			if (elements[i].equals(value)) {
				return true;
			}
		}
		return false;
	}
	
	/**
	 * Removes all elements from collection.
	 */
	public void clear() {
		elements = new Object[capacity];
		size = 0;
	}

}
