package hr.fer.zemris.java.custom.scripting.nodes;

import hr.fer.zemris.java.custom.scripting.tokens.Token;

/**
 * Node representing a command which generates some textual output 
 * dynamically. Inherits from Node class.
 * @author Mario Ćesić
 *
 */
public class EchoNode extends Node {
	
	private Token[] tokenArray;
	
	/**
	 * Constructor for this class.
	 * @param tokenArray array of tokens which EchoNode holds
	 */
	public EchoNode(Token[]	 tokenArray) {
		this.tokenArray = tokenArray;
	}
	
	/**
	 * @return token array
	 */
	public Token[] getTokens() {
		return tokenArray;
	}
	
	/**
	 * Returns string representation of EchoNode.
	 */
	@Override 
	public String toString() {
		String buffer = "{$= ";
		for (Token token: tokenArray) {
			buffer += token.asText() + " ";
		}
		buffer += "$}";
		return buffer;
	}
}
