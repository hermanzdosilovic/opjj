package hr.fer.zemris.java.custom.collections;

/**
 * Custom exception which is thrown when trying to access elements
 * from empty stack.
 * @author Mario Ćesić
 *
 */
public class EmptyStackException extends RuntimeException {
	
	/**
	 * Parametless constructor.
	 */
	public EmptyStackException() {
	}
	
	/**
	 * Constructor with given message.
	 * @param message Given message
	 */
	public EmptyStackException(String message) {
		super(message);
	}
}
