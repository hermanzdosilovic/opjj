package hr.fer.zemris.java.custom.scripting.tokens;

/**
 * Base class in Token hierarchy.
 * @author Mario Ćesić
 *
 */
public class Token {
	
	/**
	 * @return String representation of Token.
	 */
	public String asText() {
		return "";
	}
}
