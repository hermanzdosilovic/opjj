package hr.fer.zemris.java.custom.scripting.nodes;

import hr.fer.zemris.java.custom.scripting.tokens.Token;
import hr.fer.zemris.java.custom.scripting.tokens.TokenVariable;

/**
 * Node representing a single for-loop construct. 
 * Inherits from Node class.
 * @author Mario Ćesić
 *
 */
public class ForLoopNode extends Node{
	
	private TokenVariable variable;
	private Token startExpression;
	private Token endExpression;
	private Token stepExpression;
	
	/**
	 * Constructor for this class.
	 * @param variable property of type TokenVariable
	 * @param startExpression property of type Token
	 * @param endExpression property of type Token
	 * @param stepExpression property of type Token
	 */
	public ForLoopNode(TokenVariable variable, Token startExpression,
						Token endExpression, Token stepExpression) {
		this.variable = variable;
		this.startExpression = startExpression;
		this.endExpression = endExpression;
		this.stepExpression = stepExpression;
	}
	
	/**
	 * @return token variable
	 */
	public TokenVariable getVariable() {
		return variable;
	}
	
	/**
	 * @return token start expression
	 */
	public Token getStartExpression() {
		return startExpression;
	}
	
	/**
	 * @return token end expression
	 */
	public Token getEndExpression() {
		return endExpression;
	}
	
	/**
	 * @return token step expression
	 */
	public Token getStepExpression() {
		return stepExpression;
	}
	
	/**
	 * Returns string representation of ForLoopNode.
	 */
	@Override 
	public String toString() {
		String buffer;
		buffer = "{$FOR " 
				+ variable.asText() + " "
				+ startExpression.asText() + " "
				+ endExpression.asText() + " "
				+ stepExpression.asText()
				+ " $}";
		for (int i = 0; i < this.numberOfChildren(); i++) {
			buffer += this.getChild(i).toString();
		}
		buffer += "{$END$}";
		return buffer;
	}

}
