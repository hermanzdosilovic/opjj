package hr.fer.zemris.java.custom.scripting.parser;

/**
 * Custom exception which is thrown by the SmartScriptParser when it's
 * unable to process given document.
 * @author Mario Ćesić
 *
 */
public class SmartScriptParserException extends RuntimeException {
	
	/**
	 * Parametless constructor.
	 */
	public SmartScriptParserException() {
	}
	
	/**
	 * Constructor with given message.
	 * @param message Given message
	 */
	public SmartScriptParserException(String message) {
		super(message);
	}
}
