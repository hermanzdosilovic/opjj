package hr.fer.zemris.java.custom.scripting.tokens;

/**
 * Inherits Token and has single read-only String property.
 * @author Mario Ćesić
 *
 */
public class TokenString extends Token {
	
	private String value;
	
	/**
	 * Constructor for this class.
	 * @param value given value to set
	 */
	public TokenString(String value) {
		this.value = value;
	}
	
	@Override
	public String asText() {
		return "\"" + value + "\"";
	}
	
	/**
	 * @return token value
	 */
	public String getValue() {
		return value;
	}
}
