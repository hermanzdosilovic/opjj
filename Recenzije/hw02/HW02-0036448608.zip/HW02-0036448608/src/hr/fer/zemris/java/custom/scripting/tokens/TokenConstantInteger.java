package hr.fer.zemris.java.custom.scripting.tokens;

/**
 * Inherits Token and has single read-only integer property.
 * @author Mario Ćesić
 *
 */
public class TokenConstantInteger extends Token {
	
	int value;
	
	/**
	 * Default constructor for class.
	 * @param value integer value to set
	 */
	public TokenConstantInteger(int value) {
		this.value = value;
	}
	
	@Override
	public String asText() {
		return Integer.toString(value);
	}
	
	/**
	 * @return token value
	 */
	public int getValue() {
		return value;
	}
}
