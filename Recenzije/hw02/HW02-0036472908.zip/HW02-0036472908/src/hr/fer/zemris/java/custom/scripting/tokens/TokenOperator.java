package hr.fer.zemris.java.custom.scripting.tokens;
/**
 * 
 * @author Filip Culinovic
 *
 */
public class TokenOperator extends Token{

	private String symbol;
	/**
	 * Constructor method
	 * @param symbol string containing a symbol
	 */
	public TokenOperator(String symbol) {
		this.symbol = symbol;
	}
	/**
	 * Method for textual representation of this.symbol
	 */
	public String asText() {
		return symbol;
	}
	/**
	 * Getter method for this.symbol
	 * @return this.symbol
	 */
	public String getSymbol() {
		return symbol;
	}
}
