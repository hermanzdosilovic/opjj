package hr.fer.zemris.java.custom.scripting.nodes;
/**
 * 
 * @author Filip Culinovic
 *
 */
public class TextNode extends Node {

	private String text;
	/**
	 * Constructor
	 * @param text
	 */
	public TextNode(String text) {
		super();
		this.text = text;
	}
	/**
	 * Getter for text
	 * @return this.text
	 */
	public String getText() {
		return text;
	}
	
}
