package hr.fer.zemris.java.custom.collections;
/**
 * 
 * @author Filip Culinovic
 *
 */
public class EmptyStackException extends RuntimeException {

	private static final long serialVersionUID = 5019575938076748881L;
	/**
	 * Exception for addressing the stack when its empty
	 */
	public EmptyStackException() {
		super();
	}
}
