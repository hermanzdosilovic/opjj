package hr.fer.zemris.java.custom.collections;

import java.io.IOException;

/**
 * 
 * @author Filip Culinovic
 * 
 */

public class ArrayBackedIndexedCollection {

	private int size;
	private int capacity;
	private Object[] elements;

	/**
	 * Default constructor method
	 */

	public ArrayBackedIndexedCollection() {
		this.size = 0;
		this.capacity = 16;
		this.elements = new Object[16];
	}

	/**
	 * Constructor method with initial element capacity argument
	 * 
	 * @param initialCapacity
	 *            positive natural number, capacity of elements in collection
	 * @throws IOException
	 *             throws exception if capacity less than 1
	 */

	public ArrayBackedIndexedCollection(int initialCapacity) throws IOException {
		if (initialCapacity < 1) {
			throw new IOException(
					"The initial capacity must be a positive natural number!");
		}

		this.size = 0;
		this.capacity = initialCapacity;
		this.elements = new Object[capacity];
	}

	/**
	 * Method checks whether collection is empty
	 * 
	 * @return true if no elements in collection, false otherwise
	 */

	public boolean isEmpty() {
		if (this.size == 0) {
			return true;
		}
		return false;
	}

	/**
	 * Method returns number of elements in the collection
	 * 
	 * @return number of elements in the collection
	 */

	public int size() {
		return this.size;
	}

	/**
	 * Method adds the value to the collection
	 * 
	 * @param value
	 *            Object to be added to the collection
	 * @throws IllegalArgumentException
	 *             throws exception if value is null
	 */

	public void add(Object value) throws IllegalArgumentException {
		if (value == null) {
			throw new IllegalArgumentException(
					"You cannot add a null value to the collection!");
		}

		if (size == capacity) {
			Object[] auxiliary = new Object[2 * capacity];
			for (int i = 0; i < size; i++) {
				auxiliary[i] = elements[i];
			}

			elements = auxiliary;
		}

		elements[size] = value;
		size++;
	}

	/**
	 * Method for getting an object of required index number
	 * 
	 * @param index
	 *            index of the object to be fetched
	 * @return object with the given index
	 * @throws IndexOutOfBoundsException
	 *             throws exception if index less than 0 or more than size - 1
	 */

	public Object get(int index) throws IndexOutOfBoundsException {
		if (index < 0 || index > size - 1)
			throw new IndexOutOfBoundsException(
					"Index must be between 0 and size - 1");

		return elements[index];
	}

	/**
	 * Method for removing the object at a given index
	 * 
	 * @param index
	 *            index of the object to be removed
	 * @throws IndexOutOfBoundsException
	 *             throws exception if index less than 0 or more than size - 1
	 */

	public void remove(int index) throws IndexOutOfBoundsException {
		if (index < 0 || index > size - 1)
			throw new IndexOutOfBoundsException(
					"Index must be between 0 and size - 1");

		for (int i = index; i < size; i++) {
			elements[i] = elements[i + 1];
		}
		size--;
	}

	/**
	 * Method inserts the object at a given position in the collection
	 * 
	 * @param value
	 *            object to be inserted, cannot be null
	 * @param position 
	 * 			  where should the object be inserted in the collection
	 * @throws IndexOutOfBoundsException throws exception if position is less than 0 or more than size
	 * @throws IllegalArgumentException throws exception if object value is null
	 */

	public void insert(Object value, int position)
			throws IndexOutOfBoundsException, IllegalArgumentException {
		if (position < 0 || position > size)
			throw new IndexOutOfBoundsException(
					"Position must be between 0 and size");
		if (value == null)
			throw new IllegalArgumentException("Object value must not be null!");

		for (int i = position; i < size; i++) {
			elements[i + 1] = elements[i];
		}

		elements[position] = value;
		size++;
	}

	/**
	 * Method for returning the index of given object value
	 * @param value object you are asking index for
	 * @return index value if object of said value found, -1 if not found
	 */
	
	int indexOf(Object value) {
		int index = -1;
		for (int i = 0; i < size; i++) {
			if (elements[i].equals(value))
				index = i;
		}

		return index;
	}

	/**
	 * Method for checking whether the given object is in the collection
	 * @param value object you are looking for in the collection
	 * @return true if object of given value found, false otherwise
	 */
	
	boolean contains(Object value) {
		for (int i = 0; i < size; i++) {
			if (elements[i].equals(value))
				return true;
		}
		return false;
	}

	/**
	 * Method for clearing the collection
	 */
	
	void clear() {
		elements = null;
		size = 0;
	}
}
