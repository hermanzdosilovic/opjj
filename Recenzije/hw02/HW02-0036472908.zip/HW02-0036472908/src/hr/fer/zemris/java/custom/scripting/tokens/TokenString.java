package hr.fer.zemris.java.custom.scripting.tokens;
/**
 * 
 * @author Filip Culinovic
 *
 */
public class TokenString extends Token {
	
	private String value;
	/**
	 * Constructor method
	 * @param value
	 */
	public TokenString(String value) {
		this.value = value;
	}
	/**
	 * Method for textual representation of this.value
	 */
	public String asText() {
		return value;
	}
	/**
	 * Getter for this.value
	 * @return this.value
	 */
	public String getValue() {
		return value;
	}

}
