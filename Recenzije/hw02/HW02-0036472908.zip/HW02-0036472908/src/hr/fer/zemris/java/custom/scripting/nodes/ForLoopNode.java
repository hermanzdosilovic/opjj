package hr.fer.zemris.java.custom.scripting.nodes;

import hr.fer.zemris.java.custom.scripting.tokens.TokenVariable;
import hr.fer.zemris.java.custom.scripting.tokens.*;
/**
 * 
 * @author Filip Culinovic
 *
 */
public class ForLoopNode extends Node {

	TokenVariable variable;
	Token startExpression;
	Token endExpression;
	Token stepExpression;
	/**
	 * Default constructor
	 */
	public ForLoopNode() {
		super();
	}
	/**
	 * Getter method for variable
	 * @return this.variable
	 */
	public TokenVariable getVariable() {
		return variable;
	}
	/**
	 * Method for setting variable
	 * @param variable value you want to set this.variable to
	 */
	public void setVariable(TokenVariable variable) {
		this.variable = variable;
	}
	
	/**
	 * Getter method for variable
	 * @return this.startExpression
	 */
	
	public Token getStartExpression() {
		return startExpression;
	}
	/**
	 * Setter for startExpression
	 * @param startExpression value you want to set this.startExpression to
	 */
	public void setStartExpression(Token startExpression) {
		this.startExpression = startExpression;
	}
	/**
	 * Getter for EndExpression
	 * @return this.endExpression
	 */
	public Token getEndExpression() {
		return endExpression;
	}
	/**
	 * Setter for endExpression
	 * @param endExpression value you want to set this.endExpression to
	 */
	public void setEndExpression(Token endExpression) {
		this.endExpression = endExpression;
	}
	/**
	 * Getter for stepExpression
	 * @return this.stepExpression
	 */
	public Token getStepExpression() {
		return stepExpression;
	}

	/**
	 * Setter for stepExpression
	 * @param stepExpression value you want to set this.stepExpressino to
	 */
	public void setStepExpression(Token stepExpression) {
		this.stepExpression = stepExpression;
	}
	
	
	
}
