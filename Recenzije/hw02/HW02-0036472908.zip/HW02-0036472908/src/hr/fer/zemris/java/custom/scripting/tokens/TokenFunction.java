package hr.fer.zemris.java.custom.scripting.tokens;
/**
 * 
 * @author Filip Culinovic
 *
 */
public class TokenFunction extends Token {

	private String name;
	/**
	 * Constructor method
	 * @param name string to be used for token name attribute
	 */
	public TokenFunction(String name) {
		this.name = name;
	}
	/**
	 * Method for textual representation of name attribute
	 */
	public String asText() {
		return name;
	}
	/**
	 * Getter method for this.name
	 * @return this.name
	 */
	public String getName() {
		return name;
	}
}
