package hr.fer.zemris.java.custom.scripting.nodes;

import hr.fer.zemris.java.custom.collections.ArrayBackedIndexedCollection;
/**
 * 
 * @author Filip Culinovic
 *
 */
public class Node {

	private ArrayBackedIndexedCollection children;
	
	/**
	 * Method for adding a child node
	 * @param child non-null node
	 */
	public void addChildNode(Node child) {
		if (children == null) {
			children = new ArrayBackedIndexedCollection();
		}
		
		children.add(child);
	}
	/**
	 * Method for counting number of children of a node
	 * @return number of children
	 */
	public int numberOfChildren() {
		if (children == null) {
			return 0;
		}
		
		return children.size();
	}
	/**
	 * Method for retrieving a child from a node
	 * @param index index of a child you want to get
	 * @return child Node at index 'index'
	 */
	public Node getChild(int index) {
		if (index < 0 || index > children.size() - 1) {
			throw new IndexOutOfBoundsException("Index must be between 0 and collection size - 1!");
		}
		
		return (Node)children.get(index);
	}
}
