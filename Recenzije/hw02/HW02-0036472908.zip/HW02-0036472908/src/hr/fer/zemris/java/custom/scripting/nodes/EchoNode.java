package hr.fer.zemris.java.custom.scripting.nodes;

import hr.fer.zemris.java.custom.scripting.tokens.Token;

import java.util.Arrays;
/**
 * 
 * @author Filip Culinovic
 *
 */
public class EchoNode extends Node {

	private Token[] tokens;
	/**
	 * Constructor method
	 * @param objects Array of objects
	 */
	public EchoNode(Object[] objects) {
		super();
		tokens = new Token[objects.length];
		System.arraycopy(objects, 0, tokens, 0, objects.length);
	}
	
	public Token[] getTokens() {
		return Arrays.copyOf(tokens, tokens.length);
	}
}
