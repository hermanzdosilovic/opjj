package hr.fer.zemris.java.custom.scripting.parser;
/**
 * 
 * @author Filip Culinovic
 *
 */
public class SmartScriptParserException extends RuntimeException {

	private static final long serialVersionUID = 5019575938076748881L;
	/**
	 * Constructor method for exception which is used for errors in parsing
	 */
	public SmartScriptParserException() {
		super();
	}
}
