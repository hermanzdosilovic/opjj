package hr.fer.zemris.java.custom.scripting.tokens;
/**
 * 
 * @author Filip Culinovic
 *
 */
public class Token {
	/**
	 * Method for default token text representation
	 * @return
	 */
	public String asText() {
		return "";
	}
	
}
