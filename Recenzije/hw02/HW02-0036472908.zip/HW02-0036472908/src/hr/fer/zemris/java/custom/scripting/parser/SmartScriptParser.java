package hr.fer.zemris.java.custom.scripting.parser;

import hr.fer.zemris.java.custom.scripting.nodes.*;
import hr.fer.zemris.java.custom.collections.*;
import hr.fer.zemris.java.custom.scripting.nodes.DocumentNode;
import hr.fer.zemris.java.custom.scripting.nodes.EchoNode;
import hr.fer.zemris.java.custom.scripting.nodes.ForLoopNode;
import hr.fer.zemris.java.custom.scripting.nodes.Node;
import hr.fer.zemris.java.custom.scripting.nodes.TextNode;
import hr.fer.zemris.java.custom.scripting.tokens.Token;
import hr.fer.zemris.java.custom.scripting.tokens.TokenConstantDouble;
import hr.fer.zemris.java.custom.scripting.tokens.TokenConstantInteger;
import hr.fer.zemris.java.custom.scripting.tokens.TokenFunction;
import hr.fer.zemris.java.custom.scripting.tokens.TokenOperator;
import hr.fer.zemris.java.custom.scripting.tokens.TokenString;
import hr.fer.zemris.java.custom.scripting.tokens.TokenVariable;
import hr.fer.zemris.java.custom.scripting.tokens.*;
/**
 * 
 * @author Filip Culinovic
 *
 */
public class SmartScriptParser {

	private DocumentNode document;
	private ObjectStack nodeStack;
	private String documentText;
	private int textLength;
	private int index;
	private int openNodes;
	/**
	 * Constructor for the parser
	 * @param documentBody string representation of the document you want to parse
	 */
	public SmartScriptParser(String documentBody) {
		if(documentBody.isEmpty()) {
			throw new SmartScriptParserException();
		}
		
		nodeStack = new ObjectStack();
		document = new DocumentNode();
		this.documentText = documentBody;
		index = 0;
		openNodes = 0;
		textLength = documentText.length();
		
		parse();
	}
	
	/**
	 * Method for starting the parsing procedure
	 */
	private void parse() {
		nodeStack.push(document);
		if(isStartOfTag()) {
			index += 2;
			parseTag();
		}
		else {
			parseText();
		}
		if(openNodes != 0)
			throw new SmartScriptParserException();
	}
	/**
	 * Method for parsing tags in the document
	 */
	private void parseTag() {
		skipWhitespaces();
		
		switch(documentText.charAt(index)) {
		case 'F':	if(!isForTag()) {
						throw new SmartScriptParserException();
					}
					index += 3;
					skipWhitespaces();
					
					ForLoopNode forNode = new ForLoopNode();
					
					TokenVariable variable = readVariable();
					forNode.setVariable(variable);
					
					skipWhitespaces();
					
					Token startExpression = readExpression();
					forNode.setStartExpression(startExpression);
					
					skipWhitespaces();
					
					Token endExpression = readExpression();
					forNode.setEndExpression(endExpression);
					
					skipWhitespaces();
					
					Token stepExpression = readExpression();
					if (stepExpression != null) {
						forNode.setStepExpression(stepExpression);	
					}
					
					skipWhitespaces();		
					
					if (!(index < textLength && isTagEnd())) {
						throw new SmartScriptParserException();				  
					}
					Node topOfStack = (Node) nodeStack.pop();
					topOfStack.addChildNode(forNode);
					nodeStack.push(topOfStack);
					nodeStack.push(forNode);		
					
					openNodes++;

					parseNext();
					break;
					
		case 'E': 	if (!isEndTag()) {
						throw new SmartScriptParserException();
					}
					index += 3;
	  				skipWhitespaces();
	  				if (!(index < textLength && isTagEnd())) {
		  				throw new SmartScriptParserException();				  
	  				}
	  				nodeStack.pop();
	  				if (nodeStack.isEmpty()) {
		  				throw new SmartScriptParserException();
	  				}
	  				
	  				openNodes--;
	  				
	  				parseNext();	  
	  				break;
	  
		case '=': 	index++; 
	  				skipWhitespaces();
	  				tokenizeEmptyTag();
	  				break;
      
		default: throw new SmartScriptParserException(); 
		}
		
	}
	/**
	 * Method for parsing textual parts of the document
	 */
	private void parseText() {
		int beginIndex = index;
		StringBuffer textNodeValue = new StringBuffer();
		if(index < textLength) {
			index++;
		}
		else return;
		
		while(!(documentText.charAt(index - 1) != '\\' && isStartOfTag())) {
			if(documentText.charAt(index) == '\\' && documentText.charAt(index + 1) == '{') {
				textNodeValue.append(documentText.substring(beginIndex, index));
				index++;
				beginIndex = index;
			}
			index++;
			
			if(index == textLength - 1) {
				break;
			}
		}
		
		textNodeValue.append(documentText.substring(beginIndex, index));
		TextNode textNode = new TextNode(textNodeValue.toString());
		
		Node topStack = (Node) nodeStack.pop();
		topStack.addChildNode(textNode);
		nodeStack.push(topStack);
		
		if (index < textLength - 1 && isStartOfTag()) {
			index += 2;
			if (index >= textLength - 1) {
				throw new SmartScriptParserException();
			}
			parseTag();
		}
	
	}
	/**
	 * Method for skipping whitespaces
	 */
	private void skipWhitespaces() {
		if (index >= textLength) {
			throw new SmartScriptParserException();
		}
		while(Character.isWhitespace(documentText.charAt(index)) || documentText.charAt(index) == '\t') {
			index++;		
		}
	}
	/**
	 * Method checks whether start of a tag is following the current position in the document body
	 * @return true if tag follows, false otherwise
	 */
	private boolean isStartOfTag() {
		if(documentText.charAt(index) == '{' && documentText.charAt(index + 1) == '$') {
			return true;
		}
		return false;
	}
	/**
	 * Method checks whether tag END is following
	 * @return true if END tag follows, false otherwise
	 */
	private boolean isEndTag() {
		if (index + 2 >= textLength 
				|| documentText.charAt(index + 1) != 'N' 
				|| documentText.charAt(index + 2) != 'D') {
			return false;
		}
		return true;
	}
	/**
	 * Method checks whether following tag is a FOR tag
	 * @return true if FOR tag is following, false otherwise
	 */
	private boolean isForTag() {
		if (index + 2 >= textLength 
				|| documentText.charAt(index + 1) != 'O' 
				|| documentText.charAt(index + 2) != 'R') {
			return false;
		}
		return true;
	}
	/**
	 * Method checks whether end of a tag is following the current position in the document body
	 * @return true if tag ends, false otherwise
	 */
	private boolean isTagEnd() {
		if (documentText.charAt(index) == '$' && documentText.charAt(index + 1) == '}') {
			return true;
		}
		return false;

	}
	/**
	 * Method for reading a variable
	 * @return according token representation of variable
	 */
	private TokenVariable readVariable() {
		if (!Character.isLetter(documentText.charAt(index))) {
			throw new SmartScriptParserException(); 
		}
		
		int beginIndex = index;
		
		while (index < textLength - 1 
				&& (Character.isLetter(documentText.charAt(index)) 
				|| Character.isDigit(documentText.charAt(index)) 
				|| documentText.charAt(index) == '_') ) {
			
			index++;
		}
		
		return new TokenVariable(documentText.substring(beginIndex, index));
	}
	/**
	 * Method for reading expression
	 * @return token representation of the read expression
	 */
	private Token readExpression() {
		if (Character.isLetter(documentText.charAt(index))) {
			return readVariable();	
		} else if (Character.isDigit(documentText.charAt(index)) || documentText.charAt(index) == '-') {
				int beginIndex = index;
				index++;
			
				while (index < textLength && Character.isDigit(documentText.charAt(index))) {
					index++;
				}
			
				if (documentText.charAt(index) != '.') {
					return new TokenConstantInteger(documentText.substring(beginIndex, index));
				} else {
					index++;
				
					while (index < textLength && Character.isDigit(documentText.charAt(index))) {
						index++;
					}
				
					return new TokenConstantDouble(documentText.substring(beginIndex, index));
				}
		} else if (documentText.charAt(index) == '.' && Character.isDigit(documentText.charAt(index + 1))) {
				int beginIndex = index;
				index++;
				while (index < textLength && Character.isDigit(documentText.charAt(index))) {
					index++;
				}
				return new TokenConstantDouble(documentText.substring(beginIndex, index));	
		} else if (documentText.charAt(index) == '$') {
				return null;
		} else if (documentText.charAt(index) == '@') {
				return readFunction();
		} else {
				throw new SmartScriptParserException();
		}
	}
	/**
	 * Method for reading functions
	 * @return token representation of read function
	 */
	private TokenFunction readFunction() {
		index++;
		
		if (!Character.isLetter(documentText.charAt(index))) {
			throw new SmartScriptParserException(); 
		}
		
		int beginIndex = index;
		
		while (index < textLength - 1 
				&& (Character.isLetter(documentText.charAt(index))
				|| Character.isDigit(documentText.charAt(index)) 
				|| documentText.charAt(index)== '_') ) {
			index++;
		}
		
		return new TokenFunction(documentText.substring(beginIndex, index));
	}
	/**
	 * Method for deciding how to continue parsing
	 */
	private void parseNext() {
		index += 2;
		if (index < textLength - 1 && isStartOfTag()) {
			index += 2;
			
			if (index >= textLength - 1) {
				throw new SmartScriptParserException();
			}
			
			parseTag();
		} 
		parseText();
	}
	/**
	 * Method for tokenizing the empty tag
	 */
	private void tokenizeEmptyTag() {
		ArrayBackedIndexedCollection tokens = new ArrayBackedIndexedCollection();
		TokenVariable variable;
		TokenFunction function;
		TokenString string;
		TokenOperator operator;
		Token expression;
		
		while(index < textLength && !isTagEnd()) {
			skipWhitespaces();
			
			if(Character.isLetter(documentText.charAt(index))) {
				variable = readVariable();
				tokens.add(variable);
				if(isTagEnd()) {
					break;
				}
			} else if (documentText.charAt(index) == '\"') {
				string = readString();
				tokens.add(string);
			} else if (documentText.charAt(index) == '@') {
				function = readFunction();
				tokens.add(function);
			} else if (Character.isDigit(documentText.charAt(index))) {
				expression = readExpression();
				tokens.add(expression);
			} else if (isOperator()) {
				operator = new TokenOperator(Character.toString(documentText.charAt(index)));
				tokens.add(operator);
				index++;
			} else {
				throw new SmartScriptParserException();
			}
			
			skipWhitespaces();
		}	
		
		EchoNode echoNode = new EchoNode(collectionToArray(tokens));
		
		Node topOfStack = (Node) nodeStack.pop();
		topOfStack.addChildNode(echoNode);
		nodeStack.push(topOfStack);
		
		if (!(index < textLength && isTagEnd())) {
			throw new SmartScriptParserException();
		}

		parseNext();
	}
	/**
	 * Method for reading strings
	 * @return token representation of a read string
	 */
	private TokenString readString() {
		StringBuffer value = new StringBuffer();
		int backslashCount = 0;
		index++;
		
		while(index < textLength && !(documentText.charAt(index) == '\"' && backslashCount % 2 == 0)) {
			if(documentText.charAt(index) == '\\') {
				backslashCount++;
				index++;
				
				if (index >= textLength) {
					throw new SmartScriptParserException();
				}
				
				switch (documentText.charAt(index)) {
				case 'n': 	value.append('\n');
		  		  			break;
				case 'r':	value.append('\r');
						  	break;
				case 't':	value.append('\t');
				  		  	break;
				default: 	backslashCount = 0;
							value.append(documentText.charAt(index));
				}
				
			} else {
				backslashCount = 0;
				value.append(documentText.charAt(index));
			}
			index++;
		}
		
		index++;
		
		return new TokenString(value.toString());
	}
	/**
	 * Method for checking whether the current character is an operator
	 * @return true if one of 4 allowed operators, false otherwise
	 */
	private boolean isOperator() {
		switch(documentText.charAt(index)) {
		case '+':	return true;
		case '-':	return true;
		case '*':	return true;
		case '\\':	return true;
		default: return false;
		}
	}
	/**
	 * Method for converting a collection to an array
	 * @param tokens collection of tokens to be converted
	 * @return array of tokens converted from token collection
	 */
	private Token[] collectionToArray(ArrayBackedIndexedCollection tokens) {
		int length = tokens.size();
		Token[] tokenArray = new Token[length];
		
		for (int i = 0; i < length; i++) {
			tokenArray[i] = (Token) tokens.get(i);
		} 
		
		return tokenArray;
	}
	
	/**
	 * Getter for document node
	 * @return document node
	 */
	public DocumentNode getDocumentNode() {
		return document;
	}
	
}
