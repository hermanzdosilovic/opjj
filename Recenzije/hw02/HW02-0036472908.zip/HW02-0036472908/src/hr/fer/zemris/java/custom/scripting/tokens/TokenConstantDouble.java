package hr.fer.zemris.java.custom.scripting.tokens;
/**
 * 
 * @author Filip Culinovic
 *
 */
public class TokenConstantDouble extends Token {

	
	private double value;
	/**
	 * Constructor for double argument
	 * @param value double attributed to this.value
	 */
	public TokenConstantDouble(double value) {
		this.value = value;
	}
	/**
	 * Constructor for string argument which parses it into double
	 * @param value string-represented double attributed to this.value
	 */
	public TokenConstantDouble(String value) {
		super();
		this.value = Double.parseDouble(value);
	}
	/**
	 * Method for string representation of the token
	 */
	public String asText() {
		return Double.toString(value);
	}
	/**
	 * Getter for this.value
	 * @return this.value
	 */
	public double getValue() {
		return value;
	}
}
