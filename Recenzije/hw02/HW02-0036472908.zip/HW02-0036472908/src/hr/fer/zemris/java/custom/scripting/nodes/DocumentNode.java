package hr.fer.zemris.java.custom.scripting.nodes;
/**
 * 
 * @author Filip Culinovic
 *
 */
public class DocumentNode extends Node {

	/**
	 * Constructor method for node representing the document
	 */
	public DocumentNode() {
		super();
	}
	
}
