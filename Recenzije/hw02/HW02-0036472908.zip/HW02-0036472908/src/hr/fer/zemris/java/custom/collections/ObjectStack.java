package hr.fer.zemris.java.custom.collections;

import java.util.EmptyStackException;

/**
 * 
 * @author Filip Culinovic
 *
 */

public class ObjectStack extends ArrayBackedIndexedCollection {
	
	private final ArrayBackedIndexedCollection stack;
	/**
	 * default constructor
	 */
	public ObjectStack() {
		stack = new ArrayBackedIndexedCollection();
	}
	/**
	 * Method checks if stack is empty
	 */
	public boolean isEmpty() {
		return stack.isEmpty();
	}
	/**
	 * Method returns size of stack
	 */
	public int size() {
		return stack.size();
	}
	
	/**
	 * Method adds the value to the stack
	 * @param value object which is not null
	 * @throws IllegalArgumentException thrown if value is null
	 */
	public void push(Object value) throws IllegalArgumentException {
		if(value == null) {
			throw new IllegalArgumentException("Object value must not be null!");
		}
		
		stack.add(value);
	}
	/**
	 * Method returns and removes the object from the top of the stack
	 * @return object from the top of the stack
	 * @throws hr.fer.zemris.java.custom.collections.EmptyStackException throws if trying to call the method on an empty stack
	 */
	public Object pop() throws hr.fer.zemris.java.custom.collections.EmptyStackException {
		if(stack.isEmpty()) {
			throw new EmptyStackException();
		}
		
		Object top = stack.get(stack.size() - 1);
		stack.remove(stack.size() - 1);
		return top;
	}
	
	/**
	 * Method for looking at the top of the stack without removing them
	 * @return object from the top of the stack
	 * @throws hr.fer.zemris.java.custom.collections.EmptyStackException throws if trying to call the method on an empty stack
	 */
	
	public Object peep() throws hr.fer.zemris.java.custom.collections.EmptyStackException {
		if(stack.isEmpty()) {
			throw new EmptyStackException();
		}
		
		return stack.get(stack.size() - 1);
	}
	
	/**
	 * Method clears the stack
	 */
	
	public void clear() {
		stack.clear();
	}
	
	
	
}
