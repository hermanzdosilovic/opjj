package hr.fer.zemris.java.custom.scripting.tokens;
/**
 * 
 * @author Filip Culinovic
 *
 */
public class TokenConstantInteger extends Token {

	private int value;
	/**
	 * Constructor method for integer argument
	 * @param value number attributed to this.value
	 */
	public TokenConstantInteger(int value) {
		this.value = value;
	}
	/**
	 * Constructor method for string argument parsed into this.value
	 * @param value string containing a number
	 */
	public TokenConstantInteger(String value) {
		super();
		this.value = Integer.parseInt(value);
	}
	/**
	 * Method for textual representation of this token
	 */
	public String asText() {
		return Integer.toString(value);
	}
	/**
	 * Getter method for this.value
	 * @return this.value
	 */
	public int getValue() {
		return value;
	}
	
	
}
