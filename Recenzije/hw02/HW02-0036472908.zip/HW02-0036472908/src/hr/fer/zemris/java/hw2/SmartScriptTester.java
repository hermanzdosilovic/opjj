package hr.fer.zemris.java.hw2;

import hr.fer.zemris.java.custom.scripting.nodes.DocumentNode;
import hr.fer.zemris.java.custom.scripting.nodes.EchoNode;
import hr.fer.zemris.java.custom.scripting.nodes.ForLoopNode;
import hr.fer.zemris.java.custom.scripting.nodes.Node;
import hr.fer.zemris.java.custom.scripting.nodes.TextNode;
import hr.fer.zemris.java.custom.scripting.parser.*;
import hr.fer.zemris.java.custom.scripting.tokens.Token;
import hr.fer.zemris.java.custom.scripting.tokens.TokenConstantDouble;
import hr.fer.zemris.java.custom.scripting.tokens.TokenConstantInteger;
import hr.fer.zemris.java.custom.scripting.tokens.TokenFunction;
import hr.fer.zemris.java.custom.scripting.tokens.TokenOperator;
import hr.fer.zemris.java.custom.scripting.tokens.TokenString;
import hr.fer.zemris.java.custom.scripting.tokens.TokenVariable;
import hr.fer.zemris.java.custom.scripting.nodes.*;
import hr.fer.zemris.java.custom.scripting.tokens.*;

public class SmartScriptTester {
	
	public static void main(String[] args) {
		String docBody = "mojTekst{$ FOR i 1 2 1 $}{$ END $}";
		SmartScriptParser parser = null;
		
		try {
			parser = new SmartScriptParser(docBody);
		} catch(SmartScriptParserException e) {
			System.out.println("Unable to parse document!");
			System.exit(-1);
		} catch(Exception e) {
			System.out.println("If this line ever executes, you have failed this class!");
			System.exit(-1);
		}
		
		DocumentNode document = parser.getDocumentNode();
		String originalDocumentBody = createOriginalDocumentBody(document);
		System.out.println(originalDocumentBody);
	}
	
	private static String createOriginalDocumentBody(Node document) {
		if (document == null) {
			return "";
		}
		
		String documentText = "";
		int numberOfChildren = document.numberOfChildren();
		
		for (int index = numberOfChildren - 1; index >= 0; --index) {
			Node child = document.getChild(index);
			documentText = createOriginalDocumentBody(child) + documentText;
			if (child instanceof TextNode) {
				documentText = ((TextNode) child).getText() + documentText;
			}
			else if (child instanceof EchoNode) {
				Token[] tokens = ((EchoNode) child).getTokens();
				for(int i = tokens.length - 1; i >= 0; --i) {
					if (tokens[i] instanceof TokenConstantDouble) {
						documentText = " " + ((TokenConstantDouble) tokens[i]).getValue() + documentText;
					} 
					else if (tokens[i] instanceof TokenConstantInteger) {
						documentText = " " + ((TokenConstantInteger) tokens[i]).getValue() + documentText;
					}
					else if (tokens[i] instanceof TokenFunction) {
						documentText = " @" + tokens[i].asText() + documentText;
					}
					else if (tokens[i] instanceof TokenOperator) {
						documentText = " " + tokens[i].asText() + documentText;
					}
					else if (tokens[i] instanceof TokenString) {
						documentText = " " + "\"" + tokens[i].asText() + "\"" + documentText;
					}
					else if (tokens[i] instanceof TokenVariable) {
						documentText = " " + ((TokenVariable) tokens[i]).asText() + documentText;
					}
					else {
						throw new SmartScriptParserException();
					}
				}
				
			}
			else if (child instanceof ForLoopNode) {
				if (((ForLoopNode) child).getStepExpression() != null) {
					Token stepExpression = ((ForLoopNode) child).getStepExpression();
					documentText = stepExpression.asText() + documentText;
					if (stepExpression instanceof TokenFunction) {
						documentText = " @" + documentText;
					} else {
						documentText = " " + documentText;
					}
				}
				Token endExpression = ((ForLoopNode) child).getEndExpression();
				Token startExpression = ((ForLoopNode) child).getStartExpression();
				Token variable = ((ForLoopNode) child).getVariable();
				documentText = endExpression.asText() + documentText;
				if (endExpression instanceof TokenFunction) {
					documentText = " @" + documentText;
				} else {
					documentText = " " + documentText;
				}
				documentText = startExpression.asText() + documentText;
				if (startExpression instanceof TokenFunction) {
					documentText = " @" + documentText;
				} else {
					documentText = " " + documentText;
				}
				documentText = " " + variable.asText() + documentText;
				documentText = "FOR" + documentText;				
			}
			else {
				throw new SmartScriptParserException();
			}
		}
		if (document instanceof ForLoopNode) {
			documentText += "END";
		}
		return documentText;
	}
}
