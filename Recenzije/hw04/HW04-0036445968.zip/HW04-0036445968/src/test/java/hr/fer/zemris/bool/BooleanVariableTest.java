package hr.fer.zemris.bool;

import static org.junit.Assert.*;

import org.junit.Test;

public class BooleanVariableTest {

	@Test
	public void variableInicialization() {
		BooleanVariable varA = new BooleanVariable("A");
		
		assertTrue(varA.getValue() == BooleanValue.FALSE);
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void variableEmptyStringInicialization() {
		BooleanVariable varA = new BooleanVariable("");
		varA.getName();
	}
	
	@Test
	public void variableSetValue() {
		BooleanVariable varA = new BooleanVariable("A");
		varA.setValue(BooleanValue.TRUE);
		assertTrue(varA.getValue() == BooleanValue.TRUE);
	}
	
	@Test
	public void equalsTestNull() {
		BooleanVariable varA = new BooleanVariable("A");
		assertFalse(varA.equals(null));
	}
	
	@Test
	public void equalsTestNotVariable() {
		BooleanVariable varA = new BooleanVariable("A");
		assertFalse(varA.equals("Nevarijabla"));
	}

}
