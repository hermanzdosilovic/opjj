package hr.fer.zemris.bool;

import static org.junit.Assert.*;

import org.junit.Test;

public class BooleanConstantTest {

	@Test
	public void BooleanConstantUnmodifiable() {
		
		BooleanConstant constant = BooleanConstant.TRUE;
		BooleanValue value = constant.getValue();
		value = BooleanValue.DONT_CARE;
		
		assertFalse(value == constant.getValue());
	}

}
