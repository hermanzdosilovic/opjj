package hr.fer.zemris.bool.fimpl;


import org.junit.Test;

public class FunctionHelperTest {

	@Test(expected=IllegalArgumentException.class)
	public void validateNullList() {
		FunctionHelper.validateList(null, 0, true);
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void validateEmptyName() {
		FunctionHelper.validateFunctionName("", true);
	}
	
	@Test(expected=IndexOutOfBoundsException.class)
	public void validateIndexOutOfBounds() {
		FunctionHelper.indexInsideBounds(10, 1, true);
	}

}
