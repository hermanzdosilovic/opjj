package hr.fer.zemris.bool;

import static org.junit.Assert.*;

import org.junit.Test;

public class MaskTest {

	@Test
	public void maskEquals() {
		Mask mask = Mask.parse("0111");
		Mask mask2 = Mask.fromIndex(4, 7);
		
		assertTrue(mask.equals(mask2));
	}

	@Test
	public void isMoreGeneralThenEqualMasks() {
		Mask mask = Mask.parse("0111");
		Mask mask2 = Mask.fromIndex(4, 7);
		
		assertFalse(mask.isMoreGeneralThan(mask2));
	}
	
	@Test
	public void isMoreGeneralThenTrue() {
		Mask mask = Mask.parse("x11x");
		Mask mask2 = Mask.fromIndex(4, 7);
		
		assertTrue(mask.isMoreGeneralThan(mask2));
	}
	
	@Test
	public void isMoreGeneralThenFalse() {
		Mask mask = Mask.parse("x111");
		Mask mask2 = Mask.parse("x11x");
		
		assertFalse(mask.isMoreGeneralThan(mask2));
	}
	
	@Test
	public void combineMasks() {
		Mask mask1 = Mask.parse("0111");
		Mask mask2 = Mask.parse("1111");
		
		Mask newMask = Mask.combine(mask1, mask2);
		Mask expected = Mask.parse("x111");

		assertTrue(newMask.equals(expected));
	}
	
	@Test
	public void combineMasksWithDontCare() {
		Mask mask1 = Mask.parse("0x01");
		Mask mask2 = Mask.parse("0x00");
		
		Mask newMask = Mask.combine(mask1, mask2);
		Mask expected = Mask.parse("0x0x");

		assertTrue(newMask.equals(expected));
	}
	
	@Test
	public void combineMasksFalse() {
		Mask mask1 = Mask.parse("0x01");
		Mask mask2 = Mask.parse("0x0X");
		
		Mask newMask = Mask.combine(mask1, mask2);

		assertTrue(newMask==null);
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void combineMasksDifferentSize() {
		Mask mask1 = Mask.parse("0x01");
		Mask mask2 = Mask.parse("0x0X1");
		
		Mask.combine(mask1, mask2);
	}
	
	@Test
	public void parseMask() {
		Mask mask = Mask.parse("0110");
		
		assertEquals(MaskValue.ZERO, mask.getValue(0));
		assertEquals(MaskValue.ONE, mask.getValue(1));
		assertEquals(MaskValue.ONE, mask.getValue(2));
		assertEquals(MaskValue.ZERO, mask.getValue(3));
	}
	
	@Test
	public void maskFromIndex() {
		Mask mask = Mask.fromIndex(4, 6);
		
		assertEquals(MaskValue.ZERO, mask.getValue(0));
		assertEquals(MaskValue.ONE, mask.getValue(1));
		assertEquals(MaskValue.ONE, mask.getValue(2));
		assertEquals(MaskValue.ZERO, mask.getValue(3));
	}
	
	@Test
	public void maskEqualsNull() {
		Mask mask = Mask.fromIndex(4, 6);
		assertFalse(mask.equals(null));
	}
	
	@Test
	public void maskEqualsThis() {
		Mask mask = Mask.fromIndex(4, 6);
		assertTrue(mask.equals(mask));
	}
	
	@Test
	public void maskEqualsNotMask() {
		Mask mask = Mask.fromIndex(4, 6);
		assertFalse(mask.equals("Nemaska"));
	}
	
	@Test
	public void maskEqualsDifferentSize() {
		Mask mask = Mask.fromIndex(4, 6);
		Mask mask2 = Mask.fromIndex(5, 6);
		assertFalse(mask.equals(mask2));
	}
	
	
	@Test
	public void maskHashCode() {
		Mask mask = Mask.parse("0111");
		Mask mask2 = Mask.fromIndex(4, 7);
		
		assertEquals(mask.hashCode(), mask2.hashCode());
	}
	
	@Test
	public void maskNumberOfZeros() {
		Mask mask = Mask.parse("0111");
		
		assertEquals(mask.getNumberOfZeros(), 1);
	}
	
	@Test
	public void maskNumberOfOnes() {
		Mask mask = Mask.parse("0111");
		
		assertEquals(mask.getNumberOfOnes(), 3);
	}
	

	@Test(expected=IllegalArgumentException.class)
	public void masksNegativeSize() {
		Masks.fromIndexes(-1, 0);
	}

	@Test(expected=IllegalArgumentException.class)
	public void masksToLarge() {
		Masks.fromIndexes(1, 7);
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void masksParseEmptyString() {
		Masks.fromStrings("");
	}
	
}
