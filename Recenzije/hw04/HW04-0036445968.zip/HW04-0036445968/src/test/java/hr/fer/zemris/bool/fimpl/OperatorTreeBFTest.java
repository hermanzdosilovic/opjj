package hr.fer.zemris.bool.fimpl;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import hr.fer.zemris.bool.BooleanConstant;
import hr.fer.zemris.bool.BooleanFunction;
import hr.fer.zemris.bool.BooleanOperator;
import hr.fer.zemris.bool.BooleanValue;
import hr.fer.zemris.bool.BooleanVariable;
import hr.fer.zemris.bool.opimpl.BooleanOperators;

import org.junit.Test;

public class OperatorTreeBFTest {

	@Test
	public void operatorTreeTrue() {
		
		BooleanVariable varA = new BooleanVariable("A");
		BooleanVariable varB = new BooleanVariable("B");
		BooleanVariable varC = new BooleanVariable("C");
		
		varA.setValue(BooleanValue.TRUE);
		
		BooleanOperator izraz1 = BooleanOperators.or(
		BooleanConstant.FALSE,
		varC,
		BooleanOperators.and(varA, BooleanOperators.not(varB))
		);
		
		BooleanFunction f1 = new OperatorTreeBF(
		"f1",
		Arrays.asList(varA, varB, varC),
		izraz1);
		
		assertEquals(f1.getValue(), BooleanValue.TRUE);;
	}
	
	@Test
	public void operatorTreeFalse() {
		
		BooleanVariable varA = new BooleanVariable("A");
		BooleanVariable varB = new BooleanVariable("B");
		BooleanVariable varC = new BooleanVariable("C");
		
		BooleanOperator izraz1 = BooleanOperators.or(
		BooleanConstant.FALSE,
		varC,
		BooleanOperators.and(varA, BooleanOperators.not(varB))
		);
		
		BooleanFunction f1 = new OperatorTreeBF(
		"f1",
		Arrays.asList(varA, varB, varC),
		izraz1);
		
		assertEquals(f1.getValue(), BooleanValue.FALSE);;
	}
	
	@Test
	public void operatorTreeDontCare() {
		
		BooleanVariable varA = new BooleanVariable("A");
		BooleanVariable varB = new BooleanVariable("B");
		BooleanVariable varC = new BooleanVariable("C");
		
		varA.setValue(BooleanValue.DONT_CARE);
		
		BooleanOperator izraz1 = BooleanOperators.or(
		BooleanConstant.FALSE,
		varC,
		BooleanOperators.and(varA, BooleanOperators.not(varB))
		);
		
		BooleanFunction f1 = new OperatorTreeBF(
		"f1",
		Arrays.asList(varA, varB, varC),
		izraz1);
		
		assertEquals(f1.getValue(), BooleanValue.DONT_CARE);
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void notSupportedVaiables() {
		
		BooleanVariable varA = new BooleanVariable("A");
		BooleanVariable varB = new BooleanVariable("B");
		BooleanVariable varC = new BooleanVariable("C");
		BooleanVariable varD = new BooleanVariable("D");
		
		varA.setValue(BooleanValue.TRUE);
		
		BooleanOperator izraz1 = BooleanOperators.or(
		BooleanConstant.FALSE,
		varC,
		BooleanOperators.and(varA, BooleanOperators.not(varB)),
		varD
		);
		
		BooleanFunction f1 = new OperatorTreeBF(
		"f1",
		Arrays.asList(varA, varB, varC),
		izraz1);
		
		f1.getValue();
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void nullDomainTest() {
		
		BooleanVariable varA = new BooleanVariable("A");
		BooleanVariable varB = new BooleanVariable("B");
		BooleanVariable varC = new BooleanVariable("C");
		
		varA.setValue(BooleanValue.TRUE);
		
		BooleanOperator izraz1 = BooleanOperators.or(
		BooleanConstant.FALSE,
		varC,
		BooleanOperators.and(varA, BooleanOperators.not(varB))
		);
		
		BooleanFunction f1 = new OperatorTreeBF(
		"f1",
		null,
		izraz1);
		
		f1.getValue();
	}
	
	@Test
	public void hasMintermTest() {

		BooleanVariable varA = new BooleanVariable("A");
		BooleanVariable varB = new BooleanVariable("B");
		BooleanVariable varC = new BooleanVariable("C");
		
		BooleanOperator izraz1 = BooleanOperators.or(
		BooleanConstant.FALSE,
		varC,
		BooleanOperators.and(varA, BooleanOperators.not(varB))
		);
		
		BooleanFunction f1 = new OperatorTreeBF(
		"f1",
		Arrays.asList(varA, varB, varC),
		izraz1);
		
		assertEquals(f1.hasMinterm(4), true);
	}
	
	@Test
	public void iteratorsTest() {
		
		BooleanVariable varA = new BooleanVariable("A");
		BooleanVariable varB = new BooleanVariable("B");
		BooleanVariable varC = new BooleanVariable("C");
		
		BooleanOperator izraz1 = BooleanOperators.or(
		BooleanConstant.FALSE,
		varC,
		BooleanOperators.and(varA, BooleanOperators.not(varB))
		);
		
		BooleanFunction f1 = new OperatorTreeBF(
		"f1",
		Arrays.asList(varA, varB, varC),
		izraz1);
		
		List<Integer> mintermi = new ArrayList<Integer>();
		List<Integer> maxtermi = new ArrayList<Integer>();
		List<Integer> dontcareovi = new ArrayList<Integer>();
		
		for(Integer i : f1.mintermIterable()) {  // Ispis: 1, 3, 4, 5, 7
			mintermi.add(i);
		}
		for(Integer i : f1.maxtermIterable()) { // Ispis: 0, 2, 6
			maxtermi.add(i);
		}
		for(Integer i : f1.dontcareIterable()) { 
			dontcareovi.add(i);
		}
		
		assertEquals(mintermi.get(0), Integer.valueOf(1));
		assertEquals(mintermi.get(1), Integer.valueOf(3));
		assertEquals(mintermi.get(2), Integer.valueOf(4));
		assertEquals(mintermi.get(3), Integer.valueOf(5));
		assertEquals(mintermi.get(4), Integer.valueOf(7));
		
		assertEquals(maxtermi.get(0), Integer.valueOf(0));
		assertEquals(maxtermi.get(1), Integer.valueOf(2));
		assertEquals(maxtermi.get(2), Integer.valueOf(6));
		
	}
}
