package hr.fer.zemris.bool;

import static org.junit.Assert.*;

import java.util.List;

import hr.fer.zemris.bool.opimpl.BooleanOperators;

import org.junit.Test;

public class BooleanOperatorTest {

	@Test
	public void orOperatorTrue() {

		BooleanVariable varA = new BooleanVariable("A");
		BooleanVariable varB = new BooleanVariable("B");
	
		varA.setValue(BooleanValue.TRUE);
		varB.setValue(BooleanValue.DONT_CARE);
		
		BooleanOperator orOperator = BooleanOperators.or(
				BooleanConstant.FALSE,
				varA,
				varB);
		
		assertEquals(orOperator.getValue(), BooleanValue.TRUE);
		
	}
	
	@Test
	public void orOperatorDontCare() {

		BooleanVariable varA = new BooleanVariable("A");
		BooleanVariable varB = new BooleanVariable("B");
	
		varB.setValue(BooleanValue.DONT_CARE);
		
		BooleanOperator orOperator = BooleanOperators.or(
				BooleanConstant.FALSE,
				varA,
				varB);
		
		assertEquals(orOperator.getValue(), BooleanValue.DONT_CARE);
		
	}
	
	@Test
	public void orOperatorFalse() {

		BooleanVariable varA = new BooleanVariable("A");
		BooleanVariable varB = new BooleanVariable("B");
	
		BooleanOperator orOperator = BooleanOperators.or(
				BooleanConstant.FALSE,
				varA,
				varB);
		
		assertEquals(orOperator.getValue(), BooleanValue.FALSE);
		
	}
	
	@Test
	public void andOperatorTrue() {

		BooleanVariable varA = new BooleanVariable("A");
		BooleanVariable varB = new BooleanVariable("B");
	
		varA.setValue(BooleanValue.TRUE);
		varB.setValue(BooleanValue.TRUE);
		
		BooleanOperator orOperator = BooleanOperators.and(
				BooleanConstant.TRUE,
				varA,
				varB);
		
		assertEquals(orOperator.getValue(), BooleanValue.TRUE);
		
	}
	
	@Test
	public void andOperatorDontCare() {

		BooleanVariable varA = new BooleanVariable("A");
		BooleanVariable varB = new BooleanVariable("B");
	
		varA.setValue(BooleanValue.TRUE);
		varB.setValue(BooleanValue.DONT_CARE);
		
		BooleanOperator orOperator = BooleanOperators.and(
				BooleanConstant.TRUE,
				varA,
				varB);
		
		assertEquals(orOperator.getValue(), BooleanValue.DONT_CARE);
		
	}
	
	@Test
	public void andOperatorFalse() {

		BooleanVariable varA = new BooleanVariable("A");
		BooleanVariable varB = new BooleanVariable("B");
	
		varA.setValue(BooleanValue.FALSE);
		varB.setValue(BooleanValue.DONT_CARE);
		
		BooleanOperator orOperator = BooleanOperators.and(
				BooleanConstant.TRUE,
				varA,
				varB);
		
		assertEquals(orOperator.getValue(), BooleanValue.FALSE);
		
	}

	@Test
	public void operatorDomain() {
		
		BooleanVariable varA = new BooleanVariable("A");
		BooleanVariable varB = new BooleanVariable("B");
		BooleanVariable varC = new BooleanVariable("C");
		BooleanVariable varC2 = new BooleanVariable("C");
		
		BooleanOperator orOperator = BooleanOperators.and(
				varA,
				varB,
				varC,
				varC2);
		
		List<BooleanVariable> domain = orOperator.getDomain();
		assertEquals(domain.size(), 3);
		assertEquals(domain.get(0).getName(), "A");
		assertEquals(domain.get(1).getName(), "B");
		assertEquals(domain.get(2).getName(), "C");
	}
}
