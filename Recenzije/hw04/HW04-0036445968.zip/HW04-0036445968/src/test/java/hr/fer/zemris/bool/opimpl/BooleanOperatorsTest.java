package hr.fer.zemris.bool.opimpl;

import static org.junit.Assert.*;
import hr.fer.zemris.bool.BooleanConstant;
import hr.fer.zemris.bool.BooleanOperator;
import hr.fer.zemris.bool.BooleanValue;
import hr.fer.zemris.bool.BooleanVariable;

import org.junit.Test;

public class BooleanOperatorsTest {

	@Test(expected=IllegalArgumentException.class)
	public void booleanOperatorANDnull() {

		BooleanOperator and = BooleanOperators.and(null, BooleanConstant.FALSE);
		and.getValue();
	}
	
	@Test
	public void booleanOperatorANDDontCareFalse() {

		BooleanVariable varA = new BooleanVariable("A");
		varA.setValue(BooleanValue.DONT_CARE);
		
		BooleanOperator and = BooleanOperators.and(varA, BooleanConstant.FALSE);
		assertEquals(and.getValue(), BooleanValue.FALSE) ;
	}
	
	@Test
	public void booleanOperatorANDDontCareTrue() {

		BooleanVariable varA = new BooleanVariable("A");
		varA.setValue(BooleanValue.DONT_CARE);
		
		BooleanOperator and = BooleanOperators.and(varA, BooleanConstant.TRUE);
		assertEquals(and.getValue(), BooleanValue.DONT_CARE) ;
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void booleanOperatorNOTnull() {

		BooleanOperator and = BooleanOperators.not(null);
		and.getValue();
	}
	
	@Test
	public void booleanOperatorNOTDontCare() {

		BooleanVariable varA = new BooleanVariable("A");
		varA.setValue(BooleanValue.DONT_CARE);
		
		BooleanOperator and = BooleanOperators.not(varA);
		assertEquals(and.getValue(), BooleanValue.DONT_CARE) ;
	}

	@Test(expected=IllegalArgumentException.class)
	public void booleanOperatorORnull() {

		BooleanOperator or = BooleanOperators.or(null, BooleanConstant.TRUE);
		or.getValue();
	}
	
	@Test
	public void booleanOperatorORDontCareTrue() {

		BooleanVariable varA = new BooleanVariable("A");
		varA.setValue(BooleanValue.DONT_CARE);
		
		BooleanOperator or = BooleanOperators.or(varA, BooleanConstant.TRUE);
		assertEquals(or.getValue(), BooleanValue.TRUE) ;
	}
	
	@Test
	public void booleanOperatorORDontCareFalse() {

		BooleanVariable varA = new BooleanVariable("A");
		varA.setValue(BooleanValue.DONT_CARE);
		
		BooleanOperator or = BooleanOperators.or(varA, BooleanConstant.FALSE);
		assertEquals(or.getValue(), BooleanValue.DONT_CARE) ;
	}

}
