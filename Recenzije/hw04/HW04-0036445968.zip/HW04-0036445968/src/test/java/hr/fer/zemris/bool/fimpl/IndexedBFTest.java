package hr.fer.zemris.bool.fimpl;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import hr.fer.zemris.bool.BooleanFunction;
import hr.fer.zemris.bool.BooleanValue;
import hr.fer.zemris.bool.BooleanVariable;

import org.junit.Test;

public class IndexedBFTest {


	@Test
	public void functionMintermsOneVariable() {
		BooleanVariable varA = new BooleanVariable("A");
		
		BooleanFunction f1 = new IndexedBF(
		"f1",
		Arrays.asList(varA),
		true,
		Arrays.asList(0),
		Collections.<Integer> emptyList()
		);
		
		assertEquals(f1.getValue(), BooleanValue.TRUE);
	}
	
	@Test
	public void functionMintermsTrueWithDontCares() {
		BooleanVariable varA = new BooleanVariable("A");
		BooleanVariable varB = new BooleanVariable("B");
		BooleanVariable varC = new BooleanVariable("C");
		
		BooleanFunction f1 = new IndexedBF(
		"f1",
		Arrays.asList(varA, varB, varC),
		true,
		Arrays.asList(0,1,5,7),
		Arrays.asList(2,3)
		);
		
		assertEquals(f1.getValue(), BooleanValue.TRUE);
	}

	@Test
	public void functionMaxtermsOneVariable() {
		BooleanVariable varA = new BooleanVariable("A");
		
		BooleanFunction f1 = new IndexedBF(
		"f1",
		Arrays.asList(varA),
		false,
		Arrays.asList(1),
		Collections.<Integer> emptyList()
		);
		
		assertEquals(f1.getValue(), BooleanValue.TRUE);
	}
	
	@Test
	public void functionMaxtermsFalseWithoutDontCares() {
		BooleanVariable varA = new BooleanVariable("A");
		BooleanVariable varB = new BooleanVariable("B");
		BooleanVariable varC = new BooleanVariable("C");
		
		varB.setValue(BooleanValue.TRUE);
		
		BooleanFunction f1 = new IndexedBF(
		"f1",
		Arrays.asList(varA, varB, varC),
		false,
		Arrays.asList(0,1,2,3,4,5,6,7),
		Collections.<Integer> emptyList()
		);
		
		assertEquals(f1.getValue(), BooleanValue.FALSE);
	}
	
	@Test
	public void functionMaxtermsTrueWithDontCares() {
		BooleanVariable varA = new BooleanVariable("A");
		BooleanVariable varB = new BooleanVariable("B");
		BooleanVariable varC = new BooleanVariable("C");
		
		BooleanFunction f1 = new IndexedBF(
		"f1",
		Arrays.asList(varA, varB, varC),
		false,
		Arrays.asList(4,6),
		Arrays.asList(2,3)
		);
		
		assertEquals(f1.getValue(), BooleanValue.TRUE);
	}
	
	@Test
	public void iteratorsTest() {
		BooleanVariable varA = new BooleanVariable("A");
		BooleanVariable varB = new BooleanVariable("B");
		BooleanVariable varC = new BooleanVariable("C");
		BooleanFunction f1 = new IndexedBF(
		"f1",
		Arrays.asList(varA, varB, varC),
		true,
		Arrays.asList(0,1,5,7),
		Arrays.asList(2,3)
		);
		
		List<Integer> mintermi = new ArrayList<Integer>();
		List<Integer> maxtermi = new ArrayList<Integer>();
		List<Integer> dontcareovi = new ArrayList<Integer>();
		
		for(Integer i : f1.mintermIterable()) { // Ispis: 0, 1, 5, 7
			mintermi.add(i);
		}
		for(Integer i : f1.maxtermIterable()) { // Ispis: 4, 6
			maxtermi.add(i);
		}
		for(Integer i : f1.dontcareIterable()) { // 2, 3
			dontcareovi.add(i);
		}
		
		assertEquals(mintermi.get(0), Integer.valueOf(0));
		assertEquals(mintermi.get(1), Integer.valueOf(1));
		assertEquals(mintermi.get(2), Integer.valueOf(5));
		assertEquals(mintermi.get(3), Integer.valueOf(7));
		
		assertEquals(maxtermi.get(0), Integer.valueOf(4));
		assertEquals(maxtermi.get(1), Integer.valueOf(6));
		
		assertEquals(dontcareovi.get(0), Integer.valueOf(2));
		assertEquals(dontcareovi.get(1), Integer.valueOf(3));
	}

	@Test(expected=IllegalArgumentException.class)
	public void functionMaxtermsIndexesDontcaresSameElements() {
		BooleanVariable varA = new BooleanVariable("A");
		BooleanVariable varB = new BooleanVariable("B");
		BooleanVariable varC = new BooleanVariable("C");
		
		BooleanFunction f1 = new IndexedBF(
		"f1",
		Arrays.asList(varA, varB, varC),
		false,
		Arrays.asList(4,6),
		Arrays.asList(2,4)
		);
		
		assertEquals(f1.getValue(), BooleanValue.TRUE);
	}
	
	@Test
	public void functionMaxtermsGetDomain() {
		BooleanVariable varA = new BooleanVariable("A");
		BooleanVariable varB = new BooleanVariable("B");
		BooleanVariable varC = new BooleanVariable("C");
		
		BooleanFunction f1 = new IndexedBF(
		"f1",
		Arrays.asList(varA, varB, varC),
		false,
		Arrays.asList(4,6),
		Arrays.asList(2,3)
		);
		
		List<BooleanVariable> domain = f1.getDomain();
		assertEquals(domain.get(0), varA);
		assertEquals(domain.get(1), varB);
		assertEquals(domain.get(2), varC);
	}
	
	@Test
	public void functionHasMinterm() {
		BooleanVariable varA = new BooleanVariable("A");
		BooleanVariable varB = new BooleanVariable("B");
		BooleanVariable varC = new BooleanVariable("C");
		
		BooleanFunction f1 = new IndexedBF(
		"f1",
		Arrays.asList(varA, varB, varC),
		false,
		Arrays.asList(4,6),
		Arrays.asList(2,3)
		);
		
		assertTrue(f1.hasMinterm(0));
	}
	
	@Test
	public void functionHasMaxterm() {
		BooleanVariable varA = new BooleanVariable("A");
		BooleanVariable varB = new BooleanVariable("B");
		BooleanVariable varC = new BooleanVariable("C");
		
		BooleanFunction f1 = new IndexedBF(
		"f1",
		Arrays.asList(varA, varB, varC),
		false,
		Arrays.asList(4,6),
		Arrays.asList(2,3)
		);
		
		assertTrue(f1.hasMaxterm(4));
	}
	
	@Test
	public void functionHasDontCare() {
		BooleanVariable varA = new BooleanVariable("A");
		BooleanVariable varB = new BooleanVariable("B");
		BooleanVariable varC = new BooleanVariable("C");
		
		BooleanFunction f1 = new IndexedBF(
		"f1",
		Arrays.asList(varA, varB, varC),
		false,
		Arrays.asList(4,6),
		Arrays.asList(2,3)
		);
		
		assertTrue(f1.hasDontCare(2));
	}
}
