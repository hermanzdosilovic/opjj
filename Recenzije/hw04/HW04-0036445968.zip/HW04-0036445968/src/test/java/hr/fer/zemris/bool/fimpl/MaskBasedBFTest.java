package hr.fer.zemris.bool.fimpl;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import hr.fer.zemris.bool.BooleanFunction;
import hr.fer.zemris.bool.BooleanValue;
import hr.fer.zemris.bool.BooleanVariable;
import hr.fer.zemris.bool.Masks;

import org.junit.Test;

public class MaskBasedBFTest {

	@Test
	public void iteratorsTest() {
		BooleanVariable varA = new BooleanVariable("A");
		BooleanVariable varB = new BooleanVariable("B");
		BooleanVariable varC = new BooleanVariable("C");
		BooleanVariable varD = new BooleanVariable("D");
		
		BooleanFunction f1 = new MaskBasedBF(
		"f1",
		Arrays.asList(varA, varB, varC, varD),
		true,
		Masks.fromStrings("00x0", "1xx1"),
		Masks.fromStrings("10x0")
		);
		
		List<Integer> mintermi = new ArrayList<Integer>();
		List<Integer> maxtermi = new ArrayList<Integer>();
		List<Integer> dontcareovi = new ArrayList<Integer>();
		
		for(Integer i : f1.mintermIterable()) { 
			mintermi.add(i);
		}
		for(Integer i : f1.maxtermIterable()) { 
			maxtermi.add(i);
		}
		for(Integer i : f1.dontcareIterable()) {
			dontcareovi.add(i);
		}
		
		assertEquals(mintermi.get(0), Integer.valueOf(0));
		assertEquals(mintermi.get(1), Integer.valueOf(2));
		assertEquals(mintermi.get(2), Integer.valueOf(9));
		assertEquals(mintermi.get(3), Integer.valueOf(11));
		assertEquals(mintermi.get(4), Integer.valueOf(13));
		assertEquals(mintermi.get(5), Integer.valueOf(15));
		
		assertEquals(maxtermi.get(0), Integer.valueOf(1));
		assertEquals(maxtermi.get(1), Integer.valueOf(3));
		assertEquals(maxtermi.get(2), Integer.valueOf(4));
		assertEquals(maxtermi.get(3), Integer.valueOf(5));
		assertEquals(maxtermi.get(4), Integer.valueOf(6));
		assertEquals(maxtermi.get(5), Integer.valueOf(7));
		assertEquals(maxtermi.get(6), Integer.valueOf(12));
		assertEquals(maxtermi.get(7), Integer.valueOf(14));
		
		assertEquals(dontcareovi.get(0), Integer.valueOf(8));
		assertEquals(dontcareovi.get(1), Integer.valueOf(10));
		
	}

	
	@Test
	public void getValue() {
		BooleanVariable varA = new BooleanVariable("A");
		BooleanVariable varB = new BooleanVariable("B");
		BooleanVariable varC = new BooleanVariable("C");
		BooleanVariable varD = new BooleanVariable("D");
		
		BooleanFunction f1 = new MaskBasedBF(
		"f1",
		Arrays.asList(varA, varB, varC, varD),
		true,
		Masks.fromStrings("00x0", "1xx1"),
		Masks.fromStrings("10x0")
		);
		
		assertEquals(f1.getValue(), BooleanValue.TRUE);
	}
	
	@Test
	public void getDomain() {
		BooleanVariable varA = new BooleanVariable("A");
		BooleanVariable varB = new BooleanVariable("B");
		BooleanVariable varC = new BooleanVariable("C");
		BooleanVariable varD = new BooleanVariable("D");
		
		BooleanFunction f1 = new MaskBasedBF(
		"f1",
		Arrays.asList(varA, varB, varC, varD),
		true,
		Masks.fromStrings("00x0", "1xx1"),
		Masks.fromStrings("10x0")
		);
		
		List<BooleanVariable> domain = f1.getDomain();
		assertEquals(domain.get(0), varA);
		assertEquals(domain.get(1), varB);
		assertEquals(domain.get(2), varC);
		assertEquals(domain.get(3), varD);
	}
	
	@Test
	public void hasMinterm() {
		BooleanVariable varA = new BooleanVariable("A");
		BooleanVariable varB = new BooleanVariable("B");
		BooleanVariable varC = new BooleanVariable("C");
		BooleanVariable varD = new BooleanVariable("D");
		
		BooleanFunction f1 = new MaskBasedBF(
		"f1",
		Arrays.asList(varA, varB, varC, varD),
		true,
		Masks.fromStrings("00x0", "1xx1"),
		Masks.fromStrings("10x0")
		);
		
		assertTrue(f1.hasMinterm(0));
	}
	
	@Test
	public void hasMaxterm() {
		BooleanVariable varA = new BooleanVariable("A");
		BooleanVariable varB = new BooleanVariable("B");
		BooleanVariable varC = new BooleanVariable("C");
		BooleanVariable varD = new BooleanVariable("D");
		
		BooleanFunction f1 = new MaskBasedBF(
		"f1",
		Arrays.asList(varA, varB, varC, varD),
		true,
		Masks.fromStrings("00x0", "1xx1"),
		Masks.fromStrings("10x0")
		);
		
		assertTrue(f1.hasMaxterm(4));
	}

	@Test
	public void hasDontcare() {
		BooleanVariable varA = new BooleanVariable("A");
		BooleanVariable varB = new BooleanVariable("B");
		BooleanVariable varC = new BooleanVariable("C");
		BooleanVariable varD = new BooleanVariable("D");
		
		BooleanFunction f1 = new MaskBasedBF(
		"f1",
		Arrays.asList(varA, varB, varC, varD),
		true,
		Masks.fromStrings("0000", "1xx1"),
		Masks.fromStrings("10x0")
		);
		
		assertTrue(f1.hasDontCare(10));
	}

}
