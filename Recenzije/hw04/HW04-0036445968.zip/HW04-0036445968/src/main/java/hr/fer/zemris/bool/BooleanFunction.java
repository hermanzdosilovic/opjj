/**
 * Paket sadrži klase koje su potrebne za definiranje boolean konstanti, operatora i maski. 
 */
package hr.fer.zemris.bool;

/**
 * Sučelje <code>BooleanFunction</code> definira šest metoda:
 * hasMinterm(int index), hasMaxterm(int index), mintermIterable()
 * maxtermIterable(), dontcareIterable()
 * @author mbogovic
 * @version 1.0
 */
public interface BooleanFunction extends NamedBooleanSource {

	public boolean hasMinterm(int index);
	public boolean hasMaxterm(int index);
	public boolean hasDontCare(int index);
	public Iterable<Integer> mintermIterable();
	public Iterable<Integer> maxtermIterable();
	public Iterable<Integer> dontcareIterable();
	
}
