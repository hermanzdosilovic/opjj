/**
 * Paket sadrži klase koje su potrebne za definiranje boolean konstanti, operatora i maski. 
 */
package hr.fer.zemris.bool;

/**
 * Enumeracijski razred <code>MaskValue</code> koji definira tri vrijednosti:
 * ZERO, ONE, DONT_CARE
 * @author mbogovic
 * @version
 */
public enum MaskValue {
	ZERO, ONE, DONT_CARE
}
