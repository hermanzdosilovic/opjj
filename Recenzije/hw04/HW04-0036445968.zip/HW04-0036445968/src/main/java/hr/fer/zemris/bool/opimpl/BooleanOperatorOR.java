package hr.fer.zemris.bool.opimpl;

import java.util.List;

import hr.fer.zemris.bool.BooleanOperator;
import hr.fer.zemris.bool.BooleanSource;
import hr.fer.zemris.bool.BooleanValue;

public class BooleanOperatorOR extends BooleanOperator {

	public BooleanOperatorOR(List<BooleanSource> sources) {
		super(sources);
	}
	
	@Override
	public BooleanValue getValue() {
		
		BooleanValue result = BooleanValue.FALSE;
		
		for(BooleanSource source : this.getSources()) {
			if (source == null) {
				throw new IllegalArgumentException("Can not execute OR operation if source is null!");
			}
			result = this.logicalOR(result, source.getValue());
		}
	
		return result;
	}
	
	private BooleanValue logicalOR(	BooleanValue first, BooleanValue second) {

		BooleanValue result = BooleanValue.FALSE;
		
		switch(first) {
		
		case TRUE:
			result = BooleanValue.TRUE;
			break;
			
		case FALSE:
			result = second;
			break;
			
		case DONT_CARE:
			if (second.equals(BooleanValue.TRUE)) {
				result = BooleanValue.TRUE;
			} else {
				result = BooleanValue.DONT_CARE;
			}
			break;
		}
		
		return result;
	}

}
