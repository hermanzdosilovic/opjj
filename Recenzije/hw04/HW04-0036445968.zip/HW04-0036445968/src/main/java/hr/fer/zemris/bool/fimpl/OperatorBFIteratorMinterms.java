package hr.fer.zemris.bool.fimpl;


import hr.fer.zemris.bool.BooleanFunction;

public class OperatorBFIteratorMinterms extends OperatorBFIterator {

	@Override
	protected boolean hasValue(BooleanFunction function, int index) {
		return function.hasMinterm(index);
	}

}
