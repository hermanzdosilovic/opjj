package hr.fer.zemris.java.tecaj.hw4.db;


public class StudentRecord {

	private String jmbag;
	private String firstName;
	private String lastName;
	private int grade;
	
	public StudentRecord(String jmbag, String lastName, String firstName, int grade) {
		this.jmbag = jmbag;
		this.firstName = firstName;
		this.lastName = lastName;
		this.grade = grade;
	}

	public String getJmbag() {
		return this.jmbag;
	}

	public String getFirstName() {
		return this.firstName;
	}

	public String getLastName() {
		return this.lastName;
	}

	public int getGrade() {
		return this.grade;
	}
	
	@Override
	public boolean equals(Object object) {
		if (object == null) {
			return false;
		} else if  (object == this) {
			return true;
		} else if (!(object instanceof StudentRecord)) {
			return false;
		}
		
		StudentRecord student = (StudentRecord)object;
		return this.jmbag.equals(student.jmbag);
	}
	
	@Override
	public int hashCode() {
		return this.jmbag.hashCode();
	}
	
	@Override
	public String toString() {
		return String.format(
				"Student: jmbag=%s, first name=%s, last name=%s, grade=%d",
				this.jmbag, this.firstName, this.lastName, this.grade);
	}
	
}
