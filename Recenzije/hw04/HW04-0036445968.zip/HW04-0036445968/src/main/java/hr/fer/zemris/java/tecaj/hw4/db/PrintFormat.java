package hr.fer.zemris.java.tecaj.hw4.db;

import java.util.List;

public class PrintFormat {

	public static final int JMBAG_LENGTH = 10;
	public static final int GRADE_LENGTH = 1;
	private int lastNameLength;
	private int firstNameLength;
	
	public PrintFormat() {
		this.lastNameLength = 0;
		this.firstNameLength = 0;
	}
	
	public PrintFormat(int lastNameLength, int firstNameLength) {
		this.lastNameLength = lastNameLength;
		this.firstNameLength = firstNameLength;
	}
	
	public int getLastNameLength() {
		return lastNameLength;
	}
	public void setLastNameLength(int lastNameLength) {
		this.lastNameLength = lastNameLength;
	}
	public int getFirstNameLength() {
		return firstNameLength;
	}
	public void setFirstNameLength(int nameLength) {
		this.firstNameLength = nameLength;
	}
	
	public String createPrint(List<StudentRecord> students) {
		
		if(students.size() == 0) {
			return "Records selected: " + students.size();
		}
		
		String jmbags = new String(new char[JMBAG_LENGTH+2]).replace("\0", "=");
		String lastNames = new String(new char[this.lastNameLength+2]).replace("\0", "=");
		String firstNames = new String(new char[this.firstNameLength+2]).replace("\0", "=");
		String grades = new String(new char[GRADE_LENGTH+2]).replace("\0", "=");
		
		StringBuilder builder = new StringBuilder();
		builder.append("+" + jmbags + "+" + lastNames + "+" + firstNames + "+" + grades + "+\n");
		
		for(StudentRecord student : students) {
			
			int lastNameDifference = this.lastNameLength - student.getLastName().length();
			int firstNameDifference = this.firstNameLength - student.getFirstName().length();
			
			String lastNameSpaces = lastNameDifference > 0 ? String.format("%" + lastNameDifference + "s", "") : "";
			String firstNameSpaces = firstNameDifference > 0 ? String.format("%" + firstNameDifference + "s", "") : "";
			
			builder.append("| " + student.getJmbag() + " | "+ student.getLastName() + lastNameSpaces + " | "
					+ student.getFirstName() + firstNameSpaces + " | " + student.getGrade() + " |\n");
		}
		
		builder.append("+" + jmbags + "+" + lastNames + "+" + firstNames + "+" + grades + "+\n");
		builder.append("Records selected: " + students.size());
		
		return builder.toString(); 
	}
	
}
