/**
 * Paket sadrži klase koje su potrebne za definiranje boolean funkcija. 
 */
package hr.fer.zemris.bool.fimpl;

import java.util.List;

/**
 * Razred <code>FunctionHelper</code> je pomoćni razred za manipulaciju 
 * rada s Bool funkcijama. Najčešće se koristiti za validaciju ulaza
 * funkcije.
 * @author mbogovic
 * @version
 */
public final class FunctionHelper {

	private FunctionHelper() {}
	
	/**
	 * Metoda provjrava da li index unutr granica
	 * @param index index
	 * @param domainSize veličina domene
	 * @param throwException true ukoliko validacija nije prošla, metoda baca iznimku
	 * @return true ukoliko je validacija prošla
	 */
	public static boolean indexInsideBounds(int index, int domainSize, boolean throwException) {
		
		boolean insideBounds = (index>=0) && (index<=FunctionHelper.calculateIndexSpace(domainSize));
		
		if(!insideBounds && throwException ) {
			throw new IndexOutOfBoundsException("Input index is out of the bounds: " 
					+ "index=" + index );
		}
		
		return insideBounds ;
		
	}
	
	/**
	 * Metoda provjerava da li su svi indexi unutrar domene.
	 * @param values lista indexa
	 * @param domainSize velicina domene
	 * @param throwException true ukoliko validacija nije prošla, metoda baca iznimku
	 * @return  true ukoliko je validacija prošla
	 */
	public static boolean validateList(List<Integer> values, int domainSize, boolean throwException) {
		
		boolean validation = true;
		
		if(values==null) {
			validation = false;
			
		} else {
			
			for(Integer value : values) {
				if(!FunctionHelper.indexInsideBounds(value, domainSize, false)) {
					validation = false;
					break;
				}
			}
		}
		
		if(!validation && throwException) {
			throw new IllegalArgumentException("Values in list are not in allowed range!");
		}
		
		return validation;
	}

	/**
	 * Validira nziv funkcije
	 * @param name naziv funkcije
	 * @param throwException true ukoliko validacija nije prošla, metoda baca iznimku
	 * @return  true ukoliko je validacija prošla
	 */
	public static boolean validateFunctionName(String name, boolean throwException) {
		
		if(name.isEmpty() && throwException) {
			throw new IllegalArgumentException("Function name can not be empty string!");
		}
		
		return name.isEmpty();
	}
	
	/**
	 * Metoda izračunava veličini indeksnog prostora. 
	 * @param domainSize veličina domene
	 * @return veličina indeksnog prostora.
	 */
	public static int calculateIndexSpace(int domainSize) {
		 return (int)Math.pow(2, domainSize) - 1;
	}
}
