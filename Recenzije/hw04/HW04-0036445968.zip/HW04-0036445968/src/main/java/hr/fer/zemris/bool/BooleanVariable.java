/**
 * Paket sadrži klase koje su potrebne za definiranje boolean konstanti, operatora i maski. 
 */
package hr.fer.zemris.bool;

import java.util.ArrayList;
import java.util.List;

/**
 * Razred <code>BooleanVariable</code> omogućuje manipuliranje
 * bool varijablama. 
 * Implementira sučelje <code>NamedBooleanSource</code>.
 * @author mbogovic
 * @version
 */
public class BooleanVariable implements NamedBooleanSource {

	private String name;
	private BooleanValue value;
	
	/**
	 * Public konstruktor.
	 * @param name String naziv varijable.
	 */
	public BooleanVariable(String name) {
		if(name.isEmpty()) {
			throw new IllegalArgumentException("Variable name can not be empty string!");
		}
		this.name = name;
		this.value = BooleanValue.FALSE;
	}
	
	/**
	 * Metoda vraća vrijednost varijable.
	 * @return BooleanValue vrijednost varijable.
	 */
	@Override
	public BooleanValue getValue() {
		return this.value;
	}
	
	/**
	 * Metoda postavlja vrijednost varijable.
	 * @param newValue BooleanValue nova vrijednost varijable.
	 */
	public void setValue(BooleanValue newValue) {
		this.value = newValue;
	}

	/**
	 * Metoda vraća domenu varijable.
	 * @return List<BooleanVariable> lista sa samom varijablom kao jedinim elementom.
	 */
	@Override
	public List<BooleanVariable> getDomain() {
		List<BooleanVariable> vairables = new ArrayList<>();
		vairables.add(this);
		return vairables;
	}

	/**
	 * Metoda vraća nazov varijable
	 * @return String, naziv varijable.
	 */
	@Override
	public String getName() {
		return this.name;
	}

	/**
	 * Metoda provjerava da li su dvije varijable jednake (po nazivu).
	 * @param Object, objekt s kojim se ova varijabla uspoređuje.
	 * @return true, ukoliko varijabla ima isti naziv kao i primljena.
	 */
	@Override
	public boolean equals(Object object) {
		
		if (object == null) {
			return false;
		} else if  (object == this) {
			return true;
		} else if (!(object instanceof BooleanVariable)) {
			return false;
		}
		
		BooleanVariable variable = (BooleanVariable)object;
		return this.name.equals(variable.name);
	}
	
	/**
	 * Metoda izračunava hash code varijable na osnovu njenog imena.
	 * @return broj koji označava hash code ove varijable.
	 */
	@Override
	public int hashCode() {
		return this.name.hashCode();
	}
	 
}
