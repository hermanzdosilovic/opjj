package hr.fer.zemris.java.tecaj.hw4.db;

public class LastNameFilter implements IFilter {

	private String mask;
	
	public LastNameFilter(String mask) {
		
		if(mask.contains("*")){
			this.mask = mask.toUpperCase().replace("*", Regex.LETTERS + Regex.ZERO_OR_MORE
					+ Regex.SPACE + Regex.ZERO_OR_MORE + Regex.DASH + Regex.ZERO_OR_MORE +
					Regex.LETTERS + Regex.ZERO_OR_MORE);
		} else {
			this.mask = mask.toUpperCase();
		}
		
	}
	
	@Override
	public boolean accepts(StudentRecord record) {
		return record.getLastName().toUpperCase().matches(this.mask);
	}

}
