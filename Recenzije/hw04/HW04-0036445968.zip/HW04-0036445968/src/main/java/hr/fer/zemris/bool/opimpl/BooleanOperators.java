package hr.fer.zemris.bool.opimpl;

import java.util.Arrays;

import hr.fer.zemris.bool.BooleanOperator;
import hr.fer.zemris.bool.BooleanSource;

public final class BooleanOperators {

	private BooleanOperators() {}
	
	public static BooleanOperator and(BooleanSource ... sources) {
		return new BooleanOperatorAND(Arrays.asList(sources));
	}
	
	public static BooleanOperator or(BooleanSource ... sources) {
		return new BooleanOperatorOR(Arrays.asList(sources));
	}
	
	public static BooleanOperator not(BooleanSource source) {
		return new BooleanOperatorNOT(source);
	}
}
