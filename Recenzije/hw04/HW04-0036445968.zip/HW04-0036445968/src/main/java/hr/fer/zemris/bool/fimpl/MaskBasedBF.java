/**
 * Paket sadrži klase koje su potrebne za definiranje boolean funkcija. 
 */
package hr.fer.zemris.bool.fimpl;

import java.util.ArrayList;
import java.util.List;

import hr.fer.zemris.bool.BooleanFunction;
import hr.fer.zemris.bool.BooleanValue;
import hr.fer.zemris.bool.BooleanVariable;
import hr.fer.zemris.bool.Mask;

/**
 * Razred <code>MaskBasedBF</code> koji se koristi za manipulaciju 
 * rada s Bool funkcijama koristeći maske.
 * @author mbogovic
 * @version
 */
public class MaskBasedBF implements BooleanFunction {

	private IndexedBF indexedFunction;
	
	/**
	 * Public konstruktor
	 * @param name naziv funkcije
	 * @param domain domena funkcije
	 * @param masksAreMinterms true ukoliko su primljene maske mintermi, inaće false
	 * @param masks lista maski minterma/maxterma
	 * @param dontCareMasks lista maski dont careova
	 */
	public MaskBasedBF(String name, List<BooleanVariable> domain, boolean masksAreMinterms,
			List<Mask> masks, List<Mask> dontCareMasks) {
		
		//Extractaj mi liste maski i dontCareova u liste brojeva, te s istima kreiraj 
		//odgovarajuću instancu indexed funkcije
		this.indexedFunction = new IndexedBF(name, domain, masksAreMinterms,
				this.extractMasks(masks), this.extractMasks(dontCareMasks));
		
	}
	
	/**
	 * Metoda vraća naziv funkcije
	 * @return name naziv funkcije
	 */
	@Override
	public String getName() {
		return this.indexedFunction.getName();
	}

	/**
	 * Metoda računa i vraća vrijednost funkcije
	 * @return BooleanValue vrijednost funkcije.
	 */
	@Override
	public BooleanValue getValue() {
		return this.indexedFunction.getValue();
	}

	/**
	 * Metoda vraća domenu funkcije
	 * @return List<BooleanVariable> lista varijabli
	 */
	@Override
	public List<BooleanVariable> getDomain() {
		return this.indexedFunction.getDomain();
	}

	/**
	 * Metoda provjerava da li je na određenom indexu funkcija TRUE
	 * @param int index
	 * @return boolean ukoliko je na određenom indexu funkcija TRUE.
	 */
	@Override
	public boolean hasMinterm(int index) {
		return this.indexedFunction.hasMinterm(index);
	}

	/**
	 * Metoda provjerava da li je na određenom indexu funkcija FALSE
	 * @param int index
	 * @return boolean ukoliko je na određenom indexu funkcija FALSE.
	 */
	@Override
	public boolean hasMaxterm(int index) {
		return this.indexedFunction.hasMaxterm(index);
	}

	/**
	 * Metoda provjerava da li je na određenom indexu funkcija DON'T CARE
	 * @param int index
	 * @return boolean ukoliko je na određenom indexu funkcija DONT CARE.
	 */
	@Override
	public boolean hasDontCare(int index) {
		return this.indexedFunction.hasDontCare(index);
	}

	/**
	 * Metoda vraća iterator za iteriranje kroz sve minterme
	 * @return Iterable<Integer> iterator
	 */
	@Override
	public Iterable<Integer> mintermIterable() {
		return this.indexedFunction.mintermIterable();
	}

	/**
	 * Metoda vraća iterator za iteriranje kroz sve maxterme
	 * @return Iterable<Integer> iterator
	 */
	@Override
	public Iterable<Integer> maxtermIterable() {
		return this.indexedFunction.maxtermIterable();
	}

	/**
	 * Metoda vraća iterator za iteriranje kroz sve dontcareove
	 * @return Iterable<Integer> iterator
	 */
	@Override
	public Iterable<Integer> dontcareIterable() {
		return this.indexedFunction.dontcareIterable();
	}

	private List<Integer> extractMasks(List<Mask> masksList) {
		
		List<Integer> extractedList = new ArrayList<>();
		int size = masksList.get(0).getSize();
		
		for(Mask mask : masksList) {
			
			if(mask.getSize() != size) {
				throw new IllegalArgumentException("All masks have to have the same size!");
			}
			
			extractedList.addAll(processMask(mask));
		}
			
		return extractedList;
	}
	
	private List<Integer> processMask(Mask mask) {
		
		List<Integer> indexes = new ArrayList<>();
		String maskString = mask.toString();
		
		//Ako ne sadrži x, odmah parsiraj binarni broj u integer
		if(!maskString.contains("x")) {
			indexes.add(Integer.parseInt(maskString, 2));
			return indexes;
		}
		
		//Ako sadrzi x, treba odrediti sve mogucnosti i dodati ih u listu allCombinations
		List<String> allCombinations = new ArrayList<>();
		List<String> temp = new ArrayList<>();
		allCombinations.add(maskString);
		
		while(maskString.contains("x")) {
			
			maskString = maskString.replaceFirst("x", "-");
			
			for(int i=0; i<allCombinations.size(); i++) {
				temp.add(allCombinations.get(i).replaceFirst("x", "0"));
				temp.add(allCombinations.get(i).replaceFirst("x", "1"));
			}
			
			allCombinations.clear();
			allCombinations.addAll(temp);
			temp.clear();
			
		}
		
		//Svi x-evi su izbaceni, sad mi svaku kombinaciju parsiraj u integer
		for(String binaryNumber : allCombinations) {
			indexes.add(Integer.parseInt(binaryNumber, 2));
		}
		
		return indexes;
	}
}
