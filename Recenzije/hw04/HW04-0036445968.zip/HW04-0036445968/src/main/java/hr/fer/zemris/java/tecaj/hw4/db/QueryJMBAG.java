package hr.fer.zemris.java.tecaj.hw4.db;

import java.util.ArrayList;
import java.util.List;

public class QueryJMBAG extends Query {

	public QueryJMBAG(StudentDatabase db, String command) {
		super(db, command);
	}
	
	@Override
	public String proccess() {
		
		String jmbag = this.getCommand().split("\"")[1];
		StudentRecord student = this.getDb().forJMBAG(jmbag);
		
		if(student== null) {
			throw new IllegalArgumentException(
					"Student with jmbag("+ jmbag + ") doesn't exist");
		}
		
		List<StudentRecord> students = new ArrayList<>();
		students.add(student);
		
		PrintFormat print = new PrintFormat(student.getLastName().length(), 
				student.getFirstName().length());
		
		return print.createPrint(students);
	}

}
