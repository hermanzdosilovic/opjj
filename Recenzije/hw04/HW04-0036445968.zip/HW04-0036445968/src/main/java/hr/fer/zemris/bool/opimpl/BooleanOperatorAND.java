package hr.fer.zemris.bool.opimpl;

import java.util.List;

import hr.fer.zemris.bool.BooleanOperator;
import hr.fer.zemris.bool.BooleanSource;
import hr.fer.zemris.bool.BooleanValue;

public class BooleanOperatorAND extends BooleanOperator {

	public BooleanOperatorAND(List<BooleanSource> sources) {
		super(sources);
	}
	
	@Override
	public BooleanValue getValue() {
		
		BooleanValue result = BooleanValue.TRUE;
		
		for(BooleanSource source : this.getSources()) {
			if (source == null) {
				throw new IllegalArgumentException("Can not execute AND operation if source is null!");
			}
			result = this.logicalAND(result, source.getValue());
		}
	
		return result;
	}
	
	private BooleanValue logicalAND(BooleanValue first, BooleanValue second) {

		BooleanValue result = BooleanValue.TRUE;
		
		switch(first) {
		
		case TRUE:
			result = second;
			break;
			
		case FALSE:
			result = BooleanValue.FALSE;
			break;
			
		case DONT_CARE:
			if (second.equals(BooleanValue.FALSE)) {
				result = BooleanValue.FALSE;
			} else {
				result = BooleanValue.DONT_CARE;
			}
			break;
		}
		
		return result;
	}

}
