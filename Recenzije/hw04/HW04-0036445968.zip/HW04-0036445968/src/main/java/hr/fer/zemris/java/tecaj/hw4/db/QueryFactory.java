package hr.fer.zemris.java.tecaj.hw4.db;

public final class QueryFactory {

	private static final String JMBAG_PATTERN = 
			Regex.QUERY_JMBAG + Regex.QUOTE + Regex.DIGITS + 
			Regex.TIMES_10 + Regex.QUOTE; //query jmbag="0000000003"
	
	private static final String LAST_NAME_PATTERN_START = 
			Regex.QUERY_LAST_NAME + Regex.QUOTE + Regex.WILDCARD
			+ Regex.LETTERS + Regex.ONE_OR_MORE + Regex.SPACE
			+ Regex.ZERO_OR_MORE + Regex.DASH + Regex.ZERO_OR_MORE
			+ Regex.LETTERS + Regex.ZERO_OR_MORE
			+ Regex.QUOTE; //query lastName="*B" - regex mora obuhvatiti i dva prezimena
	
	private static final String LAST_NAME_PATTERN_MID = 
			Regex.QUERY_LAST_NAME + Regex.QUOTE + Regex.LETTERS + Regex.ONE_OR_MORE
			+ Regex.SPACE + Regex.ZERO_OR_MORE + Regex.DASH + Regex.ZERO_OR_MORE 
			+ Regex.LETTERS + Regex.ZERO_OR_MORE + Regex.WILDCARD + Regex.LETTERS
			+ Regex.ONE_OR_MORE + Regex.SPACE + Regex.ZERO_OR_MORE + Regex.DASH 
			+ Regex.ZERO_OR_MORE + Regex.LETTERS + Regex.ZERO_OR_MORE
			+ Regex.QUOTE; //query lastName="B*a"
	
	private static final String LAST_NAME_PATTERN_END = 
			Regex.QUERY_LAST_NAME + Regex.QUOTE + Regex.LETTERS + Regex.ONE_OR_MORE
			+ Regex.SPACE + Regex.ZERO_OR_MORE  + Regex.DASH + Regex.ZERO_OR_MORE
			+ Regex.LETTERS + Regex.ZERO_OR_MORE
			+ Regex.WILDCARD + Regex.ZERO_OR_ONE + Regex.QUOTE; //query lastName="B*" ili "B"
	
	private QueryFactory() {}
	
	public static Query createQuery(StudentDatabase db, String command) {
		
		String upperCaseCommand =command.toUpperCase();
		
		if(upperCaseCommand.matches(JMBAG_PATTERN)) {
			return new QueryJMBAG(db, upperCaseCommand);
			
		} else if(upperCaseCommand.matches(LAST_NAME_PATTERN_START) 
				|| upperCaseCommand.matches(LAST_NAME_PATTERN_MID)
				|| upperCaseCommand.matches(LAST_NAME_PATTERN_END)
				) {
			return new QueryLastName(db, upperCaseCommand);
			
		} else {
			throw new IllegalArgumentException("Command is not valid : " + command);
		}
		
	}
}
