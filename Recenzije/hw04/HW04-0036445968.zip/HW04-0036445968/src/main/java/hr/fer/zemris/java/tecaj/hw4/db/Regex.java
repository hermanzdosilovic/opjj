package hr.fer.zemris.java.tecaj.hw4.db;

public final class Regex {

	public static final String QUERY_JMBAG = "^[\\s]*QUERY[\\s]+JMBAG[\\s]*=[\\s]*"; 
	public static final String QUERY_LAST_NAME = "^[\\s]*QUERY[\\s]+LASTNAME[\\s]*=[\\s]*"; 
	public static final String LETTERS = "[A-ZČĆĐŠŽ]";
	public static final String DIGITS = "[0-9]";
	public static final String SPACE = "\\s";
	public static final String QUOTE = "\"";
	public static final String WILDCARD = "\\*";
	public static final String TIMES_10 = "{10}";
	public static final String ONE_OR_MORE = "+";
	public static final String ZERO_OR_MORE = "*";
	public static final String ZERO_OR_ONE = "?";
	public static final String DASH = "-";
	
	private Regex() {}
}
