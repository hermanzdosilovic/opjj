/**
 * Paket sadrži klase koje su potrebne za definiranje boolean konstanti, operatora i maski. 
 */
package hr.fer.zemris.bool;

import java.util.ArrayList;
import java.util.List;

/**
 * Razred <code>Masks</code> omogućuje kreiranje i manipuliranje
 * maskama.  
 * @author mbogovic
 * @version
 */
public final class Masks {

	private Masks() {}
	
	/**
	 * Metoda kreira jednu ili više maski iz zadanih vrijednosti brojeva. 
	 * @param size veličina maske
	 * @param values varijabilni broj argumenata (koliko vrijednosti toliko i novih maski)
	 * @return List<Mask> lista novih maski.
	 */
	public static List<Mask> fromIndexes(int size, int ... values) {
		
		List<Mask> newMasks = new ArrayList<>();
		
		for(int value : values) {
			newMasks.add(fromIndex(size, value));
		}
		
		return newMasks;
	}
	

	/**
	 * Metoda parsira Stringove i stvara novu maske
	 * @param values varijabilni broj Stringova koji se parsiraju. 
	 * @return List<Mask> lista novih maski.
	 */
	public static List<Mask> fromStrings(String ... values) {
		
		List<Mask> newMasks = new ArrayList<>();
		
		for(String value : values) {
			newMasks.add(parse(value));
		}
		
		return newMasks;
	}

	private static Mask fromIndex(int size, int value) {
		
		if(size<=0 || value<0) {
			throw new IllegalArgumentException("Can not create mask, illegal arguments: size="
					+ size + ", value=" + value);
		}
		
		String maskString = Integer.toBinaryString(value);
		
		if(size < maskString.length()) {
			throw new IllegalArgumentException("Can not create mask, too big value for defined size:"
					+ " size=" + size + ", value=" + value);
		}
		
		for(int i= maskString.length(); i<size; i++) {
			maskString = "0" + maskString;
		}
		
		return new Mask( parseStringToMaskArray(maskString) );
	}

	/**
	 * Metoda konvertira MaskValue u BooleanValue
	 * @param maskValue MaskValue
	 * @return BooleanValue
	 */
	public static BooleanValue convertMaskToBoolean(MaskValue maskValue) {
		
		switch(maskValue) {
		
		case ONE:
			return BooleanValue.TRUE;
		case ZERO:
			return BooleanValue.FALSE;
		default:
			return BooleanValue.DONT_CARE;
			
		}
		
	}
	private static Mask parse(String maskString) {
		
		if(maskString.isEmpty()) {
			throw new IllegalArgumentException("Parsing empty string is not possible!");
		}
		
		maskString = maskString.toLowerCase();
		return new Mask( parseStringToMaskArray(maskString) );
		
	}
	
	private static MaskValue[] parseStringToMaskArray(String maskString ) {
		
		MaskValue[] newMasks = new MaskValue[maskString.length()];
		
		for(int i = 0; i<maskString.length(); i++) {
			
			if(maskString.charAt(i)=='1') {
				newMasks[i] = MaskValue.ONE;
			} else if (maskString.charAt(i)=='0') {
				newMasks[i] = MaskValue.ZERO;
			} else if(maskString.charAt(i)=='x') {
				newMasks[i] = MaskValue.DONT_CARE;
			} else {
				throw new IllegalArgumentException("Can not parse input string: " + maskString);
			}
		}
		
		return newMasks;
	}
}
