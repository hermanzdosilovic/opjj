package hr.fer.zemris.java.tecaj.hw4.db;

public interface IFilter {
	public boolean accepts(StudentRecord record);
}
