/**
 * Paket sadrži klase koje su potrebne za definiranje boolean konstanti, operatora i maski. 
 */
package hr.fer.zemris.bool;

import java.util.List;

/**
 * Razred <code>Mask</code> omogućuje kreiranje i manipuliranje
 * maskama.  
 * @author mbogovic
 * @version
 */
public class Mask {

	private MaskValue[] masks;
	
	/**
	 * Public konstrukor.
	 * @param maskValues varijabilni broj argumenata (polje) koje  definiraju masku.
	 */
	public Mask(MaskValue ... maskValues ) {
		this.masks = new MaskValue[maskValues.length];
		System.arraycopy(maskValues, 0, this.masks, 0, maskValues.length);
	}
	
	/**
	 * Public getter za dohvat MaskValue na određenom indeksu. 
	 * @param index indeks MaskValue-a
	 * @return traženi MaskValue
	 * @throws IndexOutOfBoundsException ukoliko je indeks prevelik
	 */
	public MaskValue getValue(int index) {
		if(index >= this.masks.length) {
			throw new IndexOutOfBoundsException("Index in mask is out ouf bounds!");
		}
		return this.masks[index];
	}
	
	/**
	 * Metoda vraca broj nula u maski. 
	 * @return int broj nula. 
	 */
	public int getNumberOfZeros() {
		return getNumberOfValue(MaskValue.ZERO);
	}
	
	/**
	 * Metoda vraca broj jedinica u maski. 
	 * @return int broj jedinica. 
	 */
	public int getNumberOfOnes() {
		return getNumberOfValue(MaskValue.ONE);
	}
	
	/**
	 * Metoda vraca duljinu maske.
	 * @return int  duljina maske
	 */
	public int getSize() {
		return this.masks.length;
	}
	
	/**
	 * Metoda provjerava da li su dvije maske jednake.
	 * @param Object, objekt s kojim se ova maska uspoređuje.
	 * @return true, ukoliko su maske jednake.
	 */
	@Override
	public boolean equals(Object object) {
		if (object == null) {
			return false;
		} else if  (object == this) {
			return true;
		} else if (!(object instanceof Mask)) {
			return false;
		}
		
		Mask mask = (Mask)object;
		if(this.getSize() != mask.getSize()) {
			return false;
		}
		
		for(int i=0; i<this.getSize(); i++) {
			if(this.getValue(i) != mask.getValue(i)) {
				return false;
			}
		}
		
		return true;
	}
	
	/**
	 * Metoda izračunava hash code maske na osnovu polja MaskValue-a.
	 * @return broj koji označava hash code ove maske.
	 */
	@Override
	public int hashCode() {

		StringBuilder builder = new StringBuilder();
		for(int i=0; i<this.getSize(); i++) {
			builder.append(this.getValue(i).toString());
		}
		
		return builder.toString().hashCode();
	}
	
	/**
	 * Metoda odreduje String reprezentaciju ove maske.
	 * @return String string koji određuje ovu masku.
	 */
	@Override
	public String toString() {
		
		StringBuilder builder = new StringBuilder();
		
		for(MaskValue value : this.masks) {
			
			switch(value) {
			case ONE:
				builder.append("1");
				break;
			case ZERO:
				builder.append("0");
				break;
			default:
				builder.append("x");
				break;
			}
		}
		
		return builder.toString();
	}
	
	/**
	 * Metoda provjerava da li je općenitija od primljene maske.
	 * @param mask maska za oku treba provjeriti da li je trenutna oćenitija.
	 * @return true ukoliko je trenutna maska općenitija, inaće false.
	 */
	public boolean isMoreGeneralThan(Mask mask) {
		
		if(this.getSize()!=mask.getSize()) {
			return false;
		}
		
		int brojac = 0;
		for(int i=0; i<this.getSize(); i++) {
			
			if(this.getValue(i)==mask.getValue(i)) {
				continue;
			}
			
			if(this.getValue(i)==MaskValue.DONT_CARE) {
				brojac++;
			} else {
				return false;
			}
		}
		
		return brojac > 0;
		
	}
	
	/**
	 * Metoda kombinira 2 maske i stvara novu masku iz njih. 
	 * @param mask1 prva maska 
	 * @param mask2 druga maska
	 * @return nova maska
	 * @throws IllegalArgumentException ukoliko je jedna od maski null ili 
	 * su različite veličine
	 */
	public static Mask combine(Mask mask1, Mask mask2) {
		
		if(mask1==null || mask2==null || mask1.getSize()!=mask2.getSize()) {
			throw new IllegalArgumentException("To combine two masks in a new mask, " + 
					"masks should have the same lenght!");
		}
		
		MaskValue[] newMaskValues = new MaskValue[mask1.getSize()];
		
		for(int i=0; i<mask1.getSize(); i++) {
			
			if(mask1.getValue(i)==mask2.getValue(i)) {
				newMaskValues[i] = mask1.getValue(i);
				continue;
			}
			
			if(mask1.getValue(i)==MaskValue.DONT_CARE || mask2.getValue(i)==MaskValue.DONT_CARE) {
				return null;
			}
			
			newMaskValues[i] = MaskValue.DONT_CARE;
		}
		
		Mask newMask = new Mask(newMaskValues);
		
		if(newMask.equals(mask1) || newMask.equals(mask2)) {
			return null;
		} else {
			return newMask;
		}
	
	}
	
	/**
	 * Metoda parsira String i stvara novu masku
	 * @param maskString String koji se parsinra
	 * @return nova maska
	 */
	public static Mask parse(String maskString) {
		
		List<Mask> masks = Masks.fromStrings(maskString);
		return masks.get(0);
	}
	
	/**
	 * Metoda kreira masku iz vrijednosti broja 
	 * @param size velicina maske
	 * @param value vrijednost broja
	 * @return
	 */
	public static Mask fromIndex(int size, int value) {
		
		List<Mask> masks =  Masks.fromIndexes(size, value);
		return masks.get(0);
	}
	
	
	private int getNumberOfValue(MaskValue value) {
		
		int brojac = 0;
	
		for(int i = 0; i<this.masks.length; i++) {
			if(this.getValue(i)==value) {
				brojac++;
			}
		}
		
		return brojac;
	}
}
