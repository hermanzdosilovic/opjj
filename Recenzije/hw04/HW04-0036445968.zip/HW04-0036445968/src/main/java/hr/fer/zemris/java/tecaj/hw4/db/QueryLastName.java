package hr.fer.zemris.java.tecaj.hw4.db;

import java.util.List;

public class QueryLastName extends Query {

	public QueryLastName(StudentDatabase db, String command) {
		super(db, command);
	}
	
	@Override
	public String proccess() {
		
		LastNameFilter filter = new LastNameFilter(this.getCommand().split("\"")[1]);
	
		List<StudentRecord> students = this.getDb().filter(filter);

		PrintFormat print = new PrintFormat();
		
		for(StudentRecord student : students) {
			if(student.getLastName().length() > print.getLastNameLength()) {
				print.setLastNameLength(student.getLastName().length());
			}
			
			if(student.getFirstName().length() > print.getFirstNameLength()) {
				print.setFirstNameLength(student.getFirstName().length());
			}

		}
		
		return print.createPrint(students);
	}

}
