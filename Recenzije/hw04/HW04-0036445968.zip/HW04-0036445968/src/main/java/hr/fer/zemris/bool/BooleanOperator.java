/**
 * Paket sadrži klase koje su potrebne za definiranje boolean konstanti, operatora i maski. 
 */
package hr.fer.zemris.bool;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/**
 * Apstraktni razred <code>BooleanOperator</code> predstavlja apstrakciju za 
 * rad s operatorima. 
 * Implementira sučelje <code>BooleanSource</code>.
 * @author mbogovic
 * @version
 */
public abstract class BooleanOperator implements BooleanSource{

	private List<BooleanSource> sources;
	
	/**
	 * Protected konstruktor kojim se definira domena operatora.
	 * @param sources List<BooleanSource> lista izvora.
	 */
	protected BooleanOperator(List<BooleanSource> sources) {
		this.sources = new ArrayList<BooleanSource>(sources);
	}

	/**
	 * Metoda vraća listu izvora nad kojima operator vrši
	 * svoju funkciju.
	 * @return List<BooleanSource> lista izvora.
	 */
	protected List<BooleanSource> getSources() {
		return new ArrayList<BooleanSource>(this.sources);
	}

	/**
	 * Metoda vraća domenu operatora.
	 * @return List<BooleanVariable> lista varijabli koje čine domenu.
	 */
	@Override
	public List<BooleanVariable> getDomain() {
		
		Set<BooleanVariable> union = new LinkedHashSet<>();
		for(BooleanSource source : this.sources) {
			union.addAll(source.getDomain());
		}
		
		return new ArrayList<BooleanVariable>(union);
	}
	
	public abstract BooleanValue getValue();

}
