/**
 * Paket sadrži klase koje su potrebne za definiranje boolean konstanti, operatora i maski. 
 */
package hr.fer.zemris.bool;

import java.util.List;

/**
 * Sučelje <code>BooleanSource</code> definira dvije metode, GetValue() i getDomain()
 * @author mbogovic
 * @version 1.0
 */
public interface BooleanSource {
	public BooleanValue getValue();
	public List<BooleanVariable> getDomain();
}
