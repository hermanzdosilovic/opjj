package hr.fer.zemris.bool.fimpl;

import hr.fer.zemris.bool.BooleanFunction;

public class OperatorBFIteratorDontcares extends OperatorBFIterator {

	@Override
	protected boolean hasValue(BooleanFunction function, int index) {
		return function.hasDontCare(index);
	}

}
