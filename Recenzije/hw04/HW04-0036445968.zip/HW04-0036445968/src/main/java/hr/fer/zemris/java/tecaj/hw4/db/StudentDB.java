package hr.fer.zemris.java.tecaj.hw4.db;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

public class StudentDB {

	public static void main(String[] args) {
		
		try {
			
			StudentDatabase database = initializeDatabase();
			
			System.out.println("Database is initialized, you can write your queries now, "
					+ "if you want to disconnect type 'quit'..." );
			
			BufferedReader reader = new BufferedReader(
					new InputStreamReader( new BufferedInputStream(System.in), StandardCharsets.UTF_8 ) 
					);
			
			String command = "";
			while (command.isEmpty()) {
				
				System.out.print("> ");
				command = reader.readLine();
				
				if (command == null)
					break;
			
				command = command.trim();
				if (command.isEmpty()) {
					continue;
				}
				
				if(command.toUpperCase().equals("QUIT")) {
					break;
				}
				
				try {
					Query query = QueryFactory.createQuery(database, command);
					System.out.println(query.proccess());
				} catch (IllegalArgumentException exception) {
					System.out.println("Invalid input, error description: " + exception.getMessage());
				}
				
				command = "";
			}
			
		
		} catch(IOException exception) {
			System.out.println("Error while reading database.txt file: " + exception.getMessage());
			
		} catch(Exception exception) {
			System.out.println("Error: " + exception.getMessage());
		}
		
	}
	
	private static StudentDatabase initializeDatabase() throws IOException {
		
		List<String> lines = Files.readAllLines(
				Paths.get("./database.txt"),
				StandardCharsets.UTF_8
				);
		
		//Set osigurava da za jednog studenta nece biti vise zapisa
		Set<StudentRecord> allStudents = new LinkedHashSet<>();
		String[] studentData;
		int lineCounter = 1;
		
		for(String line : lines) {
			
			if(line.isEmpty()) {
				continue;
			}
				
			studentData = line.split("\\t");
			
			try {
				allStudents.add(
						new StudentRecord(studentData[0], studentData[1], 
								studentData[2], Integer.parseInt(studentData[3]))
						);
				
			} catch(NumberFormatException exception) {
				System.out.println("Student: " + studentData[0] + " has invalid grade!" );

			} catch(ArrayIndexOutOfBoundsException exception) {
				System.out.println("In database file, line: " + lineCounter 
						+ " does not have all the necessary data!" );
			}
				
			lineCounter++;
		}
			
		return new StudentDatabase(new ArrayList<StudentRecord>(allStudents));
	}

}
