package hr.fer.zemris.bool;

public interface NamedBooleanSource extends BooleanSource {
	public String getName();
}
