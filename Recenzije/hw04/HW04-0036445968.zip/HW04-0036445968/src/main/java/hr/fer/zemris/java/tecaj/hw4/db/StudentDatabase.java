package hr.fer.zemris.java.tecaj.hw4.db;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

public class StudentDatabase {

	Map<String, StudentRecord> studentsMap;
	
	
	public StudentDatabase(List<StudentRecord> studentList) {
		
		this.studentsMap = new TreeMap<String, StudentRecord>();
		this.initializeMap(studentList);
	}
	
	public StudentRecord forJMBAG(String jmbag) {
		return this.studentsMap.get(jmbag);
	}
	
	public List<StudentRecord> filter(IFilter filter) {
		
		List<StudentRecord> resultList = new ArrayList<>();
		for(StudentRecord student : studentsMap.values() ) {
			
			if(filter.accepts(student)) {
				resultList.add(student);
			}
		}
		
		return resultList;
	}
	
	private void initializeMap(List<StudentRecord> studentList) {
		
		for(StudentRecord student : studentList) {
			this.studentsMap.put(student.getJmbag(), student);
		}
	}
}
