package hr.fer.zemris.java.tecaj.hw4;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class AboveAverage {

	public static void main(String[] args) {
		

		try {
			
			BufferedReader reader = new BufferedReader(
					new InputStreamReader( new BufferedInputStream(System.in), StandardCharsets.UTF_8 ) 
					);
			
			String number = "";
			List<Double> numbers = new ArrayList<Double>();
			
			System.out.println("Enter decimal numbers: " );
			
			while (number.isEmpty()) {
				
				System.out.print("> ");
				number = reader.readLine();
				
				if (number == null)
					break;
			
				number = number.trim();
				if (number.isEmpty()) {
					continue;
				}
				
				if(number.toUpperCase().equals("QUIT")) {
					break;
				}
		
				try {
					numbers.add(Double.parseDouble(number));
				} catch (NumberFormatException exception) {
					System.out.println("Invalid input: " + exception.getMessage());
				}
				
				number = "";
			}
			
		
			double avg = calculateAvg(numbers);
			printNumbersAboveAvg(numbers, avg);
			
		} catch(IOException exception) {
			System.out.println("Error:" + exception.getMessage());
			
		} catch(Exception exception) {
			System.out.println("Error: " + exception.getMessage());
		}
		
	}
	
	private static double calculateAvg(List<Double> numbers) {
		
		Double sum = 0.0;
		for(Double number : numbers ){
			sum += number;
		}
		
		return numbers.size() > 0 ? sum/numbers.size() : sum;
	}
	
	private static void printNumbersAboveAvg(List<Double> numbers, Double avg) {
		
		Collections.sort(numbers);
		
		avg = 1.2*avg;
		
		System.out.println("1.2 * average = " + avg);
		for(Double number : numbers) {
			
			if(number >= avg) {
				System.out.println(number);
			}
		}
		
	}

}
