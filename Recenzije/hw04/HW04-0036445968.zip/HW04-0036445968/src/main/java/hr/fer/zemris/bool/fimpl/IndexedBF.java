/**
 * Paket sadrži klase koje su potrebne za definiranje boolean funkcija. 
 */
package hr.fer.zemris.bool.fimpl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import hr.fer.zemris.bool.BooleanFunction;
import hr.fer.zemris.bool.BooleanSource;
import hr.fer.zemris.bool.BooleanValue;
import hr.fer.zemris.bool.BooleanVariable;
import hr.fer.zemris.bool.Mask;
import hr.fer.zemris.bool.MaskValue;
import hr.fer.zemris.bool.Masks;
import hr.fer.zemris.bool.opimpl.BooleanOperatorAND;
import hr.fer.zemris.bool.opimpl.BooleanOperatorNOT;
import hr.fer.zemris.bool.opimpl.BooleanOperatorOR;

/**
 * Razred <code>IndexedBF</code> koji se koristi za manipulaciju 
 * rada s Bool funkcijama koristeći indexe minterma ili maxterma i dont careova.
 * @author mbogovic
 * @version
 */
public class IndexedBF implements BooleanFunction {

	private String name;
	private boolean indexesAreMinterms;
	private int indexSpace;
	
	private List<BooleanVariable> domain;
	private List<Integer> indexes;
	private List<Integer> dontCares;
	
	/**
	 * Public konstruktor
	 * @param name nazivfunkcije
	 * @param domain domena funkcije
	 * @param indexesAreMinterms true ukoliko su primljeni indexi mintermi, inaće false
	 * @param indexes lista indexa minterma/maxterma
	 * @param dontCares lista indexa dont careova
	 */
	public IndexedBF(String name, List<BooleanVariable> domain, boolean indexesAreMinterms, 
			List<Integer> indexes, List<Integer> dontCares) {
	
		FunctionHelper.validateFunctionName(name, true);
		FunctionHelper.validateList(indexes, domain.size(), true);
		FunctionHelper.validateList(dontCares, domain.size(), true);
		
		if(!Collections.disjoint(indexes, dontCares)) {
			throw new IllegalArgumentException("Indexes and dontCares are not allowed "
					+"to have same elements!");
		}
		
		this.name = name;
		this.indexSpace = FunctionHelper.calculateIndexSpace(domain.size());
		this.indexesAreMinterms = indexesAreMinterms;
		
		this.domain = new ArrayList<BooleanVariable>(domain);
		this.indexes = new ArrayList<Integer>(indexes);
		this.dontCares = new ArrayList<Integer>(dontCares);
	}
	
	/**
	 * Metoda vraća naziv funkcije
	 * @return name naziv funkcije
	 */
	@Override
	public String getName() {
		return this.name;
	}

	/**
	 * Metoda računa i vraća vrijednost funkcije
	 * @return BooleanValue vrijednost funkcije.
	 */
	@Override
	public BooleanValue getValue() {
		
		if(this.indexesAreMinterms) {
			return this.calculateSumMinterms(this.indexes);
		} else {
			return this.calculateSumMinterms(this.returnDifferenceList());
		}
		
	}

	/**
	 * Metoda vraća domenu funkcije
	 * @return List<BooleanVariable> lista varijabli
	 */
	@Override
	public List<BooleanVariable> getDomain() {
		return new ArrayList<>(this.domain);
	}

	/**
	 * Metoda provjerava da li je na određenom indexu funkcija TRUE
	 * @param int index
	 * @return boolean ukoliko je na određenom indexu funkcija TRUE.
	 */
	@Override
	public boolean hasMinterm(int index) {
		return this.hasIndex(true, index);
		
	}

	/**
	 * Metoda provjerava da li je na određenom indexu funkcija FALSE
	 * @param int index
	 * @return boolean ukoliko je na određenom indexu funkcija FALSE.
	 */
	@Override
	public boolean hasMaxterm(int index) {
		return this.hasIndex(false, index);
	}

	/**
	 * Metoda provjerava da li je na određenom indexu funkcija DON'T CARE
	 * @param int index
	 * @return boolean ukoliko je na određenom indexu funkcija DONT CARE.
	 */
	@Override
	public boolean hasDontCare(int index) {
		FunctionHelper.indexInsideBounds(index, this.domain.size(), true);
		return this.dontCares.contains(Integer.valueOf(index));
	}

	/**
	 * Metoda vraća iterator za iteriranje kroz sve minterme
	 * @return Iterable<Integer> iterator
	 */
	@Override
	public Iterable<Integer> mintermIterable() {
		if(this.indexesAreMinterms) {
			return this.indexes;
		} else {
			return returnDifferenceList();
		}
	}

	/**
	 * Metoda vraća iterator za iteriranje kroz sve maxterme
	 * @return Iterable<Integer> iterator
	 */
	@Override
	public Iterable<Integer> maxtermIterable() {
		if(this.indexesAreMinterms) {
			return returnDifferenceList();
		} else {
			return this.indexes;
		}
	}

	/**
	 * Metoda vraća iterator za iteriranje kroz sve dontcareove
	 * @return Iterable<Integer> iterator
	 */
	@Override
	public Iterable<Integer> dontcareIterable() {
		return this.dontCares;
	}
	

	private BooleanValue calculateSumMinterms(List<Integer> targetIndexes) {
		
		Mask mask = null;
		
		List<BooleanSource> variables = null;
		List<BooleanSource> sumMinterms = new ArrayList<>();
	
		for(int index : targetIndexes) {
			
			mask = Masks.fromIndexes(this.domain.size(), index).get(0);
			
			variables = new ArrayList<>();
			for(int indexVariable=0;  indexVariable<mask.getSize(); indexVariable++) {
				
				if(mask.getValue(indexVariable)==MaskValue.ONE) {
					variables.add(this.domain.get(indexVariable));
				} else {
					variables.add(new BooleanOperatorNOT(this.domain.get(indexVariable)));
				}
	
			}
			
			sumMinterms.add(new BooleanOperatorAND(variables));
		}
		
		if(!this.dontCares.isEmpty()) {
			BooleanVariable variableDontCare = new BooleanVariable("dontCare");
			variableDontCare.setValue(BooleanValue.DONT_CARE);
			sumMinterms.add(variableDontCare);
		}
		
		return new BooleanOperatorOR(sumMinterms).getValue();	
	}
	
	private boolean hasIndex(boolean mintermWanted, Integer index) {
		
		FunctionHelper.indexInsideBounds(index, this.domain.size(), true);
		
		if(this.dontCares.contains(index)) {
			return false;
		}
		
		boolean hasIndex;
		
		if(this.indexesAreMinterms) {
			hasIndex = this.indexes.contains(index);
		} else {
			hasIndex = !this.indexes.contains(index);
		}
		
		//Ako se tražio maxterm, rjesnje je obrnuto
		return (mintermWanted ? hasIndex : !hasIndex);
	}
	
	private List<Integer> returnDifferenceList() {
		
		List<Integer> differenceList = new ArrayList<>();
		
		for(int i=0; i<=this.indexSpace; i++) {
			
			if(!(this.indexes.contains(i) || this.dontCares.contains(i)) ) {
				differenceList.add(i);
			}
		}
		
		return differenceList;
		
	}
}
