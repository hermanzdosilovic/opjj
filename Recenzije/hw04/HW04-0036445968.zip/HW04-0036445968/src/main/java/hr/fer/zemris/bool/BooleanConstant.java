/**
 * Paket sadrži klase koje su potrebne za definiranje boolean konstanti, operatora i maski. 
 */
package hr.fer.zemris.bool;

import java.util.Collections;
import java.util.List;

/**
 * Razred <code>BooleanConstant</code> omogućava rad s Bool konstantama. 
 * Implementira sučelje <code>BooleanSource</code>.
 * Najcesci nacin uporabe:
 * <pre>
 * BooleanVariable a = new BooleanVariable("a");
 * a.setValue(BooleanConstant.TRUE)
 * </pre>
 * @author mbogovic
 * @version
 */
public final class BooleanConstant implements BooleanSource {

	private BooleanValue value;
	
	public static final BooleanConstant TRUE = new BooleanConstant(BooleanValue.TRUE);
	public static final BooleanConstant FALSE = new BooleanConstant(BooleanValue.FALSE);
			
	/**
	 * Privatni konstruktor.
	 * @param value BooleanValue koja označava koju konstanta ima vrijednost.
	 */
	private BooleanConstant(BooleanValue value) {
		this.value = value;
	}

	/**
	 * Metoda vraća bool vrijednost konstate.
	 * @return BooleanValue vrijednost konstante.
	 */
	@Override
	public BooleanValue getValue() {
		return this.value;
	}
	
	/**
	 * Metoda vraća domenu za konju konstanta vrijedi.
	 * @return List<BooleanVariable> prazna lista.
	 */
	@Override
	public List<BooleanVariable> getDomain() {
		return Collections.<BooleanVariable>emptyList();
	}
	
}
