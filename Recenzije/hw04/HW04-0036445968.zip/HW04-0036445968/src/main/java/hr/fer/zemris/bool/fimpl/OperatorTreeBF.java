/**
 * Paket sadrži klase koje su potrebne za definiranje boolean funkcija. 
 */
package hr.fer.zemris.bool.fimpl;

import java.util.ArrayList;
import java.util.List;

import hr.fer.zemris.bool.BooleanFunction;
import hr.fer.zemris.bool.BooleanOperator;
import hr.fer.zemris.bool.BooleanValue;
import hr.fer.zemris.bool.BooleanVariable;
import hr.fer.zemris.bool.Mask;
import hr.fer.zemris.bool.Masks;

/**
 * Razred <code>OperatorTreeBF</code> koji se koristi za manipulaciju 
 * rada s Bool funkcijama koristeći bool operator/e.
 * @author mbogovic
 * @version
 */
public class OperatorTreeBF implements BooleanFunction {

	private String name;
	private List<BooleanVariable> domain;
	private BooleanOperator operatorTree;
	
	/**
	 * Public konstruktor
	 * @param name naziv funkcije
	 * @param domain domena funkcije
	 * @param operatorTree operator koji definiraa ovu funkciju
	 */
	public OperatorTreeBF(String name, List<BooleanVariable> domain, BooleanOperator operatorTree) {

		FunctionHelper.validateFunctionName(name, true);
		
		if( domain == null 
				|| operatorTree == null 
				|| !domain.containsAll(operatorTree.getDomain()) ) {
				throw new IllegalArgumentException("Domain and operator can not be null " 
					+ "and function must depend on all variables on which operator tree depends!");
		}
		
		this.name = name;
		this.domain = new ArrayList<BooleanVariable>(domain);
		this.operatorTree = operatorTree; 
	}
	
	/**
	 * Metoda vraća naziv funkcije
	 * @return name naziv funkcije
	 */
	@Override
	public String getName() {
		return this.name;
	}

	/**
	 * Metoda računa i vraća vrijednost funkcije
	 * @return BooleanValue vrijednost funkcije.
	 */
	@Override
	public BooleanValue getValue() {
		return this.operatorTree.getValue();
	}

	/**
	 * Metoda vraća domenu funkcije
	 * @return List<BooleanVariable> lista varijabli
	 */
	@Override
	public List<BooleanVariable> getDomain() {
		return new ArrayList<BooleanVariable>(this.domain);
	}

	/**
	 * Metoda provjerava da li je na određenom indexu funkcija TRUE
	 * @param int index
	 * @return boolean ukoliko je na određenom indexu funkcija TRUE.
	 */
	@Override
	public boolean hasMinterm(int index) {
		
		this.setVariables(index);
		return this.getValue()==BooleanValue.TRUE;
	}

	/**
	 * Metoda provjerava da li je na određenom indexu funkcija FALSE
	 * @param int index
	 * @return boolean ukoliko je na određenom indexu funkcija FALSE.
	 */
	@Override
	public boolean hasMaxterm(int index) {

		this.setVariables(index);
		return this.getValue()==BooleanValue.FALSE;
	}

	/**
	 * Metoda provjerava da li je na određenom indexu funkcija DON'T CARE
	 * @param int index
	 * @return boolean ukoliko je na određenom indexu funkcija DONT CARE.
	 */
	@Override
	public boolean hasDontCare(int index) {

		this.setVariables(index);
		return this.getValue()==BooleanValue.DONT_CARE;
	}

	/**
	 * Metoda vraća iterator za iteriranje kroz sve minterme
	 * @return Iterable<Integer> iterator
	 */
	@Override
	public Iterable<Integer> mintermIterable() {
		
		OperatorBFIterator iterator = new OperatorBFIteratorMinterms();
		return iterator.valueIterable(this);
	}

	/**
	 * Metoda vraća iterator za iteriranje kroz sve maxterme
	 * @return Iterable<Integer> iterator
	 */
	@Override
	public Iterable<Integer> maxtermIterable() {
		
		OperatorBFIterator iterator = new OperatorBFIteratorMaxterms();
		return iterator.valueIterable(this);
	}

	/**
	 * Metoda vraća iterator za iteriranje kroz sve dontcareove
	 * @return Iterable<Integer> iterator
	 */
	@Override
	public Iterable<Integer> dontcareIterable() {
		
		OperatorBFIterator iterator = new OperatorBFIteratorDontcares();
		return iterator.valueIterable(this);
	}

	private void setVariables(int index) {
		
		FunctionHelper.indexInsideBounds(index, this.domain.size(), true); 
		
		Mask mask = Masks.fromIndexes(this.domain.size(), index).get(0);
		
		BooleanVariable variable;
		for(int i=0; i<this.domain.size(); i++) {
			
			variable = this.domain.get(i);
			variable.setValue( Masks.convertMaskToBoolean(mask.getValue(i)) );
			
		}
		
	}
	
}
