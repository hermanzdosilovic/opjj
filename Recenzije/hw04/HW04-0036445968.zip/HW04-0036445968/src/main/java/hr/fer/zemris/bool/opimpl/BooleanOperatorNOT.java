package hr.fer.zemris.bool.opimpl;

import java.util.Arrays;

import hr.fer.zemris.bool.BooleanOperator;
import hr.fer.zemris.bool.BooleanSource;
import hr.fer.zemris.bool.BooleanValue;

public class BooleanOperatorNOT extends BooleanOperator {

	public BooleanOperatorNOT(BooleanSource source) {
		super(Arrays.asList(source));
	}
	
	@Override
	public BooleanValue getValue() {	
		
		BooleanSource source = this.getSources().get(0);
		if (source == null) {
			throw new IllegalArgumentException("Can not execute NOT operation if source is null!");
		}
		
		BooleanValue result = null;
		
		switch(source.getValue()) {
		case TRUE:
			result = BooleanValue.FALSE;
			break;
		case FALSE:
			result = BooleanValue.TRUE;
			break;
		default:
			result = BooleanValue.DONT_CARE;
			break;
		}
		
		return result;
	}
	
}
