package hr.fer.zemris.java.tecaj.hw4.db;

public abstract class Query {

	private StudentDatabase db;
	private String command;
	
	protected Query(StudentDatabase db, String command) {
		this.db = db;
		this.command = command;
	}
	
	public abstract String proccess();

	protected StudentDatabase getDb() {
		return db;
	}
	protected String getCommand() {
		return command;
	}
	
	
}
