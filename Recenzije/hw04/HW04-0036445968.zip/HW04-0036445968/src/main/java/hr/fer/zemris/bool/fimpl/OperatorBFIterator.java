/**
 * Paket sadrži klase koje su potrebne za definiranje boolean funkcija. 
 */
package hr.fer.zemris.bool.fimpl;

import java.util.ArrayList;
import java.util.List;

import hr.fer.zemris.bool.BooleanFunction;

/**
 * Apstraktni razred <code>OperatorBFIterator</code> je pomoćni razred koji omogućuje iteriranje
 * kroz minterme, maxterme i dont careove razreda OperatorTreeBF.
 * @author mbogovic
 * @version
 */
public abstract class OperatorBFIterator {

	/**
	 * Public konstruktor
	 * @param function boolean funkcija
	 * @return Iterator<Integer>
	 */
	public Iterable<Integer> valueIterable(BooleanFunction function) {
		
		int indexSpace = FunctionHelper.calculateIndexSpace(function.getDomain().size());
		List<Integer> list = new ArrayList<Integer>();
		
		for(int i=0; i<=indexSpace; i++) {
			
			if(hasValue(function, i)) {
				list.add(i);
			}
		}
		
		return list;
		
	}
	
	protected abstract boolean hasValue(BooleanFunction function, int index);
}
