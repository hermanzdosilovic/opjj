package hr.fer.zemris.java.tecaj.hw4;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

public class NamesCounter {

	public static void main(String[] args) {
		
		try {
			
			BufferedReader reader = new BufferedReader(
					new InputStreamReader( new BufferedInputStream(System.in), StandardCharsets.UTF_8 ) 
					);
			
			String name = "";
			Integer counter;
			Map<String, Integer> names = new HashMap<>();
			
			System.out.println("Enter names: " );
			
			while (name.isEmpty()) {
				
				System.out.print("> ");
				name = reader.readLine();
				
				if (name == null)
					break;
			
				name = name.trim();
				if (name.isEmpty()) {
					continue;
				}
				
				if(name.toUpperCase().equals("QUIT")) {
					break;
				}
		
				counter = names.get(name);
				if(counter==null) {
					names.put(name, 1);
				} else {
					names.put(name, counter + 1);
				}
			
				name = "";
			}
			
		printNames(names);
		
		} catch(IOException exception) {
			System.out.println("Error:" + exception.getMessage());
			
		} catch(Exception exception) {
			System.out.println("Error: " + exception.getMessage());
		}

	}
	
	private static void printNames(Map<String, Integer> names) {
		
		for(Entry<String, Integer> name : names.entrySet()) {
			System.out.println(name.getKey() + " --> " + name.getValue());
		}
	}

}
