package hr.fer.zemris.bool.fimpl;

import hr.fer.zemris.bool.BooleanVariable;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.Test;

import static org.junit.Assert.*;

public class IndexedBFTest {

	@Test
	public void createIndexedBF() {
		BooleanVariable varA = new BooleanVariable("A");
		BooleanVariable varB = new BooleanVariable("B");
		
		new IndexedBF(
				"f1",
				Arrays.asList(varA,varB),
				true,
				Arrays.asList(1,2), 
				Arrays.asList(0)
			);
	
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void createIndexedBFDomainNull() {
		List<BooleanVariable> domain = null;
		
		new IndexedBF(
				"f1",
				domain,
				true,
				Arrays.asList(1,2), 
				Arrays.asList(0)
			);
	
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void createIndexedBFIndexesNull() {
		BooleanVariable varA = new BooleanVariable("A");
		BooleanVariable varB = new BooleanVariable("B");
		
		List<Integer> ind = null;
		
		new IndexedBF(
				"f1",
				Arrays.asList(varA,varB),
				true,
				ind, 
				Arrays.asList(0)
			);
	
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void createIndexedBFDontCaresNull() {
		BooleanVariable varA = new BooleanVariable("A");
		BooleanVariable varB = new BooleanVariable("B");
		
		List<Integer> ind = null;
		
		new IndexedBF(
				"f1",
				Arrays.asList(varA,varB),
				true,
				Arrays.asList(1,2), 
				ind
			);
	
	}
	
	
	@Test(expected=IllegalArgumentException.class)
	public void createIndexedBFNameNull() {
		BooleanVariable varA = new BooleanVariable("A");
		BooleanVariable varB = new BooleanVariable("B");
		
		String name = null;
		
		new IndexedBF(
				name,
				Arrays.asList(varA,varB),
				true,
				Arrays.asList(1,2), 
				Arrays.asList(0) 
			);
	
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void createIndexedBFNameEmpty() {
		BooleanVariable varA = new BooleanVariable("A");
		BooleanVariable varB = new BooleanVariable("B");
		
		String name = "";
		
		new IndexedBF(
				name,
				Arrays.asList(varA,varB),
				true,
				Arrays.asList(1,2), 
				Arrays.asList(0) 
			);
	
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void createIndexedBFOverlapping() {
		BooleanVariable varA = new BooleanVariable("A");
		BooleanVariable varB = new BooleanVariable("B");
		
		new IndexedBF(
				"f1",
				Arrays.asList(varA,varB),
				true,
				Arrays.asList(1,2), 
				Arrays.asList(0,1)
			);
	
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void createIndexedBFIndexNegative() {
		BooleanVariable varA = new BooleanVariable("A");
		BooleanVariable varB = new BooleanVariable("B");
		
		new IndexedBF(
				"f1",
				Arrays.asList(varA,varB),
				true,
				Arrays.asList(1,-2), 
				Arrays.asList(0)
			);
	
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void createIndexedBFIndexTooBig() {
		BooleanVariable varA = new BooleanVariable("A");
		BooleanVariable varB = new BooleanVariable("B");
		
		new IndexedBF(
				"f1",
				Arrays.asList(varA,varB),
				true,
				Arrays.asList(1,20), 
				Arrays.asList(0)
			);
	
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void createIndexedBFDontCareTooBig() {
		BooleanVariable varA = new BooleanVariable("A");
		BooleanVariable varB = new BooleanVariable("B");
		
		new IndexedBF(
				"f1",
				Arrays.asList(varA,varB),
				true,
				Arrays.asList(1,2), 
				Arrays.asList(17)
			);
	
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void createIndexedBFDontCareNegative() {
		BooleanVariable varA = new BooleanVariable("A");
		BooleanVariable varB = new BooleanVariable("B");
		
		new IndexedBF(
				"f1",
				Arrays.asList(varA,varB),
				true,
				Arrays.asList(1,2), 
				Arrays.asList(17)
			);
	
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void createIndexedBFDuplicatesDontCares() {
		BooleanVariable varA = new BooleanVariable("A");
		BooleanVariable varB = new BooleanVariable("B");
		
		new IndexedBF(
				"f1",
				Arrays.asList(varA,varB),
				true,
				Arrays.asList(1,2), 
				Arrays.asList(0,1,1)
			);
	
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void createIndexedBFDuplicatesIndexes() {
		BooleanVariable varA = new BooleanVariable("A");
		BooleanVariable varB = new BooleanVariable("B");
		
		new IndexedBF(
				"f1",
				Arrays.asList(varA,varB),
				true,
				Arrays.asList(1,2,1), 
				Arrays.asList(0,1)
			);
	
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void createIndexedBFDuplicatesDomain() {
		BooleanVariable varA = new BooleanVariable("A");
		BooleanVariable varB = new BooleanVariable("B");
		
		new IndexedBF(
				"f1",
				Arrays.asList(varA,varB,varA),
				true,
				Arrays.asList(1,2), 
				Arrays.asList(0,1)
			);
	
	}
	
	@Test
	public void getName() {
		BooleanVariable varA = new BooleanVariable("A");
		BooleanVariable varB = new BooleanVariable("B");
		
		IndexedBF bf = new IndexedBF(
				"f1",
				Arrays.asList(varA,varB),
				true,
				Arrays.asList(1,2), 
				Arrays.asList(0)
			);
		
		assertEquals("f1", bf.getName());
	}
	
	@Test
	public void getDomain() {
		// TODO
		BooleanVariable varA = new BooleanVariable("A");
		BooleanVariable varB = new BooleanVariable("B");
		
		IndexedBF bf = new IndexedBF(
				"f1",
				Arrays.asList(varA,varB),
				true,
				Arrays.asList(1,2), 
				Arrays.asList(0)
			);
		
		assertArrayEquals(Arrays.asList(varA,varB).toArray(), bf.getDomain().toArray());
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void hasMinterIndexNegative() {
		BooleanVariable varA = new BooleanVariable("A");
		BooleanVariable varB = new BooleanVariable("B");
		
		IndexedBF bf = new IndexedBF(
				"f1",
				Arrays.asList(varA,varB),
				true,
				Arrays.asList(1,2), 
				Arrays.asList(0)
			);
		
		bf.hasMaxterm(-1);
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void hasMinterIndexTooBig() {
		BooleanVariable varA = new BooleanVariable("A");
		BooleanVariable varB = new BooleanVariable("B");
		
		IndexedBF bf = new IndexedBF(
				"f1",
				Arrays.asList(varA,varB),
				true,
				Arrays.asList(1,2), 
				Arrays.asList(0)
			);
		
		bf.hasMaxterm(17);
	}
	
	@Test
	public void hasMinterMinterms() {
		BooleanVariable varA = new BooleanVariable("A");
		BooleanVariable varB = new BooleanVariable("B");
		
		IndexedBF bf = new IndexedBF(
				"f1",
				Arrays.asList(varA,varB),
				true,
				Arrays.asList(1,2), 
				Arrays.asList(0)
			);
		
		assertEquals(true,bf.hasMinterm(1));
		assertEquals(true,bf.hasMinterm(2));
	}
	
	@Test
	public void hasMinterMaxterms() {
		BooleanVariable varA = new BooleanVariable("A");
		BooleanVariable varB = new BooleanVariable("B");
		
		IndexedBF bf = new IndexedBF(
				"f1",
				Arrays.asList(varA,varB),
				false,
				Arrays.asList(1,2), 
				Arrays.asList(0)
			);
		
		assertEquals(true,bf.hasMinterm(3));
	}
	
	@Test
	public void hasMaxtermMaxterms() {
		BooleanVariable varA = new BooleanVariable("A");
		BooleanVariable varB = new BooleanVariable("B");
		
		IndexedBF bf = new IndexedBF(
				"f1",
				Arrays.asList(varA,varB),
				false,
				Arrays.asList(1,2), 
				Arrays.asList(0)
			);
		
		assertEquals(true,bf.hasMaxterm(1));
		assertEquals(true,bf.hasMaxterm(2));
	}
	
	@Test
	public void hasMaxtermMinterms() {
		BooleanVariable varA = new BooleanVariable("A");
		BooleanVariable varB = new BooleanVariable("B");
		
		IndexedBF bf = new IndexedBF(
				"f1",
				Arrays.asList(varA,varB),
				true,
				Arrays.asList(1,2), 
				Arrays.asList(0)
			);
		
		assertEquals(true,bf.hasMaxterm(3));
	}
	
	@Test
	public void hasDontCares() {
		BooleanVariable varA = new BooleanVariable("A");
		BooleanVariable varB = new BooleanVariable("B");
		
		IndexedBF bf = new IndexedBF(
				"f1",
				Arrays.asList(varA,varB),
				true,
				Arrays.asList(1,2), 
				Arrays.asList(0)
			);
		
		assertEquals(true,bf.hasDontCare(0));
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void hasDontCaresNegativeIndex() {
		BooleanVariable varA = new BooleanVariable("A");
		BooleanVariable varB = new BooleanVariable("B");
		
		IndexedBF bf = new IndexedBF(
				"f1",
				Arrays.asList(varA,varB),
				true,
				Arrays.asList(1,2), 
				Arrays.asList(0)
			);
		
		assertEquals(true,bf.hasDontCare(-2));
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void hasDontCaresIndexTooBig() {
		BooleanVariable varA = new BooleanVariable("A");
		BooleanVariable varB = new BooleanVariable("B");
		
		IndexedBF bf = new IndexedBF(
				"f1",
				Arrays.asList(varA,varB),
				true,
				Arrays.asList(1,2), 
				Arrays.asList(0)
			);
		
		assertEquals(true,bf.hasDontCare(4));
	}
	
	@Test
	public void getMintermIterableMinterms() {
		BooleanVariable varA = new BooleanVariable("A");
		BooleanVariable varB = new BooleanVariable("B");
		
		IndexedBF bf = new IndexedBF(
				"f1",
				Arrays.asList(varA,varB),
				true,
				Arrays.asList(1,2), 
				Arrays.asList(0)
			);
		
		Iterable<Integer> iterable = bf.mintermIterable();
		
		List<Integer> list =  new ArrayList<>();
		
		for(Integer it: iterable) {
			list.add(it);
		}
		
		assertEquals(2,list.size());
		assertArrayEquals(new Integer[]{1,2}, list.toArray());
	}
	
	@Test
	public void getMintermIterableMaxterms() {
		BooleanVariable varA = new BooleanVariable("A");
		BooleanVariable varB = new BooleanVariable("B");
		
		IndexedBF bf = new IndexedBF(
				"f1",
				Arrays.asList(varA,varB),
				false,
				Arrays.asList(1,2), 
				Arrays.asList(0)
			);
		
		Iterable<Integer> iterable = bf.mintermIterable();
		
		List<Integer> list =  new ArrayList<>();
		
		for(Integer it: iterable) {
			list.add(it);
		}
		
		assertEquals(1,list.size());
		assertArrayEquals(new Integer[]{3}, list.toArray());
	}
	
	@Test
	public void getMaxtermIterableMaxterms() {
		BooleanVariable varA = new BooleanVariable("A");
		BooleanVariable varB = new BooleanVariable("B");
		
		IndexedBF bf = new IndexedBF(
				"f1",
				Arrays.asList(varA,varB),
				false,
				Arrays.asList(1,2), 
				Arrays.asList(0)
			);
		
		Iterable<Integer> iterable = bf.maxtermIterable();
		
		List<Integer> list =  new ArrayList<>();
		
		for(Integer it: iterable) {
			list.add(it);
		}
		
		assertEquals(2,list.size());
		assertArrayEquals(new Integer[]{1,2}, list.toArray());
	}
	
	@Test
	public void getMaxtermIterableMinterms() {
		BooleanVariable varA = new BooleanVariable("A");
		BooleanVariable varB = new BooleanVariable("B");
		
		IndexedBF bf = new IndexedBF(
				"f1",
				Arrays.asList(varA,varB),
				true,
				Arrays.asList(1,2), 
				Arrays.asList(0)
			);
		
		Iterable<Integer> iterable = bf.maxtermIterable();
		
		List<Integer> list =  new ArrayList<>();
		
		for(Integer it: iterable) {
			list.add(it);
		}
		
		assertEquals(1,list.size());
		assertArrayEquals(new Integer[]{3}, list.toArray());
	}
	
	@Test
	public void getDontCareIterable() {
		BooleanVariable varA = new BooleanVariable("A");
		BooleanVariable varB = new BooleanVariable("B");
		
		IndexedBF bf = new IndexedBF(
				"f1",
				Arrays.asList(varA,varB),
				false,
				Arrays.asList(1,2), 
				Arrays.asList(0)
			);
		
		Iterable<Integer> iterable = bf.dontcareIterable();
		
		List<Integer> list =  new ArrayList<>();
		
		for(Integer it: iterable) {
			list.add(it);
		}
		
		assertEquals(1,list.size());
		assertArrayEquals(new Integer[]{0}, list.toArray());
	}
	
}
