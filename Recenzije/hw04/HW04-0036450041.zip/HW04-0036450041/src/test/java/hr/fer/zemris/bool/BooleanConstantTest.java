package hr.fer.zemris.bool;

import static org.junit.Assert.assertEquals;
import hr.fer.zemris.bool.BooleanConstant;
import hr.fer.zemris.bool.BooleanValue;

import java.util.ArrayList;

import org.junit.Test;

public class BooleanConstantTest {

	@Test
	public void getBooleanConstantValue() {
		BooleanConstant bcTrue = BooleanConstant.TRUE;
		BooleanConstant bcFalse = BooleanConstant.FALSE;

		assertEquals(BooleanValue.TRUE, bcTrue.getValue());
		assertEquals(BooleanValue.FALSE, bcFalse.getValue());

	}

	@Test
	public void getBooleanConstantDomain() {
		BooleanConstant bcTrue = BooleanConstant.TRUE;
		BooleanConstant bcFalse = BooleanConstant.FALSE;

		assertEquals(true, bcTrue.getDomain().equals(new ArrayList<>()));
		assertEquals(true, bcFalse.getDomain().equals(new ArrayList<>()));
	}

}
