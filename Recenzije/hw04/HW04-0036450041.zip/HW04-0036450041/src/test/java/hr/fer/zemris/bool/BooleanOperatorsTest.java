package hr.fer.zemris.bool;

import static org.junit.Assert.assertEquals;
import hr.fer.zemris.bool.opimpl.BooleanOperatorAND;
import hr.fer.zemris.bool.opimpl.BooleanOperatorNOT;
import hr.fer.zemris.bool.opimpl.BooleanOperatorOR;
import hr.fer.zemris.bool.opimpl.BooleanOperators;

import org.junit.Test;

public class BooleanOperatorsTest {

	@Test
	public void createBooleanOperatorNOT() {

		BooleanVariable varA = new BooleanVariable("A");

		BooleanOperatorNOT bNot = new BooleanOperatorNOT(varA);
		assertEquals(true, bNot.getValue().equals(BooleanValue.TRUE));

	}

	@Test
	public void setValueNOT() {
		BooleanVariable varB = new BooleanVariable("B");
		BooleanVariable varC = new BooleanVariable("C");

		varB.setValue(BooleanValue.TRUE);
		BooleanOperatorNOT bNot1 = new BooleanOperatorNOT(varB);
		assertEquals(true, bNot1.getValue().equals(BooleanValue.FALSE));

		varC.setValue(BooleanValue.DONT_CARE);
		BooleanOperatorNOT bNot2 = new BooleanOperatorNOT(varC);
		assertEquals(true, bNot2.getValue().equals(BooleanValue.DONT_CARE));
	}

	@Test
	public void getDomainNOT() {
		BooleanVariable varB = new BooleanVariable("B");

		assertEquals("B", varB.getDomain().get(0).getName());
	}

	@Test
	public void createBooleanOperatorAND() {

		BooleanVariable varA = new BooleanVariable("A");
		BooleanVariable varB = new BooleanVariable("B");

		BooleanOperatorNOT bNot = new BooleanOperatorNOT(varA);

		new BooleanOperatorAND(varA, varB);
		new BooleanOperatorAND(varA, bNot);
		new BooleanOperatorAND();

	}

	@Test(expected = IllegalArgumentException.class)
	public void createBooleanOperatorANDwithDuplicates() {

		BooleanVariable varA = new BooleanVariable("A");

		new BooleanOperatorAND(varA, varA);
	}

	@Test
	public void getValueAND() {
		BooleanVariable varA = new BooleanVariable("A");
		BooleanVariable varB = new BooleanVariable("B");
		BooleanVariable varC = new BooleanVariable("C");

		varA.setValue(BooleanValue.TRUE);
		BooleanOperatorAND bAnd = new BooleanOperatorAND(varA, varB);
		assertEquals(true, bAnd.getValue().equals(BooleanValue.FALSE));

		varB.setValue(BooleanValue.TRUE);
		BooleanOperatorAND bAnd1 = new BooleanOperatorAND(varA, varB);
		assertEquals(true, bAnd1.getValue().equals(BooleanValue.TRUE));

		varB.setValue(BooleanValue.DONT_CARE);
		BooleanOperatorAND bAnd2 = new BooleanOperatorAND(varA, varB);
		assertEquals(true, bAnd2.getValue().equals(BooleanValue.DONT_CARE));

		varB.setValue(BooleanValue.DONT_CARE);
		varA.setValue(BooleanValue.DONT_CARE);
		BooleanOperatorAND bAnd3 = new BooleanOperatorAND(varA, varB);
		assertEquals(true, bAnd3.getValue().equals(BooleanValue.DONT_CARE));

		varA.setValue(BooleanValue.FALSE);
		BooleanOperatorAND bAnd4 = new BooleanOperatorAND(varA, varB);
		assertEquals(true, bAnd4.getValue().equals(BooleanValue.FALSE));

		varB.setValue(BooleanValue.FALSE);
		BooleanOperatorAND bAnd5 = new BooleanOperatorAND(varA, varB);
		assertEquals(true, bAnd5.getValue().equals(BooleanValue.FALSE));

		BooleanOperatorAND bAnd6 = new BooleanOperatorAND(varA, varB, varC);
		assertEquals(true, bAnd6.getValue().equals(BooleanValue.FALSE));

		varA.setValue(BooleanValue.TRUE);
		varB.setValue(BooleanValue.TRUE);
		varC.setValue(BooleanValue.TRUE);
		BooleanOperatorAND bAnd7 = new BooleanOperatorAND(varA, varB, varC);
		assertEquals(true, bAnd7.getValue().equals(BooleanValue.TRUE));

	}
	
	
	@Test(expected = IllegalArgumentException.class)
	public void createBooleanOperatorORwithDuplicates() {

		BooleanVariable varA = new BooleanVariable("A");

		new BooleanOperatorOR(varA, varA);
	}
	
	@Test
	public void createBooleanOperatorOR() {

		BooleanVariable varA = new BooleanVariable("A");
		BooleanVariable varB = new BooleanVariable("B");

		BooleanOperatorNOT bNot = new BooleanOperatorNOT(varA);

		new BooleanOperatorOR(varA, varB);
		new BooleanOperatorOR(varA, bNot);
		new BooleanOperatorOR();
	}
	
	@Test
	public void getValueOR() {
		BooleanVariable varA = new BooleanVariable("A");
		BooleanVariable varB = new BooleanVariable("B");
		BooleanVariable varC = new BooleanVariable("C");

		varA.setValue(BooleanValue.TRUE);
		BooleanOperatorOR bOr= new BooleanOperatorOR(varA, varB);
		assertEquals(true, bOr.getValue().equals(BooleanValue.TRUE));

		varB.setValue(BooleanValue.TRUE);
		BooleanOperatorOR bOr1 = new BooleanOperatorOR(varA, varB);
		assertEquals(true, bOr1.getValue().equals(BooleanValue.TRUE));

		varB.setValue(BooleanValue.DONT_CARE);
		BooleanOperatorOR bOr2 = new BooleanOperatorOR(varA, varB);
		assertEquals(true, bOr2.getValue().equals(BooleanValue.TRUE));

		varB.setValue(BooleanValue.DONT_CARE);
		varA.setValue(BooleanValue.DONT_CARE);
		BooleanOperatorOR bOr3 = new BooleanOperatorOR(varA, varB);
		assertEquals(true, bOr3.getValue().equals(BooleanValue.DONT_CARE));

		varA.setValue(BooleanValue.FALSE);
		BooleanOperatorOR bOr4 = new BooleanOperatorOR(varA, varB);
		assertEquals(true, bOr4.getValue().equals(BooleanValue.DONT_CARE));

		varB.setValue(BooleanValue.FALSE);
		BooleanOperatorOR bOr5 = new BooleanOperatorOR(varA, varB);
		assertEquals(true, bOr5.getValue().equals(BooleanValue.FALSE));

		varA.setValue(BooleanValue.TRUE);
		varB.setValue(BooleanValue.FALSE);
		varC.setValue(BooleanValue.DONT_CARE);
		BooleanOperatorOR bAnd7 = new BooleanOperatorOR(varA, varB, varC);
		assertEquals(true, bAnd7.getValue().equals(BooleanValue.TRUE));

	}
	
	@Test
	public void booleanOperatorsFactory() {
		BooleanVariable varA = new BooleanVariable("A");
		BooleanVariable varB = new BooleanVariable("B");
		BooleanVariable varC = new BooleanVariable("C");
		
		varA.setValue(BooleanValue.TRUE);
		varB.setValue(BooleanValue.TRUE);
		
		BooleanOperator OR = BooleanOperators.or(varA,varB,varC);
		BooleanOperator AND = BooleanOperators.and(varA,varB,varC);
		BooleanOperator NOT = BooleanOperators.not(varA);
		
		assertEquals(BooleanValue.TRUE, OR.getValue());
		assertEquals(BooleanValue.FALSE, AND.getValue());
		assertEquals(BooleanValue.FALSE, NOT.getValue());
		
		varA.setValue(BooleanValue.FALSE);
		
		assertEquals(BooleanValue.TRUE, OR.getValue());
		assertEquals(BooleanValue.FALSE, AND.getValue());
		
	}

}
