package hr.fer.zemris.bool.fimpl;


import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;
import hr.fer.zemris.bool.BooleanValue;
import hr.fer.zemris.bool.BooleanVariable;
import hr.fer.zemris.bool.Mask;
import hr.fer.zemris.bool.Masks;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.Test;

public class MaskBasedBFTest {
	
	 @Test
	 public void createMaskBasedBF() {
	 BooleanVariable varA = new BooleanVariable("A");
	 BooleanVariable varB = new BooleanVariable("B");
	 BooleanVariable varC = new BooleanVariable("C");
	
	 new MaskBasedBF(
	 "f1",
	 Arrays.asList(varA,varB,varC),
	 true,
	 Masks.fromStrings("0x1"),
	 Masks.fromStrings("000")
	 );
	
	 }
	
	 @Test(expected=IllegalArgumentException.class)
	 public void createMaskBasedBFDomainNull() {
	 List<BooleanVariable> domain = null;
	
	 new MaskBasedBF(
	 "f1",
	 domain,
	 true,
	 Masks.fromStrings("0x1"),
	 Masks.fromStrings("000")
	 );
	
	 }
	
	@Test(expected=IllegalArgumentException.class)
	public void createMaskBasedBFIndexesNull() {
		BooleanVariable varA = new BooleanVariable("A");
		BooleanVariable varB = new BooleanVariable("B");
		
		List<Mask> ind = null;
		
		new MaskBasedBF(
				"f1",
				Arrays.asList(varA,varB),
				true,
				ind, 
				Masks.fromStrings("000")
			);
	
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void createMaskBasedBFDontCaresNull() {
		BooleanVariable varA = new BooleanVariable("A");
		BooleanVariable varB = new BooleanVariable("B");
		
		List<Mask> ind = null;
		
		new MaskBasedBF(
				"f1",
				Arrays.asList(varA,varB),
				true,
				Masks.fromStrings("0x1"), 
				ind
			);
	
	}
	
	
	@Test(expected=IllegalArgumentException.class)
	public void createMaskBasedBFNameNull() {
		BooleanVariable varA = new BooleanVariable("A");
		BooleanVariable varB = new BooleanVariable("B");
		
		String name = null;
		
		new MaskBasedBF(
				name,
				Arrays.asList(varA,varB),
				true,
				Masks.fromStrings("0x1"), 
				Masks.fromStrings("000")
			);
	
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void createMaskBasedBFNameEmpty() {
		BooleanVariable varA = new BooleanVariable("A");
		BooleanVariable varB = new BooleanVariable("B");
		
		String name = "";
		
		new MaskBasedBF(
				name,
				Arrays.asList(varA,varB),
				true,
				Masks.fromStrings("0x1"), 
				Masks.fromStrings("000")
			);
	
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void createMaskBasedBFOverlapping() {
		BooleanVariable varA = new BooleanVariable("A");
		BooleanVariable varB = new BooleanVariable("B");
		
		new MaskBasedBF(
				"f1",
				Arrays.asList(varA,varB),
				true,
				Masks.fromStrings("0x1"), 
				Masks.fromStrings("00x")
			);
	
	}
		
	@Test(expected=IllegalArgumentException.class)
	public void createMaskBasedBFDuplicatesDontCares() {
		BooleanVariable varA = new BooleanVariable("A");
		BooleanVariable varB = new BooleanVariable("B");
		
		new MaskBasedBF(
				"f1",
				Arrays.asList(varA,varB),
				true,
				Masks.fromStrings("0x1"), 
				Masks.fromStrings("000","000")
			);
	
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void createMaskBasedBFDuplicatesIndexes() {
		BooleanVariable varA = new BooleanVariable("A");
		BooleanVariable varB = new BooleanVariable("B");
		
		new MaskBasedBF(
				"f1",
				Arrays.asList(varA,varB),
				true,
				Masks.fromStrings("0x1","001"), 
				Masks.fromStrings("000")
			);
	
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void createMaskBasedBFDuplicatesDomain() {
		BooleanVariable varA = new BooleanVariable("A");
		BooleanVariable varB = new BooleanVariable("B");
		
		new MaskBasedBF(
				"f1",
				Arrays.asList(varA,varB,varA),
				true,
				Masks.fromStrings("0x1"), 
				Masks.fromStrings("000")
			);
	
	}
	
	@Test
	public void getName() {
		BooleanVariable varA = new BooleanVariable("A");
		BooleanVariable varB = new BooleanVariable("B");
		BooleanVariable varC = new BooleanVariable("C");
		
		MaskBasedBF bf = new MaskBasedBF(
				"f1",
				Arrays.asList(varA,varB,varC),
				true,
				Masks.fromStrings("0x1"), 
				Masks.fromStrings("000")
			);
		
		assertEquals("f1", bf.getName());
	}
	
	@Test
	public void getDomain() {
		BooleanVariable varA = new BooleanVariable("A");
		BooleanVariable varB = new BooleanVariable("B");
		BooleanVariable varC = new BooleanVariable("C");
		
		MaskBasedBF bf = new MaskBasedBF(
				"f1",
				Arrays.asList(varA,varB,varC),
				true,
				Masks.fromStrings("0x1"), 
				Masks.fromStrings("000")
			);
		
		assertArrayEquals(Arrays.asList(varA,varB,varC).toArray(), bf.getDomain().toArray());
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void hasMinterIndexNegative() {
		BooleanVariable varA = new BooleanVariable("A");
		BooleanVariable varB = new BooleanVariable("B");
		BooleanVariable varC = new BooleanVariable("C");
		MaskBasedBF bf = new MaskBasedBF(
				"f1",
				Arrays.asList(varA,varB,varC),
				true,
				Masks.fromStrings("0x1"), 
				Masks.fromStrings("000")
			);
		
		bf.hasMaxterm(-1);
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void hasMinterIndexTooBig() {
		BooleanVariable varA = new BooleanVariable("A");
		BooleanVariable varB = new BooleanVariable("B");
		
		MaskBasedBF bf = new MaskBasedBF(
				"f1",
				Arrays.asList(varA,varB),
				true,
				Masks.fromStrings("0x1"), 
				Masks.fromStrings("000")
			);
		
		bf.hasMaxterm(17);
	}
	
	@Test
	public void hasMinterMinterms() {
		BooleanVariable varA = new BooleanVariable("A");
		BooleanVariable varB = new BooleanVariable("B");
		BooleanVariable varC = new BooleanVariable("C");
		
		MaskBasedBF bf = new MaskBasedBF(
				"f1",
				Arrays.asList(varA,varB,varC),
				true,
				Masks.fromStrings("0x1"), 
				Masks.fromStrings("000")
			);
		
		assertEquals(true,bf.hasMinterm(1));
		assertEquals(true,bf.hasMinterm(3));
	}
	
	@Test
	public void hasMinterMaxterms() {
		BooleanVariable varA = new BooleanVariable("A");
		BooleanVariable varB = new BooleanVariable("B");
		BooleanVariable varC = new BooleanVariable("C");
		
		MaskBasedBF bf = new MaskBasedBF(
				"f1",
				Arrays.asList(varA,varB,varC),
				false,
				Masks.fromStrings("0x1"), 
				Masks.fromStrings("000")
			);
		
		assertEquals(true,bf.hasMinterm(2));
	}
	
	@Test
	public void hasMaxtermMaxterms() {
		BooleanVariable varA = new BooleanVariable("A");
		BooleanVariable varB = new BooleanVariable("B");
		BooleanVariable varC = new BooleanVariable("C");
		
		MaskBasedBF bf = new MaskBasedBF(
				"f1",
				Arrays.asList(varA,varB,varC),
				false,
				Masks.fromStrings("0x1"), 
				Masks.fromStrings("000")
			);
		
		assertEquals(true,bf.hasMaxterm(1));
		assertEquals(true,bf.hasMaxterm(3));
	}
	
	@Test
	public void hasMaxtermMinterms() {
		BooleanVariable varA = new BooleanVariable("A");
		BooleanVariable varB = new BooleanVariable("B");
		BooleanVariable varC = new BooleanVariable("C");
		
		MaskBasedBF bf = new MaskBasedBF(
				"f1",
				Arrays.asList(varA,varB,varC),
				true,
				Masks.fromStrings("0x1"), 
				Masks.fromStrings("000")
			);
		
		assertEquals(true,bf.hasMaxterm(2));
	}
	
	@Test
	public void hasDontCares() {
		BooleanVariable varA = new BooleanVariable("A");
		BooleanVariable varB = new BooleanVariable("B");
		BooleanVariable varC = new BooleanVariable("C");
		
		MaskBasedBF bf = new MaskBasedBF(
				"f1",
				Arrays.asList(varA,varB,varC),
				true,
				Masks.fromStrings("0x1"), 
				Masks.fromStrings("000")
			);
		
		assertEquals(true,bf.hasDontCare(0));
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void hasDontCaresNegativeIndex() {
		BooleanVariable varA = new BooleanVariable("A");
		BooleanVariable varB = new BooleanVariable("B");
		BooleanVariable varC = new BooleanVariable("C");
		
		MaskBasedBF bf = new MaskBasedBF(
				"f1",
				Arrays.asList(varA,varB,varC),
				true,
				Masks.fromStrings("0x1"), 
				Masks.fromStrings("000")
			);
		
		assertEquals(true,bf.hasDontCare(-2));
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void hasDontCaresIndexTooBig() {
		BooleanVariable varA = new BooleanVariable("A");
		BooleanVariable varB = new BooleanVariable("B");
		BooleanVariable varC = new BooleanVariable("C");
		
		MaskBasedBF bf = new MaskBasedBF(
				"f1",
				Arrays.asList(varA,varB,varC),
				true,
				Masks.fromStrings("0x1"), 
				Masks.fromStrings("000")
			);
		
		assertEquals(true,bf.hasDontCare(8));
	}
	
	@Test
	public void getMintermIterableMinterms() {
		BooleanVariable varA = new BooleanVariable("A");
		BooleanVariable varB = new BooleanVariable("B");
		BooleanVariable varC = new BooleanVariable("C");
		
		MaskBasedBF bf = new MaskBasedBF(
				"f1",
				Arrays.asList(varA,varB,varC),
				true,
				Masks.fromStrings("0x1"), 
				Masks.fromStrings("000")
			);
		
		Iterable<Integer> iterable = bf.mintermIterable();
		
		List<Integer> list =  new ArrayList<>();
		
		for(Integer it: iterable) {
			list.add(it);
		}
		
		assertEquals(2,list.size());
		assertArrayEquals(new Integer[]{1,3}, list.toArray());
	}
	
	@Test
	public void getMintermIterableMaxterms() {
		BooleanVariable varA = new BooleanVariable("A");
		BooleanVariable varB = new BooleanVariable("B");
		BooleanVariable varC = new BooleanVariable("C");
		
		MaskBasedBF bf = new MaskBasedBF(
				"f1",
				Arrays.asList(varA,varB,varC),
				false,
				Masks.fromStrings("0x1"), 
				Masks.fromStrings("000")
			);
		
		Iterable<Integer> iterable = bf.mintermIterable();
		
		List<Integer> list =  new ArrayList<>();
		
		for(Integer it: iterable) {
			list.add(it);
		}
		
		assertEquals(5,list.size());
		assertArrayEquals(new Integer[]{2,4,5,6,7}, list.toArray());
	}
	
	@Test
	public void getMaxtermIterableMaxterms() {
		BooleanVariable varA = new BooleanVariable("A");
		BooleanVariable varB = new BooleanVariable("B");
		BooleanVariable varC = new BooleanVariable("C");
		
		MaskBasedBF bf = new MaskBasedBF(
				"f1",
				Arrays.asList(varA,varB,varC),
				false,
				Masks.fromStrings("0x1"), 
				Masks.fromStrings("000")
			);
		
		Iterable<Integer> iterable = bf.maxtermIterable();
		
		List<Integer> list =  new ArrayList<>();
		
		for(Integer it: iterable) {
			list.add(it);
		}
		
		assertEquals(2,list.size());
		assertArrayEquals(new Integer[]{1,3}, list.toArray());
	}
	
	@Test
	public void getMaxtermIterableMinterms() {
		BooleanVariable varA = new BooleanVariable("A");
		BooleanVariable varB = new BooleanVariable("B");
		BooleanVariable varC = new BooleanVariable("C");
		MaskBasedBF bf = new MaskBasedBF(
				"f1",
				Arrays.asList(varA,varB,varC),
				true,
				Masks.fromStrings("0x1"), 
				Masks.fromStrings("000")
			);
		
		Iterable<Integer> iterable = bf.maxtermIterable();
		
		List<Integer> list =  new ArrayList<>();
		
		for(Integer it: iterable) {
			list.add(it);
		}
		
		assertEquals(5,list.size());
		assertArrayEquals(new Integer[]{2,4,5,6,7}, list.toArray());
	}
	
	@Test
	public void getDontCareIterable() {
		BooleanVariable varA = new BooleanVariable("A");
		BooleanVariable varB = new BooleanVariable("B");
		BooleanVariable varC = new BooleanVariable("C");
		
		MaskBasedBF bf = new MaskBasedBF(
				"f1",
				Arrays.asList(varA,varB,varC),
				true,
				Masks.fromStrings("0x1"), 
				Masks.fromStrings("000")
			);
		
		Iterable<Integer> iterable = bf.dontcareIterable();
		
		List<Integer> list =  new ArrayList<>();
		
		for(Integer it: iterable) {
			list.add(it);
		}
		
		assertEquals(1,list.size());
		assertArrayEquals(new Integer[]{0}, list.toArray());
	}
	
	@Test
	public void getValue() {
		BooleanVariable varA = new BooleanVariable("A");
		BooleanVariable varB = new BooleanVariable("B");
		BooleanVariable varC = new BooleanVariable("C");
		
		MaskBasedBF bf = new MaskBasedBF(
				"f1",
				Arrays.asList(varA,varB,varC),
				true,
				Masks.fromStrings("0x1"), 
				Masks.fromStrings("000")
			);
		
		assertEquals(BooleanValue.FALSE,bf.getValue());
	}
	
	
}
