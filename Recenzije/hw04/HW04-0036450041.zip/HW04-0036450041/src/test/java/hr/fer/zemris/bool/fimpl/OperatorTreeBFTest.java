package hr.fer.zemris.bool.fimpl;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;
import hr.fer.zemris.bool.BooleanConstant;
import hr.fer.zemris.bool.BooleanOperator;
import hr.fer.zemris.bool.BooleanValue;
import hr.fer.zemris.bool.BooleanVariable;
import hr.fer.zemris.bool.opimpl.BooleanOperators;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.Test;

public class OperatorTreeBFTest {

	@Test
	public void createOperatorTreeBF() {
		BooleanVariable varA = new BooleanVariable("A");
		BooleanVariable varB = new BooleanVariable("B");
		BooleanVariable varC = new BooleanVariable("C");

		BooleanOperator operator = BooleanOperators.or(BooleanConstant.FALSE,
				varC, BooleanOperators.and(varA, BooleanOperators.not(varB)));

		new OperatorTreeBF("f1", Arrays.asList(varA, varB, varC), operator);

	}

	@Test(expected = IllegalArgumentException.class)
	public void createOperatorTreeBFDomainNull() {
		List<BooleanVariable> domain = null;

		BooleanVariable varA = new BooleanVariable("A");
		BooleanVariable varB = new BooleanVariable("B");
		BooleanVariable varC = new BooleanVariable("C");

		BooleanOperator operator = BooleanOperators.or(BooleanConstant.FALSE,
				varC, BooleanOperators.and(varA, BooleanOperators.not(varB)));

		new OperatorTreeBF("f1", domain, operator);

	}

	@Test(expected = IllegalArgumentException.class)
	public void createOperatorTreeBFOperatorNull() {
		BooleanVariable varA = new BooleanVariable("A");
		BooleanVariable varB = new BooleanVariable("B");
		BooleanVariable varC = new BooleanVariable("C");

		BooleanOperator operator = null;

		new OperatorTreeBF("f1", Arrays.asList(varA, varB, varC), operator);

	}

	@Test(expected = IllegalArgumentException.class)
	public void createOperatorTreeBFNameNull() {
		BooleanVariable varA = new BooleanVariable("A");
		BooleanVariable varB = new BooleanVariable("B");
		BooleanVariable varC = new BooleanVariable("C");

		String name = null;

		BooleanOperator operator = BooleanOperators.or(BooleanConstant.FALSE,
				varC, BooleanOperators.and(varA, BooleanOperators.not(varB)));
		new OperatorTreeBF(name, Arrays.asList(varA, varB, varC), operator);

	}

	@Test(expected = IllegalArgumentException.class)
	public void createOperatorTreeBFNameEmpty() {
		BooleanVariable varA = new BooleanVariable("A");
		BooleanVariable varB = new BooleanVariable("B");
		BooleanVariable varC = new BooleanVariable("C");

		String name = "   ";

		BooleanOperator operator = BooleanOperators.or(BooleanConstant.FALSE,
				varC, BooleanOperators.and(varA, BooleanOperators.not(varB)));
		new OperatorTreeBF(name, Arrays.asList(varA, varB, varC), operator);

	}

	@Test(expected = IllegalArgumentException.class)
	public void createOperatorTreeBFDuplicatesDomain() {

		BooleanVariable varA = new BooleanVariable("A");
		BooleanVariable varB = new BooleanVariable("B");
		BooleanVariable varC = new BooleanVariable("C");

		BooleanOperator operator = BooleanOperators.or(BooleanConstant.FALSE,
				varC, BooleanOperators.and(varA, BooleanOperators.not(varB)));
		new OperatorTreeBF("f1", Arrays.asList(varA, varB, varC, varA),
				operator);

	}

	@Test
	public void getName() {
		BooleanVariable varA = new BooleanVariable("A");
		BooleanVariable varB = new BooleanVariable("B");
		BooleanVariable varC = new BooleanVariable("C");

		BooleanOperator operator = BooleanOperators.or(BooleanConstant.FALSE,
				varC, BooleanOperators.and(varA, BooleanOperators.not(varB)));
		OperatorTreeBF bf = new OperatorTreeBF("f1", Arrays.asList(varA, varB,
				varC), operator);

		assertEquals("f1", bf.getName());
	}

	@Test
	public void getDomain() {
		BooleanVariable varA = new BooleanVariable("A");
		BooleanVariable varB = new BooleanVariable("B");
		BooleanVariable varC = new BooleanVariable("C");

		BooleanOperator operator = BooleanOperators.or(BooleanConstant.FALSE,
				varC, BooleanOperators.and(varA, BooleanOperators.not(varB)));
		OperatorTreeBF bf = new OperatorTreeBF("f1", Arrays.asList(varA, varB,
				varC), operator);

		assertArrayEquals(Arrays.asList(varA, varB, varC).toArray(), bf
				.getDomain().toArray());
	}

	@Test(expected = IllegalArgumentException.class)
	public void hasMinterIndexNegative() {
		BooleanVariable varA = new BooleanVariable("A");
		BooleanVariable varB = new BooleanVariable("B");
		BooleanVariable varC = new BooleanVariable("C");

		BooleanOperator operator = BooleanOperators.or(BooleanConstant.FALSE,
				varC, BooleanOperators.and(varA, BooleanOperators.not(varB)));
		OperatorTreeBF bf = new OperatorTreeBF("f1", Arrays.asList(varA, varB,
				varC), operator);

		bf.hasMinterm(-1);
	}

	@Test(expected = IllegalArgumentException.class)
	public void hasMinterIndexTooBig() {
		BooleanVariable varA = new BooleanVariable("A");
		BooleanVariable varB = new BooleanVariable("B");
		BooleanVariable varC = new BooleanVariable("C");

		BooleanOperator operator = BooleanOperators.or(BooleanConstant.FALSE,
				varC, BooleanOperators.and(varA, BooleanOperators.not(varB)));
		OperatorTreeBF bf = new OperatorTreeBF("f1", Arrays.asList(varA, varB,
				varC), operator);
		bf.hasMinterm(17);
	}
	
	@Test(expected = IllegalArgumentException.class)
	public void hasMaxtermIndexNegative() {
		BooleanVariable varA = new BooleanVariable("A");
		BooleanVariable varB = new BooleanVariable("B");
		BooleanVariable varC = new BooleanVariable("C");

		BooleanOperator operator = BooleanOperators.or(BooleanConstant.FALSE,
				varC, BooleanOperators.and(varA, BooleanOperators.not(varB)));
		OperatorTreeBF bf = new OperatorTreeBF("f1", Arrays.asList(varA, varB,
				varC), operator);

		bf.hasMaxterm(-1);
	}

	@Test(expected = IllegalArgumentException.class)
	public void hasMaxtermIndexTooBig() {
		BooleanVariable varA = new BooleanVariable("A");
		BooleanVariable varB = new BooleanVariable("B");
		BooleanVariable varC = new BooleanVariable("C");

		BooleanOperator operator = BooleanOperators.or(BooleanConstant.FALSE,
				varC, BooleanOperators.and(varA, BooleanOperators.not(varB)));
		OperatorTreeBF bf = new OperatorTreeBF("f1", Arrays.asList(varA, varB,
				varC), operator);
		bf.hasMaxterm(17);
	}

	@Test
	public void hasMinterms() {
		BooleanVariable varA = new BooleanVariable("A");
		BooleanVariable varB = new BooleanVariable("B");
		BooleanVariable varC = new BooleanVariable("C");

		BooleanOperator operator = BooleanOperators.or(BooleanConstant.FALSE,
				varC, BooleanOperators.and(varA, BooleanOperators.not(varB)));
		OperatorTreeBF bf = new OperatorTreeBF("f1", Arrays.asList(varA, varB,
				varC), operator);

		assertEquals(true, bf.hasMinterm(1));
		assertEquals(true, bf.hasMinterm(3));
		assertEquals(true, bf.hasMinterm(4));
		assertEquals(true, bf.hasMinterm(5));
		assertEquals(true, bf.hasMinterm(7));
	}

	@Test
	public void hasMaxterms() {
		BooleanVariable varA = new BooleanVariable("A");
		BooleanVariable varB = new BooleanVariable("B");
		BooleanVariable varC = new BooleanVariable("C");

		BooleanOperator operator = BooleanOperators.or(BooleanConstant.FALSE,
				varC, BooleanOperators.and(varA, BooleanOperators.not(varB)));
		OperatorTreeBF bf = new OperatorTreeBF("f1", Arrays.asList(varA, varB,
				varC), operator);

		assertEquals(true, bf.hasMaxterm(0));
		assertEquals(true, bf.hasMaxterm(2));
		assertEquals(true, bf.hasMaxterm(6));
	}

	@Test
	public void hasDontCares() {
		BooleanVariable varA = new BooleanVariable("A");
		BooleanVariable varB = new BooleanVariable("B");
		BooleanVariable varC = new BooleanVariable("C");

		BooleanOperator operator = BooleanOperators.or(BooleanConstant.FALSE,
				varC, BooleanOperators.and(varA, BooleanOperators.not(varB)));
		OperatorTreeBF bf = new OperatorTreeBF("f1", Arrays.asList(varA, varB,
				varC), operator);

		assertEquals(false, bf.hasDontCare(0));
	}

	@Test(expected = IllegalArgumentException.class)
	public void hasDontCaresNegativeIndex() {
		BooleanVariable varA = new BooleanVariable("A");
		BooleanVariable varB = new BooleanVariable("B");
		BooleanVariable varC = new BooleanVariable("C");

		BooleanOperator operator = BooleanOperators.or(BooleanConstant.FALSE,
				varC, BooleanOperators.and(varA, BooleanOperators.not(varB)));
		OperatorTreeBF bf = new OperatorTreeBF("f1", Arrays.asList(varA, varB,
				varC), operator);

		assertEquals(true, bf.hasDontCare(-2));
	}

	@Test(expected = IllegalArgumentException.class)
	public void hasDontCaresIndexTooBig() {
		BooleanVariable varA = new BooleanVariable("A");
		BooleanVariable varB = new BooleanVariable("B");
		BooleanVariable varC = new BooleanVariable("C");

		BooleanOperator operator = BooleanOperators.or(BooleanConstant.FALSE,
				varC, BooleanOperators.and(varA, BooleanOperators.not(varB)));
		OperatorTreeBF bf = new OperatorTreeBF("f1", Arrays.asList(varA, varB,
				varC), operator);

		assertEquals(true, bf.hasDontCare(8));
	}

	@Test
	public void getMintermIterable() {
		BooleanVariable varA = new BooleanVariable("A");
		BooleanVariable varB = new BooleanVariable("B");
		BooleanVariable varC = new BooleanVariable("C");

		BooleanOperator operator = BooleanOperators.or(BooleanConstant.FALSE,
				varC, BooleanOperators.and(varA, BooleanOperators.not(varB)));
		OperatorTreeBF bf = new OperatorTreeBF("f1", Arrays.asList(varA, varB,
				varC), operator);

		Iterable<Integer> iterable = bf.mintermIterable();

		List<Integer> list = new ArrayList<>();

		for (Integer it : iterable) {
			list.add(it);
		}

		assertEquals(5, list.size());
		assertArrayEquals(new Integer[] { 1, 3, 4, 5, 7 }, list.toArray());
	}

	@Test
	public void getMaxtermIterable() {
		BooleanVariable varA = new BooleanVariable("A");
		BooleanVariable varB = new BooleanVariable("B");
		BooleanVariable varC = new BooleanVariable("C");

		BooleanOperator operator = BooleanOperators.or(BooleanConstant.FALSE,
				varC, BooleanOperators.and(varA, BooleanOperators.not(varB)));
		OperatorTreeBF bf = new OperatorTreeBF("f1", Arrays.asList(varA, varB,
				varC), operator);

		Iterable<Integer> iterable = bf.maxtermIterable();

		List<Integer> list = new ArrayList<>();

		for (Integer it : iterable) {
			list.add(it);
		}

		assertEquals(3, list.size());
		assertArrayEquals(new Integer[] { 0, 2, 6 }, list.toArray());
	}

	@Test
	public void getDontCareIterable() {
		BooleanVariable varA = new BooleanVariable("A");
		BooleanVariable varB = new BooleanVariable("B");
		BooleanVariable varC = new BooleanVariable("C");

		BooleanOperator operator = BooleanOperators.or(BooleanConstant.FALSE,
				varC, BooleanOperators.and(varA, BooleanOperators.not(varB)));
		OperatorTreeBF bf = new OperatorTreeBF("f1", Arrays.asList(varA, varB,
				varC), operator);

		Iterable<Integer> iterable = bf.dontcareIterable();

		List<Integer> list = new ArrayList<>();

		for (Integer it : iterable) {
			list.add(it);
		}

		assertEquals(0, list.size());
	}

	@Test
	public void getValue() {

		BooleanVariable varA = new BooleanVariable("A");
		BooleanVariable varB = new BooleanVariable("B");
		BooleanVariable varC = new BooleanVariable("C");

		BooleanOperator operator = BooleanOperators.or(BooleanConstant.FALSE,
				varC, BooleanOperators.and(varA, BooleanOperators.not(varB)));
		OperatorTreeBF bf = new OperatorTreeBF("f1", Arrays.asList(varA, varB,
				varC), operator);

		assertEquals(BooleanValue.FALSE, bf.getValue());
	}
	
	@Test
	public void getValueTrue() {

		BooleanVariable varA = new BooleanVariable("A");
		BooleanVariable varB = new BooleanVariable("B");
		BooleanVariable varC = new BooleanVariable("C");

		varA.setValue(BooleanValue.TRUE);
		varB.setValue(BooleanValue.TRUE);
		varC.setValue(BooleanValue.TRUE);
		BooleanOperator operator = BooleanOperators.or(BooleanConstant.FALSE,
				varC, BooleanOperators.and(varA, BooleanOperators.not(varB)));
		OperatorTreeBF bf = new OperatorTreeBF("f1", Arrays.asList(varA, varB,
				varC), operator);

		assertEquals(BooleanValue.TRUE, bf.getValue());
	}
}
