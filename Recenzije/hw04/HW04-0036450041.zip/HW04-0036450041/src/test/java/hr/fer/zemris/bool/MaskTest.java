package hr.fer.zemris.bool;

import java.util.List;

import org.junit.Test;

import static org.junit.Assert.*;

public class MaskTest {

	@Test
	public void createMask() {
		MaskValue[] values = {MaskValue.ONE, MaskValue.ZERO, MaskValue.DONT_CARE};
		new Mask(values);
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void indexesFromMaskNull() {
		Mask.indexesFromMasks(null);
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void createMaskWithNullValues() {
		MaskValue[] values = {MaskValue.ONE, MaskValue.ZERO, MaskValue.DONT_CARE,null};
		new Mask(values);
	}
	
	@Test
	public void getValue() {
		MaskValue[] values = {MaskValue.ONE, MaskValue.ZERO, MaskValue.DONT_CARE};
		Mask mask = new Mask(values);
		assertEquals(MaskValue.ONE,mask.getValue(0));
	}
	
	@Test(expected=IndexOutOfBoundsException.class)
	public void getValueNegativeIndex() {
		MaskValue[] values = {MaskValue.ONE, MaskValue.ZERO, MaskValue.DONT_CARE};
		Mask mask = new Mask(values);
		mask.getValue(-1);
	}
	
	@Test(expected=IndexOutOfBoundsException.class)
	public void getValueIndexTooBig() {
		MaskValue[] values = {MaskValue.ONE, MaskValue.ZERO, MaskValue.DONT_CARE};
		Mask mask = new Mask(values);
		mask.getValue(5);
	}
	
	@Test
	public void createMaskParse() {
		Mask mask = Mask.parse("01x");
		
		assertEquals(MaskValue.ZERO, mask.getValue(0));
		assertEquals(MaskValue.ONE, mask.getValue(1));
		assertEquals(MaskValue.DONT_CARE, mask.getValue(2));
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void createMaskParseIllegalString() {
		Mask.parse("01xC");
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void createMaskParseEmptyString() {
		Mask.parse("");
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void createMaskParseNullString() {
		String s = null;
		Mask.parse(s);
	}
	
	@Test
	public void isMoreGeneralTrue() {
		Mask mask1 = Mask.parse("11x");
		Mask mask2 = Mask.parse("111");
		Mask mask3 = Mask.parse("110");
		Mask mask4 = Mask.parse("xx0");
	
		assertEquals(true, mask1.isMoreGeneralThan(mask2));
		assertEquals(true, mask1.isMoreGeneralThan(mask3));
		assertEquals(true, mask4.isMoreGeneralThan(mask3));
		assertEquals(false, mask3.isMoreGeneralThan(mask4));
	
	}
	
	@Test
	public void isMoreGeneralFalse() {
		Mask mask1 = Mask.parse("111");
		Mask mask2 = Mask.parse("110");
		Mask mask3 = Mask.parse("0x0");
		Mask mask4 = Mask.parse("0x000x");
		Mask mask5 = Mask.parse("xxxx");
		Mask mask6 = Mask.parse("xxxx");
	
		assertEquals(false, mask1.isMoreGeneralThan(mask2));
		assertEquals(false, mask2.isMoreGeneralThan(mask1));
		assertEquals(false, mask3.isMoreGeneralThan(mask2));
		assertEquals(false, mask4.isMoreGeneralThan(mask3));
		assertEquals(false, mask5.isMoreGeneralThan(mask5));
		assertEquals(false, mask5.isMoreGeneralThan(mask6));	
	}
	
	@Test
	public void equals() {
		Mask mask1 = Mask.parse("111");
		Mask mask3 = Mask.parse("101");
		Mask mask4 = Mask.parse("111");
		Mask mask2 = null;
		BooleanValue value = BooleanValue.TRUE;
		
		assertEquals(true, mask1.equals(mask1));
		assertEquals(true, mask1.equals(mask4));
		assertEquals(false, mask1.equals(mask2));
		assertEquals(false, mask1.equals(value));
		assertEquals(false, mask1.equals(mask3));
	}
	
	@Test
	public void getSize() {
		Mask mask1 = Mask.parse("111");
		Mask mask2 = Mask.parse("1x10");
		
		assertEquals(3,mask1.getSize());
		assertEquals(4,mask2.getSize());
	}
	
	@Test
	public void combine() {
		Mask mask1 = Mask.parse("111");
		Mask mask2 = Mask.parse("110");
		
		assertEquals(Mask.combine(mask1, mask2), Mask.parse("11x"));
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void combineDifferentLength() {
		Mask mask1 = Mask.parse("111000");
		Mask mask2 = Mask.parse("110");
		
		Mask.combine(mask1, mask2);
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void combineFirstNull() {
		Mask mask1 = null;
		Mask mask2 = Mask.parse("110");
		
		Mask.combine(mask1, mask2);
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void combineSecondNull() {
		Mask mask2 = null;
		Mask mask1 = Mask.parse("110");
		
		Mask.combine(mask1, mask2);
	}
	
	@Test
	public void combineMoreGeneral() {
		Mask mask1 = Mask.parse("110");
		Mask mask2 = Mask.parse("110");
		
		assertEquals(null, Mask.combine(mask1, mask2));
	}
	
	@Test
	public void createFromIndex() {
		Mask mask1 = Mask.fromIndex(5, 3);
		Mask mask2 = Mask.fromIndex(5, 10);
		
		assertEquals(Mask.parse("00011"), mask1);
		assertEquals(Mask.parse("01010"), mask2);
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void createFromIndexIndexBiggerThanSize() {
		Mask.fromIndex(2, 4);
	}
	
	@Test
	public void getNumberOfOnes() {
		Mask mask = Mask.parse("110");
		
		assertEquals(2, mask.getNumberOfOnes());
	}
	
	@Test
	public void getNumberOfZeros() {
		Mask mask = Mask.parse("110");
		
		assertEquals(1, mask.getNumberOfZeros());
	}
	
	@Test
	public void hashCodeTest() {
		Mask mask1 = Mask.parse("110");
		
		assertEquals(mask1.hashCode(), mask1.hashCode());
	}
	@Test
	public void toStringTest() {
		String s = "10101xx1";
		
		Mask mask = Mask.parse(s);
		
		assertEquals(true, mask.toString().equals(s));
	}
	
	@Test
	public void masksFromIndexes() {
		List<Mask> masks = Masks.fromIndexes(3,1,2,3);
		
		assertEquals("001", masks.get(0).toString());
		assertEquals("010", masks.get(1).toString());
		assertEquals("011", masks.get(2).toString());
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void masksFromIndexesTooFewArguments() {
		Masks.fromIndexes(3);
	}
	
	@Test
	public void masksFromStrings() {
		List<Mask> masks = Masks.fromStrings("010","xx0x","0010");
		
		assertEquals("010", masks.get(0).toString());
		assertEquals("xx0x", masks.get(1).toString());
		assertEquals("0010", masks.get(2).toString());
	}
	@Test
	public void maskEqualsDifferentSize() {
		List<Mask> masks = Masks.fromStrings("010","xx0x","0010");
		
		assertNotEquals(masks.get(1), masks.get(0));
		
	}
	
	@Test
	public void maskEquals() {
		List<Mask> masks = Masks.fromStrings("010","xx0","0010");
		
		assertEquals(masks.get(1), masks.get(0));
		
	}
	

	
}
