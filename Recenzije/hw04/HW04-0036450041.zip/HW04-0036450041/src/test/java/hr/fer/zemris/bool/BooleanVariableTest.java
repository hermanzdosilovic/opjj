package hr.fer.zemris.bool;

import hr.fer.zemris.bool.BooleanValue;
import hr.fer.zemris.bool.BooleanVariable;

import org.junit.Test;
import static org.junit.Assert.*;

public class BooleanVariableTest {

	@Test
	public void createVariable() {
		BooleanVariable falseA = new BooleanVariable("A");

		assertEquals("A", falseA.getName());
		assertEquals(BooleanValue.FALSE, falseA.getValue());
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void createVariableEmptyName() {
		new BooleanVariable("");
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void createVariableNullName() {
		String s = null;
		new BooleanVariable(s);
	}

	@Test
	public void setValue() {
		BooleanVariable trueB = new BooleanVariable("B");
		trueB.setValue(BooleanValue.TRUE);

		assertEquals("B", trueB.getName());
		assertEquals(BooleanValue.TRUE, trueB.getValue());
	}
	
	@Test
	public void equalsTest(){
		BooleanVariable falseA = new BooleanVariable("A");
		BooleanVariable falseB = new BooleanVariable("A");
		BooleanVariable falseC = new BooleanVariable("C");
		
		assertEquals(true, falseA.equals(falseB));
		assertEquals(false, falseA.equals(falseC));
		
		falseB.setValue(BooleanValue.TRUE);
		assertEquals(true, falseA.equals(falseB));
		
		falseB.setValue(BooleanValue.DONT_CARE);
		assertEquals(true, falseA.equals(falseB));
	}
	
	@Test
	public void hashCodeTest() {
		BooleanVariable falseA = new BooleanVariable("A");
		BooleanVariable falseB = new BooleanVariable("A");
		BooleanVariable falseC = new BooleanVariable("C");
		
		assertEquals(falseA.hashCode(), falseB.hashCode());
		assertNotEquals(falseA.hashCode(), falseC.hashCode());
		
	}
	
	@Test
	public void hachCodeEmptyNull() {
		BooleanVariable falseA = null;
		BooleanVariable falseB = new BooleanVariable("B");
		
		assertEquals(false,falseB.equals(falseA));		
	}
	
	@Test
	public void hachCodeWrongClass() {
		BooleanSource falseA = new BooleanOperator();
		BooleanVariable falseB = new BooleanVariable("B");
		
		assertEquals(false,falseB.equals(falseA));		
	}
	
	@Test
	public void booleanValuesValuesMethod() {
		BooleanValue.values();
	}
	
	@Test
	public void booleanValuesValueOfMethod() {
		BooleanValue trueValue = BooleanValue.valueOf("TRUE");
		
		assertEquals(BooleanValue.TRUE,trueValue);
	}
	
}
