package hr.fer.zemris.bool.fimpl;

import hr.fer.zemris.bool.BooleanFunction;
import hr.fer.zemris.bool.BooleanValue;
import hr.fer.zemris.bool.BooleanVariable;
import hr.fer.zemris.bool.Mask;

import java.util.List;

/**
 * Class implements operator function based on masks.
 * 
 * @author Viktor Berger
 * @version 1.0
 */
public class MaskBasedBF implements BooleanFunction {

	/**
	 * Private instance of an indexed function which internally handles all
	 * operations. This is an adaptee in the adapter design pattern.
	 */
	private IndexedBF privateIndexedFunction;

	/**
	 * /** Creates a new mask based boolean function based on provided
	 * parameters.
	 * 
	 * @param name
	 *            name of the function.
	 * @param domain
	 *            domain of the function.
	 * @param masksAreMinterms
	 *            <code>true</code> if indexes are minterms, <code>false</code>
	 *            otherwise
	 * @param masks
	 *            a list of masks.
	 * @param dontCareMasks
	 *            a list of dontCare masks.
	 * @throws IllegalArgumentException
	 *             if:
	 *             <ul>
	 *             <li>masks and dontCareMasks lists overlap.</li>
	 *             <li>arguments are null references</li>
	 *             <li>name is empty string</li>
	 *             <li>lists contain duplicate elements</li>
	 *             <li>masks are of the wrong size</li>
	 *             </ul>
	 */
	public MaskBasedBF(String name, List<BooleanVariable> domain,
			boolean masksAreMinterms, List<Mask> masks, List<Mask> dontCareMasks) {

		if (name == null || domain == null || masks == null
				|| dontCareMasks == null || domain.contains(null)
				|| masks.contains(null) || dontCareMasks.contains(null)) {
			throw new IllegalArgumentException(
					"Argument cannot be null or contain null.");
		}

		if (wrongSize(masks, domain.size())
				|| wrongSize(dontCareMasks, domain.size())) {
			throw new IllegalArgumentException("masks or don't care masks are out of domain!");
		}
		privateIndexedFunction = new IndexedBF(name, domain, masksAreMinterms,
				Mask.indexesFromMasks(masks),
				Mask.indexesFromMasks(dontCareMasks));

	}

	@Override
	public String getName() {
		return privateIndexedFunction.getName();
	}

	@Override
	public BooleanValue getValue() {
		return privateIndexedFunction.getValue();
	}

	@Override
	public List<BooleanVariable> getDomain() {
		return privateIndexedFunction.getDomain();
	}

	@Override
	public boolean hasMinterm(int index) {
		return privateIndexedFunction.hasMinterm(index);
	}

	@Override
	public boolean hasMaxterm(int index) {
		return privateIndexedFunction.hasMaxterm(index);
	}

	@Override
	public boolean hasDontCare(int index) {
		return privateIndexedFunction.hasDontCare(index);
	}

	@Override
	public Iterable<Integer> mintermIterable() {
		return privateIndexedFunction.mintermIterable();
	}

	@Override
	public Iterable<Integer> maxtermIterable() {
		return privateIndexedFunction.maxtermIterable();
	}

	@Override
	public Iterable<Integer> dontcareIterable() {
		return privateIndexedFunction.dontcareIterable();
	}

	/**
	 * Checks if all the masks in the list are of the same size as the domain.
	 * 
	 * @param list
	 *            list which contains masks.
	 * @param size
	 *            size of the domain.
	 * @return <code>true</code> if list contains a mask of the wring size,
	 *         <code>false</code> otherwise.
	 */
	private boolean wrongSize(List<Mask> list, int size) {
		for (Mask mask : list) {
			if (mask.getSize() != size) {
				return true;
			}
		}
		return false;
	}

}
