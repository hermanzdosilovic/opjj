package hr.fer.zemris.java.tecaj.hw4.db;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Class provides a command line interface for work with student database
 * emulator. It accepts queries and prints query results in form of a table.
 * 
 * @author Viktor Berger
 * @version 1.0
 */
public class StudentDB {

	/** pattern of a valid query. */
	private static Pattern queryPattern = Pattern
			.compile("\\s*query\\s*(\\w+)\\s*=\\s*\"([ \\p{L}\\*]+|\\d+)\"|exit");

	/**
	 * Main method which is the entry point of this program.
	 * 
	 * @param args
	 *            not used
	 */
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in, "utf8");
		List<String> lines = null;

		try {
			lines = Files.readAllLines(Paths.get("./database.txt"),
					StandardCharsets.UTF_8);
		} catch (IOException e) {
			System.err.println("Cannot read from the file!");
			System.exit(1);
		}

		StudentDatabase database = null;
		try {
			database = new StudentDatabase(lines);
		} catch (StudentDatabaseException e) {
			System.out.println(e.getMessage());
			System.exit(1);
		}
		Matcher matcher;
		IFilter filter;
		List<StudentRecord> queryResult;

		System.out.print("> ");
		while (scanner.hasNext()) {

			String query = scanner.nextLine();
			matcher = queryPattern.matcher(query);

			if (matcher.find()) {

				if (matcher.group(0).equals("exit")) {
					System.out.println("Bye!");
					scanner.close();
					return;
				}

				String command = matcher.group(1);
				String argument = matcher.group(2);

				if (command.equals("lastName")) {
					filter = new LastNameFilter(argument);
					queryResult = database.filter(filter);
				} else if (command.equals("jmbag")) {
					queryResult = new ArrayList<>();
					StudentRecord record = database.forJMBAG(argument);
					if (record != null) {
						queryResult.add(record);
					}
				} else {
					System.err.println("Unknown condition: " + command);
					continue;
				}

				printResult(queryResult);

			} else {
				System.out.println("Unknown command!");
			}

			System.out.print("> ");

		}
		scanner.close();

	}

	/**
	 * Prints result of the query in form of a table.
	 * 
	 * @param records
	 *            list of student records produced by filtering the database.
	 */
	private static void printResult(List<StudentRecord> records) {
		int numberOfRecords = records.size();
		if (numberOfRecords != 0) {

			int padding = 2;
			int jmbagLength = 10;
			int gradeLength = 1;
			int firstNameLength = 0;
			int lastNameLength = 0;

			for (StudentRecord record : records) {
				int currFirstNameLen = record.getFirstName().length();
				int currLastNameLen = record.getLastName().length();

				if (currLastNameLen > lastNameLength) {
					lastNameLength = currLastNameLen;
				}
				if (currFirstNameLen > firstNameLength) {
					firstNameLength = currFirstNameLen;
				}
			}

			jmbagLength += padding;
			gradeLength += padding;
			firstNameLength += padding;
			lastNameLength += padding;

			// creating header and footer for the table
			StringBuffer bound = new StringBuffer();
			bound.append("+");
			for (int i = 0; i < jmbagLength; i++) {
				bound.append("=");
			}
			bound.append("+");
			for (int i = 0; i < lastNameLength; i++) {
				bound.append("=");
			}
			bound.append("+");
			for (int i = 0; i < firstNameLength; i++) {
				bound.append("=");
			}
			bound.append("+");
			for (int i = 0; i < gradeLength; i++) {
				bound.append("=");
			}
			bound.append("+");
			String tableBound = bound.toString();

			String recordFormat = "| %" + (jmbagLength - padding) + "s | %-"
					+ (lastNameLength - padding) + "s | %-"
					+ (firstNameLength - padding) + "s | %"
					+ (gradeLength - padding) + "s |\n";

			// Printing table
			System.out.println(tableBound);
			for (StudentRecord record : records) {
				System.out.format(recordFormat, record.getJmbag(),
						record.getLastName(), record.getFirstName(),
						record.getGrade());
			}
			System.out.println(tableBound);
		}

		System.out.println("Records selected: " + numberOfRecords);
	}

}
