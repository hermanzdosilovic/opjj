package hr.fer.zemris.bool.opimpl;

import hr.fer.zemris.bool.BooleanOperator;
import hr.fer.zemris.bool.BooleanSource;

/**
 * Factory class which contains static methods for instantiating operators.
 * 
 * @author Viktor Berger
 * @version 1.0
 * 
 */
public final class BooleanOperators {

	/**
	 * This utility class can't be instantiated in a dynamic way. It contains
	 * only static methods.
	 */
	private BooleanOperators() {
	}

	/**
	 * Factory method which creates an instance of logical AND operator.
	 * 
	 * @param sources
	 *            sources on which AND operator will be applied.
	 * @return {@link BooleanOperatorAND} applied on given sources.
	 */
	public static BooleanOperator and(BooleanSource... sources) {
		return new BooleanOperatorAND(sources);
	}

	/**
	 * Factory method which creates an instance of logical OR operator.
	 * 
	 * @param sources
	 *            sources on which OR operator will be applied.
	 * @return {@link BooleanOperatorOR} applied on given sources.
	 */
	public static BooleanOperator or(BooleanSource... sources) {
		return new BooleanOperatorOR(sources);
	}

	/**
	 * Factory method which creates an instance of logical NOT operator.
	 * 
	 * @param source
	 *            sources on which NOT operator will be applied.
	 * @return {@link BooleanOperatorNOT} applied on given sources.
	 */
	public static BooleanOperator not(BooleanSource source) {
		return new BooleanOperatorNOT(source);
	}

}
