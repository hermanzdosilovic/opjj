package hr.fer.zemris.bool;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

public class Mask {

	/** logical values contained in this mask. */
	MaskValue[] values;

	/**
	 * Creates an instance of this class based on provided array of logical
	 * values.
	 * 
	 * @param values
	 *            logical values which serve as basis for construction of this
	 *            mask.
	 * @throws IllegalArgumentException
	 *             if some of the elements in the mask are null elements.
	 */
	public Mask(final MaskValue[] values) {
		for (int i = 0; i < values.length; i++) {
			if (values[i] == null) {
				throw new IllegalArgumentException(
						"Null references are not allowed in mask!");
			}
		}
		this.values = Arrays.copyOf(values, values.length);
	}

	/**
	 * Returns mask value at given index.
	 * 
	 * @param index
	 *            position of wanted mask value.
	 * @return mask value at given index.
	 * @throws IndexOutOfBoundsException
	 *             if index is out of array bounds.
	 */
	public MaskValue getValue(int index) {
		if (index < 0 || index >= values.length) {
			throw new IndexOutOfBoundsException("Mask index is out of bounds!");
		}
		return values[index];
	}

	/**
	 * Creates new {@link Mask} based on parsed string provided as argument.
	 * 
	 * @param mask
	 *            string for parsing.
	 * @return {@link Mask} created from given string.
	 * @throws IllegalArgumentException
	 *             if string is null, is empty or contains characters other than
	 *             '0', '1' or 'x'.
	 */
	public static Mask parse(String mask) {
		if (null == mask || mask.isEmpty()) {
			throw new IllegalArgumentException("Invalid mask string format!");
		}

		MaskValue[] maskValues = new MaskValue[mask.length()];

		for (int i = 0; i < mask.length(); i++) {
			switch (mask.charAt(i)) {
			case '0':
				maskValues[i] = MaskValue.ZERO;
				break;
			case '1':
				maskValues[i] = MaskValue.ONE;
				break;
			case 'x':
				maskValues[i] = MaskValue.DONT_CARE;
				break;
			default:
				throw new IllegalArgumentException(
						"Invalid mask string format!");
			}
		}

		return new Mask(maskValues);
	}

	/**
	 * Compares this mask with the one in the argument and tells which one is
	 * more general.
	 * 
	 * @param other
	 *            other mask
	 * @return <code>true</code> if this mask is more general than the one in
	 *         argument, <code>false</code> otherwise
	 */
	public boolean isMoreGeneralThan(Mask other) {
		if (this.getSize() != other.getSize()) {
			return false;
		}

		int dontcaresThis = 0;
		int dontcaresOther = 0;

		for (int i = 0; i < getSize(); i++) {
			if (this.getValue(i) != other.getValue(i)) {
				if (this.getValue(i) == MaskValue.DONT_CARE
						&& other.getValue(i) != MaskValue.DONT_CARE) {
					dontcaresThis++;
				} else if (this.getValue(i) != MaskValue.DONT_CARE
						&& other.getValue(i) == MaskValue.DONT_CARE) {
					dontcaresOther++;
				} else if (this.getValue(i) != MaskValue.DONT_CARE
						&& other.getValue(i) != MaskValue.DONT_CARE) {
					return false;
				}
			}
		}

		return dontcaresThis > dontcaresOther;
	}

	/**
	 * Combines two masks of the same size into one more general {@link Mask}.
	 * 
	 * @param first
	 *            first mask.
	 * @param second
	 *            second mask.
	 * @return combined {@link Mask}.
	 * @throws NullPointerException
	 *             if one of the masks is null.
	 * @throws IllegalArgumentException
	 *             if masks have different sizes or arguments are null
	 *             references.
	 */
	public static Mask combine(Mask first, Mask second) {

		if (first == null || second == null) {
			throw new IllegalArgumentException("One of the masks is null!");
		}
		if (first.getSize() != second.getSize()) {
			throw new IllegalArgumentException(
					"Masks have to be the same size!");
		}

		final int size = first.getSize();
		MaskValue[] newValues = new MaskValue[size];

		MaskValue firstValue;
		MaskValue secondValue;

		for (int i = 0; i < size; i++) {
			firstValue = first.getValue(i);
			secondValue = second.getValue(i);
			if (firstValue.equals(secondValue)) {
				newValues[i] = firstValue;
			} else {
				newValues[i] = MaskValue.DONT_CARE;
			}
		}

		Mask combined = new Mask(newValues);

		if (!combined.isMoreGeneralThan(first)
				|| !combined.isMoreGeneralThan(second)) {
			return null;
		}

		return combined;
	}

	/**
	 * Creates a new mask instance base on given size and index.
	 * 
	 * @param size
	 *            size of the new mask.
	 * @param index
	 *            index of the mask.
	 * @return new {@link Mask} instance created from index.
	 * @throws IllegalArgumentException
	 *             if index is out of domain range.
	 */
	public static Mask fromIndex(int size, int index) {
		if (index < 0 || index >= Math.pow(2, size)) {
			throw new IllegalArgumentException(
					"Index can't be negative or bigger than size of the mask!");
		}
		String format = "%" + size + "s";
		return Mask.parse(String.format(format, Integer.toBinaryString(index))
				.replace(' ', '0'));
	}

	/**
	 * Returns string representation of this mask.
	 * 
	 * @return string representation of this mask.
	 */
	@Override
	public String toString() {
		StringBuffer buff = new StringBuffer();
		for (MaskValue value : values) {
			switch (value) {
			case ONE:
				buff.append("1");
				break;
			case ZERO:
				buff.append("0");
				break;
			case DONT_CARE:
				buff.append("x");
				break;
			}
		}
		return buff.toString();
	}

	/**
	 * Counts all the zeros in this mask.
	 * 
	 * @return number of zeros in the mask.
	 */
	public int getNumberOfZeros() {
		int numberOfZeros = 0;
		for (MaskValue value : values) {
			if (value.equals(MaskValue.ZERO)) {
				numberOfZeros++;
			}
		}
		return numberOfZeros;
	}

	/**
	 * Counts all the ones in this mask.
	 * 
	 * @return number of ones in the mask.
	 */
	public int getNumberOfOnes() {
		int numberOfOnes = 0;
		for (MaskValue value : values) {
			if (value.equals(MaskValue.ONE)) {
				numberOfOnes++;
			}
		}
		return numberOfOnes;
	}

	/**
	 * Returns number of characters in this mask.
	 * 
	 * @return size of the mask.
	 */
	public int getSize() {
		return values.length;
	}
	
	/**
	 * Gets indexes in this mask.
	 * 
	 * @param masks
	 *            list of masks.
	 * @return list of indexes based on given masks.
	 * @throws IllegalArgumentException
	 *             if list is null or contains null.
	 */
	public static List<Integer> indexesFromMasks(List<Mask> masks) {

		if (masks == null || masks.contains(null)) {
			throw new IllegalArgumentException("Mask cannot be null!");
		}

		Set<Integer> indexes = new LinkedHashSet<>();
		for (Mask mask : masks) {
			indexes.addAll(mask.getIndexList());
		}

		return new ArrayList<>(indexes);
	}
	
	/**
	 * Returns index representation of this mask.
	 * 
	 * @return list of indexes.
	 */
	private List<Integer> getIndexList() {

		List<Integer> indexes = new ArrayList<>();
		int maskSize = this.getSize();
		int maxDomainValue = (int) Math.pow(2, maskSize);

		for (int i = 0; i < maxDomainValue; i++) {
			Mask currentMask = Mask.fromIndex(maskSize, i);
			if (this.isMoreGeneralThan(currentMask) || this.equals(currentMask)) {
				indexes.add(i);
			}
		}

		return indexes;
	}

	/**
	 * Returns hashCode of this Mask instance.
	 * 
	 * @return hash code.
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + Arrays.hashCode(values);
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		Mask other = (Mask) obj;
		if (values.length != other.values.length) {
			return false;
		}
		for (int i = 0; i < values.length; i++) {
			if (this.getValue(i) != other.getValue(i)
					&& this.getValue(i) != MaskValue.DONT_CARE
					&& other.getValue(i) != MaskValue.DONT_CARE) {
				return false;
			}
		}

		return true;
	}

}
