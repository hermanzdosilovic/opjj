package hr.fer.zemris.bool;

import java.util.ArrayList;
import java.util.List;

/**
 * Class implements a notion of boolean constant. 
 * Valid values are:
 * <ul>
 * <li>true</li>
 * <li>false</li>
 * <li>don't care</li>
 * </ul>
 * @author Viktor Berger
 * @version 1.0
 */
public final class BooleanConstant implements BooleanSource {

	/** Boolean value. */
	private BooleanValue value;
	
	/**
	 * Creates an instance of this class based on given parameter.
	 * @param value {@link BooleanValue} which denotes if this constant is
	 * <code>true</code> or <code>false</code>
	 */
	private BooleanConstant(BooleanValue value) {
		this.value = value;
	}
	
	/** Instance of this class which provides value TRUE. */
	public static final BooleanConstant TRUE = new BooleanConstant(BooleanValue.TRUE);
	/** Instance of this class which provides value FALSE. */
	public static final BooleanConstant FALSE = new BooleanConstant(BooleanValue.FALSE);
	
	@Override
	public BooleanValue getValue() {
		return value;
	}

	@Override
	public List<BooleanVariable> getDomain() {
		return new ArrayList<>();
	}
}
