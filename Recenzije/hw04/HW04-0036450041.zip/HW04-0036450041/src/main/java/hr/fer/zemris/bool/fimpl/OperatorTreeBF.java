package hr.fer.zemris.bool.fimpl;

import hr.fer.zemris.bool.BooleanFunction;
import hr.fer.zemris.bool.BooleanOperator;
import hr.fer.zemris.bool.BooleanValue;
import hr.fer.zemris.bool.BooleanVariable;
import hr.fer.zemris.bool.Mask;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Class implements boolean function based on operator tree.
 * 
 * @author Viktor Berger
 * @version 1.0
 */
public class OperatorTreeBF implements BooleanFunction {

	/** Name of the function. */
	private String name;

	/** Domain of the function. */
	List<BooleanVariable> domain;

	/** operator tree. */
	BooleanOperator operatorTree;

	/**
	 * Creates an instance of operator tree boolean function based on provided
	 * arguments.
	 * 
	 * @param name
	 *            name of the function.
	 * @param domain
	 *            domain of the function.
	 * @param operatorTree
	 *            operator tree of the function.
	 */
	public OperatorTreeBF(String name, List<BooleanVariable> domain,
			BooleanOperator operatorTree) {
		if (name == null || domain == null || operatorTree == null
				|| domain.contains(null)) {
			throw new IllegalArgumentException(
					"Arguments cannot be null references!");
		}
		if (name.trim().isEmpty()) {
			throw new IllegalArgumentException("Name can't be an empty string!");
		}

		if (checkDuplicates(domain)) {
			throw new IllegalArgumentException(
					"Duplicate variables are not allowed!");
		}

		this.name = name;
		this.domain = new ArrayList<>(domain);
		this.operatorTree = operatorTree;
	}

	@Override
	public String getName() {
		return name;
	}

	@Override
	public BooleanValue getValue() {
		return operatorTree.getValue();
	}

	/**
	 * Returns value of the operator tree on given index. Given index defines
	 * new state of the domain.
	 * 
	 * @param index
	 *            state of the variables.
	 * @return value of the new operator tree.
	 */
	private BooleanValue getOperatorTreeValue(int index) {

		int domainSize = domain.size();
		Mask mask = Mask.fromIndex(domainSize, index);

		for (int i = 0; i < domainSize; i++) {
			switch (mask.getValue(i)) {
			case ONE:
				domain.get(i).setValue(BooleanValue.TRUE);
				break;
			case ZERO:
				domain.get(i).setValue(BooleanValue.FALSE);
				break;
			case DONT_CARE:
				break;
			}
		}

		return getValue();
	}

	/**
	 * Gets iterable object with specified boolean value.
	 * 
	 * @param value
	 *            boolean value.
	 * @return iterable which contains indices with given boolean value.
	 */
	private List<Integer> getIterable(BooleanValue value) {

		int range = (int) Math.pow(2, domain.size());
		List<Integer> indices = new ArrayList<>();

		for (int i = 0; i < range; i++) {
			if (getOperatorTreeValue(i) == value) {
				indices.add(i);
			}
		}
		return indices;
	}

	@Override
	public List<BooleanVariable> getDomain() {
		return Collections.unmodifiableList(domain);
	}

	@Override
	public boolean hasMinterm(int index) {
		if (index < 0 || index >= Math.pow(2, domain.size())) {
			throw new IllegalArgumentException(
					"Don't care index is out of bounds!");
		}
		return getOperatorTreeValue(index) == BooleanValue.TRUE;
	}

	@Override
	public boolean hasMaxterm(int index) {
		if (index < 0 || index >= Math.pow(2, domain.size())) {
			throw new IllegalArgumentException(
					"Don't care index is out of bounds!");
		}
		return getOperatorTreeValue(index) == BooleanValue.FALSE;
	}

	@Override
	public boolean hasDontCare(int index) {
		if (index < 0 || index >= Math.pow(2, domain.size())) {
			throw new IllegalArgumentException(
					"Don't care index is out of bounds!");
		}
		return getOperatorTreeValue(index) == BooleanValue.DONT_CARE;
	}

	@Override
	public Iterable<Integer> mintermIterable() {
		return getIterable(BooleanValue.TRUE);
	}

	@Override
	public Iterable<Integer> maxtermIterable() {
		return getIterable(BooleanValue.FALSE);
	}

	@Override
	public Iterable<Integer> dontcareIterable() {
		return getIterable(BooleanValue.DONT_CARE);
	}

	/**
	 * Method check if there are duplicates in list.
	 * 
	 * @param list
	 *            list which is being checked.
	 * @return <code>true</code> if list contains duplicates, <code>false</code>
	 *         otherwise
	 */
	private <T> boolean checkDuplicates(List<T> list) {
		Set<T> set = new HashSet<>(list);
		if (set.size() < list.size()) {
			return true;
		}
		return false;
	}

}
