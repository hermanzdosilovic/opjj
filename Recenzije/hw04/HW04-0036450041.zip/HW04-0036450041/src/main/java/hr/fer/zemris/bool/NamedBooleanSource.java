package hr.fer.zemris.bool;

/**
 * Represents a source with associated name.
 * @author Viktor Berger
 * @version 1.0
 */
public interface NamedBooleanSource extends BooleanSource {

	/**
	 * Returns name of this boolean source.
	 * @return name of this boolean source.
	 */
	String getName();
}
