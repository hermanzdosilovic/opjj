package hr.fer.zemris.java.tecaj.hw4;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Class is an example of usage of a map collection.
 * 
 * @author Viktor Berger
 * @version 1.0
 */
public class NamesCounter {

	/**
	 * Reads names from standard input while input is not "quit". After input is
	 * "quit", prints all the names with corresponding number of occurrences.
	 * 
	 * @param args
	 *            not used
	 */
	public static void main(String[] args) {
		Pattern pattern = Pattern.compile("[a-zA-Z]+");
		Matcher matcher;
		Scanner scanner = new Scanner(System.in, "utf8");
		Map<String, Integer> names = new HashMap<>();
		String name;

		while (scanner.hasNext()) {
			name = scanner.next();
			matcher = pattern.matcher(name);

			if (!matcher.find()) {
				System.err.println("Name can contains only letters!");
				continue;
			}

			if (name.equals("quit")) {
				break;
			} else {
				if (names.containsKey(name)) {
					names.put(name, names.get(name) + 1);
				} else {
					names.put(name, 1);
				}
			}
		}

		for (Entry<String, Integer> entry : names.entrySet()) {
			System.out.println(entry.getKey() + " " + entry.getValue());
		}

		scanner.close();

	}
}
