package hr.fer.zemris.bool;

import java.util.Arrays;
import java.util.List;

public class BooleanVariable implements NamedBooleanSource {

	/** Name of this boolean variable. */
	private String name;
	/** Values of this boolean variable. */
	private BooleanValue value = BooleanValue.FALSE;

	/**
	 * Creates an instance of this class based on given name.
	 * 
	 * @param name
	 *            name of this variable.
	 * @throws IllegalArgumentException
	 *             if name is empty string or null reference.
	 */
	public BooleanVariable(String name) {
		if (null == name || name.isEmpty()) {
			throw new IllegalArgumentException(
					"Name cannot be empty string or null reference!");
		}
		this.name = name;
	}

	/**
	 * Sets value of this variable on value provided as argument.
	 * 
	 * @param value
	 *            value of the variable.
	 */
	public void setValue(BooleanValue value) {
		this.value = value;
	}

	@Override
	public BooleanValue getValue() {
		return value;
	}

	@Override
	public List<BooleanVariable> getDomain() {
		return Arrays.asList(this);
	}

	@Override
	public String getName() {
		return name;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + name.hashCode();
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		BooleanVariable other = (BooleanVariable) obj;
		if (!name.equals(other.name)) {
			return false;
		}
		return true;
	}

}
