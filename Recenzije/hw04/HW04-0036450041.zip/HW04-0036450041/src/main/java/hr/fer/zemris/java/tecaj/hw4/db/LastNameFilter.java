package hr.fer.zemris.java.tecaj.hw4.db;

/**
 * Class implements filtering based on last name.
 *
 * @author Viktor Berger
 * @version 1.0
 */
public class LastNameFilter implements IFilter {

	/** Regex used as a condition for accepting a student. */
	private String regex;

	/**
	 * Creates an instance of this class based on query string which contains
	 * last name with or without wildcards (mask).
	 *
	 * @param mask
	 *            mask used for filtering.
	 */
	public LastNameFilter(String mask) {
		regex = mask.replace("*", "[ \\p{L}]*");
	}

	/**
	 * Accepts or rejects a student based on his/hers last name.
	 *
	 * @param record {@link StudentRecord} tested against conditional in this filter.
	 * @return <code>true</code> if the mask from condition matches students
	 *         last name, <code>false</code> otherwise.
	 */
	@Override
	public boolean accepts(StudentRecord record) {
		return record.getLastName().matches(regex);
	}
}
