package hr.fer.zemris.bool.fimpl;

import hr.fer.zemris.bool.BooleanFunction;
import hr.fer.zemris.bool.BooleanSource;
import hr.fer.zemris.bool.BooleanValue;
import hr.fer.zemris.bool.BooleanVariable;
import hr.fer.zemris.bool.Mask;
import hr.fer.zemris.bool.MaskValue;
import hr.fer.zemris.bool.opimpl.BooleanOperators;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Class implements boolean function based on indexes of the minterms, maxterms
 * and don't care values.
 * 
 * @author Viktor Berger
 * @version 1.0
 * 
 */
public class IndexedBF implements BooleanFunction {

	/** Name of the function. */
	private String name;

	/** Domain of the function. */
	List<BooleanVariable> domain;

	/**
	 * <code>true</code> if indexes of the function are minterms
	 * <code>false</code> otherwise.
	 */
	boolean indexesAreMinterms;

	/** List of indexes. */
	List<Integer> indexes;

	/** List of dontcares. */
	List<Integer> dontCares;

	/**
	 * Creates a new indexed boolean function based on provided parameters.
	 * 
	 * @param name
	 *            name of the function.
	 * @param domain
	 *            domain of the function.
	 * @param indexesAreMinterms
	 *            <code>true</code> if indexes are minterms, <code>false</code>
	 *            otherwise
	 * @param indexes
	 *            list of indexes.
	 * @param dontCares
	 *            list of dontCares.
	 * @throws IllegalArgumentException
	 *             if:
	 *             <ul>
	 *             <li>indexes and dontcares lists overlap.</li>
	 *             <li>one of the arguments is null reference</li>
	 *             <li>one of the lists contain duplicate elements</li>
	 *             <li>name is empty string</li>
	 *             <li>elements in lists are out of domain</li>
	 *             </ul>
	 */
	public IndexedBF(String name, List<BooleanVariable> domain,
			boolean indexesAreMinterms, List<Integer> indexes,
			List<Integer> dontCares) {

		checkConditions(name, domain, indexes, dontCares);

		this.name = name;
		this.domain = new ArrayList<>(domain);
		this.indexesAreMinterms = indexesAreMinterms;
		this.indexes = new ArrayList<>(indexes);
		this.dontCares = new ArrayList<>(dontCares);

	}

	/**
	 * Checks if all the conditions for creating this function are satisfied.
	 * 
	 * @param name
	 *            name of the function.
	 * @param domain
	 *            domain of the function.
	 * @param indexes
	 *            list of indexes.
	 * @param dontCares
	 *            list of dontCares.
	 */
	private void checkConditions(String name, List<BooleanVariable> domain,
			List<Integer> indexes, List<Integer> dontCares) {
		// null references
		if (domain == null || indexes == null || dontCares == null
				|| name == null) {
			throw new IllegalArgumentException(
					"Arguments cannot be null references!");
		}

		int maxDomainElement = (int) Math.pow(2, domain.size());

		// all indexes and don't cares are not in domain
		if (Collections.max(indexes) >= maxDomainElement
				|| Collections.min(indexes) < 0
				|| Collections.max(dontCares) >= maxDomainElement
				|| Collections.min(dontCares) < 0) {
			throw new IllegalArgumentException(
					"Indexes and dontcares must be in domain range!");
		}

		// empty name
		if (name.trim().isEmpty()) {
			throw new IllegalArgumentException("Name can't be an empty string!");
		}

		// duplicates in one of the lists
		if (checkDuplicates(domain) || checkDuplicates(indexes)
				|| checkDuplicates(dontCares)) {
			throw new IllegalArgumentException(
					"Duplicate elements in one of the lists!");
		}

		// overlapping of indexes and dontcares
		for (Integer index : indexes) {
			if (dontCares.contains(index)) {
				throw new IllegalArgumentException(
						"Indexes and dontCares can't contain the same elements!");
			}
		}
	}

	@Override
	public String getName() {
		return name;
	}

	@Override
	public BooleanValue getValue() {

		// Value is computed using minterms
		int domainSize = domain.size();
		List<Integer> minterms = (List<Integer>) mintermIterable();
		int mintermsSize = minterms.size();
		BooleanSource[] operators = new BooleanSource[mintermsSize];

		for (int i = 0; i < mintermsSize; i++) {

			Mask mask = Mask.fromIndex(domainSize, minterms.get(i));
			BooleanSource[] sources = new BooleanSource[domainSize];

			// check all values for given minterm
			for (int j = 0; j < domainSize; j++) {

				MaskValue value = mask.getValue(j);
				BooleanVariable variable = domain.get(j);

				if (value == MaskValue.ONE) {
					sources[j] = variable;
				} else {
					sources[j] = BooleanOperators.not(variable);
				}
			}

			operators[i] = BooleanOperators.and(sources);
		}

		return BooleanOperators.or(operators).getValue();
	}

	@Override
	public List<BooleanVariable> getDomain() {
		return Collections.unmodifiableList(domain);
	}

	@Override
	public boolean hasMinterm(int index) {
		if (index < 0 || index >= Math.pow(2, domain.size())) {
			throw new IllegalArgumentException("Index is out of bounds!");
		}
		if (indexesAreMinterms) {
			return indexes.contains(index);
		} else {
			return !hasDontCare(index) && !indexes.contains(index);
		}
	}

	@Override
	public boolean hasMaxterm(int index) {
		return !hasMinterm(index);
	}

	@Override
	public boolean hasDontCare(int index) {
		if (index < 0 || index >= Math.pow(2, domain.size())) {
			throw new IllegalArgumentException(
					"Don't care index is out of bounds!");
		}

		return dontCares.contains(index);
	}

	@Override
	public Iterable<Integer> mintermIterable() {
		if (indexesAreMinterms) {
			return Collections.unmodifiableList(indexes);
		} else {
			return differenceList();
		}
	}

	@Override
	public Iterable<Integer> maxtermIterable() {
		if (!indexesAreMinterms) {
			return Collections.unmodifiableList(indexes);
		} else {
			return differenceList();
		}
	}

	@Override
	public Iterable<Integer> dontcareIterable() {
		return Collections.unmodifiableList(dontCares);
	}

	/**
	 * Creates list of all elements in range 2^(domain size) that are not in
	 * indexes list.
	 * 
	 * @return new index list.
	 */
	private List<Integer> differenceList() {
		List<Integer> differenceList = new ArrayList<>();
		for (int i = 0; i < Math.pow(2, domain.size()); i++) {
			if (!indexes.contains(i) && !dontCares.contains(i)) {
				differenceList.add(i);
			}
		}
		return differenceList;
	}

	/**
	 * Method check if there are duplicates in list.
	 * 
	 * @param list
	 *            list which is being checked.
	 * @return <code>true</code> if list contains duplicates, <code>false</code>
	 *         otherwise
	 */
	private <T> boolean checkDuplicates(List<T> list) {
		Set<T> set = new HashSet<>(list);
		if (set.size() < list.size()) {
			return true;
		}
		return false;
	}

}
