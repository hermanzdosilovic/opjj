package hr.fer.zemris.bool;

import java.util.List;

/**
 * Represents any source capable of producing legal {@link BooleanValue}.
 *
 * @author Viktor Berger
 * @version 1.0
 */
public interface BooleanSource {
	/**
	 * Returns boolean value produced by some source.
	 * @return boolean value produce by some source.
	 */
	BooleanValue getValue();
	
	/**
	 * Information about variables that produced value of this source.
	 * @return information about variables that produced value of this source.
	 */
	List<BooleanVariable> getDomain();
}
