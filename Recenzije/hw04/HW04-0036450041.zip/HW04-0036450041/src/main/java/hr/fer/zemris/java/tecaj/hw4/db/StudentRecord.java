package hr.fer.zemris.java.tecaj.hw4.db;

/**
 * Represents a record for one student in database. Each record contains
 * student's:
 * <ul>
 * <li>First name</li>
 * <li>Last name</li>
 * <li>Grade</li>
 * <li>JMBAG</li>
 * </ul>
 * Student's jmbag is unique and therefore used as the primary key.
 *
 * @author Viktor Berger
 * @version 1.0
 */
public class StudentRecord {

	/** Student's unique identifier. */
	private String jmbag;
	/** Student's first name. */
	private String firstName;
	/** Student's last name. */
	private String lastName;
	/** Student's grade. */
	private String grade;

	/**
	 * Creates an instance of the StudentRecord class based on given parameters.
	 * 
	 * @param fields a list of strings which contains information about student.
	 */
	public StudentRecord(String[] fields) {
		final int jmbag = 0;
		final int firstName = 2;
		final int lastName = 1;
		final int grade = 3;
		this.jmbag = fields[jmbag];
		this.firstName = fields[firstName];
		this.lastName = fields[lastName];
		this.grade = fields[grade];
	}

	/**
	 * Returns student's jmbag.
	 *
	 * @return student's jmbag.
	 */
	public String getJmbag() {
		return jmbag;
	}

	/**
	 * Returns student's first name.
	 *
	 * @return student's first name.
	 */
	public String getFirstName() {
		return firstName;
	}

	/**
	 * Returns student's last name.
	 *
	 * @return student's last name.
	 */
	public String getLastName() {
		return lastName;
	}

	/**
	 * Returns student's grade.
	 *
	 * @return student's grade.
	 */
	public String getGrade() {
		return grade;
	}

	/**
	 * Indicates whether this object is equivalent to the object given as
	 * argument to this method. Two StudentRecords are equal if their jmbags are
	 * equal.
	 *
	 * @param obj
	 *            object which is tested for equality with this StudntRecord.
	 *
	 * @return <code>true</code> is jmbag numbers of two student records are
	 *         equal, <code>false</code> otherwise
	 */
	@Override
	public boolean equals(Object obj) {
		if (!(obj instanceof StudentRecord)) {
			return false;
		}
		StudentRecord other = (StudentRecord) obj;

		return this.jmbag.equals(other.jmbag);
	}

	/**
	 * Returns a hash code value of the student record object.
	 *
	 * @return hash code.
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((jmbag == null) ? 0 : jmbag.hashCode());
		return result;
	}

	@Override
	public String toString() {
		return "| " + jmbag + " | " + lastName + " | " + firstName + " | "
				+ grade + " |";
	}

}
