package hr.fer.zemris.java.tecaj.hw4.db;

/**
 * Exception is raised when database is in inconsistent state.
 * @author Viktor Berger
 * @version 1.0
 */
public class StudentDatabaseException extends RuntimeException {
	
	/** version ID. */
	private static final long serialVersionUID = 1L;
	
	/**
	 * Default {@link StudentDatabaseException} constructor.
	 */
	public StudentDatabaseException() {
		super();
	}
	
	/**
	 * Creates {@link StudentDatabaseException} with message.
	 * @param message exception message.
	 */
	public StudentDatabaseException(String message) {
		super(message);
	}

}
