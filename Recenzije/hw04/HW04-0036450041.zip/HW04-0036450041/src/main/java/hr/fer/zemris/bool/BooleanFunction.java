package hr.fer.zemris.bool;

/**
 * Represents an abstract boolean function.
 * @author Viktor Berger
 * @version 1.0
 */
public interface BooleanFunction extends NamedBooleanSource {

	/**
	 * Checking if this function contains minterm on given index.
	 * @param index index on which function's minterm is checked.
	 * @return <code>true</code> if this function contains minterm on given index,
	 * <code>false</code> otherwise
	 * @throws IndexOutOfBoundsException if minterm index is out of bounds.
	 */
	boolean hasMinterm(int index);
	
	/**
	 * Checking if this function contains maxterm on given index.
	 * @param index index on which function's maxterm checked.
	 * @return <code>true</code> if this function contains maxterm on given index,
	 * <code>false</code> otherwise
	 * @throws IndexOutOfBoundsException if maxterm index is out of bounds.
	 */
	boolean hasMaxterm(int index);
	
	/**
	 * Checking if this function contains dontcare on given index.
	 * @param index index on which function's dontare is checked.
	 * @return <code>true</code> if this function contains dontcare on given index,
	 * <code>false</code> otherwise
	 * @throws IndexOutOfBoundsException if dontcare index is out of bounds.
	 */
	boolean hasDontCare(int index);
	
	/**
	 * Provides object suitable for minterm "foreach" iteration. 
	 * @return {@link Iterable} object which contains minterms of this function.
	 */
	Iterable<Integer> mintermIterable();
	
	/**
	 * Provides object suitable for maxterm "foreach" iteration. 
	 * @return {@link Iterable} object which contains maxterms of this function.
	 */
	Iterable<Integer> maxtermIterable();
	
	/**
	 * Provides object suitable for dontcare "foreach" iteration. 
	 * @return {@link Iterable} object which contains dontcares of this function.
	 */
	Iterable<Integer> dontcareIterable();
}
