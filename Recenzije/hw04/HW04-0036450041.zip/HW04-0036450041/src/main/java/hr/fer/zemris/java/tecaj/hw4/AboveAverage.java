package hr.fer.zemris.java.tecaj.hw4;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

/**
 * Class's main functionality is reading a sequence of numbers (one per line)
 * from standard input, and printing the numbers that are bigger for at least
 * 20% than average in ascending order.
 * 
 * @author Viktor Berger
 * @version 1.0
 */
public class AboveAverage {

	/**
	 * Main method which is the entry point of this program.
	 * 
	 * @param args
	 *            not used
	 */
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in, "utf8");
		List<Double> numbers = new ArrayList<>();

		while (scanner.hasNext()) {
			try {
				String input = scanner.next();
				if (input.equals("quit")) {
					break;
				}
				numbers.add(Double.parseDouble(input));
			} catch (Exception e) {
				System.err.println("Unesen je nedopušteni znak!");
				System.exit(1);
			}
		}

		double average = 0.0;
		for (Double d : numbers) {
			average += d;
		}

		average /= numbers.size();

		Collections.sort(numbers);

		double percentage = 1.2;

		for (Double d : numbers) {
			if (d > percentage * average) {
				System.out.println(d);
			}
		}
		scanner.close();

	}
}
