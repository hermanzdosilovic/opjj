package hr.fer.zemris.bool;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Represents a notion of operator that works with boolean values.
 * 
 * @author Viktor Berger
 * @version 1.0
 */
public class BooleanOperator implements BooleanSource {

	/** List of all the sources of this operator. */
	private List<BooleanSource> sources;

	/**
	 * Creates an instance of BooleanOperator class based on given sources.
	 * 
	 * @param sources
	 *            list of sources.
	 * @throws IllegalArgumentException
	 *             if there are duplicate sources.
	 */
	protected BooleanOperator(BooleanSource... sources) {
		this.sources = new ArrayList<BooleanSource>(Arrays.asList(sources));
		Set<BooleanSource> controlSet = new HashSet<>(this.sources);

		if (controlSet.size() < this.sources.size()) {
			throw new IllegalArgumentException(
					"Duplicate variables are not allwed!");
		}
	}

	/**
	 * Returns sources of this boolean operator.
	 * 
	 * @return sources of this boolean operator.
	 */
	protected List<BooleanSource> getSources() {
		return Collections.unmodifiableList(sources);
	}

	@Override
	public BooleanValue getValue() {
		return null;
	}

	/**
	 * Returns domain as a union of his sources' domains.
	 * 
	 * @return a list of {@link BooleanVariable} object which represents a
	 *         domain of this operator.
	 */
	@Override
	public List<BooleanVariable> getDomain() {
		Set<BooleanVariable> variables = new HashSet<>();

		for (BooleanSource source : sources) {
			variables.addAll(source.getDomain());
		}
		return new ArrayList<>(variables);
	}

}
