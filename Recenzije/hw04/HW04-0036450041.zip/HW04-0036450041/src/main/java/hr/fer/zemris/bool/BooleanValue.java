package hr.fer.zemris.bool;

/**
 * Holds definition of all legal values for a
 * Boolean function.
 * @author Viktor Berger
 * @version 1.0
 */
public enum BooleanValue {
	/** logical true value. */
	TRUE,
	/** logical false value. */
	FALSE,
	/** logical value which doesn't matter. */
	DONT_CARE
}
