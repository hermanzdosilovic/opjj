package hr.fer.zemris.bool.opimpl;

import hr.fer.zemris.bool.BooleanOperator;
import hr.fer.zemris.bool.BooleanSource;
import hr.fer.zemris.bool.BooleanValue;

/**
 * Class implements boolean operator of negation. If the given source
 * contains variable with value TRUE, it will become FALSE and vice versa. 
 * @author Viktor Berger
 * @version 1.0
 */
public class BooleanOperatorNOT extends BooleanOperator {

	/**
	 * Creates an instance of this class based on provided {@link BooleanSource}
	 * in argument.
	 * @param source {@link BooleanSource} which will be negated.
	 */
	public BooleanOperatorNOT(BooleanSource source) {
		super(source);
	}
	
	/**
	 * Returns result produced by application of logical AND operator on a set of
	 * {@link BooleanSource} objects.
	 * @return result {@link BooleanValue} produced by application of 
	 * logical AND operator.
	 */
	@Override
	public BooleanValue getValue() {
		BooleanValue value = getDomain().get(0).getValue();
		if (value.equals(BooleanValue.DONT_CARE)) {
			return BooleanValue.DONT_CARE;
		}
		if (value.equals(BooleanValue.TRUE)) {
			return BooleanValue.FALSE;
		} else {
			return BooleanValue.TRUE;
		}
	}

}
