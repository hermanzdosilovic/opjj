package hr.fer.zemris.bool.opimpl;

import hr.fer.zemris.bool.BooleanOperator;
import hr.fer.zemris.bool.BooleanSource;
import hr.fer.zemris.bool.BooleanValue;

import java.util.List;

/**
 * Class implements boolean operator of disjunction. If the given source
 * contains at least one variable with value TRUE, it will become TRUE.
 * Otherwise, if all variables are set to FALSE, result is also FALSE.
 * 
 * @author Viktor Berger
 * @version 1.0
 */
public class BooleanOperatorOR extends BooleanOperator {

	/**
	 * Creates an instance of this class based on provided {@link BooleanSource}
	 * in argument.
	 * 
	 * @param source
	 *            a list of {@link BooleanSource} objects.
	 */
	public BooleanOperatorOR(BooleanSource... sources) {
		super(sources);
	}

	/**
	 * Returns result produced by application of logical OR operator on a set of
	 * {@link BooleanSource} objects.
	 * 
	 * @return result {@link BooleanValue} produced by application of logical OR
	 *         operator.
	 * @throws IllegalArgumentException
	 *             if there are duplicate values.
	 */
	@Override
	public BooleanValue getValue() {
		List<BooleanSource> sources = getSources();
		for (BooleanSource source : sources) {
			if (source.getValue().equals(BooleanValue.TRUE)) {
				return BooleanValue.TRUE;
			}
		}

		for (BooleanSource source : sources) {
			if (source.getValue().equals(BooleanValue.DONT_CARE)) {
				return BooleanValue.DONT_CARE;
			}
		}

		return BooleanValue.FALSE;
	}

}
