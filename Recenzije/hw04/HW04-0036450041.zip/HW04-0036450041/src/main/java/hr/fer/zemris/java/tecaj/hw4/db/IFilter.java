package hr.fer.zemris.java.tecaj.hw4.db;

/**
 * Interface defines a method which filters StudentRecords.
 *
 * @author Viktor Berger
 * @version 1.0
 */
public interface IFilter {
	/**
	 * Method defines a condition for accepting {@link StudentRecord}, and checks
	 * if the given record satisfies it.
	 * @param record {@link StudentRecord} being checked against the condition.
	 * @return <code>true</code> if record satisfies condition, <code>false</code> otherwise.
 	 */
	public boolean accepts(StudentRecord record);
}
