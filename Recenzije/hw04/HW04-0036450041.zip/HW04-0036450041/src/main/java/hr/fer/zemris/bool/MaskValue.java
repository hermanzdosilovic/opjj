package hr.fer.zemris.bool;

/**
 * Enumeration represents all possible values which a mask can contain.
 * 
 * @author Viktor Berger
 * @version 1.0
 */
public enum MaskValue {
	/** mask value one. */
	ZERO,
	/** mask value zero. */
	ONE,
	/** mask value which doesn't matter */
	DONT_CARE
}
