package hr.fer.zemris.bool.opimpl;

import hr.fer.zemris.bool.BooleanOperator;
import hr.fer.zemris.bool.BooleanSource;
import hr.fer.zemris.bool.BooleanValue;

import java.util.List;

/**
 * Class implements boolean operator of conjunction. All the variables of given
 * sources have to be TRUE in order for result to be TRUE. If at least one of
 * the variables has value FALSE, result is also FALSE.
 * 
 * @author Viktor Berger
 * @version 1.0
 */
public class BooleanOperatorAND extends BooleanOperator {

	/**
	 * Creates an instance of this class based on provided list of
	 * {@link BooleanSource} in argument.
	 * 
	 * @param sources
	 *            a list of {@link BooleanSource} objects.
	 * @throws IllegalArgumentException
	 *             if there are duplicate variables.
	 */
	public BooleanOperatorAND(BooleanSource... sources) {
		super(sources);
	}

	/**
	 * Returns result produced by application of logical AND operator on a set
	 * of {@link BooleanSource} objects.
	 * 
	 * @return result {@link BooleanValue} produced by application of logical
	 *         AND operator.
	 */
	@Override
	public BooleanValue getValue() {
		List<BooleanSource> sources = getSources();
		for (BooleanSource source : sources) {
			if (source.getValue().equals(BooleanValue.FALSE)) {
				return BooleanValue.FALSE;
			}
		}

		for (BooleanSource source : sources) {
			if (source.getValue().equals(BooleanValue.DONT_CARE)) {
				return BooleanValue.DONT_CARE;
			}
		}
		return BooleanValue.TRUE;
	}

}
