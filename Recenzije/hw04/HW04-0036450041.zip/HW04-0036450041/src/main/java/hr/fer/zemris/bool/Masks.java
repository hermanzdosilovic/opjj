package hr.fer.zemris.bool;

import java.util.ArrayList;
import java.util.List;

/**
 * Factory class which creates lists of masks.
 * 
 * @author Viktor Berger
 * @version 1.0
 */
public final class Masks {

	/**
	 * Private constructor. Class can't be instantiated.
	 */
	private Masks() {
	}

	/**
	 * Returns a list of {@link Mask} objects based on given indexes.
	 * 
	 * @param parameters
	 *            list of indexes used for creating masks.
	 * @return list of {@link Mask} objects.
	 */
	public static List<Mask> fromIndexes(int... parameters) {
		List<Mask> masks = new ArrayList<>();

		if (parameters.length < 2) {
			throw new IllegalArgumentException(
					"There has to be at least 2 parameters!");
		}

		int sizeIndex = 0;
		int size = parameters[sizeIndex];
		for (int i = 1; i < parameters.length; i++) {
			masks.add(Mask.fromIndex(size, parameters[i]));
		}
		return masks;
	}

	/**
	 * Returns a list of {@link Mask} objects based on parsing given strings.
	 * 
	 * @param templates
	 *            list of indexes used for creating masks.
	 * @return list of {@link Mask} objects.
	 * @throws IllegalArgumentException
	 *             if one of the arguments contains illegal characters.
	 */
	public static List<Mask> fromStrings(String... templates) {
		List<Mask> masks = new ArrayList<>();
		for (String template : templates) {
			masks.add(Mask.parse(template));
		}
		return masks;
	}
}
