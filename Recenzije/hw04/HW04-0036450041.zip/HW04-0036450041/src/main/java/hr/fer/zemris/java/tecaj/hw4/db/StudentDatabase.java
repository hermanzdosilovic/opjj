package hr.fer.zemris.java.tecaj.hw4.db;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Class implements a simple database emulator. This "database" holds one table
 * with student records (jmbag, first name, last name, grade). "Database"
 * supports a <b>query</b> command in two forms. First one accepts jmbag, while
 * the second one works with a whole or partial (use of wildcards) last name.
 *
 * @author Viktor Berger
 * @version 1.0
 */
public class StudentDatabase {

	/** A list of student records. */
	private List<StudentRecord> records;
	/** A map of student records */
	private Map<String, StudentRecord> index;

	/**
	 * Creates a StudentDatabase object based on list of strings. Every string
	 * contains one whitespace delimited student record.
	 *
	 * @param lines
	 *            list of strings which contains information about students.
	 */
	public StudentDatabase(List<String> lines) {
		records = new ArrayList<>();
		index = new LinkedHashMap<>();

		for (String record : lines) {
			parseAndSaveRecord(record);
		}
	}

	/**
	 * Parses given String and then creates and saves {@link StudentRecord}
	 * object.
	 *
	 * @param record
	 *            string which holds information about one student.
	 */
	private void parseAndSaveRecord(String record) {
		String[] fields = record.split("\\t");
		final int numberOfFields = 4;

		if (fields.length != numberOfFields) {
			throw new StudentDatabaseException("Database file is inconsistent");
		}

		StudentRecord currentRecord = new StudentRecord(fields);

		records.add(currentRecord);
		index.put(fields[0], currentRecord);

	}

	/**
	 * Returns a StudentRecord object with specified jmbag.
	 *
	 * @param jmbag
	 *            student's jmbag.
	 * @return a StudentRecord object with specified jmbag.
	 */
	public StudentRecord forJMBAG(String jmbag) {
		return index.containsKey(jmbag) ? index.get(jmbag) : null;
	}

	/**
	 * Returns a list of {@link StudentRecord} objects which satisfy a condition
	 * in the given filter.
	 *
	 * @param filter
	 *            IFilter object used for record filtering.
	 * @return a filtered list of StudentRecord objects.
	 */
	public List<StudentRecord> filter(IFilter filter) {
		List<StudentRecord> filteredRecords = new ArrayList<>();
		for (StudentRecord record : records) {
			if (filter.accepts(record)) {
				filteredRecords.add(record);
			}
		}
		return filteredRecords;
	}

}
