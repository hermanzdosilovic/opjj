package hr.fer.zemris.web.radionice;

/**
 * Razred implementira opciju koja sadrzi dvije vrijednosti: id i vrijednost
 * opcije.
 * 
 * @author Roni Puž
 * 
 */
public class Opcija implements Comparable<Opcija> {

	private String id;
	private String vrijednost;

	/**
	 * Konstruktor
	 * 
	 * @param id
	 * @param vrijednost
	 */
	public Opcija(String id, String vrijednost) {
		this.id = id;
		this.vrijednost = vrijednost;
	}

	/**
	 * Metoda vraca vrijednost opcije
	 * 
	 * @return
	 */
	public String getVrijednost() {
		return vrijednost;
	}

	/**
	 * Metoda postavlja vrijednost
	 * 
	 * @param vrijednost
	 */
	public void setVrijednost(String vrijednost) {
		this.vrijednost = vrijednost;
	}

	/**
	 * Metoda vraca id.
	 * 
	 * @return id
	 */
	public String getId() {
		return id;
	}

	@Override
	public int compareTo(Opcija o) {
		if (this.id == null) {
			if (o.id == null)
				return 0;
			return -1;
		} else if (o.id == null) {
			return 1;
		}
		return this.id.compareTo(o.id);
	}

	/**
	 * Ispis opcije
	 */
	public String toString() {
		return this.getId() + "\t" + this.getVrijednost() + "\r\n";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Opcija other = (Opcija) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}

}
