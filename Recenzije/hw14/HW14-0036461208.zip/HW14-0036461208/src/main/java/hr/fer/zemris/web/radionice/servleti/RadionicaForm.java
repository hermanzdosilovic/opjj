package hr.fer.zemris.web.radionice.servleti;

import hr.fer.zemris.web.radionice.Opcija;
import hr.fer.zemris.web.radionice.Radionica;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;

/**
 * Razred definira formu koja se ispunjava na web stranici, te nakon koje se
 * šalju podaci na provjeru i spremanje.
 * 
 * @author Roni Puž
 * 
 */

public class RadionicaForm {

	private String id;
	private String naziv;
	private String datum;
	private List<String> oprema;
	private String trajanje;
	private List<String> publika;
	private String maksPolaznika;
	private String email;
	private String dopuna;

	// Map<property, tekst-greske>
	Map<String, String> greske = new HashMap<>();

	/**
	 * Konstruktor.
	 */
	public RadionicaForm() {
	}

	/**
	 * Metoda dohvaca pogresku.
	 * @param ime pogreske
	 * @return vraca tekst pogreske
	 */
	public String dohvatiPogresku(String ime) {
		return greske.get(ime);
	}

	/**
	 * Metoda provjerava da li postoje pogreske
	 * @return <true> ili <false>
	 */
	public boolean imaPogresaka() {
		return !greske.isEmpty();
	}

	/**
	 * Metoda provjerava konkretnu pogresku
	 * @param ime ime pogreske
	 * @return <true> ili <false>
	 */
	public boolean imaPogresku(String ime) {
		return greske.containsKey(ime);
	}

	/**
	 * Popunjavanje forme iz http zahtjeva.
	 * @param req zahtjev
	 */
	public void popuniIzHttpRequesta(HttpServletRequest req) {
		this.id = pripremi(req.getParameter("id"));
		this.naziv = pripremi(req.getParameter("naziv"));
		this.datum = pripremi(req.getParameter("datum"));
		this.oprema = pripremi(req.getParameterValues("oprema"));
		this.trajanje = pripremi(req.getParameter("trajanje"));
		this.publika = pripremi(req.getParameterValues("publika"));
		this.maksPolaznika = pripremi(req.getParameter("maksPolaznika"));
		this.email = pripremi(req.getParameter("email"));
		this.dopuna = pripremi(req.getParameter("dopuna"));
	}

	/**
	 * Metoda popunjava formu iz postojeće radionice
	 * @param r radionica
	 */
	public void popuniIzRadionice(Radionica r) {
		if (r.getId() == null) {
			this.id = "";
		} else {
			this.id = r.getId().toString();
		}
		if (r.getNaziv() != null) {
			this.naziv = r.getNaziv();
		}
		if (r.getDatum() != null) {
			this.datum = r.getDatum();
		}
		if (r.getOprema() != null) {
			this.oprema = new ArrayList<>();
			for (Opcija o : r.getOprema()) {
				this.oprema.add(o.getId().toString());
			}
		}
		if (r.getTrajanje() != null) {
			this.trajanje = r.getTrajanje().getId().toString();
		}
		if (r.getPublika() != null) {
			this.publika = new ArrayList<>();
			for (Opcija p : r.getPublika()) {
				this.publika.add(p.getId().toString());
			}
		}
		if (r.getMaksPolaznika() != null) {
			this.maksPolaznika = r.getMaksPolaznika().toString();
		}
		if (r.getEmail() != null) {
			this.email = r.getEmail();
		}
		if (r.getDopuna() != null) {
			this.dopuna = r.getDopuna();
		} else {
			this.dopuna = "";
		}
	}

	/**
	 * Metoda koja stavlja podatke u radionicu iz forme.
	 * @param r radionica u koju se podaci spremaju
	 * @param bazaOprema sve opreme u bazi
	 * @param bazaPublika sve publike u bazi
	 * @param bazaTrajanja sva trajanja u bazi
	 */
	public void popuniURadionicu(Radionica r, Map<String, Opcija> bazaOprema,
			Map<String, Opcija> bazaPublika, Map<String, Opcija> bazaTrajanja) {
		if (this.id.isEmpty()) {
			r.setId(null);
		} else {
			r.setId(Long.valueOf(id));
		}
		if (!this.naziv.isEmpty()) {
			r.setNaziv(naziv);
		}
		if (!this.datum.isEmpty()) {
			r.setDatum(datum);
		}
		Set<Opcija> radionicaOprema = new TreeSet<>();
		if (oprema != null && oprema.size() != 0) {
			for (String opremaKey : oprema) {
				if (bazaOprema.containsKey(opremaKey)) {
					radionicaOprema.add(bazaOprema.get(opremaKey));
				}
			}
		}
		r.setOprema(radionicaOprema);
		if (trajanje != null) {
			if (bazaTrajanja.containsKey(trajanje)) {
				r.setTrajanje(bazaTrajanja.get(trajanje));
			}
		}
		Set<Opcija> radionicaPublika = new TreeSet<>();
		if (publika != null && publika.size() != 0) {
			for (String publikaKey : publika) {
				if (bazaPublika.containsKey(publikaKey)) {
					radionicaPublika.add(bazaPublika.get(publikaKey));
				}
			}
		}
		r.setPublika(radionicaPublika);

		if (!this.maksPolaznika.isEmpty()) {
			try {
				r.setMaksPolaznika(Integer.parseInt(maksPolaznika));
			} catch (NumberFormatException e) {
			}
		}
		if (email != null) {
			r.setEmail(email);
		}
		if (!dopuna.isEmpty()) {
			r.setDopuna(dopuna);
		}
	}

	/**
	 * Metoda validira podatke iz formulara(forme).
	 */
	public void validiraj() {
		greske.clear();

		if (!this.id.isEmpty()) {
			try {
				long value = Long.parseLong(this.id);
				if (value < 1) {
					greske.put("id",
							"Vrijednost identifikatora mora biti pozitivna.");
				}
			} catch (NumberFormatException ex) {
				greske.put("id", "Vrijednost identifikatora nije valjana.");
			}
		}

		if (this.naziv.isEmpty()) {
			greske.put("naziv", "Naziv je obavezan!");
		} else {
			if (this.naziv.length() < 1 || this.naziv.length() > 40) {
				greske.put("naziv", "Naziv ne smije biti duži od 40 znakova.");
			}
		}

		if (this.datum.isEmpty()) {
			greske.put("datum", "Datum je obavezan!");
		} else {
			Pattern datePattern = Pattern
					.compile("^[0-9]{4}-[0-9]{2}-[0-9]{2}$");

			Matcher matcher = datePattern.matcher(this.datum);
			if (!matcher.find()) {
				greske.put("datum",
						"Datum nije ispravnog formata, ispravno je: GGGG-MM-DD");
			}
		}

		if (trajanje == null || trajanje.isEmpty()) {
			greske.put("trajanje", "Trajanje mora biti definirano.");
		}
		if (publika == null || publika.isEmpty()) {
			greske.put("publika", "Publika mora biti odabrana.");
		}
		if (this.maksPolaznika.isEmpty()) {
			greske.put("maksPolaznika",
					"Broj maksimalnih polaznika je obavezan!");
		} else {
			try {
				int value = Integer.parseInt(maksPolaznika);
				if (value < 10 || value > 50) {
					greske.put("maksPolaznika",
							"Broj polaznika mora biti u intervalu [10,50].");
				}
			} catch (NumberFormatException ex) {
				greske.put("maksPolaznika",
						"Vrijednost maksimalnog broja polaznika mora biti broj!");
			}
		}

		if (this.email.isEmpty()) {
			greske.put("email", "Email je obavezan!");
		} else {
			int l = email.length();
			int p = email.indexOf('@');
			if (l < 3 || p == -1 || p == 0 || p == l - 1) {
				greske.put("email", "Email nije ispravnog formata.");
			}

			Pattern emailPattern = Pattern.compile(
					"^[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,6}$",
					Pattern.CASE_INSENSITIVE);

			Matcher matcher = emailPattern.matcher(this.email);
			if (!matcher.find()) {
				greske.put("email", "Email nije ispravnog formata.");
			}
		}
	}

	/**
	 * Metoda priprema null stringove za formu.
	 * @param s primljeni string.
	 * @return {@link String}
	 */
	private String pripremi(String s) {
		if (s == null) {
			return "";
		}
		return s.trim();
	}

	/**
	 * Metoda priprema listu stringova za formu.
	 * @param s primljena lista stringova.
	 * @return {@link String} lista
	 */
	private List<String> pripremi(String[] polje) {
		List<String> lista = new ArrayList<>();
		if (polje != null) {
			lista = Arrays.asList(polje);
		}
		for (String s : lista) {
			s = pripremi(s);
		}
		return lista;
	}

	/**
	 * Getter za id radionice
	 * @return id
	 */
	public String getId() {
		return id;
	}

	/**
	 * Getter za naziv radionice
	 * @return naziv
	 */
	public String getNaziv() {
		return naziv;
	}

	/**
	 * Getter za datum
	 * @return datum
	 */
	public String getDatum() {
		return datum;
	}

	/**
	 * Getter za opremu
	 * @return opremu
	 */
	public List<String> getOprema() {
		return oprema;
	}

	/**
	 * Getter za trajanje
	 * @return trajanja
	 */
	public String getTrajanje() {
		return trajanje;
	}

	/**
	 * Getter za publiku
	 * @return publiku
	 */
	public List<String> getPublika() {
		return publika;
	}

	/**
	 * Getter za maksimalni broj polaznika
	 * @return broj polaznika
	 */
	public String getMaksPolaznika() {
		return maksPolaznika;
	}

	/**
	 * Getter za email.
	 * @return email
	 */
	public String getEmail() {
		return email;
	}

	/**
	 * Getter za dopunu
	 * @return dopuna
	 */
	public String getDopuna() {
		return dopuna;
	}

	/**
	 * Getter za mapu gresaka
	 * @return greske
	 */
	public Map<String, String> getGreske() {
		return greske;
	}
}
