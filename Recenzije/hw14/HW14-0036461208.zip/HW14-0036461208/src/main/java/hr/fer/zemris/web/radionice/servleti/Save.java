package hr.fer.zemris.web.radionice.servleti;

import hr.fer.zemris.web.radionice.Opcija;
import hr.fer.zemris.web.radionice.Radionica;
import hr.fer.zemris.web.radionice.RadionicaBaza;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet sluzi za spremanje radionice.
 * 
 * @author Roni Puž
 * 
 */
@WebServlet("/save")
public class Save extends HttpServlet {

	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		obradi(req, resp);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		obradi(req, resp);
	}

	protected void obradi(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {

		req.setCharacterEncoding("UTF-8"); // prije prvog getParameter, može se
											// mjenjat encoding

		if (req.getSession().getAttribute("currentUser") == null) {
			req.setAttribute("poruka", "Potrebna je autorizacija!");
			req.getRequestDispatcher("/WEB-INF/pages/Greska.jsp").forward(req,
					resp);
			return;
		}

		String metoda = req.getParameter("metoda");
		if (!"Pohrani".equals(metoda)) {
			resp.sendRedirect(req.getServletContext().getContextPath()
					+ "/listaj");
			return;
		}

		RadionicaForm f = new RadionicaForm();
		f.popuniIzHttpRequesta(req);
		f.validiraj();

		String fileName = req.getServletContext().getRealPath("/WEB-INF/baza");
		RadionicaBaza baza = RadionicaBaza.ucitaj(fileName);
		List<Opcija> svaOprema = new ArrayList<>(baza.getOprema());
		List<Opcija> svaPublika = new ArrayList<>(baza.getPublika());
		List<Opcija> svaTrajanja = new ArrayList<>(baza.getTrajanje());

		Map<String, Opcija> bazaOprema = setToMaps(baza.getOprema());
		Map<String, Opcija> bazaPublika = setToMaps(baza.getPublika());
		Map<String, Opcija> bazaTrajanja = setToMaps(baza.getTrajanje());

		if (f.imaPogresaka()) {
			req.setAttribute("zapis", f);
			req.setAttribute("svaOprema", svaOprema);
			req.setAttribute("svaPublika", svaPublika);
			req.setAttribute("svaTrajanja", svaTrajanja);
			req.setAttribute("selectedOprema",
					stvoriOpcije(f.getOprema(), bazaOprema));
			req.setAttribute("selectedTrajanje",
					stvoriOpciju(f.getTrajanje(), bazaTrajanja));
			req.setAttribute("selectedPublika",
					stvoriOpcije(f.getPublika(), bazaPublika));
			req.getRequestDispatcher("/WEB-INF/pages/Formular.jsp").forward(
					req, resp);
			return;
		}

		Radionica r = new Radionica();
		f.popuniURadionicu(r, bazaOprema, bazaPublika, bazaTrajanja);

		baza.zapamti(r);

		baza.snimi();

		resp.sendRedirect(req.getServletContext().getContextPath() + "/listaj");
	}

	private Map<String, Opcija> setToMaps(Set<Opcija> collection) {
		Map<String, Opcija> mapa = new TreeMap<String, Opcija>();
		for (Opcija o : collection) {
			mapa.put(o.getId(), o);
		}
		return mapa;
	}

	private Set<Opcija> stvoriOpcije(List<String> opcije,
			Map<String, Opcija> bazaOpcija) {
		Set<Opcija> radionicaOpcije = new TreeSet<>();
		if (opcije != null && opcije.size() != 0) {
			for (String opcijaKey : opcije) {
				if (bazaOpcija.containsKey(opcijaKey)) {
					radionicaOpcije.add(bazaOpcija.get(opcijaKey));
				}
			}
			return radionicaOpcije;
		} else {
			return new TreeSet<Opcija>();
		}

	}

	private Opcija stvoriOpciju(String opcija, Map<String, Opcija> bazaOpcija) {
		if (opcija != null) {
			if (bazaOpcija.containsKey(opcija)) {
				return bazaOpcija.get(opcija);
			}
		}
		return null;
	}

}
