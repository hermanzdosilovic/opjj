package hr.fer.zemris.web.radionice;

import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

/**
 * Razred implementira bazu podataka radionica
 * 
 * @author Roni Puž
 * 
 */
public class RadionicaBaza {

	/** direktorij u koji se baza sprema **/
	private String direktorij;
	/** radionice u bazi **/
	private Map<Long, Radionica> radionice = new TreeMap<>();
	/** oprema koja postoji u bazi **/
	private Set<Opcija> oprema;
	/** publika koja postoji u bazi **/
	private Set<Opcija> publika;
	/** trajanje koja postoji u bazi **/
	private Set<Opcija> trajanje;
	/** maksimalni id u bazi za radionice **/
	private Long maxID;

	/**
	 * Konstruktor baze radionica
	 * 
	 * @param direktorij
	 *            direktorij za spremanje
	 */
	private RadionicaBaza(String direktorij) {
		this.direktorij = direktorij;
	}

	/**
	 * Metoda učitava bazu podataka iz datoteka i vraća njenu instancu.
	 * 
	 * @param direktorij
	 *            direktorij iz kojeg ucitava
	 * @return instancu baze.
	 */
	public static RadionicaBaza ucitaj(String direktorij) {
		try {
			Path path = Paths.get(direktorij);
			if (!Files.exists(path)) {
				return new RadionicaBaza(direktorij);
			}

			RadionicaBaza baza = new RadionicaBaza(direktorij);
			baza.oprema = ucitajOpcije(direktorij + "/oprema.txt");
			baza.publika = ucitajOpcije(direktorij + "/publika.txt");
			baza.trajanje = ucitajOpcije(direktorij + "/trajanje.txt");
			Map<Integer, Set<Integer>> radionice_oprema = spojiIdOpcijaSRadionicom(direktorij
					+ "/radionice_oprema.txt");
			Map<Integer, Set<Integer>> radionice_publika = spojiIdOpcijaSRadionicom(direktorij
					+ "/radionice_publika.txt");

			List<String> lines = Files.readAllLines(
					Paths.get(direktorij + "/radionice.txt"),
					StandardCharsets.UTF_8);
			for (String line : lines) {
				line = line.trim();
				if (line.isEmpty())
					continue;
				String[] elementi = line.split("\t");
				String radionicaID = elementi[0];
				Set<Integer> setIdOprema = radionice_oprema.get(Integer
						.valueOf(Integer.parseInt(radionicaID)));
				Set<Integer> setIdPublika = radionice_publika.get(Integer
						.valueOf(Integer.parseInt(radionicaID)));
				Set<Opcija> novaRadionicaOprema = new TreeSet<>();
				Set<Opcija> novaRadionicaPublika = new TreeSet<>();
				Opcija novaRadionicaTrajanje = null;

				for (Opcija opremaZaRadionicu : baza.oprema) {
					if (setIdOprema != null) {
						if (setIdOprema.contains(Integer.valueOf(Integer
								.parseInt(opremaZaRadionicu.getId())))) {
							novaRadionicaOprema.add(opremaZaRadionicu);
						}
					}
				}

				for (Opcija publikaZaRadionicu : baza.publika) {
					if (setIdPublika.contains(Integer.valueOf(Integer
							.parseInt(publikaZaRadionicu.getId())))) {
						novaRadionicaPublika.add(publikaZaRadionicu);
					}
				}

				for (Opcija trajanjeZaRadionicu : baza.trajanje) {
					if (trajanjeZaRadionicu.getId().equals(elementi[4])) {
						novaRadionicaTrajanje = new Opcija(
								trajanjeZaRadionicu.getId(),
								trajanjeZaRadionicu.getVrijednost());
					}
				}
				String dopuna = null;
				if (elementi.length == 7) {
					dopuna = elementi[6];
				}
				Radionica r = new Radionica(Long.valueOf(elementi[0]),
						elementi[1], elementi[2], novaRadionicaOprema,
						novaRadionicaTrajanje, novaRadionicaPublika,
						Integer.valueOf(elementi[3]), elementi[5], dopuna);
				baza.zapamti(r);
			}
			return baza;

		} catch (IOException e) {
		}
		return null;
	}

	/**
	 * Metoda služi za ubacivanje radionice u bazu podataka.
	 * 
	 * @param r
	 *            radionica koja se ubacuje
	 */
	public void zapamti(Radionica r) {
		if (r.getId() == null) {
			Long noviId = maxID == null ? 1 : maxID + 1;
			r.setId(noviId);
		}

		this.radionice.put(r.getId(), r);
		if (maxID == null || r.getId().compareTo(maxID) > 0) {
			maxID = r.getId();
		}
	}

	/**
	 * Metoda spaja idijeve sa opcijama.
	 * 
	 * @param filepath
	 *            putanja
	 * @return vraca mapu sa opcijama
	 * @throws IOException
	 */
	private static Map<Integer, Set<Integer>> spojiIdOpcijaSRadionicom(
			String filepath) throws IOException {
		Map<Integer, Set<Integer>> mapa = new HashMap<>();
		List<String> lines = Files.readAllLines(Paths.get(filepath),
				StandardCharsets.UTF_8);
		for (String line : lines) {
			String[] lineParts = line.split("\t");
			int radionicaId = Integer.parseInt(lineParts[0].trim());
			int opremaId = Integer.parseInt(lineParts[1].trim());
			if (mapa.containsKey(Integer.valueOf(radionicaId))) {
				mapa.get(Integer.valueOf(radionicaId)).add(
						Integer.valueOf(opremaId));
			} else {
				Set<Integer> noviSet = new TreeSet<>();
				noviSet.add(Integer.valueOf(opremaId));
				mapa.put(Integer.valueOf(radionicaId), noviSet);
			}

		}
		return mapa;
	}

	/**
	 * Metoda sprema postojeću bazu u datoteke.
	 * 
	 * @param direktorij
	 *            direktorij u koji se sprema
	 * @throws IOException
	 */
	public void snimi(String direktorij) throws IOException {
		List<Radionica> lista = new ArrayList<>(radionice.values());
		Collections.sort(lista);
		provjeriIspravnostOpcija();
		BufferedWriter bwRadionice = new BufferedWriter(new OutputStreamWriter(
				new FileOutputStream(direktorij + "/radionice.txt"),
				StandardCharsets.UTF_8));
		BufferedWriter bwRadioniceOprema = new BufferedWriter(
				new OutputStreamWriter(new FileOutputStream(direktorij
						+ "/radionice_oprema.txt"), StandardCharsets.UTF_8));
		BufferedWriter bwRadionicePublika = new BufferedWriter(
				new OutputStreamWriter(new FileOutputStream(direktorij
						+ "/radionice_publika.txt"), StandardCharsets.UTF_8));
		for (Radionica r : lista) {
			bwRadionice.write(r.toString());

			// radionice_oprema
			for (Opcija o : r.getOprema()) {
				bwRadioniceOprema.write(r.getId() + "\t" + o.getId() + "\r\n");
			}

			// radionice_publika
			for (Opcija p : r.getPublika()) {
				bwRadionicePublika.write(r.getId() + "\t" + p.getId() + "\r\n");
			}
		}
		bwRadionice.flush();
		bwRadioniceOprema.flush();
		bwRadionicePublika.flush();
		bwRadionice.close();
		bwRadioniceOprema.close();
		bwRadionicePublika.close();

		// oprema
		BufferedWriter bwOprema = new BufferedWriter(new OutputStreamWriter(
				new FileOutputStream(direktorij + "/oprema.txt"),
				StandardCharsets.UTF_8));
		for (Opcija o : this.oprema) {
			bwOprema.write(o.toString());
		}
		bwOprema.flush();
		bwOprema.close();

		// publika
		BufferedWriter bwPublika = new BufferedWriter(new OutputStreamWriter(
				new FileOutputStream(direktorij + "/publika.txt"),
				StandardCharsets.UTF_8));
		for (Opcija p : this.publika) {
			bwPublika.write(p.toString());
		}
		bwPublika.flush();
		bwPublika.close();

		// trajanje
		BufferedWriter bwTrajanje = new BufferedWriter(new OutputStreamWriter(
				new FileOutputStream(direktorij + "/trajanje.txt"),
				StandardCharsets.UTF_8));
		for (Opcija t : this.trajanje) {
			bwTrajanje.write(t.toString());
		}
		bwTrajanje.flush();
		bwTrajanje.close();

	}

	/**
	 * Metoda sprema bazu u direktorij.
	 * 
	 * @throws IOException
	 */
	public void snimi() throws IOException {
		snimi(this.direktorij);
	}

	/**
	 * Metoda provjerava ispravnost i konzistentnost podataka u bazi
	 */
	private void provjeriIspravnostOpcija() {
		for (Radionica r : this.radionice.values()) {
			for (Opcija o : r.getOprema()) {
				if (!this.oprema.contains(o)) {
					throw new InconsistentDatabaseException(
							"Oprema ima nekonzistentne podatke!");
				}
			}
			for (Opcija p : r.getPublika()) {
				if (!this.publika.contains(p)) {
					throw new InconsistentDatabaseException(
							"Publika ima nekonzistentne podatke!");
				}
			}
			if (!this.trajanje.contains(r.getTrajanje())) {
				throw new InconsistentDatabaseException(
						"Trajanje ima nekonzistentne podatke!");
			}
		}
	}

	/**
	 * Metoda vraća radionicu
	 * 
	 * @param id
	 *            id radionice
	 * @return vraca radionicu
	 */
	public Radionica dohvatiRadionicu(Long id) {
		return this.radionice.get(id);
	}

	/**
	 * Metoda ucitava opcije
	 * 
	 * @param filepath
	 *            putanja do datoteke
	 * @return set opcija
	 * @throws IOException
	 */
	private static Set<Opcija> ucitajOpcije(String filepath) throws IOException {
		Set<Opcija> opcije = new TreeSet<>();
		List<String> lines = Files.readAllLines(Paths.get(filepath),
				StandardCharsets.UTF_8);
		for (String line : lines) {
			String[] lineParts = line.split("\t");
			opcije.add(new Opcija(lineParts[0].trim(), lineParts[1].trim()));
		}
		return opcije;
	}

	/**
	 * Metoda vraća radionice u bazi
	 * 
	 * @return radionice
	 */
	public Map<Long, Radionica> getRadionice() {
		return Collections.unmodifiableMap(radionice);
	}

	/**
	 * Metoda vraca opremu u bazi.
	 * 
	 * @return opremu
	 */
	public Set<Opcija> getOprema() {
		return Collections.unmodifiableSet(oprema);
	}

	/**
	 * Metoda vraca publiku u bazi.
	 * 
	 * @return publiku
	 */
	public Set<Opcija> getPublika() {
		return Collections.unmodifiableSet(publika);
	}

	/**
	 * Metoda vraca trajanja u bazi.
	 * 
	 * @return trajanja
	 */
	public Set<Opcija> getTrajanje() {
		return Collections.unmodifiableSet(trajanje);
	}

}
