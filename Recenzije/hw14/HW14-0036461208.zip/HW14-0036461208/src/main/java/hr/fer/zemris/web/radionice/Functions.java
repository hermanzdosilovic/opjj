package hr.fer.zemris.web.radionice;

import java.util.Collection;

/**
 * Razred implementira pomocne funkcije.
 * 
 * @author Roni Puž
 * 
 */
public final class Functions {

	private Functions() {
	}

	/**
	 * Metoda vraca da li sadrzi objekt u kolekciji
	 * @param collection kolekcija objekata
	 * @param item objekt
	 * @return <true> ili <false>
	 */
	public static boolean contains(Collection<Object> collection, Object item) {
		return collection.contains(item);
	}

	/**
	 * Metoda vraca da li su dva objekta ista.
	 * @param o1 prvi objekt
	 * @param o2 drugi objekt
	 * @return <true> ili <false>
	 */
	public static boolean equals(Object o1, Object o2) {
		return o1.equals(o2);
	}
}
