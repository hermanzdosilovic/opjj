package hr.fer.zemris.web.radionice.servleti;

import hr.fer.zemris.web.radionice.Opcija;
import hr.fer.zemris.web.radionice.Radionica;
import hr.fer.zemris.web.radionice.RadionicaBaza;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet služi za uređivanje postojećih radionica
 * 
 * @author Roni Puž
 * 
 */
@WebServlet("/edit")
public class Edit extends HttpServlet {

	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {

		if (req.getSession().getAttribute("currentUser") == null) {
			req.setAttribute("poruka", "Potrebna je autorizacija!");
			req.getRequestDispatcher("/WEB-INF/pages/Greska.jsp").forward(req,
					resp);
			return;
		}

		Long id = null;
		try {
			id = Long.valueOf(req.getParameter("id"));
		} catch (Exception ex) {
			req.setAttribute("poruka", "Primljeni su neispravni parametri");
			req.getRequestDispatcher("/WEB-INF/pages/Greska.jsp").forward(req,
					resp);
			return;
		}

		RadionicaBaza baza = RadionicaBaza.ucitaj(req.getServletContext()
				.getRealPath("/WEB-INF/baza"));

		Radionica r = baza.dohvatiRadionicu(id);

		if (r == null) {
			req.setAttribute("poruka", "Traženi zapis ne postoji.");
			req.getRequestDispatcher("/WEB-INF/pages/Greska.jsp").forward(req,
					resp);
			return;
		}

		RadionicaForm f = new RadionicaForm();
		f.popuniIzRadionice(r);

		List<Opcija> svaOprema = new ArrayList<>(baza.getOprema());
		List<Opcija> svaPublika = new ArrayList<>(baza.getPublika());
		List<Opcija> svaTrajanja = new ArrayList<>(baza.getTrajanje());

		req.setAttribute("svaOprema", svaOprema);
		req.setAttribute("svaPublika", svaPublika);
		req.setAttribute("svaTrajanja", svaTrajanja);

		req.setAttribute("zapis", f);

		req.setAttribute("selectedOprema", r.getOprema());
		req.setAttribute("selectedTrajanje", r.getTrajanje());
		req.setAttribute("selectedPublika", r.getPublika());

		req.getRequestDispatcher("/WEB-INF/pages/Formular.jsp").forward(req,
				resp);
	}
}
