package hr.fer.zemris.web.radionice.servleti;

/**
 * Razred predstavlja korisnika aplikacije.
 * 
 * @author Roni Puž
 * 
 */
public class User {

	private String login;
	private String zaporka;
	private String ime;
	private String prezime;

	/**
	 * Konstruktor korisnika.
	 * 
	 * @param login
	 * @param zaporka
	 * @param ime
	 * @param prezime
	 */
	public User(String login, String zaporka, String ime, String prezime) {
		super();
		this.login = login;
		this.zaporka = zaporka;
		this.ime = ime;
		this.prezime = prezime;
	}

	public String getLogin() {
		return login;
	}

	public String getZaporka() {
		return zaporka;
	}

	public String getIme() {
		return ime;
	}

	public String getPrezime() {
		return prezime;
	}

}
