package hr.fer.zemris.web.radionice.servleti;

import hr.fer.zemris.web.radionice.Radionica;
import hr.fer.zemris.web.radionice.RadionicaBaza;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet služi za izlistavanje postojećih radionica.
 * 
 * @author Roni Puž
 * 
 */
@WebServlet(urlPatterns = { "/listaj", "/index.html" })
public class Listaj extends HttpServlet {

	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {

		RadionicaBaza baza = RadionicaBaza.ucitaj(req.getServletContext()
				.getRealPath("/WEB-INF/baza"));

		List<Radionica> zapisi = new ArrayList<>(baza.getRadionice().values());

		Collections.sort(zapisi, new Comparator<Radionica>() {
			public int compare(Radionica o1, Radionica o2) {
				if (o1.getDatum().compareTo(o2.getDatum()) != 0) {
					return o1.getDatum().compareTo(o2.getDatum());
				} else {
					return o1.getNaziv().compareTo(o2.getNaziv());
				}
			};
		});

		req.setAttribute("zapisi", zapisi);

		req.getRequestDispatcher("/WEB-INF/pages/Listaj.jsp")
				.forward(req, resp);
	}
}
