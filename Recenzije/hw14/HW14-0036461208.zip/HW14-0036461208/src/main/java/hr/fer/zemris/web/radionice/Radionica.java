package hr.fer.zemris.web.radionice;

import java.util.Set;

/**
 * Razred predstavlja radionicu
 * 
 * @author Roni Puž
 * 
 */
public class Radionica implements Comparable<Radionica> {

	private Long id;
	private String naziv;
	private String datum;
	private Set<Opcija> oprema;
	private Opcija trajanje;
	private Set<Opcija> publika;
	private Integer maksPolaznika;
	private String email;
	private String dopuna;

	/**
	 * Konstruktor za radionicu.
	 * 
	 * @param id
	 *            id radionice
	 * @param naziv
	 *            naziv radionice
	 * @param datum
	 *            datum radionice
	 * @param oprema
	 *            oprema radionice
	 * @param trajanje
	 *            trajanje radionice
	 * @param publika
	 *            publika koja moze prisustvovati radionici
	 * @param maksPolaznika
	 *            maksimalni broj polaznika
	 * @param email
	 *            email radionice
	 * @param dopuna
	 *            tekst dopune
	 */
	public Radionica(Long id, String naziv, String datum, Set<Opcija> oprema,
			Opcija trajanje, Set<Opcija> publika, Integer maksPolaznika,
			String email, String dopuna) {
		super();
		this.id = id;
		this.naziv = naziv;
		this.datum = datum;
		this.oprema = oprema;
		this.trajanje = trajanje;
		this.publika = publika;
		this.maksPolaznika = maksPolaznika;
		this.email = email;
		this.dopuna = dopuna;
	}

	/**
	 * Konstruktor
	 */
	public Radionica() {
	}

	/**
	 * Dohvaća opremu
	 * 
	 * @return opremu
	 */
	public Set<Opcija> getOprema() {
		return oprema; // mora bit modifiable - test primjer
	}

	/**
	 * Dohvaca publiku
	 * 
	 * @return
	 */
	public Set<Opcija> getPublika() {
		return publika;
	}

	/**
	 * Metoda ispisuje opremu radionice
	 * 
	 * @return ispis opreme radionice
	 */
	public String toRadioniceOprema() {
		StringBuilder sb = new StringBuilder();
		for (Opcija o : this.oprema) {
			sb.append(this.getId()).append("\t").append(o.getId())
					.append("\r\n");
		}
		return sb.toString();
	}

	/**
	 * Ispis publike radionice
	 * 
	 * @return ispis publike radionice
	 */
	public String toRadionicePublika() {
		StringBuilder sb = new StringBuilder();
		for (Opcija o : this.publika) {
			sb.append(this.getId()).append("\t").append(o.getId())
					.append("\r\n");
		}
		return sb.toString();
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(this.id.toString()).append("\t");
		sb.append(this.naziv).append("\t");
		sb.append(this.datum).append("\t");
		sb.append(this.maksPolaznika.toString()).append("\t");
		sb.append(this.trajanje.getId()).append("\t");
		sb.append(this.email).append("\t");
		if (dopuna != null) {
			sb.append(this.dopuna);
		}
		sb.append("\r\n");
		return sb.toString();
	}

	/**
	 * Getter
	 * 
	 * @return id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * Setter za id
	 * 
	 * @param id
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * Setter za naziv
	 * 
	 * @param naziv
	 */
	public void setNaziv(String naziv) {
		this.naziv = naziv;
	}

	/**
	 * Setter za datum
	 * 
	 * @param datum
	 */
	public void setDatum(String datum) {
		this.datum = datum;
	}

	public void setOprema(Set<Opcija> oprema) {
		this.oprema = oprema;
	}

	public void setTrajanje(Opcija trajanje) {
		this.trajanje = trajanje;
	}

	public void setPublika(Set<Opcija> publika) {
		this.publika = publika;
	}

	public void setMaksPolaznika(Integer maksPolaznika) {
		this.maksPolaznika = maksPolaznika;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public void setDopuna(String dopuna) {
		this.dopuna = dopuna;
	}

	public String getNaziv() {
		return naziv;
	}

	public String getDatum() {
		return datum;
	}

	public Opcija getTrajanje() {
		return trajanje;
	}

	public Integer getMaksPolaznika() {
		return maksPolaznika;
	}

	public String getEmail() {
		return email;
	}

	public String getDopuna() {
		return dopuna;
	}

	@Override
	public int compareTo(Radionica o) {
		if (this.id == null) {
			if (o.id == null)
				return 0;
			return -1;
		} else if (o.id == null) {
			return 1;
		}
		return this.id.compareTo(o.id);
	}

}
