package hr.fer.zemris.web.radionice.servleti;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet za logiranje
 * 
 * @author Roni Puž
 * 
 */
@WebServlet("/login")
public class Login extends HttpServlet {

	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		obradi(req, resp);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		obradi(req, resp);
	}

	protected void obradi(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		if (req.getParameter("username") != null) {
			String username = req.getParameter("username");
			String password = req.getParameter("password");
			User korisnik = provjeri(username, password);
			if (korisnik != null) {
				req.getSession().setAttribute("currentUser", korisnik);
				resp.sendRedirect(req.getServletContext().getContextPath()
						+ "/listaj");
			} else {
				req.setAttribute("greska", "username ili password je pogrešan");
				req.getRequestDispatcher("/WEB-INF/pages/Login.jsp").forward(
						req, resp);
			}
		} else {
			req.getRequestDispatcher("/WEB-INF/pages/Login.jsp").forward(req,
					resp);
		}

	}

	/**
	 * Metoda provjerava ispravnost unesenih podataka za logiranje korisnika.
	 * 
	 * @param username
	 *            korisnicko ime
	 * @param password
	 *            lozinka
	 * @return
	 */
	private User provjeri(String username, String password) {
		if ("aante".equals(username) && "tajna".equals(password)) {
			return new User("aante", "tajna", "Ante", "Anić");
		} else {
			return null;
		}
	}
}
