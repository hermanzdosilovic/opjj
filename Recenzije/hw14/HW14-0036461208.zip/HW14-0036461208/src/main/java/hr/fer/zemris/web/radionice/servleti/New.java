package hr.fer.zemris.web.radionice.servleti;

import hr.fer.zemris.web.radionice.Opcija;
import hr.fer.zemris.web.radionice.Radionica;
import hr.fer.zemris.web.radionice.RadionicaBaza;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet za stvaranje nove radionice
 * 
 * @author Roni Puž
 * 
 */
@WebServlet("/new")
public class New extends HttpServlet {

	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {

		if (req.getSession().getAttribute("currentUser") == null) {
			req.setAttribute("poruka", "Potrebna je autorizacija!");
			req.getRequestDispatcher("/WEB-INF/pages/Greska.jsp").forward(req,
					resp);
			return;
		}

		Radionica r = new Radionica();
		RadionicaForm f = new RadionicaForm();
		f.popuniIzRadionice(r);
		RadionicaBaza baza = RadionicaBaza.ucitaj(req.getServletContext()
				.getRealPath("/WEB-INF/baza"));

		List<Opcija> svaOprema = new ArrayList<>(baza.getOprema());
		List<Opcija> svaPublika = new ArrayList<>(baza.getPublika());
		List<Opcija> svaTrajanja = new ArrayList<>(baza.getTrajanje());
		req.setAttribute("zapis", f);
		req.setAttribute("svaOprema", svaOprema);
		req.setAttribute("svaPublika", svaPublika);
		req.setAttribute("svaTrajanja", svaTrajanja);
		req.setAttribute("selectedOprema", new ArrayList<>());
		req.setAttribute("selectedTrajanje", new String());
		req.setAttribute("selectedPublika", new ArrayList<>());

		req.getRequestDispatcher("/WEB-INF/pages/Formular.jsp").forward(req,
				resp);
	}
}
