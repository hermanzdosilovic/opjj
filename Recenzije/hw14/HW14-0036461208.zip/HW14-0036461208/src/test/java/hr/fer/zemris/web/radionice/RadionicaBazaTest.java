package hr.fer.zemris.web.radionice;

import static org.junit.Assert.*;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

import org.junit.Test;

public class RadionicaBazaTest {
	
	@Test
	public void test1() throws IOException {
		RadionicaBaza baza = RadionicaBaza.ucitaj("./baza");
		Path d = Files.createTempDirectory(Paths.get("./"),"TmpFiles");
		baza.snimi(d.toString());
		File[] bazaFiles = Paths.get("./baza").toFile().listFiles();
		File[] tmpFiles = d.toFile().listFiles();
		boolean iste = usporedi(bazaFiles, tmpFiles);
		for (File file : tmpFiles) {
			file.delete();
		}
		d.toFile().delete();
		assertEquals("Datoteke bi trebale biti iste!", true, iste);

	}

	private boolean usporedi(File[] bazaFiles, File[] tmpFiles) throws IOException {

		if (bazaFiles.length != tmpFiles.length) {
			return false;
		}
		for (int i = 0; i < bazaFiles.length; i++) {
			List<String> list1 = Files.readAllLines(bazaFiles[i].toPath(), StandardCharsets.UTF_8);
			List<String> list2 = Files.readAllLines(tmpFiles[i].toPath(), StandardCharsets.UTF_8);
			
			if(!list1.equals(list2)) {
				return false;
			}
		}
		return true;
	}

	@Test
	public void Test2() throws IOException {
		RadionicaBaza baza = RadionicaBaza.ucitaj("./baza");
		Radionica radionica = baza.dohvatiRadionicu(Long.valueOf(1));
		radionica.getOprema().add(new Opcija("101", "USB stick"));
		Path d = Files.createTempDirectory(null);
		try {
			baza.snimi(d.toString());
		}
		catch (InconsistentDatabaseException e) {
			return;
		}
		finally {
			for (File file : d.toFile().listFiles()) {
				file.delete();
			}
			d.toFile().delete();
		}
		fail();
		
	}

}
