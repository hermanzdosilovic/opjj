package hr.fer.zemris.java.test;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;


import hr.fer.zemris.web.radionice.RadioniceBaza;

import org.junit.Test;


public class TestDatabase {

	@Test
	public void test ()throws IOException {
		String file="./baza";
		RadioniceBaza baza=new RadioniceBaza(file);
		Path myTempDir = Files.createTempDirectory("temp");
		baza.snimi(myTempDir.toString());
		
	}
}
