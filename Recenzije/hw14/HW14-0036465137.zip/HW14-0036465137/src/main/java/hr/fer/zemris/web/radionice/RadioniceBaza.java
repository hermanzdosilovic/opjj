package hr.fer.zemris.web.radionice;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.logging.Handler;

/**
 * Klasa koja predstavlja bazu podataka
 */
public class RadioniceBaza {

	private String direktorij;
	private Map<Long,Radionica> radionice;
	private Map<Integer,String> oprema;
	private Map<Integer,String> publika;
	private Map<Integer,String> trajanje;

	/**
	 * Razred koji implementira bazu podataka za rad s radionicama
	 * @param direktorij
	 * @throws IOException
	 */
	public RadioniceBaza(String direktorij) throws IOException {
		super();
		this.direktorij = direktorij;
		
		radionice=new HashMap<>();
		oprema=new HashMap<>();
		publika=new HashMap<>();
		trajanje=new HashMap<>();
		
		createMap(oprema, "oprema.txt");
		createMap(publika, "publika.txt");
		createMap(trajanje, "trajanje.txt");
		createRadionice("radionice.txt");
	}
	
	/**
	 * Metoda koja ucitava bazu podataka iz datoteka
	 * @param direktorij
	 * @return
	 * @throws IOException
	 */
	public static RadioniceBaza ucitaj(String direktorij) throws IOException {
		return new RadioniceBaza(direktorij);
	}
	
	/**
	 * Snima bazu u datoteku
	 * @throws IOException 
	 */
	public void snimi(String string) throws IOException {
		
		File f= new File(direktorij);
		f.delete();
		
		File file=new File(string
				+"radionice.txt");
		file.createNewFile();
		
		 FileWriter fstream = new FileWriter(file);
	        BufferedWriter out = new BufferedWriter(fstream);
	        
	        
		for (Long id:radionice.keySet()){
			StringBuilder sb=new StringBuilder();
			sb.append(String.valueOf(radionice.get(id).getId())+"\t");
			sb.append(radionice.get(id).getNaziv()+"\t");
			sb.append(radionice.get(id).getDatum()+"\t");
			sb.append(String.valueOf(radionice.get(id).getMaksPolaznika())+"\t");
			sb.append(radionice.get(id).getTrajanje().getVrijednost()+"\t");
			sb.append(radionice.get(id).getEmail()+"\t");
			sb.append(radionice.get(id).getDopuna()+"\n");
			
			String s=new String(sb);
			out.write(s);
			
		
		}
		out.close();
	}
	
	public String getDirektorij() {
		return direktorij;
	}

	public Map<Long, Radionica> getRadionice() {
		return new HashMap<>(radionice);
	}

	public Map<Integer, String> getOprema() {
		return new HashMap<>(oprema);
	}

	public Map<Integer, String> getPublika() {
		return new HashMap<>(publika);
	}

	public Map<Integer, String> getTrajanje() {
		 return new HashMap<>(trajanje);
	}
 
	private void createRadionice(String filename) throws NumberFormatException, IOException{
	File f=new File(direktorij+"/"+filename);
		
		BufferedReader in = new BufferedReader(new FileReader(f));

		while (in.ready()) {
		  String s = in.readLine();
		  String [] fields=s.split("\t");
		  
		  Long id=Long.parseLong(fields[0]);
		  String naziv=fields[1];
		  String datum=fields[2];
		  Integer maksPolaznika=Integer.parseInt(fields[4]);
		  String email=fields[5];
		  String dopuna=null;
		  if (fields.length==7){
			  dopuna=fields[6];
		  }
		  
		  radionice.put(id,new Radionica(id, naziv, datum, new HashSet<Opcija>(), new Opcija("m", fields[3]), maksPolaznika, email, dopuna));
		}
		in.close();
	}
	
	/**
	 * Pomoćna metoda koja prima ime mape i datoteke te parsira datoteku u mapu
	 * @param mapa
	 * @param filename
	 * @throws IOException
	 */
	private void createMap (Map<Integer,String> mapa, String filename ) throws IOException {
		
		File f=new File(direktorij+"/"+filename);
		
		BufferedReader in = new BufferedReader(new FileReader(f));

		while (in.ready()) {
		  String s = in.readLine();
		  String [] fields=s.split("\t");
		  int id=Integer.parseInt(fields[0]);
		  System.out.println(id);
		  mapa.put(id, fields[1]);
		}
		in.close();
		
	}
}
