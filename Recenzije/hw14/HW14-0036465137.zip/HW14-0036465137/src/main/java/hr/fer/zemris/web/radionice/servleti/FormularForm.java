package hr.fer.zemris.web.radionice.servleti;

import hr.fer.zemris.web.radionice.Opcija;
import hr.fer.zemris.web.radionice.Radionica;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

/**
 * Klasa koja definira formular
 * @author Marta Postenjak
 *
 */
public class FormularForm {

		private String id;
		private String naziv;
		private String datum;
		private String trajanje;
		private String maxPolaznika;
		private String email;
		private String dopuna;

		Map<String, String> greske = new HashMap<>();
		

		public FormularForm() {
		}

		public String dohvatiPogresku(String ime) {
			return greske.get(ime);
		}

		public boolean imaPogresaka() {
			return !greske.isEmpty();
		}

		public boolean imaPogresku(String ime) {
			return greske.containsKey(ime);
		}

		public void popuniIzHttpRequesta(HttpServletRequest req) {
			
			this.naziv = pripremi(req.getParameter("naziv"));
			this.datum = pripremi(req.getParameter("datum"));
			this.trajanje = pripremi(req.getParameter("trajanje"));
			this.maxPolaznika = pripremi(req.getParameter("maxPolaznika"));
			this.email = pripremi(req.getParameter("email"));
			this.dopuna = pripremi(req.getParameter("dopuna"));
			
		}

		public void popuniIzRecorda(Radionica r) {
			if (r.getId() == null) {
				this.id =String.valueOf((int) Math.random());
			} else {
				this.id = r.getId().toString();
			}

			this.naziv = r.getNaziv();
			this.datum = r.getDatum();
			this.trajanje=r.getTrajanje().getVrijednost();
			this.maxPolaznika=r.getMaksPolaznika().toString();
			this.email = r.getEmail();
			this.dopuna=r.getDopuna();
		}

		private String pripremi(String parameter) {
			if (parameter == null) {
				return "";
			} else {
				return parameter.trim();
			}
		}

		public void popuniURecord(Radionica r) {
			if (this.id.isEmpty()) {
				r.setId(null);
			} else {
				r.setId(Long.valueOf(this.id));
			}
			
			r.setNaziv(this.naziv);
			r.setDatum(this.datum);
			r.setTrajanje(new Opcija(r.getId().toString(), this.trajanje));
			r.setMaksPolaznika(Integer.parseInt(this.maxPolaznika));
			r.setEmail(this.email);
			r.setDopuna(this.dopuna);
		
		}

		public void validiraj() {
			greske.clear();

			if (!this.id.isEmpty()) {
				try {
					Long.parseLong(this.id);
				} catch (NumberFormatException e) {
					greske.put("id", "Vrijednost identifikatora nije valjana.");
				}
			}

			if (this.naziv.isEmpty()) {
				greske.put("naziv", "Naziv je obavezno!");
			}

			

			if (this.email.isEmpty()) {
				greske.put("email", "EMail je obavezan!");
			} else {
				int l = email.length();
				int p = email.indexOf('@');
				if (l < 3 || p == -1 || p == 0 || p == l - 1) {
					greske.put("email", "EMail nije ispravnog formata.");
				}
			}
		}

		public String getId() {
			return id;
		}

		public void setId(String id) {
			this.id = id;
		}

		public String getNaziv() {
			return naziv;
		}

		public void setNaziv(String naziv) {
			this.naziv = naziv;
		}

		public String getDatum() {
			return datum;
		}

		public void setDatum(String datum) {
			this.datum = datum;
		}

		public String getTrajanje() {
			return trajanje;
		}

		public void setTrajanje(String trajanje) {
			this.trajanje = trajanje;
		}

		public String getMaxPolaznika() {
			return maxPolaznika;
		}

		public void setMaxPolaznika(String maxPolaznika) {
			this.maxPolaznika = maxPolaznika;
		}

		public String getEmail() {
			return email;
		}

		public void setEmail(String email) {
			this.email = email;
		}

		public String getDopuna() {
			return dopuna;
		}

		public void setDopuna(String dopuna) {
			this.dopuna = dopuna;
		}

		public Map<String, String> getGreske() {
			return greske;
		}

		public void setGreske(Map<String, String> greske) {
			this.greske = greske;
		}



	
}
