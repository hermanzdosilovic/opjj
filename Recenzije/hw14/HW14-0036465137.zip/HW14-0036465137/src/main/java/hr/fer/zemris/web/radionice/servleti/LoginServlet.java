package hr.fer.zemris.web.radionice.servleti;

import hr.fer.zemris.java.user.User;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Klasa koja implementira  servlet za login
 * @author Marta
 *
 */
@SuppressWarnings("serial")
public class LoginServlet extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {

		if (req.getAttribute("login") == null) {
			req.getRequestDispatcher("/WEB-INF/pages/Login.jsp").forward(req,resp);
		}
		
		
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		User login=new User("k","l","K","K");
		req.getSession().setAttribute("login", login);
		req.getRequestDispatcher("/listaj").forward(req, resp);
	}
}
