package hr.fer.zemris.web.radionice;


import java.util.Set;

/**
 * Klasa koja predstavlja radionicu 
 * @author Marta
 *
 */
public class Radionica {

	private Long id;
	private String naziv;
	private String datum;
	private Set<Opcija> oprema;
	private Opcija trajanje;
	Integer maksPolaznika;
	String email;
	String dopuna;
	
	public Radionica () {
		
	}
	
	public Radionica(Long id, String naziv, String datum, Set<Opcija> oprema,
			Opcija trajanje, Integer maksPolaznika, String email, String dopuna) {
		super();
		this.id = id;
		this.naziv = naziv;
		this.datum = datum;
		this.oprema = oprema;
		this.trajanje = trajanje;
		this.maksPolaznika = maksPolaznika;
		this.email = email;
		this.dopuna = dopuna;
	}
	
	/**
	 * Getter za Id
	 * @return
	 */
	public Long getId() {
		return id;
	}
	
	/**
	 * Getter za naziv
	 * @return
	 */
	public String getNaziv() {
		return naziv;
	}
	
	/**
	 * Getter za datum
	 * @return
	 */
	public String getDatum() {
		return datum;
	}
	
	/**
	 * Getter za opcije
	 * @return
	 */
	public Set<Opcija> getOprema() {
		return oprema;
	}
	
	/**
	 * Getter za trajanje
	 * @return
	 */
	public Opcija getTrajanje() {
		return trajanje;
	}
	
	/**
	 * getter za maksimalan broj polaznika
	 * @return
	 */
	public Integer getMaksPolaznika() {
		return maksPolaznika;
	}
	
	/**
	 * Getter za email
	 * @return
	 */
	public String getEmail() {
		return email;
	}
	
	/**
	 * Getter za dopunu
	 * @return
	 */
	public String getDopuna() {
		return dopuna;
	}
	
	/**
	 * Setter za id
	 * @param id
	 */
	public void setId(Long id) {
		this.id = id;
	}
	
	/**
	 * Setter zs naziv
	 * @param naziv
	 */
	public void setNaziv(String naziv) {
		this.naziv = naziv;
	}
	
	/**
	 * Setter za datum 
	 * @param datum
	 */
	public void setDatum(String datum) {
		this.datum = datum;
	}
	
	/**
	 * Setter za opremu
	 * @param oprema
	 */
	public void setOprema(Set<Opcija> oprema) {
		this.oprema = oprema;
	}
	
	/**
	 * Setter za trajanje
	 */
	public void setTrajanje(Opcija trajanje) {
		this.trajanje = trajanje;
	}
	
	/**
	 * Setter za broj olaznika
	 * @param maksPolaznika
	 */
	public void setMaksPolaznika(Integer maksPolaznika) {
		this.maksPolaznika = maksPolaznika;
	}
	
	/**
	 * Setter za email
	 * @param email
	 */
	public void setEmail(String email) {
		this.email = email;
	}
	
	/**
	 * Setter za dopunu
	 * @param dopuna
	 */
	public void setDopuna(String dopuna) {
		this.dopuna = dopuna;
	}
}
