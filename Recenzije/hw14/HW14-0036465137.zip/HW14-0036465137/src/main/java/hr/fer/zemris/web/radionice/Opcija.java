package hr.fer.zemris.web.radionice;

/**
 * Klasa koja modelira opcije datoteka
 * @author Marta 
 *
 */
public class Opcija {

	private String id;
	private String vrijednost;	
	
	public Opcija(String id, String vrijednost) {
		super();
		this.id = id;
		this.vrijednost = vrijednost;
	}
	
	/**
	 * Dohvaca vrijednost vrijednosti
	 * @return
	 */
	public String getVrijednost() {
		return vrijednost;
	}
	
	/**
	 * Postavlja vrijednost vrijednosti
	 * @param vrijednost
	 */
	public void setVrijednost(String vrijednost) {
		this.vrijednost = vrijednost;
	}
	
	/**
	 * Dohvaća vrijednost Id-a
	 * @return
	 */
	public String getId() {
		return id;
	}
	
	
}
