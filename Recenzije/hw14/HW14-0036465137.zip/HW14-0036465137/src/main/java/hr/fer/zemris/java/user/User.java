package hr.fer.zemris.java.user;

/**
 * Klasa koja oznacava korsnika
 * @author Marta
 *
 */
public class User {

	private String login;
	private String zaporka;
	private String ime;
	private String prezime;
	
	public User(String login, String zaporka, String ime, String prezime) {
		super();
		this.login = login;
		this.zaporka = zaporka;
		this.ime = ime;
		this.prezime = prezime;
	}
	public User() {
		
	}
	/**
	 * Getter za login
	 * @return
	 */
	public String getLogin() {
		return login;
	}
	
	/**
	 * Setter za login
	 * @param login
	 */
	public void setLogin(String login) {
		this.login = login;
	}
	
	/**
	 * Getter za zaporku
	 * @return
	 */
	public String getZaporka() {
		return zaporka;
	}
	
	/**
	 * Setter za zaporku
	 * @param zaporka
	 */
	public void setZaporka(String zaporka) {
		this.zaporka = zaporka;
	}
	
	/**
	 * Getter za ime
	 * @return
	 */
	public String getIme() {
		return ime;
	}
	
	/**
	 * Setter za prezime
	 * @param ime
	 */
	public void setIme(String ime) {
		this.ime = ime;
	}
	
	/**
	 * Getter za prezime
	 * @return
	 */
	public String getPrezime() {
		return prezime;
	}
	
	/**Setter za prezime
	 * 
	 * @param prezime
	 */
	public void setPrezime(String prezime) {
		this.prezime = prezime;
	}	
}
