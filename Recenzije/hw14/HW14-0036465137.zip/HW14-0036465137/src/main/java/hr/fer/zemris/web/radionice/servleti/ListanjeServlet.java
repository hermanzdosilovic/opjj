package hr.fer.zemris.web.radionice.servleti;

import hr.fer.zemris.web.radionice.RadioniceBaza;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.imageio.ImageIO;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
/**
 * Klasa implementira servlet za listanje
 * @author Marta Postenjak 
 *
 */
@SuppressWarnings("serial")
public class ListanjeServlet extends HttpServlet{

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		
		RadioniceBaza baza=RadioniceBaza.ucitaj("d:/tecaj/HW14-0036465137/baza");
		List <String> zapisi=new ArrayList<>();
		
		for (Long l:baza.getRadionice().keySet()){
			zapisi.add(baza.getRadionice().get(l).getNaziv()+"\t\t\t"+baza.getRadionice().get(l).getDatum());
		}
		
		req.setAttribute("zapisi", zapisi);
		req.getRequestDispatcher("/WEB-INF/pages/Listaj.jsp").forward(req, resp);

	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		doGet(req, resp);
	}
}
