package hr.fer.zemris.java.tecaj.hw3;

import static org.junit.Assert.*;

import org.junit.Test;

public class ComplexNumberTest {

	private ComplexNumber complexNumber = new ComplexNumber(3, 4);
	private ComplexNumber complexNumberWithOnlyRealPart = ComplexNumber
			.fromReal(3);
	private ComplexNumber complexNumberWithOnlyImaginaryPart = ComplexNumber
			.fromImaginary(4);
	private ComplexNumber complexNumberWithOnlyImaginaryPartEqualOne = ComplexNumber
			.fromImaginary(1);

	@Test
	public void testComplexNumberZero() {
		assertEquals("Kompleksni broj s realni i imaginarnim dijelom nula treba u ispisu biti 0","0",(new ComplexNumber(0, 0)).toString());
	}
	
	@Test
	public void testComplexNumberFromReal() {
		ComplexNumber actualComplexNumber = ComplexNumber.fromReal(3);
		assertEquals("Treba biti " + complexNumberWithOnlyRealPart + ", a ne "
				+ actualComplexNumber, complexNumberWithOnlyRealPart,
				actualComplexNumber);
	}

	@Test
	public void testComplexNumberFromImaginary() {
		ComplexNumber actualComplexNumber = ComplexNumber.fromImaginary(4);
		assertEquals("Treba biti " + complexNumberWithOnlyImaginaryPart
				+ ", a ne " + actualComplexNumber,
				complexNumberWithOnlyImaginaryPart, actualComplexNumber);
	}

	@Test
	public void testComplexNumberFromMagnitudeAndAngle() {
		ComplexNumber actualComplexNumber = ComplexNumber
				.fromMagnitudeAndAngle(5, Math.atan(4.0 / 3.0));
		assertEquals("Treba biti " + complexNumber + ", a ne "
				+ actualComplexNumber, complexNumber, actualComplexNumber);
	}

	@Test
	public void testComplexNumberFromParsingStringWithOnlyRealPart() {
		ComplexNumber actualComplexNumber = ComplexNumber.parse("3");
		assertEquals("Treba biti " + complexNumberWithOnlyRealPart + ", a ne "
				+ actualComplexNumber, complexNumberWithOnlyRealPart,
				actualComplexNumber);
	}

	@Test
	public void testComplexNumberFromParsingStringWithOnlyImaginaryPart() {
		ComplexNumber actualComplexNumber = ComplexNumber.parse("4i");
		assertEquals("Treba biti " + complexNumberWithOnlyImaginaryPart
				+ ", a ne " + actualComplexNumber,
				complexNumberWithOnlyImaginaryPart, actualComplexNumber);
	}

	@Test
	public void testComplexNumberFromParsingStringWithOnlyImaginaryPartEqualOne() {
		ComplexNumber actualComplexNumber = ComplexNumber.parse("i");
		assertEquals("Treba biti " + complexNumberWithOnlyImaginaryPartEqualOne
				+ ", a ne " + actualComplexNumber,
				complexNumberWithOnlyImaginaryPartEqualOne, actualComplexNumber);

	}

	@Test
	public void testComplexNumberFromParsingString() {
		ComplexNumber actualComplexNumber = ComplexNumber.parse("3+4i");
		assertEquals("Treba biti " + complexNumber + ", a ne "
				+ actualComplexNumber, complexNumber, actualComplexNumber);
	}
	
	@Test
	public void testComplexNumberFromParsingStringWithTwoOrMoreImaginary() {
		ComplexNumber actualComplexNumber = ComplexNumber.parse("3i+4i");
		assertEquals("Treba biti " + complexNumber + ", a ne "
				+ actualComplexNumber, new ComplexNumber(0, 3), actualComplexNumber);
	}
	
	@Test
	public void testComplexNumberFromParsingStringWithTwoOrMoreReal() {
		ComplexNumber actualComplexNumber = ComplexNumber.parse("3+4");
		assertEquals("Treba biti " + complexNumber + ", a ne "
				+ actualComplexNumber, new ComplexNumber(3, 0), actualComplexNumber);
	}
	
	@Test
	public void testComplexNumberFromParsingStringWithTwoOrMoreRealAndImaginary() {
		ComplexNumber actualComplexNumber = ComplexNumber.parse("3+4+3i+4i");
		assertEquals("Treba biti " + complexNumber + ", a ne "
				+ actualComplexNumber, new ComplexNumber(3, 3), actualComplexNumber);
	}
	
	@Test
	public void testGetReal() {
		assertEquals("Treba biti 3, a ne " + complexNumber.getReal(), 3,
				complexNumber.getReal(), 1E-10);
	}

	@Test
	public void testGetImaginary() {
		assertEquals("Treba biti 4, a ne " + complexNumber.getImaginary(), 4,
				complexNumber.getImaginary(), 1E-10);
	}

	@Test
	public void testGetMagnitude() {
		double actualMagnitude = complexNumber.getMagnitude();
		double expectedMagnitude = 5;
		assertEquals("Treba biti " + expectedMagnitude + ", a ne "
				+ actualMagnitude, expectedMagnitude, actualMagnitude, 1E-10);
	}

	@Test
	public void testGetAngle() {
		double actualAngle = complexNumber.getAngle();
		double expectedAngle = Math.atan(4.0 / 3.0);
		assertEquals("Treba biti " + expectedAngle + ", a ne " + actualAngle,
				expectedAngle, actualAngle, 1E-10);
	}

	@Test
	public void testAddComplexNumber() {
		ComplexNumber actualComplexNumber = complexNumber
				.add(new ComplexNumber(7, 6));
		ComplexNumber expectedComplexNumber = new ComplexNumber(10, 10);
		assertEquals("Treba biti " + expectedComplexNumber + ", a ne "
				+ actualComplexNumber, expectedComplexNumber,
				actualComplexNumber);
	}

	@Test
	public void testSubComplexNumber() {
		ComplexNumber actualComplexNumber = complexNumber
				.sub(new ComplexNumber(3, 4));
		ComplexNumber expectedComplexNumber = new ComplexNumber(0, 0);
		assertEquals("Treba biti " + expectedComplexNumber + ", a ne "
				+ actualComplexNumber, expectedComplexNumber,
				actualComplexNumber);
	}

	@Test
	public void testMultiplyComplexNumberWithZero() {
		ComplexNumber actualComplexNumber = complexNumber
				.mul(new ComplexNumber(0, 0));
		ComplexNumber expectedComplexNumber = new ComplexNumber(0, 0);
		assertEquals("Treba biti " + expectedComplexNumber + ", a ne "
				+ actualComplexNumber, expectedComplexNumber,
				actualComplexNumber);
	}

	@Test
	public void testMultiplyComplexNumberWithOnlyRealPart() {
		ComplexNumber actualComplexNumber = complexNumber
				.mul(complexNumberWithOnlyRealPart);
		ComplexNumber expectedComplexNumber = new ComplexNumber(9, 12);
		assertEquals("Treba biti " + expectedComplexNumber + ", a ne "
				+ actualComplexNumber, expectedComplexNumber,
				actualComplexNumber);
	}

	@Test
	public void testMultiplyComplexNumberWithOnlyImaginaryPart() {
		ComplexNumber actualComplexNumber = complexNumber
				.mul(complexNumberWithOnlyImaginaryPart);
		ComplexNumber expectedComplexNumber = new ComplexNumber(-16, 12);
		assertEquals("Treba biti " + expectedComplexNumber + ", a ne "
				+ actualComplexNumber, expectedComplexNumber,
				actualComplexNumber);
	}

	@Test
	public void testMultiplyComplexNumber() {
		ComplexNumber actualComplexNumber = complexNumber.mul(complexNumber);
		ComplexNumber expectedComplexNumber = new ComplexNumber(-7, 24);
		assertEquals("Treba biti " + expectedComplexNumber + ", a ne "
				+ actualComplexNumber, expectedComplexNumber,
				actualComplexNumber);
	}

	@Test(expected = IllegalArgumentException.class)
	public void testDivideComplexNumberWithZero() {
		complexNumber.div(new ComplexNumber(0, 0));
	}

	@Test
	public void testDivideComplexNumberWithOnlyRealPart() {
		ComplexNumber actualComplexNumber = complexNumber
				.div(complexNumberWithOnlyRealPart);
		ComplexNumber expectedComplexNumber = new ComplexNumber(1.0 / 1.0,
				4.0 / 3.0);
		assertEquals("Treba biti " + expectedComplexNumber + ", a ne "
				+ actualComplexNumber, expectedComplexNumber,
				actualComplexNumber);
	}

	@Test
	public void testDivideComplexNumberWithOnlyImaginaryPart() {
		ComplexNumber actualComplexNumber = complexNumber
				.div(complexNumberWithOnlyImaginaryPart);
		ComplexNumber expectedComplexNumber = new ComplexNumber(1.0 / 1.0,
				-3.0 / 4.0);
		assertEquals("Treba biti " + expectedComplexNumber + ", a ne "
				+ actualComplexNumber, expectedComplexNumber,
				actualComplexNumber);
	}

	@Test
	public void testDivideComplexNumber() {
		ComplexNumber actualComplexNumber = complexNumber.div(complexNumber);
		ComplexNumber expectedComplexNumber = new ComplexNumber(1.0 / 1.0, 0);
		assertEquals("Treba biti " + expectedComplexNumber + ", a ne "
				+ actualComplexNumber, expectedComplexNumber,
				actualComplexNumber);
	}

	@Test(expected = IllegalArgumentException.class)
	public void testNegativeRootOfComplexNumber() {
		int n = -5;
		complexNumber.root(n);
	}

	@Test(expected = IllegalArgumentException.class)
	public void testZeroRootOfComplexNumber() {
		int n = 0;
		complexNumber.root(n);
	}

	@Test
	public void testFirstRootOfComplexNumber() {
		int n = 1;
		ComplexNumber[] complexNumbers = complexNumber.root(n);
		assertEquals("Treba biti " + complexNumber + ", a ne "
				+ complexNumbers[0], complexNumber, complexNumbers[0]);
	}

	@Test
	public void testSecondRootOfComplexNumber() {
		int n = 2;
		ComplexNumber[] actualComplexNumbers = complexNumber.root(n);
		ComplexNumber[] expectedComplexNumbers = { new ComplexNumber(2, 1),
				new ComplexNumber(-2, -1) };
		assertArrayEquals(expectedComplexNumbers, actualComplexNumbers);
	}

	@Test
	public void testFifthRootOfComplexNumber() {
		int n = 5;
		ComplexNumber[] actualComplexNumbers = complexNumber.root(n);
		ComplexNumber[] expectedComplexNumbers = {
				new ComplexNumber(1.35607, 0.25442),
				new ComplexNumber(0.17708, 1.36832),
				new ComplexNumber(-1.24663, 0.59125),
				new ComplexNumber(-0.94754, -1.00291),
				new ComplexNumber(0.66102, -1.21108) };
		assertArrayEquals(expectedComplexNumbers, actualComplexNumbers);
	}

	@Test(expected = IllegalArgumentException.class)
	public void testNegativePowerOfComplexNumber() {
		int n = -5;
		complexNumber.power(n);

	}

	@Test
	public void testZeroPowerOfComplexNumber() {
		int n = 0;
		ComplexNumber actualComplexNumber = complexNumber.power(n);
		ComplexNumber expectedComplexNumber = new ComplexNumber(1, 0);
		assertEquals("Treba biti " + expectedComplexNumber + ", a ne "
				+ actualComplexNumber, expectedComplexNumber,
				actualComplexNumber);
	}

	@Test
	public void testFifthPowerOfComplexNumber() {
		int n = 5;
		ComplexNumber actualComplexNumber = complexNumber.power(n);
		ComplexNumber expectedComplexNumber = new ComplexNumber(-237, -3116);
		assertEquals("Treba biti " + expectedComplexNumber + ", a ne "
				+ actualComplexNumber, expectedComplexNumber,
				actualComplexNumber);
	}

	@Test
	public void testComplexNumberToStringWithOnlyRealPart() {
		String expectedComplexNumber = "3";
		assertEquals("Treba biti " + expectedComplexNumber + ", a ne "
				+ complexNumberWithOnlyRealPart.toString(),
				expectedComplexNumber, complexNumberWithOnlyRealPart.toString());
	}

	@Test
	public void testComplexNumberToStringWithOnlyImaginaryPart() {
		String expectedComplexNumber = "4i";
		assertEquals("Treba biti " + expectedComplexNumber + ", a ne "
				+ complexNumberWithOnlyImaginaryPart, expectedComplexNumber,
				complexNumberWithOnlyImaginaryPart.toString());
	}

	@Test
	public void testComplexNumberToStringWithOnlyImaginaryPartEqualOne() {
		String expectedComplexNumber = "i";
		assertEquals("Treba biti " + expectedComplexNumber + ", a ne "
				+ complexNumberWithOnlyImaginaryPartEqualOne,
				expectedComplexNumber,
				complexNumberWithOnlyImaginaryPartEqualOne.toString());
	}

	@Test
	public void testComplexNumberToStringWithOnlyImaginaryPartEqualMinusOne() {
		String expectedComplexNumber = "-i";
		assertEquals("Treba biti " + expectedComplexNumber + ", a ne "
				+ (new ComplexNumber(0, -1)).toString(), expectedComplexNumber,
				(new ComplexNumber(0, -1)).toString());
	}

	@Test
	public void testComplexNumberToStringWithImaginaryPartEqualMinusOne() {
		String expectedComplexNumber = "1-i";
		assertEquals("Treba biti " + expectedComplexNumber + ", a ne "
				+ (new ComplexNumber(1, -1)).toString(), expectedComplexNumber,
				(new ComplexNumber(1, -1)).toString());
	}

	@Test
	public void testComplexNumberToStringWithImaginaryPartEqualOne() {
		String expectedComplexNumber = "1+i";
		assertEquals("Treba biti " + expectedComplexNumber + ", a ne "
				+ (new ComplexNumber(1, 1)).toString(), expectedComplexNumber,
				(new ComplexNumber(1, 1)).toString());
	}

	@Test
	public void testComplexNumberToString() {
		String expectedComplexNumber = "3+4i";
		assertEquals("Treba biti " + expectedComplexNumber + ", a ne "
				+ complexNumber.toString(), expectedComplexNumber,
				complexNumber.toString());
	}
	

	@Test
	public void testComplexNumberEqualsToDifferentTypeOfObject() {
		assertFalse(
				"Objekt tipa ComplexNumber se može usporediti jedino sa objektom tipa ComplexNumber, inace uvijek mora biti različit",
				complexNumber.equals("3+4i"));
	}

	@Test(expected=IllegalArgumentException.class)
	public void testComplexNumberCheckNull() {
		complexNumber.add(null);
	}
	
	@Test
	public void testComplexNumberHashCode() {
		assertEquals(47,complexNumber.hashCode());
	}
}
