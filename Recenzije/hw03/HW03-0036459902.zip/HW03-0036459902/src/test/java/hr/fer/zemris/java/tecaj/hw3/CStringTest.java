package hr.fer.zemris.java.tecaj.hw3;

import static org.junit.Assert.*;

import org.junit.Test;

public class CStringTest {
	
	CString cString = new CString("abcdefg");
	
	@Test(expected=IllegalArgumentException.class)
	public void testCStringCreateStringWithOffsetGreaterThanDataLength () {
		new CString(cString.toCharArray(),8,0);
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void testCStringCreateStringWithNegativeLength () {
		new CString(cString.toCharArray(),3,-1);
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void testCStringCreateStringWithOffsetPlusLengthGreaterThanDataLength () {
		new CString(cString.toCharArray(),3,5);
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void testCStringCreateStringWithOffsetPlusLengthAndOffsetGreaterThanDataLength () {
		new CString(cString.toCharArray(),8,5);
	}
	
	@Test
	public void testCStringCreateFromCStringWithDataArrayLargerThanNeeded() {
		CString actualCString = new CString(new CString(cString.toCharArray(),2,3));
		assertEquals(3,actualCString.length());
	}
	
	@Test
	public void testCStringCreateEmptyString() {
		CString emptyCString = new CString("");
		assertEquals("Prazan string \"" + emptyCString + "\" mora imati duljinu 0, a ne " + emptyCString.length(),0,emptyCString.length());
	}
	
	@Test
	public void testCStringLength() {
		int length = cString.length();
		assertEquals(cString + " mora biti duljine 7, a ne " + length, 7, length);
	}
	
	@Test
	public void testCStringCharAt() {
		assertEquals(cString + " na poziciji 3 mora imati d, a ne " + cString.charAt(3),'d', cString.charAt(3));
	}
	
	@Test(expected=IndexOutOfBoundsException.class)
	public void testCStringCharAtIndexOutOfBounds() {
		cString.charAt(10);
	}
	
	@Test
	public void testCStringToString() {
		assertEquals(cString + " kao string mora biti abcdefg, a ne " + cString.toString(),"abcdefg", cString.toString());
	}
	
	@Test
	public void testCStringIndexOf() {
		assertEquals("U" + cString + " znak d je na poziciji 3, a ne " + cString.indexOf('d'),3, cString.indexOf('d'));
	}
	
	@Test
	public void testCStringIndexOfNotContainingChar() {
		assertEquals("U" + cString + " nema znaka z pa je potrebno vratiti -1, a ne " + cString.indexOf('z'),-1, cString.indexOf('z'));
	}
	
	@Test
	public void testCStringStartsWithLongerCString() {
		CString longerSubCString = new CString("abcdefghi");
		assertFalse(cString + " ne počinje s " + longerSubCString, cString.startsWith(longerSubCString));
	}
	
	@Test
	public void testCStringStartsWith() {
		CString subCString = new CString("abc");
		assertTrue(cString + " treba počinjati s " + subCString, cString.startsWith(subCString));
	}
	
	@Test
	public void testCStringEndsWithLongerCString() {
		CString longerSubCString = new CString("abcdefghi");
		assertFalse(cString + " ne završava s " + longerSubCString, cString.endsWith(longerSubCString));
	}
	
	@Test
	public void testCStringEndsWith() {
		CString subCString = new CString("efg");
		assertTrue(cString + " treba završavati s " + subCString, cString.endsWith(subCString));
	}
	
	@Test
	public void testCStringNotEndsWith() {
		CString subCString = new CString("ef");
		assertFalse(cString + " ne završava s " + subCString, cString.endsWith(subCString));
	}
	
	@Test
	public void testCStringContains() {
		CString subCString = new CString("cde");
		assertTrue(cString + " treba sadržavati " + subCString, cString.contains(subCString));
	}
	
	@Test
	public void testCStringNotContains() {
		CString subCString = new CString("cDe");
		assertFalse(cString + " ne sadržava " + subCString, cString.contains(subCString));
	}
	
	@Test
	public void testCStringSubstring() {
		CString subCString = new CString("cde");
		assertEquals(subCString + " mora biti substring od " + cString , subCString, cString.substring(2, 5));
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void testCStringSubstringUsingStartIndexLessThanZero() {
		cString.substring(-1, 5);
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void testCStringSubstringUsingStartIndexGreaterThanStringLength() {
		cString.substring(9, 10);
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void testCStringSubstringUsingEndIndexGreaterThanStringLength() {
		cString.substring(2, 9);
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void testCStringSubstringUsingEndIndexLessThanStartIndex() {
		cString.substring(2, 1);
	}
	
	
	@Test(expected=IllegalArgumentException.class)
	public void testCStringSubstringIllegalArgumentException() {
		cString.substring(-1, 5);
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void testCStringLeftIllegalArgumentException() {
		cString.left(10);
	}
	
	@Test
	public void testCStringLeft() {
		CString pomCString = new CString("abc");
		CString leftCString = new CString(pomCString);
		assertEquals("Lijevi dio " + cString + " duljine 3 mora biti abc, a ne " + leftCString,leftCString,cString.left(3));
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void testCStringRightIllegalArgumentException() {
		cString.right(10);
	}
	
	@Test
	public void testCStringRight() {
		CString rightCString = new CString("efg");
		assertEquals("Desni dio " + cString + " duljine 3 mora biti efg, a ne " + rightCString,rightCString,cString.right(3));
	}
	
	@Test
	public void testCStringAdd() {
		CString expectedCString = new CString("abcdefghijk");
		CString actualCString = cString.add(new CString("hijk"));
		assertEquals("hijk nadodan na " + cString + " mora dati " + expectedCString + ", a ne " + actualCString,expectedCString,actualCString);
	}
	
	@Test
	public void testCStringReplaceAllOldCharWithEqualNewChar() {
		CString expectedCString = new CString("abcdefg");
		CString actualCString = cString.replaceAll('d', 'd');
		assertEquals("Zamjenom d sa d iz " + cString + " treba se dobiti " + expectedCString,expectedCString,actualCString);	
	}
	
	@Test
	public void testCStringReplaceAllChar() {
		CString expectedCString = new CString("abcDefg");
		CString actualCString = cString.replaceAll('d', 'D');
		assertEquals("Zamjenom d sa D iz " + cString + " treba se dobiti " + expectedCString,expectedCString,actualCString);
	}
	
	@Test
	public void testCStringReplaceNotContainingCString() {
		CString expectedCString = new CString("abcdefg");
		CString actualCString = cString.replaceAll(new CString("xy"), new CString("DA"));
		assertEquals("Zamjenom xy sa DA iz " + cString + " treba se dobiti " + expectedCString,expectedCString,actualCString);	
	}
	
	@Test
	public void testCStringReplaceNotContainingCStringWithEqualCString() {
		CString expectedCString = new CString("abcdefg");
		CString actualCString = cString.replaceAll(new CString("xy"), new CString("xy"));
		assertEquals("Zamjenom xy sa xy iz " + cString + " treba se dobiti " + expectedCString,expectedCString,actualCString);	
	}
	
	@Test
	public void testCStringReplaceAllCString() {
		CString expectedCString = new CString("abcDAefg");
		CString actualCString = cString.replaceAll(new CString("d"), new CString("DA"));
		assertEquals("Zamjenom d sa DA iz " + cString + " treba se dobiti " + expectedCString,expectedCString,actualCString);	
	}
	
	@Test
	public void testCStringReplaceAllOldCStringWithEqualNewCString() {
		CString expectedCString = new CString("abcdefg");
		CString actualCString = cString.replaceAll(new CString("de"), new CString("de"));
		assertEquals("Zamjenom de sa de iz " + cString + " treba se dobiti " + expectedCString,expectedCString,actualCString);	
	}
	
	@Test
	public void testCStringEqualsToDifferentTypeOfObject() {
		assertFalse("Objekt tipa CString se može usporediti jedino sa objektom tipa CString, inace uvijek mora biti različit",cString.equals(new String("abcdefg")));
	}
	
	@Test
	public void testCStringEqualsToCString() {
		CString equalCString = new CString("abcdefg");
		assertTrue(cString + " i " + equalCString + " moraju biti jednaki",cString.equals(equalCString));
	}
	
	@Test
	public void testCStringNotEqualsToCString() {
		CString notEqualCString = new CString("abcdefh");
		assertFalse(cString + " i " + notEqualCString + " ne smiju biti jednaki",cString.equals(notEqualCString));
	}
	
	@Test
	public void testCStringEqualsToCStringWithDifferentLength() {
		assertFalse("Objekt tipa CString se može usporediti jedino sa objektom tipa CString iste duljine, inace uvijek mora biti različit",cString.equals(new CString("abcdef")));
	}
	
	
	
	@Test(expected=IllegalArgumentException.class)
	public void testCStringCheckNull() {
		cString.add(null);
	}
	
	@Test
	public void testCStringHashCode() {
		assertEquals(47,cString.hashCode());
	}
	
	
}
