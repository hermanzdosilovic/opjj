package hr.fer.zemris.java.tecaj.hw3;

import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 * Klasa <code>IntegerSequence</code> omogućava stvaranje sekvence, koja se
 * sastoji od cijelih brojeva, te iteriranje kroz tu sekvencu. Klasa
 * implementira sučelje <code>Iterable</code> s Integer tipom.
 * 
 * @author Ivan Cutvarić
 * @version 1.0
 * 
 */
public class IntegerSequence implements Iterable<Integer> {

	/** Koristi se za spremanje vrijednosti početka sekvence.*/
	private int start;
	
	/** Koristi se za spremanje vrijednosti kraja sekvence.*/
	private int finish;
	
	/** Koristi se za spremanje vrijednosti koraka sekvence.*/
	private int step;
	
	/** Koristi se za spremanje polja cijelobrojnih vrijednosti.*/
	private int[] sequence;

	/**
	 * Stvara sekvencu cijelih brojeva koja počinje od vrijednosti start te je
	 * svaki slijedeći broj veći za vrijednost step. Zadnji broj je manji ili
	 * jednak vrijednosti finish.
	 * 
	 * @param start
	 *            - početna vrijednost
	 * @param finish
	 *            - krajnja vrijednost
	 * @param step
	 *            - korak
	 */
	public IntegerSequence(int start, int finish, int step) {
		this.start = start;
		this.finish = finish;
		this.step = step;
		setSequence();

	}

	/**
	 * Metoda koja stvara polje cijelih brojeva u skladu s vrijednostima
	 * predanima konstruktoru.
	 */
	private void setSequence() {
		sequence = new int[(finish - start) / step + 1];
		for (int i = 0; i < sequence.length; i++) {
			sequence[i] = start + step * i;
		}
	}

	public int getStart() {
		return start;
	}

	public int getFinish() {
		return finish;
	}

	public int getStep() {
		return step;
	}

	@Override
	public Iterator<Integer> iterator() {
		return new IntegerSequenceIterator();
	}

	/**
	 * Privatna klasa <code>IntegerSequenceIterator</code> služi za kreiranje
	 * iteratora koji omogućava iteriranje po sekvenci cijelih brojeva.
	 * Implementira sučelje <code>Iterator</code> s Integer tipom.
	 * 
	 * @author Ivan Cutvarić
	 * @version 1.0
	 */
	private class IntegerSequenceIterator implements Iterator<Integer> {

		private int current = 0;

		@Override
		public boolean hasNext() {
			return current < sequence.length;
		}

		@Override
		public Integer next() {
			if (current >= sequence.length) {
				throw new NoSuchElementException("Na poziciji " + current + " nema elementa");
			}
			return sequence[current++];
		}

		@Override
		public void remove() {
			throw new UnsupportedOperationException(
					"Metoda remove nije implementirana!");
		}

	}
}
