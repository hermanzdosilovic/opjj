/**
 * Paket sadrži razrede potrebne u 3. domaćoj zadaći.
 * Paket sadrži sljedeće razrede: <br>
 *  - razred <code>ComplexNumber</code> za rad s kompleksnim brojevima<br>
 *  - razred <code>CString</code> za rad sa stringovima<br>
 *  - razred <code>IntegerSequence</code> koji stvara iterabilnu sekvencu cijelih brojeva<br>
 * 
 * @author Ivan Cutvarić
 * @since 1.0
 */
package hr.fer.zemris.java.tecaj.hw3;
