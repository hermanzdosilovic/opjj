package hr.fer.zemris.java.tecaj.hw3;

import java.text.DecimalFormat;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Klasa <code>ComplexNumber</code> nudi podršku za rad s kompleksnim brojevima.
 * 
 * @author Ivan Cutvarić
 * @version 1.0
 */
public class ComplexNumber {

	/** Koristi se za spremanje realne vrijednosti. */
	private double real;

	/** Koristi se za spremanje imaginarne vrijednosti. */
	private double imaginary;

	/**
	 * Konstruktor koji inicijalizira realni i imaginarni dio kompleksnog broja.
	 * 
	 * @param real
	 *            - vrijednost na koju se postavi realni dio
	 * @param imaginary
	 *            - vrijednost na koju se postavi imaginarni dio
	 */
	public ComplexNumber(double real, double imaginary) {
		this.real = real;
		this.imaginary = imaginary;
	}

	/**
	 * Statička metoda koja kreira kompleksni broj iz realnog broja tako da
	 * realni dio kompleksnog broja postavi na taj realni broj, a imaginarni
	 * postavi na nula.
	 * 
	 * @param real
	 *            - realni broj na koji se postavlja realni dio kompleksnog
	 *            broja
	 * @return novostvoreni kompleksni broj
	 */
	public static ComplexNumber fromReal(double real) {
		ComplexNumber complexNumber = new ComplexNumber(real, 0.0);
		return complexNumber;
	}

	/**
	 * Statička metoda koja kreira kompleksni broj iz realnog broja tako da
	 * imaginarni dio kompleksnog broja postavi na taj realni broj, a realni
	 * postavi na nula.
	 * 
	 * @param real
	 *            - realni broj na koji se postavlja imaginarni dio kompleksnog
	 *            broja
	 * @return novostvoreni kompleksni broj
	 */
	public static ComplexNumber fromImaginary(double real) {
		ComplexNumber complexNumber = new ComplexNumber(0.0, real);
		return complexNumber;
	}

	/**
	 * Statička metoda koja kreira kompleksni broj iz realnog broja koji
	 * predstavlja modul i realnog broja koji predstavlja kut tako da se iz te
	 * dvije vrijednosti izračunaju vrijednosti realnog i imaginarnog dijela
	 * kompleksnog broja te se vrati tako novostvoreni kompleksni broj s tim
	 * vrijednostima.
	 * 
	 * @param magnitude
	 *            - realni broj koji predstavlja modul
	 * @param angle
	 *            - realni broj koji predstavlja kut
	 * @return novostvoreni kompleksni broj
	 * @throws IllegalArgumentException
	 *             ako je parametar magnitude negativan broj
	 */
	public static ComplexNumber fromMagnitudeAndAngle(double magnitude,
			double angle) {
		checkNegative(magnitude);
		double real = magnitude / (Math.sqrt(1 + Math.pow(Math.tan(angle), 2)));
		double imaginary = Math
				.sqrt(Math.pow(magnitude, 2) - Math.pow(real, 2));
		ComplexNumber complexNumber = new ComplexNumber(real, imaginary);
		return complexNumber;
	}

	/**
	 * Statička metoda koja kreira kompleksni broj iz niza znakova. Niz znakova
	 * može biti npr. "3.51","-3.17","-2.71i","i","1","-2.71-3.15i".
	 * 
	 * @param s
	 *            - niz znakova
	 * @return novostvoreni kompleksni broj
	 */
	public static ComplexNumber parse(String s) {
		Pattern pattern = Pattern.compile("[+|-]?\\d*\\.?\\d*i?");
		Matcher matcher = pattern.matcher(s);
		double real = 0, imaginary = 0;
		while (matcher.find()) {
			String number = matcher.group();
			if (!number.isEmpty()) {
				if (number.contains("i")) {
					if (imaginary == 0) {
						if (number == "i") {
							imaginary = 1;
						} else {
							imaginary = Double.parseDouble(number
								.replace('i', '\0'));
						}
					}
				} else {
					if (real == 0) {
						real = Double.parseDouble(number);
					}
				}
			}
		}
		ComplexNumber complexNumber = new ComplexNumber(real, imaginary);
		return complexNumber;
	}

	/**
	 * Metoda koja vraća realni dio kompleksnog broja.
	 * 
	 * @return realni dio kompleksnog broja
	 */
	public double getReal() {
		return real;
	}

	/**
	 * Metoda koja vraća imaginarni dio kompleksnog broja.
	 * 
	 * @return imaginarni dio kompleksnog broja
	 */
	public double getImaginary() {
		return imaginary;
	}

	/**
	 * Metoda koja računa i vraća modul kompleksnog broja.
	 * 
	 * @return modul kompleksnog broja
	 */
	public double getMagnitude() {
		double magnitude = Math.sqrt(real * real + imaginary * imaginary);
		return magnitude;
	}

	/**
	 * Metoda koja računa i vraća kut kompleksnog broja u radijanima.
	 * 
	 * @return kut imaginarnog broja u radijanima
	 */
	public double getAngle() {
		double angle = Math.atan(imaginary / real);
		return angle;
	}

	/**
	 * Metoda koja zbraja kompleksni broj c s instancom kompleksnog broja koja
	 * poziva ovu metodu te vraća dobiveni kompleksni broj nastao zbrajanjem.
	 * 
	 * @param c
	 *            - kompleksni broj
	 * @return novostvoreni kompleksni broj nastao zbrajanjem
	 * @throws IllegalArgumentException ako je c null
	 */
	public ComplexNumber add(ComplexNumber c) {
		checkNull(c);
		ComplexNumber complexNumber = new ComplexNumber(real + c.getReal(),
				imaginary + c.getImaginary());
		return complexNumber;
	}

	private void checkNull(ComplexNumber c) {
		if (c == null) {
			throw new IllegalArgumentException("Ulazni argument ne smije biti null!");
		}
	}

	/**
	 * Metoda koja oduzima kompleksni broj c od instance kompleksnog broja koja
	 * poziva ovu metodu te vraća dobiveni kompleksni broj nastao oduzimanjem.
	 * 
	 * @param c
	 *            - kompleksni broj
	 * @return novostvoreni kompleksni broj nastao oduzimanjem
	 * @throws IllegalArgumentException ako je c null
	 */
	public ComplexNumber sub(ComplexNumber c) {
		checkNull(c);
		ComplexNumber complexNumber = new ComplexNumber(real - c.getReal(),
				imaginary - c.getImaginary());
		return complexNumber;
	}

	/**
	 * Metoda koja množi kompleksni broj c s instancom kompleksnog broja koja
	 * poziva ovu metodu te vraća dobiveni kompleksni broj nastao množenjem.
	 * 
	 * @param c
	 *            - kompleksni broj
	 * @return novostvoreni kompleksni broj nastao množenjem
	 * @throws IllegalArgumentException ako je c null
	 */
	public ComplexNumber mul(ComplexNumber c) {
		checkNull(c);
		double real = this.real * c.getReal() - this.imaginary
				* c.getImaginary();
		double imaginary = this.real * c.getImaginary() + this.imaginary
				* c.getReal();
		ComplexNumber complexNumber = new ComplexNumber(real, imaginary);
		return complexNumber;
	}

	/**
	 * Metoda koja dijeli kompleksni broj c s instancom kompleksnog broja koja
	 * poziva ovu metodu te vraća dobiveni kompleksni broj nastao djeljenjem.
	 * 
	 * @param c
	 *            - kompleksni broj
	 * @return novostvoreni kompleksni broj nastao djeljenjem
	 * @throws IllegalArgumentException ako je c null ili ima realni i imaginarni dio nula
	 */
	public ComplexNumber div(ComplexNumber c) {
		checkNull(c);
		checkZero(c);
		double nazivnik = Math.pow(c.getReal(), 2)
				+ Math.pow(c.getImaginary(), 2);
		double real = (this.real * c.getReal() + this.imaginary
				* c.getImaginary())
				/ nazivnik;
		double imaginary = (this.imaginary * c.getReal() - this.real
				* c.getImaginary())
				/ nazivnik;
		ComplexNumber complexNumber = new ComplexNumber(real, imaginary);
		return complexNumber;
	}

	private void checkZero(ComplexNumber c) {
		if (c.equals(new ComplexNumber(0, 0))) {
			throw new IllegalArgumentException(
					"Nije dozvoljeno dijeljenje s nulom!");
		}

	}

	/**
	 * Metoda koja potencira instancu kompleksnog broja na n-tu potenciju te
	 * vraća dobiveni kompleksni broj nastao potenciranjem.
	 * 
	 * @param n
	 *            - potencija, mora biti veća ili jednaka od nula
	 * @return novostvoreni kompleksni broj nastao potenciranjem
	 * @throws IllegalArgumentException
	 *             ako je n<0
	 */
	public ComplexNumber power(int n) {
		checkNegative(n);
		double real = Math.pow(getMagnitude(), n) * Math.cos(getAngle() * n);
		double imaginary = Math.pow(getMagnitude(), n)
				* Math.sin(getAngle() * n);
		ComplexNumber complexNumber = new ComplexNumber(real, imaginary);
		return complexNumber;
	}

	/**
	 * Metoda koja vadi sve n-te korijene iz instance kompleksnog broja te vraća
	 * polje dobivenih kompleksnih brojeva nastalih korijenovanjem.
	 * 
	 * @param n
	 *            - n-ti korijen, mora biti veći od nula
	 * @return novostvoreno polje kompleksnih brojeva nastalih korijenovanjem
	 * @throws IllegalArgumentException
	 *             ako je n<=0
	 */
	public ComplexNumber[] root(int n) {
		checkNegative(n - 1);
		double magnitude = getMagnitude();
		double angle = getAngle();
		double magnitudeRoot = Math.pow(magnitude, 1. / n);
		ComplexNumber[] complexNumbers = new ComplexNumber[n];
		for (int i = 0; i < n; i++) {
			double real = magnitudeRoot
					* (Math.cos((angle + 2 * i * Math.PI) / n));
			double imaginary = magnitudeRoot
					* (Math.sin((angle + 2 * i * Math.PI) / n));
			ComplexNumber complexNumber = new ComplexNumber(real, imaginary);
			complexNumbers[i] = complexNumber;
		}
		return complexNumbers;
	}

	/**
	 * Vraća zapis instance u obliku [realni dio na najviše 5
	 * decimala]+/-[imaginarni dio na najviše 5 decimala]i.
	 */
	@Override
	public String toString() {
		String string = "";
		if (real != 0) {
			DecimalFormat dfReal = new DecimalFormat("0.#####");
			string += String.format("%s", dfReal.format(real));
		}
		if (imaginary != 0) {
			if (real == 0) {
				if (imaginary == 1) {
					string += "i";
				} else {
					if (imaginary == -1) {
						string += "-i";
					} else {
						DecimalFormat dfImaginary = new DecimalFormat("0.#####");
						string += dfImaginary.format(imaginary) + "i";
					}
				}
			} else {
				if (imaginary == 1) {
					string += "+i";
				} else {
					if (imaginary == -1) {
						string += "-i";
					} else {
						DecimalFormat dfImaginary = new DecimalFormat(
								"+0.#####;-0.#####");
						string += dfImaginary.format(imaginary) + "i";
					}

				}
			}

		}
		if (string.isEmpty()) {
			return "0";
		}
		return string;

	}

	/**
	 * Provjerava jednakost ComplexNumber objekata.
	 * 
	 * @return true ako objekti sadrže jednake realne i imaginarne dijelove
	 *         zaokružene na 5 decimala, inace false
	 */
	@Override
	public boolean equals(Object object) {
		if (object instanceof ComplexNumber) {
			ComplexNumber complexNumber = (ComplexNumber) object;
			if (Math.abs(complexNumber.getReal() - this.real) < 1E-5
					&& Math.abs(complexNumber.getImaginary() - this.imaginary) < 1E-5) {
				return true;
			}
		}
		return false;
	}
	
	@Override
	public int hashCode() {
		assert false : "hashCode not designed";
		return 47;
	}

	/**
	 * Privatna statička metoda koja provjera je li broj negativan.
	 * 
	 * @param n
	 *            - broj koji se provjerava
	 * @throws IllegalArgumentException
	 *             ako je broj negativan, inače samo izlazi iz metode
	 */
	private static void checkNegative(double n) {
		if (n < 0) {
			throw new IllegalArgumentException(
					"Modul mora biti nenegativan broj");
		}
	}
}
