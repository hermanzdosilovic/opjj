package hr.fer.zemris.java.tecaj.hw3;

import java.util.Arrays;

/**
 * Klasa <code>CString</code> nudi sličnu funkcionalnost kao i stara službena
 * implementacija klase <code>String</code>. Predstavlja nepromjenjive stringove
 * nad kojima se metode, poput substring, moraju izvršavati u O(1) složenosti,
 * što se postiže djeljenjem istog niza znakova.
 * 
 * @author Ivan Cutvarić
 * @version 1.0
 * 
 */
public class CString {

	/** Koristi se za spremanje broja znakova od koji predstavljaju CString. */
	private int count;

	/** Koristi se za spremanje odmaka. */
	private int offset;

	/** Koristi se za spremanje niza znakova. */
	private final char[] value;

	/**
	 * Izrađuje instancu na temelju niza znakova, odmaka od početka niza znakova
	 * i duljine koja predstavlja koliko znakova se uzima od odmaka na dalje.
	 * 
	 * @param data
	 *            - niz znakova
	 * @param offset
	 *            - odmak od početka niza znakova
	 * @param length
	 *            - duljina
	 */
	public CString(char[] data, int offset, int length) {
		if (offset > data.length || offset+length > data.length || length < 0) {
			throw new IllegalArgumentException("Offset(" + offset + ") mora biti ili jednak duljini(" + data.length + ") niza znakova, offset+length(" + (offset+length) +") mora biti manji ili jednak duljini niza znakova(" + data.length +") i length ne smije biti negativan.");
		}
		this.value = data;
		this.offset = offset;
		this.count = length;
	}

	/**
	 * Izrađuje instancu na temelju niza znakova.
	 * 
	 * @param data
	 *            - niz znakova
	 */
	public CString(char[] data) {
		this.value = data;
		this.offset = 0;
		this.count = data.length;
	}

	/**
	 * Izrađuje instancu iz druge instance isto tipa <code>Cstring</code>.
	 * 
	 * @param original
	 *            - druga instanca
	 * @see String
	 */
	public CString(CString original) {
		if (original.value.length > original.count) {
			this.value = Arrays.copyOfRange(original.value, original.offset, original.offset+original.count);
			this.offset = 0;
			this.count = original.count;
		} else {
			this.value = original.value;
			this.offset = original.offset;
			this.count = original.count;
		}
	}

	/**
	 * Provjerava da li je ulazni parametar null
	 * 
	 * @param s - ulazni parametar
	 * @throws IllegalArgumentException ako je s null
	 */
	private void checkNull(CString s) {
		if (s == null) {
			throw new IllegalArgumentException("Ulaz ne smije biti null!");
		}
		
	}

	/**
	 * Izrađuje instancu iz tipa <code>String</code>.
	 * 
	 * @param s
	 *            - instanca tipa <code>String</code>
	 */
	public CString(String s) {
		char[] charArray = s.toCharArray();
		this.value = Arrays.copyOf(charArray, charArray.length);
		this.offset = 0;
		this.count = s.length();

	}

	/**
	 * Metoda koja vraća duljinu stringa.
	 * 
	 * @return duljina stringa
	 */
	public int length() {
		return count;
	}

	/**
	 * Metoda koja vraća znak na određenoj poziciji.
	 * 
	 * @param index
	 *            - pozicija
	 * @return znak
	 * @throws IndexOutOfBoundsException
	 *             ako je index manji od 0 i veci od length()-1
	 */
	public char charAt(int index) {
		check(index);
		return value[offset + index];
	}

	/**
	 * Metoda provjerava je li index unutar granica.
	 * 
	 * @param index
	 */
	private void check(int index) {
		if (index < 0 || index >= count) {
			throw new IndexOutOfBoundsException("Index " + index
					+ " nije unutar granica [0," + (count - 1) + "]");
		}
	}

	/**
	 * Metoda pretvara string u polje znakova te vraća to polje.
	 * 
	 * @return polje znakova
	 */
	public char[] toCharArray() {
		char[] charArray = new char[count];
		for (int i = 0; i < count; i++) {
			charArray[i] = charAt(i);
		}
		return charArray;
	}

	/**
	 * Metoda koja vraća string.
	 */
	@Override
	public String toString() {
		return new String(value, offset, count);
	}

	/**
	 * Metoda koja vraća poziciju prvog pojavljivanja znaka c ili -1 ako nema
	 * tog znaka u nizu.
	 * 
	 * @param c
	 *            - znak
	 * @return pozicija prvog pojavljivanja znaka c ili -1
	 */
	public int indexOf(char c) {
		int i = 0;
		while (charAt(i) != c && ++i < count);
		if (i < count) {
			return i;
		} else {
			return -1;
		}
	}

	/**
	 * Metoda koja provjerava počinje li string sa stringom s.
	 * 
	 * @param s
	 *            - string
	 * @return <code>true</code> ako počinje, inače <code>false</code>
	 * @throws IllegalArgumentException ako je s null
	 */
	public boolean startsWith(CString s) {
		checkNull(s);
		if (s.count > count) {
			return false;
		}
		for (int i = 0; i < s.count; i++) {
			if (s.charAt(i) != charAt(i)) {
				return false;
			}
		}
		return true;
	}

	/**
	 * Metoda koja provjerava završava li string sa stringom s.
	 * 
	 * @param s
	 *            - string
	 * @return <code>true</code> ako završava, inače <code>false</code>
	 * @throws IllegalArgumentException ako je s null
	 */
	public boolean endsWith(CString s) {
		checkNull(s);
		if (s.count > count) {
			return false;
		}
		for (int i = 0; i < s.count; i++) {
			if (s.charAt(i) != charAt(count - s.count + i)) {
				return false;
			}
		}
		return true;
	}

	/**
	 * Metoda koja provjerava sadrži li string string s.
	 * 
	 * @param s
	 *            - string
	 * @return <code>true</code> ako sadrži, inače <code>false</code>
	 * @throws IllegalArgumentException ako je s null
	 */
	public boolean contains(CString s) {
		checkNull(s);
		char[] charArrayOfS = s.toCharArray();
		char[] charArrayOfThis = toCharArray();
		boolean contains = false;
		for (int i = 0; i < charArrayOfThis.length && !contains; i++) {
			if (charArrayOfThis.length - i < charArrayOfS.length) {
				contains = false;
				break;
			}
			contains = true;
			for (int j = 0; j < charArrayOfS.length; j++) {
				if (charArrayOfS[j] != charArrayOfThis[i + j]) {
					contains = false;
					break;
				}
			}
		}
		return contains;
	}

	/**
	 * Metoda koja vraća podniz niza znakova od kojih se sastoji string u obliku
	 * stringa. Podniz ide od početne pozicije do pozicije prije završne
	 * pozicije.
	 * 
	 * @param startIndex
	 *            - početna pozicija
	 * @param endIndex
	 *            - završna pozicija
	 * @return string koji se sastoji od podniza znakova
	 * @throws IllegalArgumentException
	 *             ako je startIndex manji od 0 i veći od length()-1 ili ako je
	 *             endIndex manji od startIndex i veći od length()-1
	 */
	public CString substring(int startIndex, int endIndex) {
		if (startIndex < 0 || startIndex > count || endIndex < startIndex
				|| endIndex > count) {
			throw new IllegalArgumentException("StartIndex(" + startIndex
					+ ") mora biti unutar [0," + (count) + "], a endIndex("
					+ endIndex + ") mora biti unutar [" + startIndex + ","
					+ (count) + "].");
		}
		CString subCString = new CString(value, offset + startIndex, endIndex
				- startIndex);
		return subCString;
	}

	/**
	 * Metoda koja vraća novi CString koji predstavlja početni dio originalnog
	 * stringa i duljine je n.
	 * 
	 * @param n
	 *            - duljina
	 * @return novi CString
	 * @throws IllegalArgumentException
	 *             ako je n>count
	 */
	public CString left(int n) {
		checkLength(n);
		CString leftCString = new CString(value, offset, n);
		return leftCString;
	}

	/**
	 * Metoda koja provjera duljinu n.
	 * 
	 * @param n
	 */
	private void checkLength(int n) {
		if (n > count) {
			throw new IllegalArgumentException("Duljina n(" + n
					+ ") ne smije biti veća od " + count);
		}
	}

	/**
	 * Metoda koja vraća novi CString koji predstavlja završni dio originalnog
	 * stringa i duljine je n.
	 * 
	 * @param n
	 *            - duljina
	 * @return novi CString
	 * @throws IllegalArgumentException
	 *             ako je n>count
	 */
	public CString right(int n) {
		checkLength(n);
		CString rightCString = new CString(value, offset + count - n, n);
		return rightCString;
	}

	/**
	 * Metoda koja stvara novi CString koji je nastao kao konkatenacija
	 * trenutnog stringa i danog stringa s.
	 * 
	 * @param s
	 *            - dani string
	 * @return novi CString
	 * @throws IllegalArgumentException ako je s null
	 */
	public CString add(CString s) {
		checkNull(s);
		char[] data = new char[count + s.count];
		for (int i = 0; i < count; i++) {
			data[i] = charAt(i);
		}
		for (int i = 0; i < s.count; i++) {
			data[count + i] = s.charAt(i);
		}
		CString addCString = new CString(data);
		return addCString;
	}

	/**
	 * Metoda koja stvara novi CString u kojem svako pojavljivanje starog znaka
	 * se zamijenjuje s novim znakom.
	 * 
	 * @param oldChar
	 *            - stari znak
	 * @param newChar
	 *            - novi znak
	 * @return novi CString
	 */
	public CString replaceAll(char oldChar, char newChar) {
		char[] data = new char[count];
		int index = 0;
		for (char c : toCharArray()) {
			if (c == oldChar) {
				data[index++] = newChar;
			} else {
				data[index++] = c;
			}
		}
		return new CString(data);
	}

	/**
	 * Metoda koja stvara novi CString u kojem svako pojavljivanje starog
	 * podniza znakova se zamijenjuje s novim podnizom znakova.
	 * 
	 * @param oldStr
	 *            - stari podniz znakova
	 * @param newStr
	 *            - novi podniz znakova
	 * @return novi CString
	 * @throws IllegalArgumentException ako je oldStr ili newStr null
	 */
	public CString replaceAll(CString oldStr, CString newStr) {
		checkNull(oldStr);
		checkNull(newStr);
		CString replacedCString = new CString("");
		CString pomCString = new CString(toCharArray());
		while (pomCString.count > 0) {
			if (pomCString.startsWith(oldStr)) {
				replacedCString = replacedCString.add(newStr);
				pomCString = pomCString.substring(oldStr.count,
						pomCString.count);
			} else {
				replacedCString = replacedCString.add(pomCString
						.substring(0, 1));
				pomCString = pomCString.substring(1, pomCString.count);
			}
		}
		return replacedCString;
	}

	/**
	 * Metoda koja uspoređuje dva objekta tipa CString.
	 * 
	 * @return <code>true</code> ako oba CStringa sastoje od istog niza znakova,
	 *         inace <code>false</code>
	 */
	@Override
	public boolean equals(Object s) {
		if (s instanceof CString) {
			CString cString = (CString) s;
			if (cString.count == count) {
				if (startsWith(cString)) {
					return true;
				}
			}
		}
		return false;
	}
	
	@Override
	public int hashCode() {
		assert false : "hashCode not designed";
		return 47;
	}

}
