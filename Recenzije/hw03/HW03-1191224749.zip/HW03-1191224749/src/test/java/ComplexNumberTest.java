import static org.junit.Assert.*;
import  hr.fer.zemris.java.tecaj.hw3.ComplexNumber;
import hr.fer.zemris.java.tecaj.hw3.ComplexNumberException;
import static hr.fer.zemris.java.tecaj.hw3.ComplexNumber.*;

import org.junit.Test;


public class ComplexNumberTest {

	@Test  
	public void parserAndToString() {
		ComplexNumber novi= parse("5+3i");
		boolean jeLi = novi.toString().equals("5.0+3.0i");
		
		assertEquals(true, jeLi);
	}

	@Test
	public void parserAndToString2() {
		ComplexNumber novi= parse("-56i-4");
		boolean jeLi = novi.toString().equals("-4.0-56.0i");
		
		assertEquals(true, jeLi);
	}
	
	
	@Test 
	public void parserAndGeters() {
		ComplexNumber novi= parse("5+3i");
		double real=novi.getReal();
		double imaginary=novi.getImaginary();

		
		assertEquals(true, ((real==5.0)&&(imaginary==3.0)));
	}
}
