import static org.junit.Assert.*;
import hr.fer.zemris.java.tecaj.hw3.CString;
import static hr.fer.zemris.java.tecaj.hw3.CString.*;

import org.junit.Test;


public class CStringTest {

	/**
	 * fejlaju mi testovi gdje ne bi trebali
	 */
}
