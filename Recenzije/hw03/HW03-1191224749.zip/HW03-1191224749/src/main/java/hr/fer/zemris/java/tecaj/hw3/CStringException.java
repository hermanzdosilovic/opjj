package hr.fer.zemris.java.tecaj.hw3;
/**
 * klasa iznimki koje baca rad sa cstringovima, naslijeduje RuntimeException
 * @author Tomislav Bukic
 *
 */
public class CStringException extends RuntimeException {

	public CStringException (){
		super("Error while processing CString!");
	}
	
	public CStringException (String poruka) {
		super ("Error while processing CString! "+poruka);
	}
}
