package hr.fer.zemris.java.tecaj.hw3;

import hr.fer.zemris.java.tecaj.hw3.CStringBase;
/**
 * klasa za rad sa stringovima,
 * implementacija string funkcija na "stari" nacin
 * @author Tomislav Bukic
 *
 */
public class CString {
	
	//podaci kojima klasa barata:
	private CStringBase podaci;
	private int pocetak;
	private int kraj;
	
	
	
	/**
	 * konstrkutor
	 * @param data - niz char-ova iz kojega se radi string
	 * @param offset - int>=0, od kojeg se znaka niza stvara string
	 * @param length - int>=0, koliko znakova string treba biti dugacak
	 * @author Tomislav Bukic
	 */
	public CString (char[] data, int offset, int length) {
		podaci= new CStringBase (data, offset,length+offset+1);
		pocetak=0;
		kraj=length;
	}
	
	/**
	 * konstruktor
	 * @param data - niz charova koji se pretvara u string
	 * @author Tomislav Bukic
	 */
	public CString(char[] data) {
		stvoriNovi (data);
	}
	
	/**
	 * string koji se realocira u string
	 * @param original
	 * @author Tomislav Bukic
	 */
	public CString(CString original) {
		if (original.podaci.getDuzina()!=original.length()) {
			this.podaci=new CStringBase(original.toCharArray(),original.pocetak,original.kraj+original.pocetak);
			this.pocetak=0;
			this.kraj=this.podaci.getDuzina();
		} else {
			this.podaci=original.podaci;
			this.pocetak=original.pocetak;
			this.kraj=original.kraj;
		}
	}
	
	/**
	 * javin string koji se pretvara u string
	 * @param s - String
	 * @author Tomislav Bukic
	 */
	public CString(String s) {
		this(s.toCharArray());
	}
	
	/**
	 * privatni konstruktor, koriste ga funkcije za baratanje stringovima
	 * @param baza
	 * @param offset
	 * @param length
	 * @author Tomislav Bukic
	 */
	private CString (CStringBase baza,int offset, int length) {
		podaci=baza;
		pocetak=offset;
		kraj=offset+length;
	}
	
	/**
	 * pomocna funkcija u stvaranju stringa
	 * @param data - niz charova koji postaju string
	 * @author Tomislav Bukic
	 */
	private void stvoriNovi(char[]data){
		podaci= new CStringBase (data);
		pocetak=0;
		kraj=podaci.getDuzina();
	}
	
	
	/**
	 * mjeri duzinu stringa
	 * @return - int>=0, duzina stringa
	 * @author Tomislav Bukic
	 */
	public int length(){
		return kraj-pocetak;
	}
	
	/**
	 * trazi koji se char nalazi na index-poziciji
	 * @param index - int 0<=index<length
	 * @return - char - trazeni znak
	 * @author Tomislav Bukic
	 */
	public char charAt(int index){
		if ((index==0)||(pocetak==0)) {
			return this.podaci.nadiItiZnak(index+pocetak);
		} else {
			return this.podaci.nadiItiZnak(index+pocetak+1);
		}
	
	}
	
	/**
	 * pretvara string u niz charova
	 * @return - niz charova
	 * @author Tomislav Bukic
	 */
	public char[] toCharArray(){
		int duzina=this.length();
		char[] niz=new char[duzina];
		
		for (int i=0;i<duzina;++i){
			niz[i]=podaci.nadiItiZnak(i+pocetak);
		}
		
		return niz;
	}
	
	/**
	 * stvara javin string iz ovog stringa
	 * @return: String
	 * @author: Tomislav Bukic
	 */
	public String toString(){
		int duzina=this.length();
		StringBuilder sb=new StringBuilder(duzina);
		
		for (int i=0;i<duzina;++i){
			sb.append(podaci.nadiItiZnak(i+pocetak));
		}
		
		return sb.toString();
				
	}
	
	/**
	 * vraca index prve pojave chara c
	 * @param c - char
	 * @return - int>0, njegov index ako postoji; -1 ako ne postoji
	 * @author Tomislav Bukic
	 */
	public int indexOf(char c){
		for (int i=0, duzina=this.length();i<duzina;++i){
			if (c==podaci.nadiItiZnak(i+pocetak)){
				return i;
			}
		}
		return -1;
	}
	
	/**
	 * govori pocinje li string sa odredenim stringom
	 * @param s - string koji provjeravamo da li je na pocetku
	 * @return - boolean: true ako je, false ako nije
	 * @author Tomislav Bukic
	 */
	public boolean startsWith(CString s){
		int duzina=s.length();
		if (length()<duzina) {
			return false;
		}
		
		for (int i=0;i<duzina;++i){
			if (charAt(i)!=s.charAt(i)){
				return false;
			}
		}
		
		return true;
	}
	
	
	/**
	 * govori zavrsava li string sa odredenim stringom
	 * @param s - string koji provjeravamo da li je na kraju
	 * @return - boolean: true ako je, false ako nije
	 * @author Tomislav Bukic
	 */
	public boolean endsWith(CString s){
		int duzina=s.length();
		if (length()<duzina) {
			return false;
		}
		
		for (int i=0;i<duzina;++i){
			if (charAt(kraj-duzina+i)!=s.charAt(i)){
				return false;
			}
		}
		
		return true;
	}
	
	
	/**
	 * govori sadrzi li string sa odredenim stringom
	 * @param s - string koji provjeravamo da li je negdje u trenutnom stringu
	 * @return - boolean: true ako je, false ako nije
	 * @author Tomislav Bukic
	 */
	public boolean contains(CString s){
		int duzina=s.length();
		if (length()<duzina) {
			return false;
		}

		for (int i=0;i<duzina-length()+1;++i){
			int index=0;
			while (index<=duzina){
		
				if (charAt(i+index)!=s.charAt(index)) {
					break;
				}

				if (index==duzina-1) {
					return true;
				}
				index++;
			}
		}
		
		return false;
	}
	
	/**
	 * 
	 * @param startIndex
	 * @param endIndex
	 * @return
	 * @author Tomislav Bukic
	 */
	public CString substring(int startIndex, int endIndex) {
		
		CString novi=new CString(podaci,startIndex,endIndex-startIndex);
		return novi;
	}
	
	public CString left (int n) {
		
		CString novi=new CString(podaci,0,n);
		return novi;
	}
	
	public CString right (int n) {
		
		CString novi=new CString(podaci,podaci.getDuzina()-n,n);
		return novi;
	}
	
	
	/**
	 * 
	 * @param s
	 * @return
	 * @author Tomislav Bukic
	 */
	public CString add (CString s) {
		int duzina1=length(), duzina2=s.length(), duzina=duzina1+duzina2;
		char[] novi=new char[duzina], stari1=toCharArray(), stari2=s.toCharArray();

		for (int i=0;i<duzina1;++i){
			novi[i]=stari1[i];
		}
		for (int i=0;i<duzina2;++i){
			novi[i+duzina1]=stari2[i];
		}
		
		CString rjesenje= new CString(novi);
		return rjesenje;
	}

	/**
	 * mijenja sva pojavljivanja odlChar u stringu sa newChar
	 * @param oldChar - char kojeg mijenjamo
	 * @param newChar - char sa kojim mijenjamo
	 * @return - nakon izmjena
	 * @author Tomislav Bukic
	 */
	public CString replaceAll (char oldChar, char newChar){
		int duzina=length();
		char[]novi=new char[duzina];
		
		for (int i=0;i<duzina;++i){
			char c=charAt(i);
			if (c==oldChar){
				novi[i]=newChar;
			} else {
				novi [i]=c;
			}
		}
		
		CString rjesenje=new CString(novi);
		return rjesenje;
	}
	
	/**
	 * mijenja sva pojavljivanja oldStr sa newStr
	 * @param oldStr - String
	 * @param newStr - String
	 * @return - String, novi
	 * @author Tomislav Bukic
	 */
	public CString replaceAll (CString oldStr, CString newStr){
			int duzina=length(), duzinaMijenjanog=oldStr.length(), pocetak=0,br=0;
			CString novi= new CString("");
			char []stari=this.toCharArray();
			
			for (int i=0;i<duzina-duzinaMijenjanog+1;++i){
				
				CString trenutni=new CString(stari,i,duzinaMijenjanog);
				System.out.println("trenutni  "+trenutni+i);
				if (trenutni.contains(new CString(stari,i,duzinaMijenjanog))){
					novi=novi.add(new CString (stari,pocetak,br));
					System.out.println("2"+novi);
					novi=novi.add(newStr);
					System.out.println("3"+novi);
					i=i+duzinaMijenjanog-1;
					pocetak=i;
					br=-1;
				}
				br++;
			}
			novi=novi.add(new CString(stari,pocetak,br));
			return novi;
	}
	
}
