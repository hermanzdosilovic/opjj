package hr.fer.zemris.java.tecaj.hw3;
/**
 * Klasa sa main funkcijom iz pokazuje kako da je
 * iterator ispravno napravljen 
 * @author zemris
 *
 */
public class Mejn {
	public static void main(String[]args){
		IntegerSequence range = new IntegerSequence(1, 11, 2);
		for(int i : range) {
		for(int j : range) {
		System.out.println("i="+i+", j="+j);
		}
		}
	}
}