package hr.fer.zemris.java.tecaj.hw3;

import java.util.Iterator;
/**
 * klasa iteratora po int
 * @author Tomislav Bukic
 *
 */
public class IntegerSequence implements Iterable<Integer>{
	
	//argumenti:
	private int first;
	private int last;
	private int step;
	
	/**
	 * konstruktor
	 * @param first - int prvi
	 * @param last - int zadnji
	 * @param step - int step
	 * @author Tomislav Bukic
	 */
	public IntegerSequence (int first,int last,int step){
		if (((first<last)&&(step<=0))||((first>last)&&(step>=0))) {
			throw new IllegalArgumentException("You gave infinite sequence to iterrate!");
		}
		
		this.first=first;
		this.last=last;
		this.step=step;
	}
	
	/**
	 * poziva konstruktor iteratora
	 */
	@Override
	public Iterator<Integer> iterator() {
		return new MyIterraotr();
	}
	
	/**
	 * klasa iteratora
	 * @author Tomislav Bukic
	 *
	 */
	private class MyIterraotr implements Iterator<Integer> {
		
		//trenutni broj:
		private int currentNumber;
		
		/**
		 * konstruktor iteratora
		 * 
		 * @author Tomislav Bukic
		 */
		public MyIterraotr(){
			this.currentNumber=first;
		}
		
		/**
		 * ispituje postoji li iduci clan
		 * @return boolean - true ako postoji, false ako ne postoji
		 * @author Tomislav Bukic
		 */
		@Override
		public boolean hasNext(){
			if (((step<0)&&(this.currentNumber>=last+step))||((step>0)&&(this.currentNumber<=last+step))){
				return true;
			} else {
				return false;
			}
		}
		
		/**
		 * trazi iduci clan
		 * @author Tomislav Bukic
		 */
		@Override
		public Integer next() {
			if (!this.hasNext()) {
				throw new RuntimeException ("You cannot ask for next element!");
			}
			this.currentNumber+=step;
			return currentNumber;
		}
		
		/**
		 * funkcija za brisanje clana-ova implementacija to ne podrzava!
		 * @author Tomislav Bukic
		 */
		@Override
		public void remove (){
			throw new UnsupportedOperationException ("You cannot remove numbers in given sequence");
		}
		
	}
}


