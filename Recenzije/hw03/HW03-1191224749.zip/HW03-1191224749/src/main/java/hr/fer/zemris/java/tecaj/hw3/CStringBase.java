package hr.fer.zemris.java.tecaj.hw3;

import hr.fer.zemris.java.tecaj.hw3.CStringException;

/**
 * klasa koja predstavlja niz karaktera u radu sa cstringovima
 * @author Tomislav Bukic
 *
 */
public class CStringBase {
	private char [] niz;
	private int duzina;
	
	
	/**
	 * Stvara niz charova sa charom koji pocinje sa prvi i zavrsava
	 * na poziciji zadnji
	 * @param novi - char[]
	 * @param prvi - int>=0
	 * @param zadnji - int >=0
	 * @author Tomislav Bukic
	 */
	public CStringBase(char[] novi, int prvi, int zadnji) {
		duzina=zadnji-prvi;
		niz=new char[duzina];
		kopiraj(novi,prvi,zadnji);
	}
	
	/**
	 * pretvara novi u niz charova baze za string
	 * @param novi - char[]
	 * @author Tomislav Bukic
	 */
	public CStringBase(char[] novi) {
		this (novi,0,novi.length);
	}
	
	
	/**
	 * pomocna funkcija, kopira od-do
	 * @param novi - char[]
	 * @param odakle - int>=0
	 * @param dokle - int>=0
	 * @author Tomislav Bukic
	 */
	private void kopiraj (char[] novi, int odakle, int dokle){
		if ((odakle<0)||(odakle>novi.length)||(dokle<0)||(dokle>novi.length)) {
			throw new CStringException("Bad arguments");
		}
		
		for (int i=odakle;i<dokle;++i) {
			this.niz[i-odakle]=novi[i];
		}
	 }
	
	/**
	 * trazi i-ti znak
	 * @param i- 0<=i<duzina polja
	 * @return char - znak
	 * @author Tomislav Bukic
	 */
	public char nadiItiZnak (int i) {
		if ((i<0)||(i>=duzina)) {
			throw new CStringException("I has to be in range of field");
		}
		return niz[i];
	}
	
	/**
	 * vraca duzinu niza
	 * @return - int length>=0
	 * @author Tomislav Bukic
	 */
	public int getDuzina(){
		return duzina;
	}
	
	/**
	 * vraca niz
	 * @return char[] - niz
	 * @author Tomisl1av Bukic
	 */
	public char[] getNiz(){
		return niz;
	}
}
