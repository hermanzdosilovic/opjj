package hr.fer.zemris.java.tecaj.hw3;

/**
 * klasa iznimki koje baca rad sa kompleksnim brojevima, naslijeduje RuntimeException
 * @author Tomislav Bukic
 *
 */
public class ComplexNumberException extends RuntimeException {
	public ComplexNumberException (){
		super("Error while processing complex numbers!");
	}
	
	public ComplexNumberException (String poruka) {
		super ("Error while processing complex numbers! "+poruka);
	}
}
