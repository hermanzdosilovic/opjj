package hr.fer.zemris.java.tecaj.hw3;

/**
 * klasa koja podrzava osnovne aritmeticke
 * operacije sa kompleksnim brojevima,
 * te njihovo stvaranje iz stringa,
 * preko razlicitih podataka dobivenih
 * o broju i na kraju njihovo pretvaranje
 * u oblik stringa
 * 
 * @author Tomislav Bukic
 *
 */
public class ComplexNumber {
	
	//argumenti:
	private double real;
	private double imaginary;
	
	/**
	 * konstruktor
	 * @param real - double, realni dio kompleksnoga broja
	 * @param imaginary - double, imaginarni dio kompleksnoga broja
	 * @author Tomislav Bukic
	 */
	public ComplexNumber (double real, double imaginary) {
		this.real=real;
		this.imaginary=imaginary;
	}
	
	/**
	 * stvara kompleksni broj koji se sastoji
	 * samo od realnog dijela, te vraca broj
	 * 
	 * @param real - double, realno dio kompleksnoga broja
	 * @return - ComplexNumber - kompleksni broj
	 * @author Tomislav Bukic
	 */
	public static ComplexNumber fromReal (double real) {
		ComplexNumber kompleksni=new ComplexNumber(real,0);
		return kompleksni;
	}
	
	/**
	 * stvara kompleksni broj koji se sastoji
	 * samo od imaginarnog dijela, te vraca broj
	 * 
	 * @param imaginary - double, imaginarni dio kompleksnoga broja
	 * @return - ComplexNumber - stvoreni kompleksni broj
	 * @author Tomislav Bukic
	 */
	public static ComplexNumber fromImaginary (double imaginary) {
		ComplexNumber kompleksni=new ComplexNumber (0,imaginary);
		return kompleksni;
	}
	
	 /**
	  * prima udaljenost kompleksnog broja od ishodista kompleksne ravnine,
	  * te kut koji cini s apcisom, vraca stvoren kompleksni broj
	  * @param magnitude - double, udaljenost od ishodista kompleksne ravnine
	  * @param angle - double - kut
	  * @return - ComplexNumber
	  * @author Tomislav Bukic
	  */
	 
	public static ComplexNumber fromMagnitudeAndAngle (double magnitude, double angle) {
		double real, imaginary;
		
		real=magnitude*Math.cos(angle);
		imaginary=magnitude*Math.sin(angle);
		
		ComplexNumber kompleksni=new ComplexNumber (real,imaginary);
		return kompleksni;
	}
	
	
	/**
	 * prima string koji sadrzi prikaz kompleksnog broja,
	 * vraca taj broj zapakiran u ComplexNumber
	 * @param s - String, kompleksni broj u obliku stringa
	 * @return - ComplexNumber, parsirani broj
	 * @author Tomislav Bukic
	 */
	public static ComplexNumber parse (String s) {
		
		s=s.trim();
		if (s.isEmpty()){
			throw new ComplexNumberException("String cannot be empty!");
		}
		
		int  duljina = s.length(),pocetak=0,i=0;
		
		String prosli=new String();
		if (operator(s.substring(0, 1))) {
			i=1;
			prosli=s.substring(0,1);
		}
		
		double real=0, imaginary=0;
		
		for (;i<duljina;++i){
			String trenutni=s.substring(i,i+1);
			
			if (!trenutni.matches("[0-9.i/+-/ ]")) {
				throw new ComplexNumberException("String contains of numbers it shouldn't have");
			} else if (operator(prosli)&&operator(trenutni)){
				throw new ComplexNumberException("Complex number cannnot have two operators in a row!");
			}
			
			if (trenutni.equals("i")) {
				if (pocetak==i) {
					imaginary=1;
				} else {
					imaginary=uDouble(s.substring(pocetak,i));
					i=pocetak=i+1;
				}
			}else if (operator(trenutni)){
				real=uDouble(s.substring(pocetak,i));
				i=pocetak=i;
			}else if ((i==duljina-1)){
				real=uDouble(s.substring(pocetak,i+1));
			}
			
			prosli=trenutni+1;
		}
		
		ComplexNumber kompleksni=new ComplexNumber(real,imaginary);
		return kompleksni;
		
	}
	
	/**
	 * Pretvara dobiveni broj u double
	 * @param s - string reprezentacija double broja
	 * @return - double, taj broj
	 * @author Tomislav Bukic
	 * @throws ComplexNumberException, ako parametar nije broj pretvoriv u double
	 */
	private static double uDouble(String s){
		double broj;
		try {
			broj=Double.parseDouble(s.trim());
		} catch (NumberFormatException e){
			throw new ComplexNumberException ("Argument in string: "+s+" is not a number!");
		}
		return broj;
	}
	
	
	/**
	 * provjerava da li je zadani string operator
	 * + ili - koji se nalazi u kompleksnom broju
	 * @param o - String koji provjerava
	 * @return - true ako je trazeni operator, false ako nije
	 * @author Tomislav Bukic
	 */
	private static boolean operator (String o){
		if (o.equals("+")||o.equals("-")) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * getter
	 * @return - double, realni dio kompleksnoga broja
	 * @author Tomislav Bukic
	 */
	public double getReal() {
		return real;
	}

	/**
	 * getter
	 * @return - double, imaginarni dio kompleksnoga broja
	 * @author Tomislav Bukic
	 */
	public double getImaginary() {
		return imaginary;
	}

	/**
	 * getter
	 * @return - double, udaljenost kompleksnog broja od ishodista
	 * @author Tomislav Bukic
	 */
	public double getMagnitude() {
		return Math.sqrt(real*real+imaginary*imaginary);
	}

	/**
	 * getter
	 * @return - double, kut kompleksnog broja u odnosu na apcisu kompleksne ravnine
	 * @author Tomislav Bukic
	 */
	public double getAngle() {
		return Math.atan2(imaginary, real);
	}
	
	/**
	 * zbraja 2 kompleksna broja
	 * @param c - ComplexNumber, 2. pribrojnik
	 * @return - ComplexNumber, zbroj
	 * @author Tomislav Bukic
	 */
	public ComplexNumber add(ComplexNumber c) {
		double realni=real+c.getReal();
		double imaginarni=imaginary+c.getImaginary();
		ComplexNumber sum=new ComplexNumber(realni,imaginarni);
		return sum;
	}
	
	/**
	 * oduzima 2 kompleksna broja
	 * @param c - ComplexNumber, umanjitelj
	 * @return - ComplexNumber, razlika
	 * @author Tomislav Bukic
	 */
	public ComplexNumber sub (ComplexNumber c) {
		double realni=real-c.getReal();
		double imaginarni=imaginary-c.getImaginary();
		ComplexNumber difference=new ComplexNumber(realni,imaginarni);
		return difference;
	}
	
	/**
	 * mnozi 2 kompleksna broja
	 * @param c - ComplexNumber, faktor
	 * @return - ComplexNumber, umnozak
	 * @author Tomislav Bukic
	 */
	public ComplexNumber mul (ComplexNumber c) {
		double fi1=getAngle(), fi2=c.getAngle(),r1=getMagnitude(),r2=c.getMagnitude();
		ComplexNumber umnozak=fromMagnitudeAndAngle(r1*r2,fi1+fi2);
		return umnozak;
	}
	
	/**
	 * dijeli 2 kompleksna broja
	 * @param c - ComplexNumber, djelitelj
	 * @return - ComplexNumber, kvocijent
	 * @author Tomislav Bukic
	 */
	public ComplexNumber div (ComplexNumber c) {
		double fi1=getAngle(), fi2=c.getAngle(),r1=getMagnitude(),r2=c.getMagnitude();
		ComplexNumber kvocijent=fromMagnitudeAndAngle(r1/r2,fi1-fi2);
		return kvocijent;
	}
	
	/**
	 * potencija kompleksni broj na n-tu potenciju
	 * @param n - int, n>=0
	 * @return ComplexNumber - potenciran broj
	 * @author Tomislav Bukic
	 */
	public ComplexNumber power (int n) {
		if (n<0) {
			throw new ComplexNumberException ("Argument has to be >= 0. Your argument: "+n);
		}
		Double fi=n*getAngle(),r=Math.pow(getMagnitude(),n);
		return fromMagnitudeAndAngle(r,fi);
	}
	
	/**
	 * vadi n-ti korijen iz kompleksnog broja
	 * @param n - int, koji korijen vadis, n>0
	 * @return - korijenovan broj
	 * @author Tomislav Bukic
	 */
	public ComplexNumber[] root (int n) {
		if (n<=0) {
			throw new ComplexNumberException ("Argument has to be > 0. Your argument: "+n);
		}
		
		ComplexNumber[] roots=new ComplexNumber[n];
		double fiPart=getAngle()/n, piPart=2*Math.PI/n,r=Math.pow(getMagnitude(),1/n);
		
		for (int i=0;i<n;++i){
			roots[i]=fromMagnitudeAndAngle(r,fiPart+i*piPart);
		}
		
		return roots;
	}
	

	/**
	 * pretvara kompleksni broj u string
	 * @return - String prikaz kompleksnog broja
	 * @author Tomislav Bukić
	 */
	public String toString() {
		String rjesenje=new String();
		
		if (real!=0) {
			rjesenje=Double.toString(real);
		}
		
		if (imaginary>0){
			rjesenje+=("+"+imaginary+"i");
		} else if (imaginary<0){
			rjesenje+=("-"+ Math.abs(imaginary)+"i");
		}
		
		return rjesenje;
	}
	
}
