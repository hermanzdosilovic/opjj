package hr.fer.zemris.linearna;

/**
 * Razred predstavlja matricu.
 * @author Marin Vuica
 * 27. 4. 2014.
 */
public class Matrix extends AbstractMatrix {
	
	protected double[][] array;
	protected int rows;
	protected int cols;
	
	/**
	 * Stvara matricu s danim brojem redova i stupaca.
	 * @param rows broj redova.
	 * @param cols broj stupaca.
	 */
	public Matrix(int rows, int cols) {
		this.rows = rows;
		this.cols = cols;
		array = new double[rows][cols];
	}
	
	/**
	 * Stvara matricu s danim brojem redova i stupaca, popunjava se predanim poljem.
	 * @param rows broj redaka.
	 * @param cols broj stupaca.
	 * @param array polje koje čini matricu.
	 * @param useGiven ako je true preuzima referencu na dano polje, inače kopira svoju instancu polja.
	 */
	public Matrix(int rows, int cols, double[][] array, boolean useGiven) {
		this.rows = rows;
		this.cols = cols;
		if (useGiven == true) {
			this.array = array;
		}
		else {
			this.array = array.clone();
		}
	}
	
	@Override
	public int getRowsCount() {
		return this.rows;
	}

	@Override
	public int getColsCount() {
		return this.cols;
	}

	@Override
	public double get(int row, int col) {
		if (row < 0 || col < 0 || row > this.rows || col > this.cols) {
			throw new IndexOutOfBoundsException(
					"Ne postoji element na traženom mjestu u matrici:" + row + ":" + col);
		}
		return array[row][col];
	}

	@Override
	public IMatrix set(int row, int col, double value) {
		array[row][col] = value;
		return this;
	}

	@Override
	public IMatrix newInstance(int rows, int cols) {
		Matrix matrix = new Matrix(rows, cols);
		return matrix;
	}
	
	public static Matrix parseSimple(String elementsString) {
		String[] rows = elementsString.split("\\s*\\|\\s*");
		int numberOfColumns = rows[0].split("\\s+").length;
		double[][] matrixField = new double[rows.length][numberOfColumns];
		int i = -1;
		int j = 0;
		for(String row : rows) {
			String[] columns = row.split("\\s+");
			if (columns.length != numberOfColumns) {
				throw new IllegalArgumentException("Broj stupaca matrice nije svuda jednak.");
			}
			j = 0;
			i++;
			for (String column : columns) {
				matrixField[i][j++] = Double.parseDouble(column);
			}
		}
		Matrix matrix = new Matrix(rows.length, numberOfColumns, matrixField, true);
		return matrix;
	}

}
