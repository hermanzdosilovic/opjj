package hr.fer.zemris.linearna;

/**
 * Razred može stvoriti defaultnu instancu matrice ili vektora, za slučaj da postoje različite implementacije matrica,
 * njegove metode mogu koristi korisnici s malo iskustva kako bi odabrali defaultnu implementaciju.
 * 
 * @author Marin Vuica 27. 4. 2014.
 */
public class LinAlgDefaults {
	
	/**
	 * Stvara novu praznu matricu s rows redova i cols stupaca ispunjenih nulama
	 * @param rows broj redova nove matrice
	 * @param cols broj stupaca nove matrice
	 * @return stvorenu matricu
	 */
	public static IMatrix defaultMatrix(int rows, int cols) {
		Matrix matrix = new Matrix(rows, cols);
		return matrix;

	}
	
	/**
	 * Stvara vektor dimension dimenzije i čiji su elementi nule.
	 * @param dimension dimezija vektora
	 * @return stvoreni vektor
	 */
	public static IVector defaultVector(int dimension) {
		double[] field = new double[dimension];
		return new Vector(field);

	}

}
