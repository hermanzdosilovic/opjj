package hr.fer.zemris.linearna;


/**
 * Razred predstavlja vektor.
 * @author Marin Vuica
 * 27. 4. 2014.
 */
public class Vector extends AbstractVector {
	
	/**
	 * Polje čuva elemente vektora.
	 */
	private double[] elements;
	
	/**
	 * Varijabla čuva dimenziju vektora.
	 */
	private int dimension;
	
	/**
	 * True ako se smije samo čitati, false inače.
	 */
	private boolean readOnly;
	
	/**
	 * Stvara vector s proizvoljnog broja dimenzija
	 * @param numbers parametri vektora
	 */
	public Vector(int... numbers) {
		elements = new double[numbers.length];
		this.dimension = numbers.length;
		for (int i = 0; i < this.dimension; i++) {
			elements[i] = numbers[i];
		}
		
	}
	
	/**
	 * Stvara vector.
	 * @param elements polje s parametrima vektora
	 */
	public Vector(double[] elements) {
		this.elements = elements.clone();
		this.dimension = elements.length;
		this.readOnly = false;
	}
	
	public Vector (boolean readOnly, boolean useGiven, double[] elements) {
		this.readOnly = readOnly;
		if (useGiven == true) {
			this.elements = elements;
		} else {
			this.elements = elements.clone();
		}
		this.dimension = elements.length;
	}
	
	@Override
	public double get(int index) {
		if (index < 0 || index > this.dimension - 1) {
			throw new IndexOutOfBoundsException(
					"Ne postoji element na traženoj poziciji u vektoru:" + index);
		}
		return elements[index];
	}

	@Override
	public IVector set(int index, double value) throws UnmodifiableObjectException {
		if (this.readOnly == true) {
			throw new UnmodifiableObjectException("Nije dozvoljeno mijenjati ovaj vektor.");
		}
		if (index < 0 || index > this.dimension - 1) {
			throw new IndexOutOfBoundsException(
					"Ne postoji element na traženoj poziciji u vektoru:" + index);
		}
		elements[index] = value;
		return this;
	}

	@Override
	public int getDimension() {
		return this.dimension;
	}

	@Override
	public IVector copy() {
		double[] novo = new double[this.getDimension()];
		int i = 0;
		for (double iznos : elements) {
			novo[i++] = iznos;
		}
		IVector novi = new Vector(novo);
		return novi;
	}

	@Override
	public IVector newInstance(int dimension) {
		double[] novo = new double[dimension];
		Vector novi = new Vector(novo);
		return novi;
	}
	
	public static Vector parseSimple(String elementsString) {
		String[] dijelovi = elementsString.split("\\s+");
		double[] novo = new double[dijelovi.length];
		int i = 0;
		for(String dio : dijelovi) {
			novo[i++] = Double.parseDouble(dio);
		}
		Vector novi = new Vector(novo);
		return novi;
	}
	
}
