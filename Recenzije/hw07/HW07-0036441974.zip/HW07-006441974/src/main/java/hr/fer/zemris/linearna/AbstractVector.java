package hr.fer.zemris.linearna;

import java.util.Arrays;

/**
 * Apstraktna klasa koju nasljeđuju svi vektori. Nudi funckije za definiranje vektora i rad s vektorima.
 * 
 * @author Marin Vuica 27. 4. 2014.
 */
public abstract class AbstractVector implements IVector {

	@Override
	public abstract double get(int index);

	@Override
	public abstract IVector set(int index, double value) throws UnmodifiableObjectException;

	@Override
	public abstract int getDimension();

	@Override
	public abstract IVector copy();

	@Override
	public IVector copyPart(int n) {
		int dimenzijaTrenutnog = this.getDimension();
		IVector vector = this.newInstance(n);
		for (int i = 0; i < n; i++) {
			if (i < dimenzijaTrenutnog) {
				vector.set(i, this.get(i));
			} else {
				vector.set(i, 0);
			}
		}
		return vector;
	}

	@Override
	public abstract IVector newInstance(int dimension);

	@Override
	public IVector add(IVector other) throws IncompatibleOperandException {
		if (this.getDimension() != other.getDimension()) {
			throw new IncompatibleOperandException();
		}
		for (int i = this.getDimension() - 1; i >= 0; i--) {
			this.set(i, this.get(i) + other.get(i));
		}
		return this;
	}

	@Override
	public IVector nAdd(IVector other) throws IncompatibleOperandException {
		return this.copy().add(other);
	}

	@Override
	public IVector sub(IVector other) throws IncompatibleOperandException {
		if (this.getDimension() != other.getDimension()) {
			throw new IncompatibleOperandException();
		}
		for (int i = this.getDimension() - 1; i >= 0; i--) {
			this.set(i, this.get(i) - other.get(i));
		}
		return this;
	}

	@Override
	public IVector nSub(IVector other) throws IncompatibleOperandException {
		return this.copy().sub(other);
	}

	@Override
	public IVector scalarMultiply(double byValue) {
		for (int i = this.getDimension() - 1; i >= 0; i--) {
			this.set(i, this.get(i) * byValue);
		}
		return this;
	}

	@Override
	public IVector nScalarMultiply(double byValue) {
		return this.copy().scalarMultiply(byValue);
	}

	@Override
	public double norm() {
		double result = 0;
		for (int i = 0; i < this.getDimension(); i++) {
			result += this.get(i) * this.get(i);
		}
		return Math.sqrt(result);
	}

	@Override
	public IVector normalize() {
		for (int i = 0; i < this.getDimension(); i++) {
			this.set(i, this.get(i) / norm());
		}
		return this;
	}

	@Override
	public IVector nNormalize() {
		return this.copy().normalize();
	}

	@Override
	public double cosine(IVector other) throws IncompatibleOperandException {
		return (this.scalarProduct(other)) / (this.norm() * other.norm());
	}

	@Override
	public double scalarProduct(IVector other) throws IncompatibleOperandException {
		if (this.getDimension() != other.getDimension()) {
			throw new IncompatibleOperandException();
		}
		double result = 0;
		for (int i = 0; i < this.getDimension(); i++) {
			result += this.get(i) * other.get(i);
		}
		return result;
	}

	@Override
	public IVector nVectorProduct(IVector other) throws IncompatibleOperandException {
		if ((this.getDimension() != 3) && (other.getDimension() != 3)) {
			throw new IncompatibleOperandException();
		}
		double x = this.get(1) * other.get(2) - this.get(2) * other.get(1);
		double y = this.get(2) * other.get(0) - this.get(0) * other.get(2);
		double z = this.get(0) * other.get(1) - this.get(1) * other.get(0);
		IVector vector = this.newInstance(3);
		vector.set(0, x);
		vector.set(1, y);
		vector.set(2, z);
		return vector;
	}

	@Override
	public IVector nFromHomogeneus() {
		if (this.getDimension() == 1) {
			throw new IncompatibleOperandException("nFromHomogeneus: Dimenzija vektora ne smije biti jednaka jedan.");
		}
		int newVectorDimension = this.getDimension() - 1;
		double lastElement = this.get(newVectorDimension);
		IVector vector = this.newInstance(newVectorDimension);
		for (int i = 0; i < newVectorDimension; i++) {
			vector.set(i, this.get(i) / lastElement);
		}
		return vector;
	}

	@Override
	public IMatrix toRowMatrix(boolean liveView) {
		if (liveView == true) {
			return new MatrixVectorView(this, true);
		} else {
			return new MatrixVectorView(this.copy(), true);
		}
	}

	@Override
	public IMatrix toColumnMatrix(boolean liveView) {
		if (liveView == true) {
			return new MatrixVectorView(this, false);
		} else {
			return new MatrixVectorView(this.copy(), false);
		}
	}

	@Override
	public double[] toArray() {
		int dimension = this.getDimension();
		double[] vector = new double[dimension];
		for (int i = 0; i < dimension; i++) {
			vector[i] = this.get(i);
		}
		return vector;
	}

	@Override
	public String toString() {
		return Arrays.toString(this.toArray());
	}

}
