package hr.fer.zemris.linearna.demo;

import hr.fer.zemris.linearna.IVector;
import hr.fer.zemris.linearna.Vector;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.util.Scanner;

/**
 * Razred izračunava reflektirani vektor za 2 2D ili 3D vektora.
 * 
 * @author Marin Vuica 27. 4. 2014.
 */
public class Prog5 {

	public static void main(String[] args) {

		IVector m = null;
		IVector n = null;
		int dimension = 0;
		BufferedReader reader = null;
		String line = null;
		
		try {
			reader = new BufferedReader(new InputStreamReader(System.in, "UTF-8"));
		} catch (UnsupportedEncodingException e1) {
			System.out.println("Nepodržan encoding.");
		}
		System.out.println("Unesite brojkom želite li 2D ili 3D vektor.");

		while (dimension < 2 || dimension > 3) {
			try {
				line = reader.readLine();
			} catch (IOException e) {
				System.out.println("Dogodila se pogreška prilikom učitavanja unosa.");
			}
			try {
				dimension = Integer.parseInt(line);
				if (dimension < 2 || dimension > 3) {
					System.out.println("Unesite broj 2 ili 3, ovisno o željenoj dimenziji vektora.");
				}
			} catch (NumberFormatException e) {
				System.out.println("Unesen je nevaljali broj, pokušajte ponovno.");
			}

		}

		System.out.println("Unesite vektore, brojeve odvojene razmakom za prvi, pa  tipku enter "
				+ "i ponovnite za drugi vektor.");
		try {
			n = getInputAndCreateVector(dimension, reader);
			m = getInputAndCreateVector(dimension, reader);
		} catch (IOException e) {
			System.out.println("Dogodila se pogreška prilikom učitavanja unosa.");
		}

		IVector rjesenje = n.nScalarMultiply(1.0 / n.norm()).scalarMultiply(2)
				.scalarMultiply(n.scalarProduct(m) / n.norm()).sub(m);
		System.out.println(rjesenje);
	}

	private static IVector getInputAndCreateVector(int dimension, BufferedReader reader) throws IOException {
		IVector vek;
		String line = reader.readLine();
		Scanner sc = new Scanner(line);
		int v1 = sc.nextInt();
		int v2 = sc.nextInt();
		if (dimension == 3) {
			int v3 = sc.nextInt();
			vek = new Vector(v1, v2, v3);
		} else {
			vek = new Vector(v1, v2);
		}
		return vek;
	}
}
