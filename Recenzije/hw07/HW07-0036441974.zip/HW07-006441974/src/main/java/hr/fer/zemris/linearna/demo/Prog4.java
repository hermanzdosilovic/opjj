package hr.fer.zemris.linearna.demo;

import hr.fer.zemris.linearna.IMatrix;
import hr.fer.zemris.linearna.Matrix;

/**
 * Razred izračunava baricentrične koordinate promatrajući problem kao linearni sustav jednadžbi koji je potrebno
 * riješiti.
 * 
 * @author Marin Vuica 27. 4. 2014.
 */
public class Prog4 {

	public static void main(String[] args) {

		IMatrix a = Matrix.parseSimple("1 5 3 | 0 0 8 | 1 1 1");
		IMatrix b = Matrix.parseSimple("3 | 4 | 1");
		IMatrix d = a.nInvert();
		System.out.println(d);
		IMatrix t = d.nMultiply(b);
		System.out.println(t);
	}

}
