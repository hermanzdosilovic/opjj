package hr.fer.zemris.linearna;

/**
 * Razred prestavlja matricu koja podatke vuče iz vektora.
 * @author Marin Vuica
 * 27. 4. 2014.
 */
public class MatrixVectorView extends AbstractMatrix implements IMatrix {
	
	/**
	 * referenca na dani vektor.
	 */
	private IVector reference;
	
	/**
	 *  označava jesu li podaci u stupcu ili redu.
	 */
	private boolean asRowMatrix;
	
	public MatrixVectorView(IVector original, boolean asRowMatrix) {
		this.reference = original;
		this.asRowMatrix = asRowMatrix;
	}
	
	@Override
	public int getRowsCount() {
		if (asRowMatrix == true) {
			return 1;
		} else {
			return reference.getDimension();
		}
	}

	@Override
	public int getColsCount() {
		if (asRowMatrix == false) {
			return 1;
		} else {
			return reference.getDimension();
		}
	}

	@Override
	 public double get(int row, int col) {
	  if (this.asRowMatrix == true) {
	   return reference.get(col);
	  } else {
	   return reference.get(row);
	  }
	 }
	 @Override
	 public IMatrix set(int row, int col, double value) {
	  if (this.asRowMatrix == true) {
	   reference.set(col, value);
	  } else {
	   reference.set(row, value);
	  }
	  return this.copy();
	 }
	 @Override
	 public IMatrix copy() {
	  double[][] temp = new double[this.getRowsCount()][this.getColsCount()];
	  for (int i = 0; i < this.getRowsCount(); i++) {
	   for (int j = 0; j < this.getColsCount(); j++) {
	    temp[i][j] = this.get(i, j);
	   }
	  }
	  return new Matrix(this.getRowsCount(), this.getColsCount(), temp, true);
	 }
	 @Override
	 public IMatrix newInstance(int rows, int cols) {
	  return new Matrix(rows, cols);
	 }

}
