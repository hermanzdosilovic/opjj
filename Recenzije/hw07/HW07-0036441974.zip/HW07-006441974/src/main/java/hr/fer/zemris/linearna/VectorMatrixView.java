package hr.fer.zemris.linearna;

/**
 * Razred predstavlja vektor koji vuče podatke iz jednoretčane ili jednostupčane matrice.
 * @author Marin Vuica
 * 27. 4. 2014.
 */
public class VectorMatrixView extends AbstractVector implements IVector {

	private IMatrix reference;
	private int dimension;
	private boolean rowMatrix;
	
	public VectorMatrixView(IMatrix original) {
		this.reference = original;
		if (original.getRowsCount() == 1 && (original.getColsCount() >= 1)) {
			this.dimension = original.getColsCount();
			this.rowMatrix = false;
		} else if (original.getRowsCount() > 1 && original.getColsCount() == 1) {
			this.dimension = original.getRowsCount();
			this.rowMatrix = true;
		} else {
			throw new IncompatibleOperandException("Matrica nije jednostupčana ili jednoretčana.");
		}
	}
	
	@Override
	public double get(int index) {
		if (rowMatrix == true) {
			return reference.get(0, index);
		} else {
			return reference.get(index, 0);
		}
	}

	@Override
	public IVector set(int index, double value) throws UnmodifiableObjectException {
		if (index < 0 || index > this.dimension) {
			throw new UnmodifiableObjectException("Ne mogu se mijenjati dimenzije koje premašuju vektor.");
		}
		if (rowMatrix == true) {
			reference.set(0, index, value);
		} else {
			reference.set(index, 0, value);
		}
		return this.copy();
	}

	@Override
	 public int getDimension() {
	  if(rowMatrix == true) {
	   return reference.getColsCount();
	  } else {
	   return reference.getRowsCount();
	  }
	 }

	@Override
	public IVector copy() {
		double[] field = new double[this.getDimension()];
		for (int i = 0; i < this.dimension; i++) {
			field[i] = this.get(i);
		}
		return new Vector(field);
	}

	@Override
	public IVector newInstance(int dimension) {
		double[] field = new double[this.getDimension()];
		return new Vector(field);
	}

}
