package hr.fer.zemris.linearna;

/**
 * Predstavlja pogled na instancu matrice, odnosno njen dio, dobiva indekse redova i stupaca koji ulaze u živi pogled.
 * 
 * @author Marin Vuica 27. 4. 2014.
 */
public class MatrixSubMatrixView extends AbstractMatrix implements IMatrix {

	/**
	 * referenca na danu matricu.
	 */
	private IMatrix reference;

	/**
	 * indeksi redova koji ulaze u živi pogled.
	 */
	private int[] rowIndexes;

	/**
	 * indeksi stupaca koji ulaze u živi pogled.
	 */
	private int[] colIndexes;

	/**
	 * 
	 * @param original Matrica čiji ćemo živi pogled dobiti
	 * @param row redak koji ćemo izbaciti
	 * @param col stupac koji ćemo izbaciti
	 */
	public MatrixSubMatrixView(IMatrix original, int row, int col) {
		reference = original;
		int redovi = original.getRowsCount();
		int stupci = original.getColsCount();
		this.rowIndexes = new int[redovi - 1];
		this.colIndexes = new int[stupci - 1];
		for (int i = 0, iSub = 0; i < redovi; i++, iSub++) {
			if (i == row) {
				iSub--;
				continue;
			}
			rowIndexes[iSub] = i;
		}
		for (int j = 0, jSub = 0; j < stupci; j++, jSub++) {
			if (j == col) {
				jSub--;
				continue;
			}
			colIndexes[jSub] = j;
		}
	}

	private MatrixSubMatrixView(IMatrix original, int[] rowIndexes, int[] colIndexes) {
		reference = original;
		this.rowIndexes = rowIndexes.clone();
		this.colIndexes = colIndexes.clone();
	}

	@Override
	public int getRowsCount() {
		return this.rowIndexes.length;
	}

	@Override
	public int getColsCount() {
		return this.colIndexes.length;
	}

	@Override
	public double get(int row, int col) {
		return reference.get(rowIndexes[row], colIndexes[col]);
	}

	@Override
	public IMatrix set(int row, int col, double value) {
		reference.set(rowIndexes[row], colIndexes[col], value);
		return reference;
	}

	@Override
	public IMatrix copy() {
		IMatrix matrix = this.newInstance(this.getRowsCount(), this.getColsCount());
		for (int i = this.getRowsCount() - 1; i >= 0; i--) {
			for (int j = this.getColsCount() - 1; j >= 0; j--) {
				matrix.set(i, j, reference.get(this.rowIndexes[i], this.colIndexes[j]));
			}
		}
		return matrix;
	}

	@Override
	public IMatrix newInstance(int rows, int cols) {
		return reference.newInstance(rows, cols);
	}

}
