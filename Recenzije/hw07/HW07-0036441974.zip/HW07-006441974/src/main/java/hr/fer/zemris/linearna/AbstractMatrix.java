package hr.fer.zemris.linearna;

import java.util.Arrays;

/**
 * Apstraktna klasa koju nasljeđuju sve matrice. Nudi funckije za definiranje i rad s matricama.
 * 
 * @author Marin Vuica
 * 27. 4. 2014.
 */
public abstract class AbstractMatrix implements IMatrix {

	@Override
	public abstract int getRowsCount();

	@Override
	public abstract int getColsCount();

	@Override
	public abstract double get(int row, int col);

	@Override
	public abstract IMatrix set(int row, int col, double value);

	@Override
	public IMatrix copy() {
		IMatrix matrix = this.newInstance(this.getRowsCount(), this.getColsCount());
		for (int i = this.getRowsCount() - 1; i >= 0; i--) {
			for (int j = this.getColsCount() - 1; j >= 0; j--) {
				matrix.set(i, j, this.get(i, j));
			}
		}
		return matrix;
	}

	@Override
	public abstract IMatrix newInstance(int rows, int cols);

	@Override
	public IMatrix nTranspose(boolean liveView) {
		IMatrix matrix;
		if (liveView == true) {
			matrix = new MatrixTransposeView(this);
		} else {
			// matrix = this.newInstance(this.getColsCount(), this.getRowsCount());
			// for (int i = this.getRowsCount() - 1; i >= 0; i--) {
			// for (int j = this.getColsCount() - 1; j >= 0; j--) {
			// matrix.set(j, i, this.get(i, j));
			// }
			// }
			matrix = new MatrixTransposeView(this).copy();
		}
		return matrix;
	}

	@Override
	public IMatrix add(IMatrix other) {
		if ((this.getRowsCount() != other.getRowsCount()) && (this.getColsCount() != other.getColsCount())) {
			throw new IncompatibleOperandException();
		}
		for (int i = this.getRowsCount() - 1; i >= 0; i--) {
			for (int j = this.getColsCount() - 1; j >= 0; j--) {
				this.set(i, j, this.get(i, j) + other.get(i, j));
			}
		}
		return this;
	}

	@Override
	public IMatrix nAdd(IMatrix other) {
		return this.copy().add(other);
	}

	@Override
	public IMatrix sub(IMatrix other) {
		if ((this.getRowsCount() != other.getRowsCount()) && (this.getColsCount() != other.getColsCount())) {
			throw new IncompatibleOperandException();
		}
		for (int i = this.getRowsCount() - 1; i >= 0; i--) {
			for (int j = this.getColsCount() - 1; j >= 0; j--) {
				this.set(i, j, this.get(i, j) - other.get(i, j));
			}
		}
		return this;
	}

	@Override
	public IMatrix nSub(IMatrix other) {
		return this.copy().sub(other);
	}

	@Override
	public IMatrix nMultiply(IMatrix other) {
		if (this.getColsCount() != other.getRowsCount()) {
			throw new IncompatibleOperandException();
		}
		IMatrix matrix = this.newInstance(this.getRowsCount(), other.getColsCount());
		for (int i = 0; i < this.getRowsCount(); i++) {
			for (int j = 0; j < other.getColsCount(); j++) {
				for (int k = 0; k < this.getColsCount(); k++) {
					matrix.set(i, j, matrix.get(i, j) + (this.get(i, k) * other.get(k, j)));
				}
			}
		}
		return matrix;
	}

	@Override
	public double determinant() throws IncompatibleOperandException {
		int redovi = this.getRowsCount();
		if (redovi != this.getColsCount()) {
			throw new IncompatibleOperandException("Matrica nije kvadratna, ne moguće izračunati determinantu.");
		}
		if (redovi == 1) {
			return this.get(0, 0);
		}
		if (redovi == 2) {
			return (this.get(0, 0) * this.get(1, 1)) - (this.get(1, 0) * this.get(0, 1));
		} else {
			double determinanta = 0;
			for (int i = 0; i < redovi; i++) {
				determinanta += Math.pow(-1, i) * this.get(0, i) * this.subMatrix(0, i, true).determinant();
			}
			return determinanta;
		}

	}

	@Override
	public IMatrix subMatrix(int row, int col, boolean liveView) {
		IMatrix matrix;
		if (liveView == true) {
			matrix = new MatrixSubMatrixView(this, row, col);
		} else {
			matrix = new MatrixSubMatrixView(this, row, col).copy();
		}
		return matrix;
	}

	@Override
	public IMatrix nInvert() {
		int rows = this.getRowsCount();
		int cols = this.getColsCount();
		if (rows != cols) {
			throw new IncompatibleOperandException("Matrica nije kvadratna, nemoguće izračunati determinantu.");
		}
		IMatrix matrix = this.newInstance(rows, cols);
		if (Double.compare(this.determinant(), 0) == 0) {
			throw new IncompatibleOperandException("Matrica je singularna, nemoguće izračunati inverz.");
		}
		for (int i = 0; i < rows; i++) {
			for (int j = 0; j < cols; j++) {
				matrix.set(i, j, Math.pow(-1, i + j) * this.subMatrix(i, j, true).determinant());
			}
		}
		IMatrix matrix2 = matrix.nTranspose(true);
		matrix2.scalarMultiply(1 / this.determinant());
		return matrix2;
	}

	@Override
	public double[][] toArray() {
		int rows = this.getRowsCount();
		int columns = this.getColsCount();
		double[][] matrix = new double[rows][columns];
		for (int i = this.getRowsCount() - 1; i >= 0; i--) {
			for (int j = this.getColsCount() - 1; j >= 0; j--) {
				matrix[i][j] = this.get(i, j);
			}
		}
		return matrix;
	}

	@Override
	public IVector toVector(boolean liveView) {
		if (liveView == true) {
			return new VectorMatrixView(this);
		} else {
			return new VectorMatrixView(this.copy());
		}
	}

	@Override
	public IMatrix nScalarMultiply(double value) {
		return this.copy().scalarMultiply(value);
	}

	@Override
	public IMatrix scalarMultiply(double value) {
		for (int i = this.getRowsCount() - 1; i >= 0; i--) {
			for (int j = this.getColsCount() - 1; j >= 0; j--) {
				this.set(i, j, this.get(i, j) * value);
			}
		}
		return this;
	}

	@Override
	public IMatrix makeIdentity() {
		for (int i = this.getRowsCount() - 1; i >= 0; i--) {
			for (int j = this.getColsCount() - 1; j >= 0; j--) {
				if (i != j) {
					this.set(i, j, 0);
				} else {
					this.set(i, j, 1);
				}
			}
		}
		return this;
	}

	@Override
	public String toString() {
		return Arrays.deepToString(this.toArray());
	}

}
