package hr.fer.zemris.linearna;

/**
 * Predstavlja živi pogled na matricu u njenom transponiranom obliku.
 * @author Marin Vuica
 * 27. 4. 2014.
 */
public class MatrixTransposeView extends AbstractMatrix implements IMatrix {
	
	/**
	 * referenca na danu matricu.
	 */
	private IMatrix reference;
	
	/**
	 * Daje živi pogled na matricu u njenom transponiranom obliku.
	 * @param original matrica koja će se transponirati.
	 */
	public MatrixTransposeView(IMatrix original) {
		this.reference = original;
	}
	
	@Override
	public int getRowsCount() {
		return reference.getColsCount();
	}

	@Override
	public int getColsCount() {
		return reference.getRowsCount();
	}

	@Override
	public double get(int row, int col) {
		return reference.get(col, row);
	}

	@Override
	public IMatrix set(int row, int col, double value) {
		reference.set(col, row, value);
		return reference;
	}
	
	@Override
	public IMatrix copy() {
		IMatrix matrix = this.newInstance(this.getRowsCount(), this.getColsCount());
		for (int i = matrix.getRowsCount() - 1; i >= 0; i--) {
			for (int j = matrix.getColsCount() - 1; j >= 0; j--) {
				matrix.set(i, j, this.get(i, j));
			}
		}
		return matrix;
	}
	
	@Override
	public IMatrix newInstance(int rows, int cols) {
		return reference.newInstance(rows, cols);
	}

}
