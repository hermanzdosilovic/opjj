package hr.fer.zemris.linearna;

import static org.junit.Assert.*;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class VectorTest {

	private double[] fields = new double[5];

	@Before
	   public void setUp() {
		for (int i = 0; i < 5; i++) {
			this.fields[i] = i;
		}
	   }
	
	IVector vectorUnmodifiable = new Vector(true, true, fields);
	IVector vectorUnmodifiable2 = new Vector(false, false, fields);
	IVector vector = new Vector(1, 2, 3, 4, 5, 6);
	IVector vector2 = Vector.parseSimple("0 1 2 3  4 5  ");
	IVector vectora = new Vector(1, 2, 3, 4, 5, 6);
	IVector vector2a = Vector.parseSimple("0 1 2 3  4 5  ");
	IVector vector3 = new Vector(1, 2, 3);
	IVector vector4 = new Vector(0, 1, 2);
	IVector vector5 = new Vector(10, 20, 5);
	IVector vekica = vectora.add(vector2a);
	IVector vector7 = Vector.parseSimple("12 2222 333333 4444444");
	

	@Test
	public void testGet() {
		Assert.assertEquals(1, vector.get(0), 0);
	}
	
	@Test(expected=IndexOutOfBoundsException.class)
	public void testGetthrowsIndexOutOfBoundsException() {
		vector.get(-5);
		vector.get(14);
	}
	
	@Test(expected = IndexOutOfBoundsException.class)
	public void testGetthrowsIndexOutOfBoundsException2() {
		vector.get(14);
	}

	@Test
	public void testSet() {
		vector.set(2, 13);
		Assert.assertEquals(13, vector.get(2), 0);
	}

	@Test(expected = IndexOutOfBoundsException.class)
	public void testSetthrowsIndexOutOfBoundsException() {
		vector.set(-20, 33333);
	}
	
	@Test(expected = IndexOutOfBoundsException.class)
	public void testSetthrowsIndexOutOfBoundsException2() {
		vector.set(20, 13333);
	}
	
	@Test(expected = UnmodifiableObjectException.class)
	public void testSetthrowsUnmodifiableObjectException() {
		vectorUnmodifiable.set(100, 2);
	}
	
	@Test
	public void testGetDimension() {
		Assert.assertEquals(6, vector.getDimension(), 0);
	}


	@Test
	public void testCopy() {
		IVector vector = this.vector.copy();
		Assert.assertEquals(6, vector.getDimension(), 0);
		Assert.assertEquals(4, vector.get(3), 0);
	}

	@Test
	public void testCopyPart() {
		IVector vec = vector.copyPart(3);
		Assert.assertEquals(3, vec.get(2), 0);
		Assert.assertEquals(3, vec.getDimension(), 0);
		
		IVector vec2 = vector.copyPart(10);
		Assert.assertEquals(0, vec2.get(7), 0);
		Assert.assertEquals(10, vec2.getDimension(), 0);
	}
	
	
	@Test
	public void testNewInstance() {
		vector.newInstance(6);
		Assert.assertEquals(6, vector.getDimension(), 0);
		
		IVector vectorkk = vectorUnmodifiable2.newInstance(3);
		Assert.assertEquals(3, vectorkk.getDimension(), 0);
	}

	@Test
	public void testAdd() {
		IVector vec = vector.add(vector2);
		Assert.assertEquals(5, vec.get(2), 0);
		Assert.assertEquals(6, vector.getDimension(), 0);
	}

	@Test(expected = IncompatibleOperandException.class)
	public void testAddthrowsIncompatibleOperandException() {
		IVector vec = vector.add(vector3);
	}

	@Test
	public void testNAdd() {
		IVector vec = vector.nAdd(vector2);
		Assert.assertEquals(5, vec.get(2), 0);
		Assert.assertEquals(6, vector.getDimension(), 0);
	}
	
	@Test
	public void testSub() {
		IVector vec = vector.sub(vector2);
		Assert.assertEquals(1, vec.get(2), 0);
	}
	
	@Test(expected = IncompatibleOperandException.class)
	public void testSubthrowsIncompatibleOperandException() {
		IVector vec = vector.sub(vector3);
	}
	
	@Test
	public void testNSub() {
		IVector vec = vector.nSub(vector2);
		Assert.assertEquals(1, vec.get(3), 0);
	}
	
	@Test
	public void testScalarMultiply() {
		vector.scalarMultiply(3);
		Assert.assertEquals(9, vector.get(2), 0);
		Assert.assertEquals(18, vector.get(5), 0);
	}

	@Test
	public void testNScalarMultiply() {
		IVector vec = vector.nScalarMultiply(3.0);
		Assert.assertEquals(9, vec.get(2), 0);
		Assert.assertEquals(18, vec.get(5), 0);
	}

	@Test
	public void testNorm() {
		Vector vector = new Vector(3, 1, 2);
		Assert.assertEquals(3.742, vector.norm(), 0.1);
	}

	@Test
	public void testNormalize() {
		Vector vector = new Vector(3,1,2);
		vector.normalize();
		Assert.assertEquals(0.8027, vector.get(0), 0.1);
	}

	@Test
	public void testNNormalize() {
		Vector vector = new Vector(3,1,2);
		Vector vector2 = (Vector) vector.nNormalize();
		Assert.assertEquals(0.8027, vector2.get(0), 0.1);
	}

	@Test
	public void testCosine() {
		Vector vector = new Vector(2,1,5);
		Vector vector2 = new Vector(3,5,2);
		Assert.assertEquals(0.6219, vector.cosine(vector2), 1e-3);
		vector2 = new Vector(1,2);
	}

	@Test
	public void testScalarProduct() {
		IVector vec = vector5.scalarMultiply(5);
		Assert.assertEquals(50, vec.get(0), 0);
		Assert.assertEquals(100, vec.get(1), 0);
		Assert.assertEquals(25, vec.get(2), 0);
		Assert.assertEquals(3, vec.getDimension(), 0);
	}
	
	@Test (expected = IncompatibleOperandException.class)
	public void testScalarProductIncompatibleOperandException() {
		vector2.scalarProduct(vector3);
	}
	
	@Test
	public void testNVectorProduct() {
		IVector vec = vector5.nVectorProduct(vector4);
		Assert.assertEquals(35, vec.get(0), 0);
		Assert.assertEquals(-20, vec.get(1), 0);
		Assert.assertEquals(10, vec.get(2), 0);
		Assert.assertEquals(3, vec.getDimension(), 0);
	}
	
	@Test (expected = IncompatibleOperandException.class)
	public void testNVectorProductIncompatibleOperandException() {
		vector.nVectorProduct(vector2);
	}
	
	@Test
	public void testNFromHomogeneus() {
		IVector vec = vector5.nFromHomogeneus();
		Assert.assertEquals(2, vec.get(0), 0);
		Assert.assertEquals(4, vec.get(1), 0);
		Assert.assertEquals(2, vec.getDimension(), 0);
	}

	@Test
	public void testToRowMatrix() {
		Vector vector = new Vector(3, -3, 1);
		IMatrix mat1 = vector.toRowMatrix(true);
		IMatrix mat2 = vector.toRowMatrix(false);
	}

	@Test
	public void testToColumnMatrix() {
		Vector vector = new Vector(3, -3, 1);
		IMatrix mat1 = vector.toColumnMatrix(true);
		IMatrix mat2 = vector.toColumnMatrix(false);
	}

	@Test
	public void testToArray() {
		double[] numbers = vector.toArray();
		Assert.assertEquals(4, numbers[3], 0);
	}

	@Test
	public void testToString() {
		Assert.assertTrue(vector.toString().equals("[1.0, 2.0, 3.0, 4.0, 5.0, 6.0]"));
	}

}
