package hr.fer.zemris.linearna;

/**
 * This class represents a vector of double precision values. The dimension of
 * {@code this} vector is specified on constructing.
 * <p>This vector implementation holds its elements in an array of doubles.
 * <p>If this vector is constructed as an readonly vector, when trying to modify the
 * values of that vector, an {@link UnmodifiableObjectException} will be thrown.
 * 
 * @see IVector
 * @see AbstractVector
 * @author Kristian
 */
public class Vector extends AbstractVector {

	/**
	 * The values of this vector.
	 */
	private double[] elements;
	
	/**
	 * The dimension of this vector.
	 */
    private int dimension;
    
    /**
     * Is this vector modifiable.
     */
    private boolean readOnly;

    /**
     * Creates a new {@link Vector} instance with the specified initial values.
     * The dimension of the created vector is the length of the specified array.
     * @param elements the initial vector values
     * @throws IllegalArgumentException if the specified elements array is {@code null}
     * or if this array is empty
     */
    public Vector(double...elements) {
    	if(elements == null) {
    		throw new IllegalArgumentException("Null arguments not allowed.");
    	}
    	if(elements.length == 0) {
    		throw new IllegalArgumentException("Specified array is empty.");
    	}
    	
        this.elements = elements;
        this.dimension = elements.length;
    }

    /**
     * Creates a new {@link Vector} instance with the specified initial values.
     * The dimension of the created vector is the length of the specified array.
     * <p>If the {@code readOnly} flag is {@code true} then this vector will become
     * unmodifiable, and on every try to change its values a {@link UnmodifiableObjectException}
     * will be thrown.
     * <p>If the {@code changeSafe} flag is {@code true} then the specified elements array will not
     * be copied, otherwise its values will be copied
     * @param readOnly is the created vecotr modifiable or not
     * @param changeSafe should the specified elements be copied or not
     * @param elements the initial vector values
     * @throws IllegalArgumentException if the specified elements array is {@code null}
     * or if this array is empty
     */
    public Vector(boolean readOnly, boolean changeSafe, double...elements) {
    	if(elements == null) {
    		throw new IllegalArgumentException("Null arguments not allowed.");
    	}
    	if(elements.length == 0) {
    		throw new IllegalArgumentException("Specified array is empty.");
    	}
        	
    	this.dimension = elements.length;
        this.readOnly = readOnly;
        if (changeSafe) {
        	this.elements = elements;
        }
        else {
            this.elements = new double[elements.length];
            for(int i = 0; i < elements.length; i++) {
            	this.elements[i] = elements[i];
            }
        }
    }

    /**
     * @throws IndexOutOfBoundsException if the specified index is out of bounds
     */
    @Override
    public double get(int index) {
    	if(index < 0 || index >= this.dimension) {
    		throw new IndexOutOfBoundsException("The specified index is out of bounds: " + index);
    	}
    	
        return elements[index];
    }

    /**
     * @throws UnmodifiableObjectException if this {@code vector} is readonly
     * @throws IndexOutOfBoundsException if the specified index is out of bounds
     */
    @Override
    public IVector set(int index, double value) {
    	if(index < 0 || index >= this.dimension) {
    		throw new IndexOutOfBoundsException("The specified index is out of bounds: " + index);
    	}
    	
        if(this.readOnly) {
        	throw new UnmodifiableObjectException("This vector is unmodifiable.");
        }
        
        this.elements[index] = value;
        return this;
    }

    @Override
    public int getDimension() {
        return dimension;
    }

    @Override
    public IVector copy() {
        IVector v = newInstance(this.dimension);
        for (int i = 0; i < this.dimension; i++) {
        	v.set(i, this.get(i));
        }
        return v;
    }

    /**
     * @throws IllegalArgumentException if the specified dimension is negative or zero
     */
    @Override
    public IVector newInstance(int dim) {
    	if(dim <= 0) {
    		throw new IllegalArgumentException("Dimension must be positive.");
    	}
    	
        return new Vector(new double[dim]);
    }

    /**
     * Parses the specified vector string representation into a new {@link Vector} instance if
     * possible.
     * <pre>
     * Examples:
     * "1 2 3" - vector with dimension = 3
     * "2" - vector with dimension = 1
     * </pre>
     * @param input the vector representation
     * @return a new {@link Vector} instance parsed from the specified string vector representation
     * @throws IllegalArgumentException if the specified string is {@code null} or the string does
     * not represent a valid vector.
     */
    public static Vector parseSimple(String input) {
    	if(input == null) {
    		throw new IllegalArgumentException("Null arguments not allowed.");
    	}
    	
        String[] elems = input.split("\\s+");
        
        double[] v = new double[elems.length];
        try {
        	for (int i = 0; i < v.length; i++) {
            	v[i] = Double.parseDouble(elems[i]);
            }
		} catch (NumberFormatException e) {
			throw new IllegalArgumentException("Invalid input string.");
		}

        return new Vector(v);
    }
	
}
