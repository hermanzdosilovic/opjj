package hr.fer.zemris.linearna;

/**
 * Represents a vector which is a live view of a matrix with one row or one column.
 * When the values of {@code this} vector view changes, the change is visible in the
 * matrix from which this vector is created.
 * 
 * @author Kristian
 */
public class VectorMatrixView extends AbstractVector {

	/**
	 * The original matrix.
	 */
	private IMatrix mat;
	
	/**
	 * The dimension of this vector view.
	 */
    private int dimension;
    
    /**
     * Is the original matrix a row matrix or a column matrix.
     */
    private boolean rowMatrix;

    /**
     * Creates a new {@link VectorMatrixView} instance from the specified
     * matrix which must have only one row or one column to represent it as a valid
     * vector.
     * @param mat the original matrix
     * @throws IllegalArgumentException if the specified matrix is {@code null} or the specified
     * matrix cannot be represented as a vector
     */
    public VectorMatrixView(IMatrix mat) {
    	if(mat == null) {
    		throw new IllegalArgumentException("Null arguments not allowed.");
    	}
    	
        this.mat = mat;
        if (mat.getColsCount() == 1) {
            rowMatrix = true;
            dimension = mat.getRowsCount();
        }
        else if(mat.getRowsCount() == 1) {
            rowMatrix = false;
            dimension = mat.getColsCount();
        }
        else {
        	throw new IllegalArgumentException("The specified matrix must contain only one row, or only one column.");
        }
    }

    /**
     * @throws IndexOutOfBoundsException if the specified index is not within bounds of the dimension
     */
    @Override
    public double get(int index) {
    	if(index < 0 || index >= this.dimension) {
    		throw new IndexOutOfBoundsException("Specified index is out of bounds: " + index);
    	}
    	
        if (rowMatrix) {
        	return this.mat.get(index, 0);
        }
        else {
        	return this.mat.get(0, index);
        }
    }

    /**
     * @throws IndexOutOfBoundsException if the specified index is not within bounds of the dimension
     */
    @Override
    public IVector set(int index, double value) {
    	if(index < 0 || index >= this.dimension) {
    		throw new IndexOutOfBoundsException("Specified index is out of bounds: " + index);
    	}
    	
        if (rowMatrix) {
        	this.mat.set(index, 0, value);
        }
        else {
        	this.mat.set(0, index, value);
        }
        
        return this;
    }

    @Override
    public int getDimension() {
        return this.dimension;
    }

    @Override
    public IVector copy() {
        IVector result = newInstance(this.dimension);
        for (int i = 0; i < result.getDimension(); i++) {
        	result.set(i, this.get(i));
        }

        return result;
    }

    /**
     * @throws IllegalArgumentException if the specified dimension is negative or zero
     */
    @Override
    public IVector newInstance(int dim) {
    	return LinAlgDefaults.defaultVector(dim);
    }
	
}
