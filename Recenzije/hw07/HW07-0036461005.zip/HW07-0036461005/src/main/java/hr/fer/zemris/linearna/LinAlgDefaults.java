package hr.fer.zemris.linearna;

/**
 * Class {@linkLinAlgDefaults} is responsible for creating default implementations of vectors and matrices.
 * 
 * @author Kristian
 */
public class LinAlgDefaults {

	/**
	 * Creates a new {@link Matrix} with the specified number of rows and columns.
	 * The values will be defaulted to 0.0d.
	 * @param rows the number of rows
	 * @param cols the number of columns
	 * @return a new {@link Matrix} instance
	 * @throws IllegalArgumentException if the specified number of rows or columns is less than or equal to zero
	 */
	public static IMatrix defaultMatrix(int rows, int cols) {
		return new Matrix(rows, cols);
	}
	
	/**
	 * Creates a new {@link Vector} instance with the specified dimension.
	 * The values will be defaulted to 0.0d.
	 * @param dimension the initial dimension of the created vector
	 * @return a new {@link Vector} instance
	 * @throws IllegalArgumentException if the specified dimension is less than or equal to zero
	 */
	public static IVector defaultVector(int dimension) {
		if(dimension <= 0) {
			throw new IllegalArgumentException("Specified dimension must be positive.");
		}
		
		return new Vector(new double[dimension]);
	}
	
}
