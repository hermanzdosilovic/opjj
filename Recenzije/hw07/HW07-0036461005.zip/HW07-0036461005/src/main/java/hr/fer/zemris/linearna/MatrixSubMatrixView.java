package hr.fer.zemris.linearna;

import java.util.Arrays;

/**
 * This class represents a live view of an already created matrix which doesn't have
 * all rows and columns included. When a value of {@code this} sub matrix changes,
 * the change is visible in the original matrix.
 * 
 * @author Kristian
 */
public class MatrixSubMatrixView extends AbstractMatrix {

	/**
	 * Contains the original matrix reference.
	 */
	private IMatrix matrix;
	
	/**
	 * Contains the indexes of rows of the original matrix for which this view exists.
	 * The indexes are sorted.
	 */
    private int[] rowIndexes;
    
    /**
     * Contains the indexes of columns of the original matrix for which this view exists.
     * The indexes are sorted.
     */
    private int[] columnIndexes;

    /**
     * Creates a new {@link MatrixSubMatrixView} which is a live view of the specified
     * matrix but with the specified row and column excluded 
     * @param mat the original matrix
     * @param row the row which is excluded from the original matrix
     * @param column the column which is excluded from the original matrix
     * @throws IllegalArgumentException if the specified matrix is {@code null}
     * @throws IndexOutOfBoundsException if the specified row or column is out of bounds
     */
    public MatrixSubMatrixView(IMatrix mat, int row, int column) {
    	if(mat == null) {
    		throw new IllegalArgumentException("Null arguments not allowed.");
    	}
    	if(row < 0 || row >= mat.getRowsCount()) {
    		throw new IndexOutOfBoundsException("Specified row is out of bounds: " + row);
    	}
    	if(column < 0 || column >= mat.getColsCount()) {
    		throw new IndexOutOfBoundsException("Specified column is out of bounds: " + row);
    	}
    	
        this.matrix = mat;

        this.rowIndexes = new int[mat.getRowsCount() - 1];
        this.columnIndexes = new int[mat.getColsCount() - 1];

        for (int i = 0, j = 0; i < mat.getRowsCount(); i++) {
        	if (i != row) {
        		this.rowIndexes[j++] = i;
        	}
        }

        for (int i = 0, j = 0; i < mat.getColsCount(); i++) {
        	if (i != column) {
        		this.columnIndexes[j++] = i;
        	}
        }
    }

    /**
     * Creates a new {@link MatrixSubMatrixView} which is a live view of the specified
     * matrix but with the specified rows and columns included. The specified arrays may
     * change.
     * @param mat the original matrix
     * @param rows indexes of included rows from the original matrix, no duplicate values allowed
     * @param columns indexes of included columns from the original matrix, no duplicate values allowed
     * @throws IllegalArgumentException if any of the arguments is {@code null} or the specified array
     * are empty
     * @throws IndexOutOfBoundsException if the specified indexes are out of the specified matrix bounds
     */
    @SuppressWarnings("unused")
	private MatrixSubMatrixView(IMatrix mat, int[] rows, int[] columns) {
    	if(mat == null || rows == null || columns == null) {
    		throw new IllegalArgumentException("Null arguments not allowed.");
    	}
    	if(rows.length == 0 || columns.length == 0) {
    		throw new IllegalArgumentException("No index specified.");
    	}
    	
    	// Sort the arrays
    	Arrays.sort(rows);
    	Arrays.sort(columns);
    	
    	// Check if the first and last elements are out of bounds
    	if(rows[0] < 0 || rows[rows.length-1] >= mat.getRowsCount()) {
			throw new IndexOutOfBoundsException("The rows array contains invalid index.");
		}
    	if(columns[0] < 0 || columns[columns.length-1] >= mat.getColsCount()) {
			throw new IndexOutOfBoundsException("The columns array contains invalid index.");
		}
    	
    	// Check for duplicates
    	for(int i = 0; i < rows.length; i++) {
    		if(i > 0) {
    			if(rows[i] == rows[i-1]) {
    				throw new IllegalArgumentException("Duplicate row index specified: " + rows[i]);
    			}
    		}
    	}
    	// Check for duplicates
    	for(int i = 0; i < columns.length; i++) {
    		if(i > 0) {
    			if(columns[i] == columns[i-1]) {
    				throw new IllegalArgumentException("Duplicate column index specified: " + columns[i]);
    			}
    		}
    	}
    	
        this.matrix = mat;
        this.rowIndexes = rows;
        this.columnIndexes = columns;
    }

    @Override
    public int getRowsCount() {
        return rowIndexes.length;
    }

    @Override
    public int getColsCount() {
        return columnIndexes.length;
    }

    /**
     * @throws IndexOutOfBoundsException if the specified row or column is out of bounds
     */
    @Override
    public double get(int row, int column) {
    	if(row < 0 || row >= this.rowIndexes.length) {
    		throw new IndexOutOfBoundsException("Specified row is out of bounds: " + row);
    	}
    	if(column < 0 || column >= this.columnIndexes.length) {
    		throw new IndexOutOfBoundsException("Specified column is out of bounds: " + column);
    	}
    	
        return this.matrix.get(this.rowIndexes[row], this.columnIndexes[column]);
    }

    /**
     * @throws IndexOutOfBoundsException if the specified row or column is out of bounds
     */
    @Override
    public IMatrix set(int row, int column, double value) {
    	if(row < 0 || row >= this.rowIndexes.length) {
    		throw new IndexOutOfBoundsException("Specified row is out of bounds: " + row);
    	}
    	if(column < 0 || column >= this.columnIndexes.length) {
    		throw new IndexOutOfBoundsException("Specified column is out of bounds: " + column);
    	}
    	
        this.matrix.set(rowIndexes[row], columnIndexes[column], value);
        return this;
    }

    @Override
    public IMatrix copy() {
        IMatrix result = newInstance(this.rowIndexes.length, this.columnIndexes.length);

        for (int i = 0; i < result.getRowsCount(); i++) {
            for (int j = 0; j < result.getColsCount(); j++) {
                result.set(i, j, this.matrix.get(this.rowIndexes[i], this.columnIndexes[j]));
            }
        }

        return result;
    }

    /**
     * @throws IllegalArgumentException if the specified row or column count is less than or
     * equal to zero
     */
    @Override
    public IMatrix newInstance(int rows, int columns) {
        return this.matrix.newInstance(rows, columns);
    }

    /**
     * @throws IndexOutOfBoundsException if the specified row or column is out of bounds
     */
    @Override
    public IMatrix subMatrix(int r, int c, boolean liveView) {
        if(liveView) {
        	return new MatrixSubMatrixView(this, r, c);
        }
        else {
        	return new MatrixSubMatrixView(this.copy(), r, c);
        }
    }

}
