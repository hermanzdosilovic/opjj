package hr.fer.zemris.linearna;

/**
 * This class represents a live view of an already created matrix. When a value of {@code this} sub matrix changes,
 * the change is visible in the original matrix. This view represents a transposed matrix of the original matrix.
 * 
 * @author Kristian
 */
public class MatrixTransposeView extends AbstractMatrix {

	/**
	 * Reference of the original matrix.
	 */
	private IMatrix matrix;

	/**
	 * Creates a new {@link MatrixTransposeView} instance which is 
	 * the transposed matrix view of the specified matrix.
	 * @param mat the original matrix
	 * @throws IllegalArgumentException if the specified matrix is {@code null}
	 */
    public MatrixTransposeView(IMatrix mat) {
    	if(mat == null) {
    		throw new IllegalArgumentException("Null arguments not allowed.");
    	}
    	
        this.matrix = mat;
    }

    @Override
    public int getRowsCount() {
        return this.matrix.getColsCount();
    }

    @Override
    public int getColsCount() {
        return this.matrix.getRowsCount();
    }

    /**
     * @throws IndexOutOfBoundsException if the specified row or column is out of bounds
     */
    @Override
    public double get(int row, int column) {
    	if(row < 0 || row >= this.matrix.getColsCount()) {
    		throw new IndexOutOfBoundsException("Specified row is out of bounds: " + row);
    	}
    	if(column < 0 || column >= this.matrix.getRowsCount()) {
    		throw new IndexOutOfBoundsException("Specified column is out of bounds: " + column);
    	}
    	
        return this.matrix.get(column, row);
    }

    /**
     * @throws IndexOutOfBoundsException if the specified row or column is out of bounds
     */
    @Override
    public IMatrix set(int row, int column, double value)
    {
    	if(row < 0 || row >= this.matrix.getColsCount()) {
    		throw new IndexOutOfBoundsException("Specified row is out of bounds: " + row);
    	}
    	if(column < 0 || column >= this.matrix.getRowsCount()) {
    		throw new IndexOutOfBoundsException("Specified column is out of bounds: " + column);
    	}
    	
        this.matrix.set(column, row, value);
        return this;
    }

    @Override
    public IMatrix copy() {
        IMatrix result = newInstance(this.matrix.getColsCount(), this.matrix.getRowsCount());
        for (int i = 0; i < result.getRowsCount(); i++) {
        	for (int j = 0; j < result.getColsCount(); j++) {
                result.set(i, j, this.matrix.get(j, i));
            }
        }

        return result;
    }

    /**
     * @throws IllegalArgumentException if the specified number of rows or columns is less than or equal to zero
     */
    @Override
    public IMatrix newInstance(int rows, int columns) {
        return this.matrix.newInstance(rows, columns);
    }

    @Override
    public double[][] toArray() {
        int rows = this.matrix.getColsCount();
        int columns = this.matrix.getRowsCount();
        
        double[][] result = new double[rows][columns];
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < columns; j++) {
                result[i][j] = this.matrix.get(j, i);
            }
        }
        return result;
    }
    
}
