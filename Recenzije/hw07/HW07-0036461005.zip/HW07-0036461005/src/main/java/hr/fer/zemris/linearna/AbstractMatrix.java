package hr.fer.zemris.linearna;

/**
 * This abstract matrix implements the {@link IMatrix} interface and
 * most of it's functionality where the value storage details are left
 * to the inheriting classes.
 * <p>This implementation supports standard matrix operations like addition,
 * subtraction, multiplication, determinant calculation, transposing, inversion etc.
 * 
 * @author Kristian
 */
public abstract class AbstractMatrix implements IMatrix {

	@Override
	public abstract int getRowsCount();
	
	@Override
    public abstract int getColsCount();
	
	@Override
    public abstract double get(int row, int column);
	
	@Override
    public abstract IMatrix set(int row, int column, double value);
	
	@Override
    public abstract IMatrix copy();
	
	@Override
    public abstract IMatrix newInstance(int rows, int columns);

	@Override
    public IMatrix nTranspose(boolean liveView) {
        if(liveView) {
        	return new MatrixTransposeView(this);
        }
        else {
        	return new MatrixTransposeView(this.copy());
        }
    }
	
	/**
	 * @throws IllegalArgumentException if the specified matrix is {@code null}
	 * @throws IncompatibleOperandException if the specified matrix does not have the same
	 * row and column counts as {@code this} matrix
	 */
	@Override
    public IMatrix add(IMatrix mat) {
		if(mat == null) {
			throw new IllegalArgumentException("Null arguments not allowed.");
		}
		
        if (this.getRowsCount() != mat.getRowsCount() || this.getColsCount() != mat.getColsCount()) {
        	throw new IncompatibleOperandException("Number of rows and columns does not match.");
        }
        
        for (int i = 0; i < this.getRowsCount(); i++) {
        	for (int j = 0; j < this.getColsCount(); j++) {
        		this.set(i, j, this.get(i, j) + mat.get(i, j));
        	}
        }
                
        return this;
    }

	/**
	 * @throws IllegalArgumentException if the specified matrix is {@code null}
	 * @throws IncompatibleOperandException if the specified matrix does not have the same
	 * row and column counts as {@code this} matrix
	 */
	@Override
    public IMatrix nAdd(IMatrix mat) {
        return this.copy().add(mat);
    }

	/**
	 * @throws IllegalArgumentException if the specified matrix is {@code null}
	 * @throws IncompatibleOperandException if the specified matrix does not have the same
	 * row and column counts as {@code this} matrix
	 */
	@Override
    public IMatrix sub(IMatrix mat) {
		if(mat == null) {
			throw new IllegalArgumentException("Null arguments not allowed.");
		}
		
        if (this.getRowsCount() != mat.getRowsCount() || this.getColsCount() != mat.getColsCount()) {
        	throw new IncompatibleOperandException("Number of rows and columns does not match.");
        }
        
        for (int i = 0; i < this.getRowsCount(); i++) {
        	for (int j = 0; j < this.getColsCount(); j++) {
        		this.set(i, j, this.get(i, j) - mat.get(i, j));
        	}
        }
            
        return this;
    }

	/**
	 * @throws IllegalArgumentException if the specified matrix is {@code null}
	 * @throws IncompatibleOperandException if the specified matrix does not have the same
	 * row and column counts as {@code this} matrix
	 */
	@Override
    public IMatrix nSub(IMatrix mat) {
        return this.copy().sub(mat);
    }

	/**
	 * @throws IllegalArgumentException if the specified matrix is {@code null}
	 * @throws IncompatibleOperandException if the specified matrix and {@code this} matrix cannot
	 * be multiplied because the number of columns of {@code this} matrix is not the same as the
	 * number of rows of the specified matrix
	 */
    @Override
    public IMatrix nMultiply(IMatrix mat) {
    	if(mat == null) {
			throw new IllegalArgumentException("Null arguments not allowed.");
		}
    	
        if(this.getColsCount() != mat.getRowsCount()) {
        	throw new IncompatibleOperandException("The matrices cannot be multiplied.");
        }

        IMatrix result = newInstance(this.getRowsCount(), mat.getColsCount());
        int m = this.getColsCount();

        for (int i = 0; i < result.getRowsCount(); i++) {
            for (int j = 0; j < result.getColsCount(); j++) {
                double ab = 0;
                for (int k = 0; k < m; k++) {
                    ab += this.get(i, k)*mat.get(k, j);
                }
                result.set(i, j, ab);
            }
        }

        return result;
    }

    /**
     * @throws RuntimeException if {@code this} matrix is not square
     */
    @Override
    public double determinant() {
        if(this.getColsCount() != this.getRowsCount()) {
        	throw new RuntimeException("Matrix is not square.");
        }

        if (this.getColsCount() == 1 && this.getRowsCount() == 1) {
        	return this.get(0, 0);
        }

        double result = 0;
        int j = 1;

        for (int i = 1; i <= this.getRowsCount(); i++) {
            result += Math.pow(-1, i + j)*get(i - 1, j - 1)*subMatrix(i - 1, j - 1, false).determinant();
        }

        return result;
    }

    /**
     * @throws IndexOutOfBoundsException if the specified row or column is out of bounds
     */
    @Override
    public IMatrix subMatrix(int r, int c, boolean liveView) {
        if(liveView) {
        	return new MatrixSubMatrixView(this, r, c);
        }
        else {
        	return new MatrixSubMatrixView(this.copy(), r, c);
        }
    }

    /**
     * Calculated using matrix of cofactors.
     * @throws RuntimeException if {@code this} matrix is not square or is singular
     * @see <a href="http://www.mathsisfun.com/algebra/matrix-inverse-minors-cofactors-adjugate.html">http://www.mathsisfun.com/</a>
     */
    @Override
    public IMatrix nInvert() {
        if(this.getColsCount() != this.getRowsCount()) {
        	throw new RuntimeException("Matrix must be square.");
        }

        // Calculate determinant and chack if it is zero-ish
        double deterimant = this.determinant();
        if(deterimant <= 1E-5) {
        	throw new RuntimeException("Matrix is singular.");
        }
        
        // Calculate cofactor matrix
        IMatrix cofactorMatrix = newInstance(this.getRowsCount(), this.getColsCount());
        for (int i = 0; i < this.getRowsCount(); i++) {
            for (int j = 0; j < this.getColsCount(); j++) {
                if (i % 2 != 0 && j % 2 == 0 || i % 2 == 0 && j % 2 != 0) {
                	cofactorMatrix.set(i, j, -this.subMatrix(i, j, false).determinant());
                }
                else {
                	cofactorMatrix.set(i, j, this.subMatrix(i, j, false).determinant());
                }
            }
        }
        
        double onedetA = 1/deterimant;
        IMatrix cofMTransposed = cofactorMatrix.nTranspose(false);

        for (int i = 0; i < cofMTransposed.getRowsCount(); i++) {
            for (int j = 0; j < cofMTransposed.getColsCount(); j++) {
                cofMTransposed.set(i, j, onedetA*cofMTransposed.get(i, j));
            }
        }

        return cofMTransposed.copy();
    }

    @Override
    public double[][] toArray() {
        double[][] result = new double[this.getRowsCount()][this.getColsCount()];

        for (int i = 0; i < this.getRowsCount(); i++) {
            for (int j = 0; j < this.getColsCount(); j++) {
                result[i][j] = this.get(i, j);
            }
        }
        return result;
    }

    /**
     * @throws RuntimeException if {@code this} matrix does not have only one row
     * or column
     */
    @Override
    public IVector toVector(boolean liveView) {
        if (this.getColsCount() != 1 && this.getRowsCount() != 1) {
        	throw new RuntimeException("Matrix does not represent a vector.");
        }

        if (liveView) {
        	return new VectorMatrixView(this);
        }
        else {
        	return new VectorMatrixView(this.copy());
        }
    }
    
    @Override
	public IMatrix nScalarMultiply(double value) {
		return this.copy().scalarMultiply(value);
	}

	@Override
	public IMatrix scalarMultiply(double value) {
		for (int i = 0; i < this.getRowsCount(); i++) {
        	for (int j = 0; j < this.getColsCount(); j++) {
        		this.set(i, j, value*this.get(i, j));
        	}
        }
        
        return this;
	}

	/**
	 * @throws RuntimeException if {@code this} matrix is not square
	 */
	@Override
	public IMatrix makeIdentity() {
		if(this.getRowsCount() != this.getColsCount()) {
			throw new RuntimeException("Matrix must be square.");
		}
		
		for(int i = 0; i < this.getRowsCount(); i++) {
			for(int j = 0; j < this.getColsCount(); j++) {
				if(i == j) {
					this.set(i, j, 1.0);
				}
				else {
					this.set(i, j, 0.0);
				}
			}
		}
		
		return this;
	}

    @Override
    public String toString() {
        return toString(3);
    }

    /**
     * Returns the string representation of <code>this</code> matrix where the numbers
     * are of specified precision.
     * @param precision the decimal number precision, after the comma
     * @return the string representation of <code>this</code> matrix
     * @throws IllegalArgumentException if the precision is less than 1
     */
    public String toString(int precision) {
    	if(precision < 1) {
    		throw new IllegalArgumentException("Invalid precision.");
    	}
    	
        String result = "";
        String specifier = String.format("%%.%df", precision);
        for (int i = 0; i < this.getRowsCount(); i++) {
            String temp = "[";
            for (int j = 0; j < this.getColsCount(); j++) {
                temp += String.format(specifier, this.get(i, j));
                if (j != this.getColsCount() - 1) temp += ", ";
            }
            temp += "]";
            result += temp + "\n";
        }
        
        return result;
    }
    
    @Override
    public boolean equals(Object obj) {
    	if(obj == null) return false;
    	if(this == obj) return true;
    	if(obj instanceof IMatrix) {
    		IMatrix matrix = (IMatrix)obj;
    		if(this.getColsCount() != matrix.getColsCount()) return false;
    		if(this.getRowsCount() != matrix.getRowsCount()) return false;
    		for(int i = 0; i < this.getRowsCount(); i++) {
    			for(int j = 0; j < this.getColsCount(); j++) {
    				if(this.get(i, j) != matrix.get(i, j)) return false;
    			}
    		}
    		return true;
    	}
    	return false;
    }

}
