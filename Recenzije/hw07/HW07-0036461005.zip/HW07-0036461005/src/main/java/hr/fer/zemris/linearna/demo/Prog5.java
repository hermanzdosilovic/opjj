package hr.fer.zemris.linearna.demo;

import hr.fer.zemris.linearna.IVector;
import hr.fer.zemris.linearna.Vector;

/**
 * This is an example program taken from the laboratory exercise on the course Interactive Computer Graphics.
 * This is the example 1.2.4
 * 
 * @see <a href="http://java.zemris.fer.hr/nastava/irg/labosi-0.1.2013-03-15.pdf">IRG lab exercise/</a>
 * @author Kristian
 */
public class Prog5 {

	/**
	 * The main method for this program.
	 * @param args command line arguments - not used
	 */
	public static void main(String[] args) {
		IVector n = Vector.parseSimple("3 3");
        IVector m = Vector.parseSimple("2 3");
        
        IVector k = n.nNormalize().scalarMultiply(n.cosine(m) * m.norm());
        IVector p = k.nSub(m);
        IVector r2 = m.nAdd(p.scalarMultiply(2.0));
        
        System.out.println(r2);
	}
	
}
