package hr.fer.zemris.linearna.demo;

import hr.fer.zemris.linearna.IMatrix;
import hr.fer.zemris.linearna.Matrix;

/**
 * This is an example program taken from the laboratory exercise on the course Interactive Computer Graphics.
 * This is the example 1.2.3
 * 
 * @see <a href="http://java.zemris.fer.hr/nastava/irg/labosi-0.1.2013-03-15.pdf">IRG lab exercise/</a>
 * @author Kristian
 */
public class Prog4 {

	/**
	 * The main method for this program.
	 * @param args command line arguments - not used
	 */
	public static void main(String[] args) {
		IMatrix a3 = Matrix.parseSimple("1 5 3|0 0 8|1 1 1");
        IMatrix r1 = Matrix.parseSimple("3|4|1");
        
        IMatrix v1 = a3.nInvert().nMultiply(r1);
        
        System.out.println("Rjesenje sustava je:");
        System.out.println(v1);
	}
	
}
