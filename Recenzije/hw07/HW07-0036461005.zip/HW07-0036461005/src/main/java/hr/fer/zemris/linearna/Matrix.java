package hr.fer.zemris.linearna;

/**
 * This class represents a matrix of double precision values with any number
 * of rows and columns. It implements all methods from the {@link IMatrix} interface.
 * <p>The elements of this matrix are conatined in an two-dimensional array of doubles.
 * 
 * @see IMatrix
 * @see AbstractMatrix
 * @author Kristian
 */
public class Matrix extends AbstractMatrix {

	/**
	 * Contains the matrix elements.
	 */
	private double[][] elements;
	
	/**
	 * Number of rows.
	 */
    private int rows;
	
    /**
     * Number of columns.
     */
    private int columns;

    /**
     * Creates a new {@link Matrix} instance with the specified row and 
     * column count. All values are initialized to <code>0.0d</code>.
     * @param rows the number of rows the created matrix will have, must be
     * larger than zero
     * @param columns the number of columns the created matrix will have, must
     * be larger than zero
     * @throws IllegalArgumentException if the specified number of rows or
     * columns is less than or equal to zero
     */
    public Matrix(int rows, int columns) {
    	if(rows <= 0 || columns <= 0) {
    		throw new IllegalArgumentException("Invalid row/column count. Must be positive.");
    	}
    	
        this.rows = rows;
        this.columns = columns;
        this.elements = new double[rows][columns];
    }
    
    /**
     * Creates a new {@link Matrix} instance with the specified row and column count, and
     * the initial values.
     * @param rows rows the number of rows the created matrix will have, must be
     * larger than zero
     * @param columns columns the number of columns the created matrix will have, must
     * be larger than zero
     * @param values the initial matrix values
     * @param liveView should the created matrix be modifieable or not
     * @throws IllegalArgumentException if the specified number of rows or
     * columns is less than or equal to zero or if the specified {@code values} array
     * is not of the same dimensions as the specified rows and columns count, or if the
     * specified values is {@code null}
     */
    public Matrix(int rows, int columns, double[][] values, boolean liveView) {
    	if(rows <= 0 || columns <= 0) {
    		throw new IllegalArgumentException("Invalid row/column count. Must be positive.");
    	}
    	if(values == null) {
    		throw new IllegalArgumentException("Null arguments not allowed.");
    	}
    	if(values.length != rows) {
    		throw new IllegalArgumentException("The specified number of rows does not match the specifed number of values");
    	}
    	// Check the arrays of columns
    	for(int i = 0; i < values.length; i++) {
    		if(values[i].length != columns) {
    			throw new IllegalArgumentException("The specified number of columns does not match the specified number of values.");
    		}
    	}
    	
        this.rows = rows;
        this.columns = columns;
        if (liveView) {
        	this.elements = values;
        }
        else {
            this.elements = new double[rows][columns];
            for (int i = 0; i < rows; i++) {
            	for (int j = 0; j < columns; j++) {
            		this.elements[i][j] = values[i][j];
            	}
            }
                
        }
    }

    @Override
    public int getRowsCount() {
        return this.rows;
    }

    @Override
    public int getColsCount() {
        return this.columns;
    }

    /**
     * @throws IndexOutOfBoundsException if the specified row or column is out
     * of bounds
     */
    @Override
    public double get(int row, int column) {
    	if(row < 0 || row >= this.rows) {
    		throw new IndexOutOfBoundsException("Specified row is out of bounds: " + row);
    	}
    	if(column < 0 || column >= this.columns) {
    		throw new IndexOutOfBoundsException("Specified column is out of bounds: " + column);
    	}
    	
        return this.elements[row][column];
    }

    /**
     * @throws IndexOutOfBoundsException if the specified row or column is out
     * of bounds
     */
    @Override
    public IMatrix set(int row, int column, double value) {
    	if(row < 0 || row >= this.rows) {
    		throw new IndexOutOfBoundsException("Specified row is out of bounds: " + row);
    	}
    	if(column < 0 || column >= this.columns) {
    		throw new IndexOutOfBoundsException("Specified column is out of bounds: " + column);
    	}
    	
        this.elements[row][column] = value;
        return this;
    }

    @Override
    public IMatrix copy() {
        IMatrix result = newInstance(this.rows, this.columns);
        for (int i = 0; i < this.rows; i++) {
        	for (int j = 0; j < this.columns; j++) {
        		result.set(i, j, this.get(i, j));
        	}
        }
        
        return result;
    }

    /**
     * @throws IllegalArgumentException if the specified number of rows or columns is less than or equal to zero
     */
    @Override
    public IMatrix newInstance(int r, int c) {
        return new Matrix(r, c);
    }

    /**
     * Parses the specified matrix string representation into a new {@link Matrix} instance if
     * valid.
     * <pre>
     * Examples:
     * "1 2 3 | 4 5 6" - matrix with 2 rows and 3 columns
     * "2" - matrix with 1 row and 1 column
     * </pre>
     * @param input the matrix representation
     * @return a new {@link Matrix} instance parsed from the specified string matrix representation
     * @throws IllegalArgumentException if the specified input is {@code null} or is not in correct
     * format
     */
    public static Matrix parseSimple(String input) {
    	if(input == null) {
    		throw new IllegalArgumentException("Null arguments not allowed.");
		}
    	
        String[] rows = input.split("\\|");
        for (int i = 0; i < rows.length; i++) {
        	rows[i] = rows[i].trim();
        }
        
        String[][] values = new String[rows.length][];
        int cols = 0;
        for (int i = 0; i < rows.length; i++) {
            String[] strValues = rows[i].split("\\s+");
            values[i] = strValues;
            if(cols != 0 && strValues.length != cols) {
            	throw new IllegalArgumentException("Specified string is not in correct format.");
            }
            
            cols = strValues.length;
        }

        double[][] newValues = new double[rows.length][cols];
        for (int i = 0; i < rows.length; i++) {
        	for (int j = 0; j < cols; j++) {
        		newValues[i][j] = Double.parseDouble(values[i][j]);
        	}
        }

        return new Matrix(rows.length, cols, newValues, false);
    }
	
}
