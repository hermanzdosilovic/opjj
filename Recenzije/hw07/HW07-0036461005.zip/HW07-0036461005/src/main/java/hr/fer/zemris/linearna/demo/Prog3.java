package hr.fer.zemris.linearna.demo;

import hr.fer.zemris.linearna.IMatrix;
import hr.fer.zemris.linearna.Matrix;

/**
 * This is an example program taken from the laboratory exercise on the course Interactive Computer Graphics.
 * This is the example 1.2.2
 * 
 * @see <a href="http://java.zemris.fer.hr/nastava/irg/labosi-0.1.2013-03-15.pdf">IRG lab exercise/</a>
 * @author Kristian
 */
public class Prog3 {

	/**
	 * The main method for this program.
	 * @param args command line arguments - not used
	 */
	public static void main(String[] args) {
		IMatrix a = Matrix.parseSimple("3 5 | 2 10");
		IMatrix r = Matrix.parseSimple("2 | 8");
		
		IMatrix v = a.nInvert().nMultiply(r);
		
		System.out.println("Rjesenje sustava je: ");
		System.out.println(v);
	}
	
}
