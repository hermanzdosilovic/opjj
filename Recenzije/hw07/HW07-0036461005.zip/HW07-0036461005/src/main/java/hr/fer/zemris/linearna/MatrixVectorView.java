package hr.fer.zemris.linearna;

/**
 * Represents a matrix with only one row or column and is a live view of a vector.
 * When the values of {@code this} matrix view changes, the change is visible in the
 * vector from which this matrix is created.
 * 
 * @author Kristian
 */
public class MatrixVectorView extends AbstractMatrix {

	/**
	 * The original vector.
	 */
	private IVector vector;
	
	/**
	 * Will be {@code true} if this is a one-row matrix, otherwise it is a one-column matrix.
	 */
    private boolean asRowMatrix;

    /**
     * Creates a new {@link MatrixVectorView} instance which represents a {@link IVector} as
     * a matrix.
     * @param v the vector which is represented
     * @param asRowMatrix is the created matrix a row matrix or a column matrix
     * @throws IllegalArgumentException if the specified vector is {@code null}
     */
    public MatrixVectorView(IVector v, boolean asRowMatrix) {
    	if(v == null) {
    		throw new IllegalArgumentException("Null arguments not allowed.");
    	}
    	
        this.vector = v;
        this.asRowMatrix = asRowMatrix;
    }

    @Override
    public int getRowsCount() {
        if (this.asRowMatrix) {
        	return 1;
        }
        else {
        	return this.vector.getDimension();
        }
    }

    @Override
    public int getColsCount() {
        if (this.asRowMatrix) {
        	return this.vector.getDimension();
        }
        else {
        	return 1;
        }
    }

    /**
     * @throws IndexOutOfBoundsException if this is a row matrix and the specified row is different than 0, or
     * if the matrix is a column matrix and the column is different than 0, or if any of the other specified
     * indexes is out of bounds
     */
    @Override
    public double get(int row, int column) {
        if (this.asRowMatrix) {
            if(row != 0) {
            	throw new IndexOutOfBoundsException("Specified row is out of bounds: " + row);
            }
            if(column < 0 || column >= this.vector.getDimension()) {
            	throw new IndexOutOfBoundsException("Specified column is out of bounds: " + column);
            }
            return this.vector.get(column);
        }
        else {
            if (column != 0) {
            	throw new IndexOutOfBoundsException("Specified column is out of bounds: " + column);
            }
            if(row < 0 || row >= this.vector.getDimension()) {
            	throw new IndexOutOfBoundsException("Specified row is out of bounds: " + row);
            }
            return this.vector.get(row);
        }
    }

    /**
     * @throws IndexOutOfBoundsException if this is a row matrix and the specified row is different than 0, or
     * if the matrix is a column matrix and the column is different than 0, or if any of the other specified
     * indexes is out of bounds
     * @throws UnmodifiableObjectException if the vector of which this view is created is unmodifiable
     */
    @Override
    public IMatrix set(int row, int column, double value) {
        if (this.asRowMatrix) {
        	if(row != 0) {
            	throw new IndexOutOfBoundsException("Specified row is out of bounds: " + row);
            }
            if(column < 0 || column >= this.vector.getDimension()) {
            	throw new IndexOutOfBoundsException("Specified column is out of bounds: " + column);
            }
            this.vector.set(column, value);
        }
        else {
        	if (column != 0) {
            	throw new IndexOutOfBoundsException("Specified column is out of bounds: " + column);
            }
            if(row < 0 || row >= this.vector.getDimension()) {
            	throw new IndexOutOfBoundsException("Specified row is out of bounds: " + row);
            }
            this.vector.set(row, value);
        }

        return this;
    }

    @Override
    public IMatrix copy() {
        IMatrix result;

        if (this.asRowMatrix) {
            result = newInstance(1, this.vector.getDimension());
            for (int i = 0; i < this.vector.getDimension(); i++) {
            	result.set(1, i, this.vector.get(i));
            }
        }
        else {
            result = newInstance(this.vector.getDimension(), 1);
            for (int i = 0; i < this.vector.getDimension(); i++) {
            	result.set(i, 1, this.vector.get(i));
            }
        }
        
        return result;
    }

    /**
     * @throws IllegalArgumentException if the specified number of rows or
     * columns is less than or equal to zero
     */
    @Override
    public IMatrix newInstance(int rows, int columns) {
    	return LinAlgDefaults.defaultMatrix(rows, columns);
    }
    
}
