package hr.fer.zemris.linearna;

/**
 * This abstract vector implements the {@link IVector} interface and
 * most of it's functionality where the value storage details are left
 * to the inheriting classes. 
 * <p>This vector implementation supports starndard linear algebra operations like
 * addition, subtraction, scalar multiplication, scalar product, vector product etc.
 * 
 * @author Kristian
 */
public abstract class AbstractVector implements IVector {

	@Override
	public abstract double get(int index);
	
	@Override
    public abstract IVector set(int index, double value);
	
	@Override
    public abstract int getDimension();
	
	@Override
    public abstract IVector copy();
	
	@Override
    public abstract IVector newInstance(int dimension);

	/**
	 * @throws IllegalArgumentException if the specified number is not positive.
	 */
	@Override
    public IVector copyPart(int numberFromStart) {
		if(numberFromStart <= 0) {
			throw new IllegalArgumentException("Specified number is invalid. Should be positive: " + numberFromStart);
		}
		
        IVector v = newInstance(numberFromStart);
        int j;
        if (numberFromStart > this.getDimension()) {
        	j = this.getDimension();
        }
        else {
        	j = numberFromStart;
        }
        for (int i = 0; i < j; i++) {
        	v.set(i, this.get(i));
        }
        return v;
    }

	/**
	 * @throws IncompatibleOperandException if {@code this} verctor and the specified vector
	 * are not of same dimension
	 * @throws IllegalArgumentException if the specified vector is {@code null}
	 * @throws UnmodifiableObjectException if {@code this} vector is unmodifieable
	 */
	@Override
    public IVector add(IVector v) {
		if(v == null) {
			throw new IllegalArgumentException("Null arguments not allowed.");
		}
        if(this.getDimension() != v.getDimension()) {
        	throw new IncompatibleOperandException("Vectors need to be same dimension.");
        }

        for (int i = 0; i < this.getDimension(); i++) {
        	this.set(i, this.get(i) + v.get(i));
        }
        
        return this;
    }

	/**
	 * @throws IncompatibleOperandException if {@code this} verctor and the specified vector
	 * are not of same dimension
	 * @throws IllegalArgumentException if the specified vector is {@code null}
	 */
	@Override
    public IVector nAdd(IVector v) {
        return this.copy().add(v);
    }

	/**
	 * @throws IncompatibleOperandException if {@code this} verctor and the specified vector
	 * are not of same dimension
	 * @throws IllegalArgumentException if the specified vector is {@code null}
	 * @throws UnmodifiableObjectException if {@code this} vector is unmodifieable
	 */
	@Override
    public IVector sub(IVector v) {
		if(v == null) {
			throw new IllegalArgumentException("Null arguments not allowed.");
		}
        if(this.getDimension() != v.getDimension()) {
        	throw new IncompatibleOperandException("Vectors need to be same dimension.");
        }
        
        for (int i = 0; i < this.getDimension(); i++) {
        	this.set(i, this.get(i) - v.get(i));
        }
        
        return this;
    }

	/**
	 * @throws IncompatibleOperandException if {@code this} verctor and the specified vector
	 * are not of same dimension
	 * @throws IllegalArgumentException if the specified vector is {@code null}
	 */
	@Override
    public IVector nSub(IVector v) {
        return this.copy().sub(v);
    }

	/**
	 * @throws UnmodifiableObjectException if {@code this} vector is unmodifieable
	 */
	@Override
    public IVector scalarMultiply(double value) {
        for (int i = 0; i < this.getDimension(); i++) {
            this.set(i, this.get(i)*value);
        }
        
        return this;
    }

	@Override
    public IVector nScalarMultiply(double value) {
        return this.copy().scalarMultiply(value);
    }

	@Override
    public double norm() {
        double temp = 0;
        for (int i = 0; i < this.getDimension(); i++) {
            double comp = this.get(i);
            temp += comp*comp;
        }
        return Math.sqrt(temp);
    }

	/**
	 * @throws UnmodifiableObjectException if {@code this} vector is unmodifieable
	 */
	@Override
    public IVector normalize() {
        double norm = this.norm();
        for (int i = 0; i < this.getDimension(); i++) {
            this.set(i, this.get(i) / norm);
        }
        
        return this;
    }

	@Override
    public IVector nNormalize() {
        return this.copy().normalize();
    }

	/**
	 * @throws IncompatibleOperandException if the vectors are of different dimensions
	 */
	@Override
    public double cosine(IVector v) {
		
        return this.scalarProduct(v) / (this.norm() * v.norm());
    }

	/**
	 * @throws IncompatibleOperandException if {@code this} verctor and the specified vector
	 * are not of same dimension
	 * @throws IllegalArgumentException if the specified vector is {@code null}
	 */
	@Override
    public double scalarProduct(IVector v) {
		if(v == null) {
			throw new IllegalArgumentException("Null arguments not allowed.");
		}
        if(this.getDimension() != v.getDimension()) {
        	throw new IncompatibleOperandException("Vectors need to be same dimension.");
        }

        double result = 0.0;
        for (int i = 0; i < this.getDimension(); i++) {
        	result += this.get(i)*v.get(i);
        }
        return result;
    }

	/**
	 * This method calculates and returns a new vector which is the cross product
	 * of {@code this} and the specified vector. The cross product can be calculated only
	 * on vectors which are of maximum dimension 3.
	 * @throws IncompatibleOperandException if {@code this} verctor and the specified vector
	 * are not of same dimension
	 * @throws IllegalArgumentException if the specified vector is {@code null}
	 */
	@Override
    public IVector nVectorProduct(IVector v) {
		if(v == null) {
			throw new IllegalArgumentException("Null arguments not allowed.");
		}
        if(v.getDimension() > 3 || this.getDimension() > 3) {
        	throw new IncompatibleOperandException("Can't calculate cross product. Max supported dimension is 3.");
        }
        if(v.getDimension() != this.getDimension()) {
        	throw new IncompatibleOperandException("Can't calculate cross product on vectors of different dimension.");
        }
        
        IVector result = newInstance(3);
        double[] a = this.copyPart(3).toArray();
        double[] b = v.copyPart(3).toArray();
        result.set(0, a[1]*b[2] - a[2]*b[1]);
        result.set(1, a[2]*b[0] - a[0]*b[2]);
        result.set(2, a[0]*b[1] - a[1]*b[0]);

        return result;
    }

	@Override
    public IVector nFromHomogeneus() {
        int dimension = this.getDimension();
        IVector newVector = this.copyPart(dimension - 1);
        double last = this.get(dimension - 1);
        return newVector.scalarMultiply(1 / last);
    }

	@Override
    public IMatrix toRowMatrix(boolean liveView) {
        if (liveView) {
        	return new MatrixVectorView(this, true);
        }
        else {
        	return new MatrixVectorView(this.copy(), true);
        }
    }

	@Override
    public IMatrix toColumnMatrix(boolean liveView) {
        if (liveView) {
        	return new MatrixVectorView(this, false);
        }
        else {
        	return new MatrixVectorView(this.copy(), false);
        }
    }

	@Override
    public double[] toArray() {
        double[] result = new double[this.getDimension()];
        for (int i = 0; i < this.getDimension(); i++) {
        	result[i] = this.get(i);
        }
        return result;
    }

	@Override
    public String toString() {
        return toString(3);
    }

	/**
     * Returns the string representation of <code>this</code> vector where the numbers
     * are of specified precision.
     * @param precision the decimal number precision, after the comma
     * @return the string representation of <code>this</code> vector
     * @throws IllegalArgumentException if the precision is less than 1
     */
    public String toString(int precision) {
    	if(precision < 1) {
    		throw new IllegalArgumentException("Invalid precision.");
    	}
    	
        String result = "[";
        String specifier = String.format("%%.%df", precision);
        for (int i = 0; i < this.getDimension(); i++) {
            result += String.format(specifier, this.get(i));
            if (i != this.getDimension() - 1) {
            	result += " ";
            }
        }
        result += "]";
        
        return result;
    }
    
    @Override
    public boolean equals(Object obj) {
    	if(obj == null) return false;
    	if(this == obj) return true;
    	if(obj instanceof IVector) {
    		IVector vector = (IVector) obj;
    		if(this.getDimension() != vector.getDimension()) return false;
    		for(int i = 0; i < this.getDimension(); i++) {
    			if(Math.abs(this.get(i) - vector.get(i)) > 1E-6) return false;
    		}
    		return true;
    	}
    	return false;
    }
	
}
