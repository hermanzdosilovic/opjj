package hr.fer.zemris.linearna;

import static org.junit.Assert.*;

import org.junit.Test;

/**
 * Test cases for class {@link VectorMatrixView}
 * 
 * @author Kristian
 */
public class VectorMatrixViewTest {

	@Test(expected=IllegalArgumentException.class)
	public void testVectorMatrixViewException() {
		new VectorMatrixView(null);
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void testVectorMatrixViewDimensionException() {
		new VectorMatrixView(Matrix.parseSimple("1 2 3 | 4 5 6"));
	}
	
	@Test
	public void testVectorMatrixViewRowMatrix() {
		IVector vector = new VectorMatrixView(Matrix.parseSimple("1 2 3"));
		assertEquals("Vector should be created successfully", new Vector(1,2,3), vector);
	}
	
	@Test
	public void testVectorMatrixViewColumnMatrix() {
		IVector vector = new VectorMatrixView(Matrix.parseSimple("1 | 2 | 3"));
		assertEquals("Vector should be created successfully", new Vector(1,2,3), vector);
	}
	
	@Test(expected=IndexOutOfBoundsException.class)
	public void testGetSmallIndexException() {
		IVector vector = new VectorMatrixView(Matrix.parseSimple("1 2 3"));
		vector.get(-1);
	}
	
	@Test(expected=IndexOutOfBoundsException.class)
	public void testGetLargeIndexException() {
		IVector vector = new VectorMatrixView(Matrix.parseSimple("1 2 3"));
		vector.get(5);
	}
	
	@Test
	public void testGet() {
		IVector vectorFromRow = new VectorMatrixView(Matrix.parseSimple("1 2 3"));
		IVector vectorFromColumn = new VectorMatrixView(Matrix.parseSimple("1 | 2 | 3"));
		
		assertEquals("Value on index 1 created from row matrix should be 2", 2, vectorFromRow.get(1), 1E-6);
		assertEquals("Value on index 1 created from column matrix should be 2", 2, vectorFromColumn.get(1), 1E-6);
	}
	
	@Test(expected=IndexOutOfBoundsException.class)
	public void testSetSmallIndexException() {
		IVector vector = new VectorMatrixView(Matrix.parseSimple("1 2 3"));
		vector.set(-1, 4);
	}
	
	@Test(expected=IndexOutOfBoundsException.class)
	public void testSetLargeIndexException() {
		IVector vector = new VectorMatrixView(Matrix.parseSimple("1 2 3"));
		vector.set(5, 4);
	}

	@Test
	public void testSet() {
		IVector vectorFromRow = new VectorMatrixView(Matrix.parseSimple("1 2 3"));
		IVector vectorFromColumn = new VectorMatrixView(Matrix.parseSimple("1 | 2 | 3"));
		
		vectorFromRow.set(1, 4);
		vectorFromColumn.set(1, 4);
		
		assertEquals("Value on index 1 created from row matrix should be 4", 4, vectorFromRow.get(1), 1E-6);
		assertEquals("Value on index 1 created from column matrix should be 4", 4, vectorFromColumn.get(1), 1E-6);
	}

	@Test
	public void testGetDimension() {
		IVector vector = new VectorMatrixView(Matrix.parseSimple("1 2 3"));
		assertEquals("Dimension of created vector view should be 3", 3, vector.getDimension());
	}

	@Test
	public void testCopy() {
		IVector vector = new VectorMatrixView(Matrix.parseSimple("1 2 3"));
		IVector copy = vector.copy();
		assertFalse("The copied reference should be different", vector == copy);
		assertEquals("The copied values should be same", new Vector(1, 2, 3), copy);
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void testNewInstanceException() {
		IVector vector = new VectorMatrixView(Matrix.parseSimple("1 2 3"));
		vector.newInstance(-1);
	}

	@Test
	public void testNewInstance() {
		IVector vector = new VectorMatrixView(Matrix.parseSimple("1 2 3"));
		IVector newInstance = vector.newInstance(5);
		assertEquals("Dimension of new instance should be 5", 5, newInstance.getDimension());
		// Test if values are 0.0
		assertEquals("All values should be 0.0", new Vector(0,0,0,0,0), newInstance);
	}

}
