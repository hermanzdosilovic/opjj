package hr.fer.zemris.linearna;

import static org.junit.Assert.*;

import org.junit.Test;

/**
 * Test cases for class {@link AbstractVector}
 * 
 * @author Kristian
 */
public class AbstractVectorTest {

	@Test(expected=IllegalArgumentException.class)
	public void testCopyPartException() {
		IVector vector = new Vector(1, 2, 3);
		vector.copyPart(-1);
	}
	
	@Test
	public void testCopyPart() {
		IVector vector = new Vector(1, 2, 3);
		assertEquals("Copied part of 2 elements should return vector [1 2]", new Vector(1, 2), vector.copyPart(2));
	}
	
	@Test
	public void testCopyPartLarger() {
		IVector vector = new Vector(1, 2, 3);
		assertEquals("Copied part of 5 elements should return vector [1 2 3 0 0]", new Vector(1, 2, 3, 0, 0), vector.copyPart(5));
	}

	@Test(expected=IllegalArgumentException.class)
	public void testAddNullException() {
		(new Vector(1,2,3)).add(null);
	}
	
	@Test(expected=IncompatibleOperandException.class)
	public void testAddIncompatibleException() {
		(new Vector(1,2,3)).add(new Vector(1, 2));
	}
	
	@Test
	public void testAdd() {
		IVector vector1 = new Vector(1,2,3);
		IVector vector2 = new Vector(2,3,4);
		IVector result = vector1.add(vector2);
		assertEquals("Addition of [1 2 3] and [2 3 4] should be [3 5 7]", new Vector(3,5,7), result);
		assertTrue("References should be same", vector1 == result);
	}

	@Test
	public void testNAdd() {
		IVector vector1 = new Vector(1,2,3);
		IVector vector2 = new Vector(2,3,4);
		IVector result = vector1.nAdd(vector2);
		assertEquals("Addition of [1 2 3] and [2 3 4] should be [3 5 7]", new Vector(3,5,7), result);
		assertFalse("References should be different", vector1 == result);
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void testSubNullException() {
		(new Vector(1,2,3)).sub(null);
	}
	
	@Test(expected=IncompatibleOperandException.class)
	public void testSubIncompatibleException() {
		(new Vector(1,2,3)).sub(new Vector(1, 2));
	}

	@Test
	public void testSub() {
		IVector vector1 = new Vector(1,2,3);
		IVector vector2 = new Vector(2,3,4);
		IVector result = vector1.sub(vector2);
		assertEquals("Subtraction of [1 2 3] and [2 3 4] should be [-1 -1 -1]", new Vector(-1,-1,-1), result);
		assertTrue("References should be same", vector1 == result);
	}

	@Test
	public void testNSub() {
		IVector vector1 = new Vector(1,2,3);
		IVector vector2 = new Vector(2,3,4);
		IVector result = vector1.nSub(vector2);
		assertEquals("Subtraction of [1 2 3] and [2 3 4] should be [-1 -1 -1]", new Vector(-1,-1,-1), result);
		assertFalse("References should be different", vector1 == result);
	}

	@Test
	public void testScalarMultiply() {
		IVector vector = new Vector(1,2,3);
		IVector result = vector.scalarMultiply(3);
		assertEquals("Scalar multiplication of vector [1 2 3] with 3 should be [3 6 9]", new Vector(3,6,9), result);
		assertTrue("References should be same", vector == result);
	}

	@Test
	public void testNScalarMultiply() {
		IVector vector = new Vector(1,2,3);
		IVector result = vector.nScalarMultiply(3);
		assertEquals("Scalar multiplication of vector [1 2 3] with 3 should be [3 6 9]", new Vector(3,6,9), result);
		assertFalse("References should be different", vector == result);
	}

	@Test
	public void testNorm() {
		IVector vector = new Vector(1,2,3);
		double norm = vector.norm();
		assertEquals("Norm of vector [1 2 3] should be 3.741", 3.741, norm, 1E-3);
	}

	@Test
	public void testNormalize() {
		IVector vector = new Vector(3,3,3);
		IVector result = vector.normalize();
		assertEquals("Normalized vector of [3 3 3] should be [0.577 0.577 0.577]", new Vector(0.577350, 0.577350, 0.577350), result);
		assertTrue("References should be same", vector == result);
	}

	@Test
	public void testNNormalize() {
		IVector vector = new Vector(3,3,3);
		IVector result = vector.nNormalize();
		assertEquals("Normalized vector of [3 3 3] should be [0.577 0.577 0.577]", new Vector(0.577350, 0.577350, 0.577350), result);
		assertFalse("References should be different", vector == result);
	}

	@Test
	public void testCosine() {
		IVector vector1 = new Vector(1,2,3);
		IVector vector2 = new Vector(1,4,0);
		double cosine = vector1.cosine(vector2);
		assertEquals("The cosine between vectors [1 2 3] and [1 4 0] should be 0.583", 0.583, cosine, 1E-3);
	}

	@Test(expected=IllegalArgumentException.class)
	public void testScalarProductNullException() {
		(new Vector(1,2,3)).scalarProduct(null);
	}
	
	@Test(expected=IncompatibleOperandException.class)
	public void testScalarProductIncompatibleException() {
		IVector vector1 = new Vector(1,2,3);
		IVector vector2 = new Vector(4,5,6,7);
		vector1.scalarProduct(vector2);
	}
	
	@Test
	public void testScalarProduct() {
		IVector vector1 = new Vector(1,2,3);
		IVector vector2 = new Vector(4,5,6);
		double result = vector1.scalarProduct(vector2);
		assertEquals("Scalar product of [1 2 3] and [4 5 6] should be 32", 32, result, 1E-6);
	}

	@Test(expected=IllegalArgumentException.class)
	public void testNVectorProductNullException() {
		(new Vector(1,2,3)).nVectorProduct(null);
	}
	
	@Test(expected=IncompatibleOperandException.class)
	public void testNVectorProductIncompatibleException1() {
		(new Vector(1,2,3,4)).nVectorProduct(new Vector(1,2,3,4));
	}
	
	@Test(expected=IncompatibleOperandException.class)
	public void testNVectorProductIncompatibleException2() {
		(new Vector(1,2,3,4)).nVectorProduct(new Vector(1,2));
	}
	
	@Test(expected=IncompatibleOperandException.class)
	public void testNVectorProductIncompatibleException3() {
		(new Vector(1,2)).nVectorProduct(new Vector(1,2,3,4));
	}
	
	@Test(expected=IncompatibleOperandException.class)
	public void testNVectorProductIncompatibleException4() {
		(new Vector(1,2)).nVectorProduct(new Vector(1,2,3));
	}
	
	@Test
	public void testNVectorProduct() {
		IVector vector1 = new Vector(1,2,3);
		IVector vector2 = new Vector(1,0,1);
		IVector result = vector1.nVectorProduct(vector2);
		assertEquals("Vector product of [1 2 3] and [1 0 1] should be [2 2 -2]", new Vector(2,2,-2), result);
		assertFalse("References should be different", vector1 == result);
	}

	@Test
	public void testNFromHomogeneus() {
		IVector vector = new Vector(1,3,7,2);
		IVector result = vector.nFromHomogeneus();
		assertEquals(new Vector(0.5, 1.5, 3.5), result);
		assertFalse("References should be different", vector == result);
	}

	@Test
	public void testToRowMatrix() {
		IVector vector = new Vector(1,2,3);
		IMatrix expected = Matrix.parseSimple("1 2 3");
		IMatrix result = vector.toRowMatrix(false);
		assertEquals("Expected matrix [1 2 3]", expected, result);
		// Test if live
		vector.set(0, 4);
		assertEquals("Expected matrix [1 2 3] should not change after setting vector.", expected, result);
	}
	
	@Test
	public void testToRowMatrixLiveView() {
		IVector vector = new Vector(1,2,3);
		IMatrix expected = Matrix.parseSimple("1 2 3");
		IMatrix result = vector.toRowMatrix(true);
		assertEquals("Expected matrix [1 2 3]", expected, result);
		// Test if live
		vector.set(0, 4);
		expected = Matrix.parseSimple("4 2 3");
		assertEquals("Expected matrix [4 2 3] should change after setting vector.", expected, result);
	}

	@Test
	public void testToColumnMatrix() {
		IVector vector = new Vector(1,2,3);
		IMatrix expected = Matrix.parseSimple("1 | 2 | 3");
		IMatrix result = vector.toColumnMatrix(false);
		assertEquals("Expected matrix [1 | 2 | 3]", expected, result);
		// Test if live
		vector.set(0, 4);
		assertEquals("Expected matrix [1 | 2 | 3] should not change after setting vector.", expected, result);
	}
	
	@Test
	public void testToColumnMatrixLiveView() {
		IVector vector = new Vector(1,2,3);
		IMatrix expected = Matrix.parseSimple("1 | 2 | 3");
		IMatrix result = vector.toColumnMatrix(true);
		assertEquals("Expected matrix [1 | 2 | 3]", expected, result);
		// Test if live
		vector.set(0, 4);
		expected = Matrix.parseSimple("4 | 2 | 3");
		assertEquals("Expected matrix [4 | 2 | 3] should change after setting vector.", expected, result);
	}

	@Test
	public void testToArray() {
		IVector vector = new Vector(1,2,3);
		double[] array = vector.toArray();
		assertArrayEquals(new double[]{1,2,3}, array, 1E-6);
	}

	@Test
	public void testToString() {
		IVector vector = new Vector(1,2,3);
		String str = vector.toString();
		assertEquals("String representation of vector [1 2 3] should be [1.000 2.000 3.000]", "[1.000 2.000 3.000]", str);
	}

	@Test(expected=IllegalArgumentException.class)
	public void testToStringIntPrecisionException() {
		Vector vector = new Vector(1,2,3);
		vector.toString(-1);
	}
	
	@Test
	public void testToStringInt() {
		Vector vector = new Vector(1,2,3);
		String str = vector.toString(1);
		assertEquals("String representation of vector [1 2 3] should be [1.0 2.0 3.0]", "[1.0 2.0 3.0]", str);
	}

	@Test
	public void testEqualsObject() {
		IVector vector1 = new Vector(1,2,3);
		IVector vector2 = new Vector(1,2,3);
		IVector vector3 = new Vector(1,2,3,4);
		IVector vector4 = new Vector(1,3,3);
		String vector5 = "1 2 3";
		assertFalse("Null argument should result in false", vector1.equals(null));
		assertFalse("String argument should result in false", vector1.equals(vector5));
		assertTrue("Instances should result in true", vector1.equals(vector1));
		assertFalse("Instances should result in false", vector1.equals(vector3));
		assertTrue("Values should result in true", vector1.equals(vector2));
		assertFalse("Values should result in false", vector1.equals(vector3));
		assertFalse("Different values should result in false", vector1.equals(vector4));
	}

}
