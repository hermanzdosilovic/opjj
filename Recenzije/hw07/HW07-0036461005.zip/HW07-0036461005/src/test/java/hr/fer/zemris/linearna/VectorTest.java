package hr.fer.zemris.linearna;

import static org.junit.Assert.*;

import org.junit.Test;

/**
 * Test cases for class {@link Vector}.
 * 
 * @author Kristian
 */
public class VectorTest {

	@Test(expected=IllegalArgumentException.class)
	public void testVectorDoubleArrayNullException() {
		new Vector(null);
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void testVectorDoubleArrayEmptyException() {
		new Vector(new double[0]);
	}
	
	@Test
	public void testVectorDoubleArray() {
		IVector vector = new Vector(1, 2, 3);
		assertEquals("Value on index 0 should be 1.0", 1.0, vector.get(0), 1E-6);
		assertEquals("Value on index 1 should be 2.0", 2.0, vector.get(1), 1E-6);
		assertEquals("Value on index 2 should be 3.0", 3.0, vector.get(2), 1E-6);
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void testVectorBooleanBooleanDoubleArrayNullException() {
		new Vector(false, true, null);
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void testVectorBooleanBooleanDoubleArrayEmptyException() {
		new Vector(false, true, new double[0]);
	}

	@Test
	public void testVectorBooleanBooleanDoubleArrayChangeSafe() {
		IVector vector = new Vector(false, true, 1, 2, 3);
		assertEquals("Value on index 0 should be 1.0", 1.0, vector.get(0), 1E-6);
		assertEquals("Value on index 1 should be 2.0", 2.0, vector.get(1), 1E-6);
		assertEquals("Value on index 2 should be 3.0", 3.0, vector.get(2), 1E-6);
	}
	
	@Test
	public void testVectorBooleanBooleanDoubleArray() {
		IVector vector = new Vector(false, false, 1, 2, 3);
		assertEquals("Value on index 0 should be 1.0", 1.0, vector.get(0), 1E-6);
		assertEquals("Value on index 1 should be 2.0", 2.0, vector.get(1), 1E-6);
		assertEquals("Value on index 2 should be 3.0", 3.0, vector.get(2), 1E-6);
	}

	@Test(expected=IndexOutOfBoundsException.class)
	public void testGetSmallIndexException() {
		IVector vector = new Vector(1, 2, 3);
		vector.get(-1);
	}
	
	@Test(expected=IndexOutOfBoundsException.class)
	public void testGetLargeIndexException() {
		IVector vector = new Vector(1, 2, 3);
		vector.get(5);
	}
	
	@Test
	public void testGet() {
		IVector vector = new Vector(1, 2, 3);
		assertEquals("Value on index 1 should be 2.0", 2.0, vector.get(1), 1E-6);
	}

	@Test(expected=IndexOutOfBoundsException.class)
	public void testSetSmallIndexException() {
		IVector vector = new Vector(1, 2, 3);
		vector.set(-1, 4.0);
	}
	
	@Test(expected=IndexOutOfBoundsException.class)
	public void testSetLargeIndexException() {
		IVector vector = new Vector(1, 2, 3);
		vector.set(5, 4.0);
	}
	
	@Test(expected=UnmodifiableObjectException.class)
	public void testSetUnmodifiableException() {
		IVector vector = new Vector(true, true, 1, 2, 3);
		vector.set(0, 4.0);
	}
	
	@Test
	public void testSet() {
		IVector vector = new Vector(1, 2, 3);
		vector.set(0, 4);
		assertEquals("Value on index 0 after set should be 4.0", 4.0, vector.get(0), 1E-6);
	}

	@Test
	public void testGetDimension() {
		IVector vector = new Vector(1, 2, 3);
		assertEquals("Dimension should be 3", 3, vector.getDimension());
	}

	@Test
	public void testCopy() {
		IVector vector = new Vector(1, 2, 3);
		IVector copy = vector.copy();
		assertFalse("The copied reference should be different", vector == copy);
		assertEquals("The copied values should be same", new Vector(1, 2, 3), copy);
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void testNewInstanceException() {
		IVector vector = new Vector(1, 2, 3);
		vector.newInstance(-1);
	}

	@Test
	public void testNewInstance() {
		IVector vector = new Vector(1, 2, 3);
		IVector newInstance = vector.newInstance(5);
		assertEquals("Dimension of new instance should be 5", 5, newInstance.getDimension());
		// Test if values are 0.0
		assertEquals("All values should be 0.0", new Vector(0,0,0,0,0), newInstance);
	}

	@Test(expected=IllegalArgumentException.class)
	public void testParseSimpleNullException() {
		Vector.parseSimple(null);
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void testParseSimpleInvalidFormatException() {
		Vector.parseSimple("1, 2, 3");
	}
	
	@Test
	public void testParseSimple() {
		IVector vector = Vector.parseSimple("1 2 3");
		assertEquals("Expected vector with values 1, 2, 3", new Vector(1,2,3), vector);
	}

}
