package hr.fer.zemris.java.hw13.servleti;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@SuppressWarnings("serial")
@WebServlet("/glasanje-glasaj")
public class GlasanjeGlasajServlet extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// Zabiljezi glas...
		String reqId = (String)req.getParameter("id");
		String inputFileName = req.getServletContext().getRealPath("/WEB-INF/glasanje-rezultati.txt");
		String tempFileName = req.getServletContext().getRealPath("/WEB-INF/temp.txt");
		
		// Napravi datoteku ako je potrebno; ažuriraj podatke koji su u njoj...
		File inputFile = new File(inputFileName);
		boolean created = inputFile.createNewFile();
		if (created) System.out.println("File created");
		File tempFile = new File(tempFileName);
		
		BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(inputFile), StandardCharsets.UTF_8));
		BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(tempFile), StandardCharsets.UTF_8));
		
		String currentLine;
		boolean found = false;
		
		while((currentLine = reader.readLine()) != null) {
			String[] pieces = currentLine.split("\t");
			String id = pieces[0];
			String count = pieces[1];
			
			if (id.equals(reqId)) {
				count = String.valueOf((Integer.parseInt(count)+1));
				found = true;
			}
			
			writer.write(id + "\t" + count);
			writer.newLine();
		}
		
		if (!found) {
			writer.write(reqId + "\t" + "1");
			writer.newLine();
		}
		
		reader.close();
		writer.close();
		
		boolean deleted = inputFile.delete();
		if (deleted) System.out.println("File deleted");
		boolean renamed = tempFile.renameTo(inputFile);
		if (renamed) System.out.println("File renamed");
		
		// Kad je gotovo, pošalji redirect pregledniku
		resp.sendRedirect(req.getContextPath() + "/glasanje-rezultati");
	}
	
}
