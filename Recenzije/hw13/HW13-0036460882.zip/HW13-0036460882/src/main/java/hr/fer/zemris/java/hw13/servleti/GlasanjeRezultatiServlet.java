package hr.fer.zemris.java.hw13.servleti;

import hr.fer.zemris.java.hw13.beans.Band;
import hr.fer.zemris.java.hw13.helper.Helper;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@SuppressWarnings("serial")
@WebServlet("/glasanje-rezultati")
public class GlasanjeRezultatiServlet extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		Map<String, String> results = Helper.readResults(req);
		List<Band> bands = Helper.readBands(req);
		Helper.populateResultsForZeroVotes(bands, results);
		
		int maxVotes = 0;
		
		for (String result : results.values()) {
			if (Integer.parseInt(result) > maxVotes)
				maxVotes = Integer.parseInt(result);
		}
		
		req.setAttribute("bands", bands);
		req.setAttribute("results", results);
		req.setAttribute("maxVotes", String.valueOf(maxVotes));
		
		
		// Pošalji ih JSP-u...
		req.getRequestDispatcher("/WEB-INF/pages/glasanjeRez.jsp").forward(req, resp);
	}

}
