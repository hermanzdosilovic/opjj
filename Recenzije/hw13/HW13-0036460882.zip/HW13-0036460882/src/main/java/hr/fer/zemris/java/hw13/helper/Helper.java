package hr.fer.zemris.java.hw13.helper;

import hr.fer.zemris.java.hw13.beans.Band;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

public class Helper {

	public static Map<String, String> readResults(HttpServletRequest req) throws FileNotFoundException, IOException {
		String fileName = req.getServletContext().getRealPath("/WEB-INF/glasanje-rezultati.txt");
		File inputFile = new File(fileName);
		
		BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(inputFile), StandardCharsets.UTF_8));
		
		String currentLine;
		Map<String, String> results = new HashMap<>();
		
		while((currentLine = reader.readLine()) != null) {
			String[] pieces = currentLine.split("\t");
			String id = pieces[0];
			String count = pieces[1];
			results.put(id, count);
		}
		reader.close();
		return results;
	}
	
	public static List<Band> readBands(HttpServletRequest req) throws IOException {
		String definitionFileName = req.getServletContext().getRealPath("/WEB-INF/glasanje-definicija.txt");
		List<String> lines = Files.readAllLines(Paths.get(definitionFileName), StandardCharsets.UTF_8);
		List<Band> bands = new ArrayList<>();
		for (String line : lines) {
			String[] pieces = line.split("\t");
			String id = pieces[0];
			String name = pieces[1];
			String link = pieces[2];
			bands.add(new Band(id, name, link));
		}
		Collections.sort(bands);
		return bands;
	}
	
	public static void populateResultsForZeroVotes(List<Band> bands, Map<String, String> results) {
		for (Band band : bands) {
			if (!results.containsKey(band.id)) {
				results.put(band.id, "0");
			}
		}
	}
}
