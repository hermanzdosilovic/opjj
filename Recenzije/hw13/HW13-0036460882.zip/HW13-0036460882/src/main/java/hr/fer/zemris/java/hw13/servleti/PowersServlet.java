package hr.fer.zemris.java.hw13.servleti;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

@SuppressWarnings("serial")
@WebServlet("/powers")
public class PowersServlet extends HttpServlet{

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		Integer a = null;
		Integer b = null;
		Integer n = null;
		
		try {
			a = Integer.valueOf(req.getParameter("a"));
		} catch (Exception e) {
			req.getRequestDispatcher("/WEB-INF/pages/powersError.jsp?message=Parameter \"a\" is not provided or not a number.").forward(req, resp);
			return;
		}
		try {
			b = Integer.valueOf(req.getParameter("b"));
		} catch (Exception e) {
			req.getRequestDispatcher("/WEB-INF/pages/powersError.jsp?message=Parameter \"b\" is not provided or not a number.").forward(req, resp);
			return;
		}
		try {
			n = Integer.valueOf(req.getParameter("n"));
		} catch (Exception e) {
			req.getRequestDispatcher("/WEB-INF/pages/powersError.jsp?message=Parameter \"n\" is not provided or not a number.").forward(req, resp);
			return;
		}
		if (a<-100 || a>100) {
			req.getRequestDispatcher("/WEB-INF/pages/powersError.jsp?message=Invalid value for parameter A.").forward(req, resp);
			return;
		}
		if (b<-100 || b>100) {
			req.getRequestDispatcher("/WEB-INF/pages/powersError.jsp?message=Invalid value for parameter B.").forward(req, resp);
			return;
		}
		if (n<1 || n>5) {
			req.getRequestDispatcher("/WEB-INF/pages/powersError.jsp?message=Invalid value for parameter N.").forward(req, resp);
			return;
		}
		
		PrintWriter writer = resp.getWriter();
		writer.println("<p>Generated XLS files:</p>");
		writer.println("<ol>");
		for (int i=1; i<=n; i++) {
			String fname = "document"+i+".xls";
			String fullFileName= getServletContext().getRealPath(fname);
			File file = new File(fullFileName);
			
			HSSFWorkbook hwb=new HSSFWorkbook();
			HSSFSheet sheet =  hwb.createSheet("sheet " + i);
			
			for (int j = a, r = 0; j <= b; j++, r++) {
				HSSFRow row=   sheet.createRow((short)r);
				row.createCell((short) 0).setCellValue(j);
				row.createCell((short) 1).setCellValue(Math.pow(j, i));
			}
			
			FileOutputStream fileOut;
			try {
				fileOut = new FileOutputStream(file);
				hwb.write(fileOut);
				fileOut.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
			
			writer.println("<li><a href=\""+fname+"\">"+fname+"</p></li>");
		}
		writer.println("</ol>");
		writer.close();

	}
	
	
}
