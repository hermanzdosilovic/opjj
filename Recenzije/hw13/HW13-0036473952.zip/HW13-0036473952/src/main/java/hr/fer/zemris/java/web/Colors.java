package hr.fer.zemris.java.web;

import java.util.Arrays;
import java.util.List;
import java.util.Random;

public final class Colors {

  private static final Random random;

  private static final List<String> COLORS;

  static {
    random = new Random();

    COLORS = Arrays.asList(new String[] {"white", "red", "green", "cyan"});
  }

  private Colors() {
    super();
  }

  public static List<String> getColors() {
    return COLORS;
  }

  public static String getRandomColor() {
    return COLORS.get(random.nextInt(COLORS.size()));
  }

}
