package hr.fer.zemris.java.web.glasanje;

public class Votes implements Comparable<Votes> {

  private final int id;

  private final int number;

  public Votes(final int id) {
    super();

    this.id = id;
    number = 0;
  }

  public Votes(final int id, final int number) {
    super();

    this.id = id;
    this.number = number;
  }

  public int getId() {
    return id;
  }

  public int getNumber() {
    return number;
  }

  public Votes vote() {
    return new Votes(id, number + 1);
  }

  @Override
  public int compareTo(final Votes other) {
    return Integer.compare(id, other.id);
  }

  @Override
  public String toString() {
    return id + "\t" + number;
  }

  public static Votes parse(final String string) {
    final String[] parts = string.split("\\t");

    return new Votes(Integer.parseInt(parts[0]), Integer.parseInt(parts[1]));
  }
}
