package hr.fer.zemris.java.web.servlets;

import hr.fer.zemris.java.web.Colors;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@SuppressWarnings("serial")
@WebServlet(name = "setcolor", urlPatterns = {"/setcolor"})
public class SetColor extends HttpServlet {

  @Override
  protected void doGet(final HttpServletRequest request, final HttpServletResponse response) throws ServletException,
      IOException {
    final String color = request.getParameter("color");

    if (color != null && Colors.getColors().contains(color)) {
      request.getSession().setAttribute("pickedBgCol", color);
    }

    response.sendRedirect(request.getContextPath() + "/colors.jsp");
  }

}
