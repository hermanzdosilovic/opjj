package hr.fer.zemris.java.web.servlets;

import hr.fer.zemris.java.web.Colors;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@SuppressWarnings("serial")
@WebServlet(name = "funny", urlPatterns = {"/stories/funny.jsp"})
public class Funny extends HttpServlet {

  @Override
  protected void doGet(final HttpServletRequest req, final HttpServletResponse resp) throws ServletException,
      IOException {
    req.setAttribute("textColor", Colors.getRandomColor());

    req.getRequestDispatcher("/WEB-INF/pages/funny.jsp").forward(req, resp);
  }

}
