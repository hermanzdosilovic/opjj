package hr.fer.zemris.java.web.glasanje;

public class Band implements Comparable<Band> {

  private final int id;

  private final String name;

  private final String url;

  public Band(final int id, final String name, final String url) {
    super();

    this.id = id;
    this.name = name;
    this.url = url;
  }

  public int getId() {
    return id;
  }

  public String getName() {
    return name;
  }

  public String getUrl() {
    return url;
  }

  public Votes toVotes() {
    return new Votes(id);
  }

  @Override
  public int compareTo(final Band other) {
    return Integer.compare(id, other.id);
  }

  public static Band parse(final String string) {
    final String[] parts = string.split("\\t");

    return new Band(Integer.parseInt(parts[0]), parts[1], parts[2]);
  }

}
