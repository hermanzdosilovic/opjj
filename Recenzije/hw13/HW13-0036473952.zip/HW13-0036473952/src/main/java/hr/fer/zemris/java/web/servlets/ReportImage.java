package hr.fer.zemris.java.web.servlets;

import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PiePlot3D;
import org.jfree.data.general.DefaultPieDataset;

@SuppressWarnings("serial")
@WebServlet(name = "reportImage", urlPatterns = {"/reportImage"})
public class ReportImage extends HttpServlet {

  private static final int IMAGE_WIDTH = 600;

  private static final int IMAGE_HEIGHT = 400;

  private static final String IMAGE_TYPE = "png";

  @Override
  protected void doGet(final HttpServletRequest request, final HttpServletResponse response) throws ServletException,
      IOException {
    response.setContentType("image/" + IMAGE_TYPE);

    final DefaultPieDataset dataset = new DefaultPieDataset();

    dataset.setValue("Windows 7", 49.27);
    dataset.setValue("Windows XP", 26.29);
    dataset.setValue("Windows 8", 12.24);
    dataset.setValue("OS X", 7.63);
    dataset.setValue("Other", 3.66);
    dataset.setValue("Windows Vista", 2.89);
    dataset.setValue("Linux", 1.58);

    final JFreeChart chart = ChartFactory.createPieChart3D(null, dataset, true, false, false);

    final PiePlot3D plot = (PiePlot3D) chart.getPlot();
    plot.setForegroundAlpha(0.5f);

    final BufferedImage image = chart.createBufferedImage(IMAGE_WIDTH, IMAGE_HEIGHT);

    ImageIO.write(image, IMAGE_TYPE, response.getOutputStream());
  }

}
