package hr.fer.zemris.java.web.servlets.glasanje;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@SuppressWarnings("serial")
@WebServlet(name = "glasanje", urlPatterns = {"/glasanje"})
public class GlasanjeServlet extends HttpServlet {

  @Override
  protected void doGet(final HttpServletRequest request, final HttpServletResponse response) throws ServletException,
      IOException {
    request.getRequestDispatcher("/WEB-INF/pages/glasanjeIndex.jsp").forward(request, response);
  }

}
