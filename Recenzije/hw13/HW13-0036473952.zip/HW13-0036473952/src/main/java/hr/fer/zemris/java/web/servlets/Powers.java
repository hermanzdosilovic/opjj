package hr.fer.zemris.java.web.servlets;

import hr.fer.zemris.java.web.Utils;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

@SuppressWarnings("serial")
@WebServlet(name = "powers", urlPatterns = {"/powers"})
public class Powers extends HttpServlet {

  @Override
  protected void doGet(final HttpServletRequest request, final HttpServletResponse response) throws ServletException,
      IOException {
    final Integer a = Utils.getIntegerParameter(request, "a", null);
    final Integer b = Utils.getIntegerParameter(request, "b", null);
    final Integer n = Utils.getIntegerParameter(request, "n", null);

    if (a == null || b == null || n == null) {
      error(request, response, "One or more parameters unset or malformed.");
      return;
    }

    if (Math.abs(a) > 100 || Math.abs(b) > 100) {
      error(request, response, "'a' and 'b' have to be from [-100, 100].");
      return;
    }

    if (a > b) {
      error(request, response, "'a' has to be less than or equal to 'b'.");
      return;
    }

    if (n < 1 || n > 5) {
      error(request, response, "'n' has to be from [1, 5].");
      return;
    }

    final HSSFWorkbook workbook = new HSSFWorkbook();

    for (int i = 1; i <= n; i++) {
      final HSSFSheet sheet = workbook.createSheet();

      for (int j = a; j <= b; j++) {
        final HSSFRow row = sheet.createRow(j - a);

        row.createCell(0).setCellValue(Integer.toString(j));
        row.createCell(1).setCellValue(Long.toString(power(j, i)));
      }
    }

    response.setContentType("application/vnd.ms-excel");
    response.setHeader("Content-disposition", "attachment; filename=\"powers.xls\"");

    workbook.write(response.getOutputStream());
  }

  private static long power(final int base, final int power) {
    long result = 1;

    for (int i = 0; i < power; i++) {
      result *= base;
    }

    return result;
  }

  private static void error(final HttpServletRequest request, final HttpServletResponse response, final String message)
      throws ServletException, IOException {
    request.setAttribute("error", message);
    request.getRequestDispatcher("/WEB-INF/pages/error.jsp").forward(request, response);
  }

}
