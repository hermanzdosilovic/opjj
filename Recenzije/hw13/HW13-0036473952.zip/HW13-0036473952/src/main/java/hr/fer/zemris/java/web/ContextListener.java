package hr.fer.zemris.java.web;

import hr.fer.zemris.java.web.glasanje.Band;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Collections;
import java.util.List;
import java.util.TreeSet;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;

@WebListener
public class ContextListener implements ServletContextListener {

  private static final String BANDS_DEFINITION_PATH = "/WEB-INF/glasanje-definicija.txt";

  @Override
  public void contextDestroyed(final ServletContextEvent event) {}

  @Override
  public void contextInitialized(final ServletContextEvent event) {
    final ServletContext context = event.getServletContext();

    Timer.start();

    context.setAttribute("timerInstance", Timer.getInstance());
    context.setAttribute("colorValues", Colors.getColors());

    loadBandDefinitions(context);
  }

  private void loadBandDefinitions(final ServletContext context) {
    final Path definitionsPath = Paths.get(context.getRealPath(BANDS_DEFINITION_PATH));

    List<String> definitions = null;
    try {
      definitions = Files.readAllLines(definitionsPath, StandardCharsets.UTF_8);
    } catch (final IOException exception) {
      definitions = Collections.emptyList();
    }

    final TreeSet<Band> bands = new TreeSet<>();
    for (final String definition : definitions) {
      bands.add(Band.parse(definition));
    }

    context.setAttribute("bands", bands);
  }
}
