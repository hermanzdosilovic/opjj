package hr.fer.zemris.java.web.glasanje;

public class BandVotes {

  private final Band band;

  private final int votes;

  public BandVotes(final Band band, final int votes) {
    super();

    this.band = band;
    this.votes = votes;
  }

  public BandVotes(final Band band, final Votes votes) {
    super();

    this.band = band;
    this.votes = votes.getNumber();
  }

  public Band getBand() {
    return band;
  }

  public int getVotes() {
    return votes;
  }

}
