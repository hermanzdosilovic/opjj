package hr.fer.zemris.java.web;

public final class Timer {

  private static final int SIZES[] = {1000, 60, 60, 24};

  private static final String NAMES[] = {"milisecond", "second", "minute", "hour", "day"};

  private final long start;

  private static Timer instance;

  static {
    instance = null;
  }

  private Timer() {
    super();

    start = System.currentTimeMillis();
  }

  public String getDifference() {
    long difference = System.currentTimeMillis() - start;

    final StringBuilder builder = new StringBuilder();

    for (int i = 0; i < SIZES.length; i++) {
      builder.insert(0, formatPeriod(difference % SIZES[i], NAMES[i]));

      difference /= SIZES[i];
    }

    builder.insert(0, formatPeriod(difference, NAMES[NAMES.length - 1]));
    builder.setLength(builder.length() - 1);

    return builder.toString();
  }

  public static void start() {
    if (instance == null) {
      instance = new Timer();
    }
  }

  public static Timer getInstance() {
    return instance;
  }

  private static String formatPeriod(final long number, final String name) {
    if (number == 0) {
      return "";
    }

    return number + " " + name + (number > 1 ? "s" : "") + " ";
  }
}
