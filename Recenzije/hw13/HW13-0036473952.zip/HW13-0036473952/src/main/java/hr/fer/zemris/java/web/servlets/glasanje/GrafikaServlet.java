package hr.fer.zemris.java.web.servlets.glasanje;

import hr.fer.zemris.java.web.glasanje.BandVotes;
import hr.fer.zemris.java.web.glasanje.Glasanje;

import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.List;

import javax.imageio.ImageIO;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PiePlot3D;
import org.jfree.data.general.DefaultPieDataset;

@SuppressWarnings("serial")
@WebServlet(name = "grafika", urlPatterns = {"/glasanje-grafika"})
public class GrafikaServlet extends HttpServlet {

  private static final int IMAGE_WIDTH = 600;

  private static final int IMAGE_HEIGHT = 400;

  private static final String IMAGE_TYPE = "png";

  @Override
  protected void doGet(final HttpServletRequest request, final HttpServletResponse response) throws ServletException,
      IOException {
    response.setContentType("image/" + IMAGE_TYPE);

    final List<BandVotes> bandTable = Glasanje.getBandsVotes(request);

    final DefaultPieDataset dataset = new DefaultPieDataset();

    for (final BandVotes bandVotes : bandTable) {
      dataset.setValue(bandVotes.getBand().getName(), bandVotes.getVotes());
    }

    final JFreeChart chart = ChartFactory.createPieChart3D(null, dataset, true, false, false);

    final PiePlot3D plot = (PiePlot3D) chart.getPlot();
    plot.setForegroundAlpha(0.5f);

    final BufferedImage image = chart.createBufferedImage(IMAGE_WIDTH, IMAGE_HEIGHT);

    ImageIO.write(image, IMAGE_TYPE, response.getOutputStream());
  }

}
