package hr.fer.zemris.java.web.servlets.glasanje;

import hr.fer.zemris.java.web.Utils;
import hr.fer.zemris.java.web.glasanje.Glasanje;
import hr.fer.zemris.java.web.glasanje.Votes;

import java.io.IOException;
import java.util.TreeSet;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@SuppressWarnings("serial")
@WebServlet(name = "glasaj", urlPatterns = {"/glasanje-glasaj"})
public class GlasajServlet extends HttpServlet {

  @Override
  protected void doGet(final HttpServletRequest request, final HttpServletResponse response) throws ServletException,
      IOException {
    final Integer id = Utils.getIntegerParameter(request, "id", null);

    if (id != null) {
      vote(request.getServletContext(), id);
    }

    response.sendRedirect(request.getContextPath() + "/glasanje-rezultati");
  }

  private static void vote(final ServletContext context, final int id) {
    synchronized (context) {
      final TreeSet<Votes> results = Glasanje.getResults(context);

      final Votes voted = results.ceiling(new Votes(id));

      results.remove(voted);
      results.add(voted.vote());

      Glasanje.putResults(context, results);
    }
  }

}
