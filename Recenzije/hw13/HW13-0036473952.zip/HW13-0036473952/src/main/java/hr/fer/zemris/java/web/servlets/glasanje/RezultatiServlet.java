package hr.fer.zemris.java.web.servlets.glasanje;

import hr.fer.zemris.java.web.glasanje.BandVotes;
import hr.fer.zemris.java.web.glasanje.Glasanje;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@SuppressWarnings("serial")
@WebServlet(name = "rezultati", urlPatterns = {"/glasanje-rezultati"})
public class RezultatiServlet extends HttpServlet {

  @Override
  protected void doGet(final HttpServletRequest request, final HttpServletResponse response) throws ServletException,
      IOException {
    final List<BandVotes> bandsVotes = Glasanje.getBandsVotes(request);

    request.setAttribute("bandTable", bandsVotes);

    final int size = bandsVotes.size();
    int index;

    for (index = 1; index < size; ++index) {
      if (bandsVotes.get(index).getVotes() != bandsVotes.get(0).getVotes()) {
        break;
      }
    }

    final List<BandVotes> winnerBands = bandsVotes.subList(0, index);

    request.setAttribute("winnerBands", winnerBands);

    request.getRequestDispatcher("/WEB-INF/pages/glasanjeRezultati.jsp").forward(request, response);
  }

}
