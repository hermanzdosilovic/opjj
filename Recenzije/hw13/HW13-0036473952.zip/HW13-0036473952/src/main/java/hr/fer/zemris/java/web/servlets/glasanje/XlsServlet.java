package hr.fer.zemris.java.web.servlets.glasanje;

import hr.fer.zemris.java.web.glasanje.BandVotes;
import hr.fer.zemris.java.web.glasanje.Glasanje;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

@SuppressWarnings("serial")
@WebServlet(name = "xls", urlPatterns = {"/glasanje-xls"})
public class XlsServlet extends HttpServlet {

  @Override
  protected void doGet(final HttpServletRequest request, final HttpServletResponse response) throws ServletException,
      IOException {
    final List<BandVotes> bandTable = Glasanje.getBandsVotes(request);

    final HSSFWorkbook workbook = new HSSFWorkbook();
    final HSSFSheet sheet = workbook.createSheet();

    final HSSFRow head = sheet.createRow(0);
    head.createCell(0).setCellValue("Band");
    head.createCell(1).setCellValue("Vote number");

    final int size = bandTable.size();

    for (int i = 0; i < size; i++) {
      final HSSFRow row = sheet.createRow(i + 1);

      final BandVotes bandVotes = bandTable.get(i);

      row.createCell(0).setCellValue(bandVotes.getBand().getName());
      row.createCell(1).setCellValue(bandVotes.getVotes());
    }

    response.setContentType("application/vnd.ms-excel");
    response.setHeader("Content-disposition", "attachment; filename=\"results.xls\"");

    workbook.write(response.getOutputStream());
  }

}
