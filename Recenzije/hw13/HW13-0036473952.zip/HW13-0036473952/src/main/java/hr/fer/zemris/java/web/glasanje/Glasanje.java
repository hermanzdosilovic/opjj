package hr.fer.zemris.java.web.glasanje;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;

public final class Glasanje {

  private static final String BANDS_VOTES_PATH = "/WEB-INF/glasanje-rezultati.txt";

  private Glasanje() {
    super();
  }

  public static TreeSet<Votes> getResults(final ServletContext context) {
    final Path resultsPath = Paths.get(context.getRealPath(BANDS_VOTES_PATH));

    List<String> lines = null;
    try {
      lines = Files.readAllLines(resultsPath, StandardCharsets.UTF_8);
    } catch (final IOException exception) {}

    final TreeSet<Votes> results = new TreeSet<>();

    if (lines != null) {
      for (final String line : lines) {
        results.add(Votes.parse(line));
      }
    } else {
      @SuppressWarnings("unchecked")
      final Set<Band> bands = (TreeSet<Band>) context.getAttribute("bands");

      for (final Band band : bands) {
        results.add(new Votes(band.getId(), 0));
      }

      putResults(context, results);
    }

    return results;
  }

  public static void putResults(final ServletContext context, final Iterable<Votes> results) {
    final List<String> lines = new ArrayList<>();

    for (final Votes votes : results) {
      lines.add(votes.toString());
    }

    final Path resultsPath = Paths.get(context.getRealPath(BANDS_VOTES_PATH));

    try {
      Files.write(resultsPath, lines, StandardCharsets.UTF_8);
    } catch (final IOException exception) {}
  }

  public static List<BandVotes> getBandsVotes(final HttpServletRequest request) {
    final ServletContext context = request.getServletContext();
    final TreeSet<Votes> results;

    synchronized (context) {
      results = Glasanje.getResults(context);
    }

    @SuppressWarnings("unchecked")
    final Set<Band> bands = (TreeSet<Band>) context.getAttribute("bands");
    final List<BandVotes> bandsVotes = new ArrayList<>();

    for (final Band band : bands) {
      bandsVotes.add(new BandVotes(band, results.ceiling(band.toVotes())));
    }

    Collections.sort(bandsVotes, new Comparator<BandVotes>() {

      @Override
      public int compare(final BandVotes first, final BandVotes second) {
        return Integer.compare(second.getVotes(), first.getVotes());
      }

    });

    return bandsVotes;
  }

}
