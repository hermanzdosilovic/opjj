package hr.fer.zemris.java.web.servlets;

import hr.fer.zemris.java.web.Utils;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@SuppressWarnings("serial")
@WebServlet(name = "squares", urlPatterns = {"/squares"})
public class Squares extends HttpServlet {

  private static final int DEFAULT_A = 0;

  private static final int DEFAULT_B = 20;

  private static final int MAX_RANGE = 20;

  @Override
  protected void doGet(final HttpServletRequest request, final HttpServletResponse response) throws ServletException,
      IOException {
    int a = Utils.getIntegerParameter(request, "a", DEFAULT_A);
    int b = Utils.getIntegerParameter(request, "b", DEFAULT_B);

    if (a > b) {
      final int tmp = a;
      a = b;
      b = tmp;
    }

    if (b > a + MAX_RANGE) {
      b = a + MAX_RANGE;
    }

    final List<Square> list = new ArrayList<>();

    for (int i = a; i <= b; i++) {
      list.add(new Square(i));
    }

    request.setAttribute("squares", list);

    request.getRequestDispatcher("/WEB-INF/pages/squares.jsp").forward(request, response);
  }

  public static class Square {

    private final int number;

    public Square(final int number) {
      super();

      this.number = number;
    }

    public int getNumber() {
      return number;
    }

    public int getSquare() {
      return number * number;
    }

  }

}
