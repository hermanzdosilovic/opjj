package hr.fer.zemris.java.web;

import javax.servlet.http.HttpServletRequest;

public final class Utils {

  private Utils() {
    super();
  }

  public static int
      getIntegerParameter(final HttpServletRequest request, final String name, final Integer defaultValue) {
    final String value = request.getParameter(name);

    if (value == null) {
      return defaultValue;
    }

    try {
      return Integer.parseInt(value);
    } catch (final NumberFormatException exception) {
      return defaultValue;
    }
  }

}
