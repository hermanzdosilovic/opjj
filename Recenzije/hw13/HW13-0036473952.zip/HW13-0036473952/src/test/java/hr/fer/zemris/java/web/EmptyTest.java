package hr.fer.zemris.java.web;

import org.junit.Test;

public class EmptyTest {

  @Test
  public void testTrue() {}

}
