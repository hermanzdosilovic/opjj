package hr.fer.zemris.vlang.syntax;

import hr.fer.zemris.vlang.VLangException;

/**
 * Iznimka koja opisuje pogreške nastale pri sintaksnoj analizi
 * programa.
 * 
 * @author marcupic
 */
public class VLangSyntaxException extends VLangException {

	private static final long serialVersionUID = 1L;

	/**
	 * Konstruktor.
	 */
	public VLangSyntaxException() {
	}

	/**
	 * Konstruktor.
	 * @param message opis pogreške
	 */
	public VLangSyntaxException(String message) {
		super(message);
	}

}
