package hr.fer.zemris.vlang.syntax.nodes;

/**
 * Model izraza koji predstavlja neki binarni operator, odnosno
 * operator koji djeluje nad dva druga izraza.
 * 
 * @author marcupic
 */
public class NodeBinaryOper extends ExpressionNode {
	
	/**
	 * Prvi izraz.
	 */
	private ExpressionNode first;
	/**
	 * Drugi izraz.
	 */
	private ExpressionNode second;
	
	/**
	 * Konstruktor objekta koji računa <tt>first OPER second</tt> gdje je
	 * <i>OPER</i> neki binarni (u ovom trenutku još uvijek nepoznati) 
	 * operator.
	 * @param first prvi izraz
	 * @param second drugi izraz
	 */
	public NodeBinaryOper(ExpressionNode first, ExpressionNode second) {
		this.first = first;
		this.second = second;
	}

	/**
	 * Dohvat prvog (lijevog) izraza.
	 * @return prvi izraz
	 */
	public ExpressionNode getFirst() {
		return first;
	}
	
	/**
	 * Dohvat drugog (desnog) izraza.
	 * @return drugi izraz
	 */
	public ExpressionNode getSecond() {
		return second;
	}
}
