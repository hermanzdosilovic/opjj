package hr.fer.zemris.vlang.lexical;

/**
 * Razred modelira jedan token ulaznog programa.
 * 
 * @author marcupic
 */
public class VLangToken {

	/**
	 * Vrsta tokena.
	 */
	private VLangTokenType tokenType;
	/**
	 * Vrijednost tokena.
	 */
	private Object value;
	
	/**
	 * Konstruktor.
	 * @param tokenType vrsta tokena
	 * @param value vrijednost tokena
	 */
	public VLangToken(VLangTokenType tokenType, Object value) {
		super();
		if(tokenType==null) throw new IllegalArgumentException("Token type can not be null.");
		this.tokenType = tokenType;
		this.value = value;
	}
	
	/**
	 * Dohvat vrste tokena.
	 * @return vrsta tokena
	 */
	public VLangTokenType getTokenType() {
		return tokenType;
	}
	
	/**
	 * Dohvat vrijednosti tokena.
	 * @return vrijednost tokena ili <code>null</code> ako token ove vrste nema pridruženu vrijednost
	 */
	public Object getValue() {
		return value;
	}
}
