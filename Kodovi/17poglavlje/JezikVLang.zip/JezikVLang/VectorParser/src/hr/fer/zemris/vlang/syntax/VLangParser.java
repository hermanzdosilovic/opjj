package hr.fer.zemris.vlang.syntax;

import java.util.ArrayList;
import java.util.List;

import hr.fer.zemris.vlang.Vector;
import hr.fer.zemris.vlang.lexical.VLangTokenType;
import hr.fer.zemris.vlang.lexical.VLangTokenizer;
import hr.fer.zemris.vlang.lexical.VLangTokenizerException;
import hr.fer.zemris.vlang.syntax.nodes.DefStatement;
import hr.fer.zemris.vlang.syntax.nodes.ExpressionNode;
import hr.fer.zemris.vlang.syntax.nodes.LetStatement;
import hr.fer.zemris.vlang.syntax.nodes.NodeAdd;
import hr.fer.zemris.vlang.syntax.nodes.NodeSub;
import hr.fer.zemris.vlang.syntax.nodes.NodeVariable;
import hr.fer.zemris.vlang.syntax.nodes.NodeVector;
import hr.fer.zemris.vlang.syntax.nodes.PrintStatement;
import hr.fer.zemris.vlang.syntax.nodes.ProgramNode;
import hr.fer.zemris.vlang.syntax.nodes.VLangNode;

/**
 * Implementacija parsera za jezik <i>vlang</i> rekurzivnim
 * spustom.
 * 
 * @author marcupic
 */
public class VLangParser {

	/**
	 * Tokenizator izvornog koda.
	 */
	private VLangTokenizer tokenizer;
	/**
	 * Stablo koje predstavlja parsirani program.
	 */
	private ProgramNode programNode;
	
	/**
	 * Konstruktor.
	 * @param tokenizer tokenizator izvornog koda
	 * @throws VLangSyntaxException u slučaju pogreške pri 
	 *         parsiranju
	 * @throws VLangTokenizerException u slučaju pogreške 
	 *         pri tokenizaciji
	 */
	public VLangParser(VLangTokenizer tokenizer) {
		this.tokenizer = tokenizer;
		programNode = parse();
	}

	/**
	 * Dohvat stabla nastalog parsiranjem izvornog koda.
	 * @return stablo programa
	 */
	public ProgramNode getProgramNode() {
		return programNode;
	}
	
	/**
	 * Pomoćna metoda koja provjerava je li trenutni
	 * token danog tipa. Vraća <code>true</code>
	 * ako je, <code>false</code> inače.
	 * @param type tip s kojim se uspoređuje
	 * @return <code>true</code> ako je
	 */
	private boolean isTokenOfType(VLangTokenType type) {
		return tokenizer.getCurrentToken().getTokenType()==type;
	}
	
	/**
	 * Pomoćna metoda koja predstavlja implementaciju parsera 
	 * rekurzivnim spustom. Ova metoda predstavlja vršnu metodu
	 * tako implementiranog parsera.
	 * 
	 * @return stablo programa
	 */
	private ProgramNode parse() {
		List<VLangNode> statements = new ArrayList<>();
		while(true) {
			// Ako je kraj programa, gotovi smo:
			if(isTokenOfType(VLangTokenType.EOF)) {
				break;
			}
			// Inače prema sintaksi mora doći ključna riječ:
			if(!isTokenOfType(VLangTokenType.KEYWORD)) {
				throw new VLangSyntaxException("Keyword expected.");
			}
			// Ako gledam naredbu "def":
			if("def".equals(tokenizer.getCurrentToken().getValue())) {
				tokenizer.nextToken();
				statements.add(parseDef());
				continue;
			}
			// Ako gledam naredbu "let":
			if("let".equals(tokenizer.getCurrentToken().getValue())) {
				tokenizer.nextToken();
				statements.add(parseLet());
				continue;
			}
			// Ako gledam naredbu "print":
			if("print".equals(tokenizer.getCurrentToken().getValue())) {
				tokenizer.nextToken();
				statements.add(parsePrint());
				continue;
			}
			// Inače imam nepoznatu naredbu:
			throw new VLangSyntaxException("Unexpected keyword found.");
		}
		// Obradili smo čitav program:
		return new ProgramNode(statements);
	}

	/**
	 * Pomoćna metoda koja predstavlja implementaciju parsera 
	 * naredbe "def".
	 * 
	 * @return čvor koji predstavlja ovu naredbu
	 */
	private VLangNode parseDef() {
		List<String> variables = new ArrayList<>();
		while(true) {
			if(!isTokenOfType(VLangTokenType.IDENT)) {
				throw new VLangSyntaxException("Identifier was expected.");
			}
			variables.add(
				(String)tokenizer.getCurrentToken().getValue()
			);
			tokenizer.nextToken();
			if(isTokenOfType(VLangTokenType.COMMA)) {
				tokenizer.nextToken();
				continue;
			}
			break;
		}
		if(!isTokenOfType(VLangTokenType.COLON)) {
			throw new VLangSyntaxException(
				"Colon was expected after variable(s).");
		}
		tokenizer.nextToken();
		if(!isTokenOfType(VLangTokenType.KEYWORD)) {
			throw new VLangSyntaxException("A keyword was expected.");
		}
		String varType = 
			(String)tokenizer.getCurrentToken().getValue();
		if(!"vector".equals(varType)) {
			throw new VLangSyntaxException(
				"Keyword 'vector' was expected.");
		}
		tokenizer.nextToken();
		if(!isTokenOfType(VLangTokenType.SEMICOLON)) {
			throw new VLangSyntaxException(
				"A semicolon was expected.");
		}
		tokenizer.nextToken();
		return new DefStatement(variables, varType);
	}

	/**
	 * Pomoćna metoda koja predstavlja implementaciju parsera
	 * naredbe "let".
	 * 
	 * @return čvor koji predstavlja ovu naredbu
	 */
	private VLangNode parseLet() {
		if(!isTokenOfType(VLangTokenType.IDENT)) {
			throw new VLangSyntaxException("Identifier was expected.");
		}
		String varName = 
			(String)tokenizer.getCurrentToken().getValue();
		tokenizer.nextToken();
		if(!isTokenOfType(VLangTokenType.ASSIGN)) {
			throw new VLangSyntaxException("Assignment was expected.");
		}
		tokenizer.nextToken();
		ExpressionNode expr = parseExpression();
		if(!isTokenOfType(VLangTokenType.SEMICOLON)) {
			throw new VLangSyntaxException("Semicolon was expected.");
		}
		tokenizer.nextToken();
		return new LetStatement(varName, expr);
	}

	/**
	 * Pomoćna metoda koja predstavlja implementaciju parsera
	 * izraza (ono što se nalazi s desne strane u naredbi
	 * pridruživanja ili pak u naredbi print).
	 * 
	 * @return čvor koji predstavlja čitav izraz
	 */
	private ExpressionNode parseExpression() {
		ExpressionNode first = parseAtomicValue();
		while(true) {
			if(isTokenOfType(VLangTokenType.OP_PLUS)) {
				tokenizer.nextToken();
				ExpressionNode second = parseAtomicValue();
				first = new NodeAdd(first, second);
				continue;
			}
			if(isTokenOfType(VLangTokenType.OP_MINUS)) {
				tokenizer.nextToken();
				ExpressionNode second = parseAtomicValue();
				first = new NodeSub(first, second);
				continue;
			}
			break;
		}
		return first;
	}

	/**
	 * Metoda koja parsira atomički izraz: to je vektorska 
	 * konstanta, varijabla ili pak podizraz u oblim 
	 * zagradama.
	 * @return čvor koji predstavlja ovaj izraz
	 */
	private ExpressionNode parseAtomicValue() {
		if(isTokenOfType(VLangTokenType.IDENT)) {
			String varName = 
				(String)tokenizer.getCurrentToken().getValue();
			tokenizer.nextToken();
			return new NodeVariable(varName);
		}
		if(isTokenOfType(VLangTokenType.VECTOR_CONSTANT)) {
			Vector vector = 
				(Vector)tokenizer.getCurrentToken().getValue();
			tokenizer.nextToken();
			return new NodeVector(vector);
		}
		if(isTokenOfType(VLangTokenType.OPEN_PARENTHESES)) {
			tokenizer.nextToken();
			ExpressionNode expression = parseExpression();
			if(!isTokenOfType(VLangTokenType.CLOSED_PARENTHESES)) {
				throw new VLangSyntaxException(
					"Closed parentheses was expected.");
			}
			tokenizer.nextToken();
			return expression;
		}
		throw new VLangSyntaxException("Unexpeced token type.");
	}

	/**
	 * Implementacija parsera naredbe "print".
	 * @return čvor koji predstavlja ovu naredbu.
	 */
	private VLangNode parsePrint() {
		List<ExpressionNode> list = new ArrayList<>();
		list.add(parseExpression());
		while(true) {
			if(!isTokenOfType(VLangTokenType.COMMA)) {
				break;
			}
			tokenizer.nextToken();
			list.add(parseExpression());
		}
		if(!isTokenOfType(VLangTokenType.SEMICOLON)) {
			throw new VLangSyntaxException("Semicolon was expected.");
		}
		tokenizer.nextToken();
		return new PrintStatement(list);
	}
}
