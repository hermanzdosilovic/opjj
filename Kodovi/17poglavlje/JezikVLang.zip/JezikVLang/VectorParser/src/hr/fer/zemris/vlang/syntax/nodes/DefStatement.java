package hr.fer.zemris.vlang.syntax.nodes;

import java.util.ArrayList;
import java.util.List;

/**
 * Model naredbe "def" jezika <i>vlang</i>.
 * 
 * @author marcupic
 */
public class DefStatement extends VLangNode {

	/**
	 * Lista imena varijabli koje se definiraju.
	 */
	private List<String> variables;
	/**
	 * Naziv tipa koji će biti pridružen definiranim
	 * varijablama.
	 */
	private String varType;
	
	/**
	 * Konstruktor.
	 * @param variables lista imena varijabli
	 * @param varType naziv tipa
	 */
	public DefStatement(List<String> variables, String varType) {
		this.variables = new ArrayList<>(variables);
		this.varType = varType;
	}
	
	/**
	 * Dohvat tipa varijabli.
	 * @return tip varijabli
	 */
	public String getVarType() {
		return varType;
	}
	
	/**
	 * Dohvat liste imena varijabli.
	 * @return lista imena varijabli
	 */
	public List<String> getVariables() {
		return new ArrayList<>(variables);
	}
}
