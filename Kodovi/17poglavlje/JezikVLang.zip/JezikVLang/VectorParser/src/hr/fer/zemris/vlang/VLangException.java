package hr.fer.zemris.vlang;

/**
 * Najopćenitija iznimka vezana uz prevođenje i izvođenje programa
 * pisanog jezikom <i>vlang</i>.
 * 
 * @author marcupic
 */
public class VLangException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	/**
	 * Konstruktor.
	 */
	public VLangException() {
	}

	/**
	 * Konstruktor.
	 * @param message opis pogreške
	 */
	public VLangException(String message) {
		super(message);
	}

}
