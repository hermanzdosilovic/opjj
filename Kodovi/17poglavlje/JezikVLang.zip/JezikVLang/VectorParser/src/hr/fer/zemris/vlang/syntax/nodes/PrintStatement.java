package hr.fer.zemris.vlang.syntax.nodes;

import java.util.ArrayList;
import java.util.List;

/**
 * Model naredbe "print" jezika <i>vlang</i>.
 * 
 * @author marcupic
 */
public class PrintStatement extends VLangNode {

	/**
	 * Lista izraza koje treba ispisati.
	 */
	private List<ExpressionNode> list;
	
	/**
	 * Konstruktor.
	 * @param list lista izraza koje treba ispisati
	 */
	public PrintStatement(List<ExpressionNode> list) {
		super();
		this.list = new ArrayList<>(list);
	}

	/**
	 * Dohvat liste izraza koje treba ispisati
	 * @return
	 */
	public List<ExpressionNode> getList() {
		return new ArrayList<>(list);
	}
}
