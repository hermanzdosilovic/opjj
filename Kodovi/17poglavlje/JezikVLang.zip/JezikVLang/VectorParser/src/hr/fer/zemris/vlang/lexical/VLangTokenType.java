package hr.fer.zemris.vlang.lexical;

/**
 * Enumeracija vrsta tokena od kojih se sastoji <i>vlang</i> program.
 * 
 * @author marcupic
 */
public enum VLangTokenType {
	/** Označava da više nema tokena **/
	EOF,
	/** Identifikator **/
	IDENT,
	/** Ključna riječ **/
	KEYWORD,
	/** Dvotočka **/
	COLON,
	/** Točka-zarez **/
	SEMICOLON,
	/** Zarez **/
	COMMA,
	/** Vektorska konstanta **/
	VECTOR_CONSTANT,
	/** Operator plus **/
	OP_PLUS,
	/** Operator minus **/
	OP_MINUS,
	/** Znak pridruživanja **/
	ASSIGN,
	/** Otvorena obla zagrada **/
	OPEN_PARENTHESES,
	/** Zatvorena obla zagrada **/
	CLOSED_PARENTHESES
}
