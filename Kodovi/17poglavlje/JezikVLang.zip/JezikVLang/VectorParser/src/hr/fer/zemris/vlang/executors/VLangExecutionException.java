package hr.fer.zemris.vlang.executors;

import hr.fer.zemris.vlang.VLangException;

/**
 * Iznimka koja predstavlja pogrešku koja se događa prilikom izvođenja
 * programa napisanog jezikom <i>vlang</i>.
 * 
 * @author marcupic
 *
 */
public class VLangExecutionException extends VLangException {

	private static final long serialVersionUID = 1L;

	/**
	 * Konstruktor.
	 */
	public VLangExecutionException() {
	}

	/**
	 * Konstruktor.
	 * @param message poruka pogreške
	 */
	public VLangExecutionException(String message) {
		super(message);
	}

}
