package hr.fer.zemris.vlang.lexical;

import hr.fer.zemris.vlang.Vector;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Tokenizator izvornog koda programa naapisanog jezikom <i>vlang</i>.
 * 
 * @author marcupic
 */
public class VLangTokenizer {

	/**
	 * Polje znakova koji čine izvorni kod programa koji se obrađuje.
	 */
	private char[] data;
	/**
	 * Kazaljka na prvi neobrađeni znak u polju <code>data</code>.
	 */
	private int curPos;
	/**
	 * Posljednji token koji je stvoren analizom izvornog koda programa. 
	 */
	private VLangToken currentToken;

	/**
	 * Statička mapa tipova tokena koje je moguće utvrditi prema samo jednom
	 * znaku (znak == token).
	 */
	private static final Map<Character, VLangTokenType> mapper;
	
	// Inicijalizacija mape mapper
	static {
		mapper = new HashMap<>();
		mapper.put(Character.valueOf(':'), VLangTokenType.COLON);
		mapper.put(Character.valueOf(';'), VLangTokenType.SEMICOLON);
		mapper.put(Character.valueOf('+'), VLangTokenType.OP_PLUS);
		mapper.put(Character.valueOf('-'), VLangTokenType.OP_MINUS);
		mapper.put(Character.valueOf(','), VLangTokenType.COMMA);
		mapper.put(Character.valueOf('='), VLangTokenType.ASSIGN);
		mapper.put(Character.valueOf('('), VLangTokenType.OPEN_PARENTHESES);
		mapper.put(Character.valueOf(')'), VLangTokenType.CLOSED_PARENTHESES);
	}
	
	/**
	 * Skup svih ključnih riječi programa.
	 */
	private static final Set<String> keywords;

	// Inicijalizacija skupa ključnih riječi
	static {
		keywords = new HashSet<>();
		keywords.add("def");
		keywords.add("vector");
		keywords.add("let");
		keywords.add("print");
	}
	
	/**
	 * Konstruktor. Prima izvorni kod programa kao <code>String</code>.
	 * @param program izvorni kod programa
	 * @throws VLangTokenizerException ako dođe do pogreške pri tokenizaciji
	 */
	public VLangTokenizer(String program) {
		data = program.toCharArray();
		curPos = 0;
		extractNextToken();
	}

	/**
	 * Metoda dohvaća trenutni token. Metoda se može zvati više puta i uvijek
	 * će vratiti isti token, sve dok se ne zatraži izlučivanje sljedećeg
	 * tokena.
	 * 
	 * @return trenutni token
	 */
	public VLangToken getCurrentToken() {
		return currentToken;
	}
	
	/**
	 * Metoda izlučuje sljedeći token, postavlja ga kao trenutnog i odmah ga
	 * i vraća.
	 * @throws VLangTokenizerException ako dođe do problema pri tokenizaciji
	 */
	public VLangToken nextToken() {
		extractNextToken();
		return getCurrentToken();
	}
	
	/**
	 * Metoda izlučuje sljedeći token iz izvornog koda.
	 * @throws VLangTokenizerException ako dođe do pogreške pri tokenizaciji
	 */
	private void extractNextToken() {
		// Ako je već prije utvrđen kraj, ponovni poziv metode je greška:
		if(currentToken!=null && currentToken.getTokenType()==VLangTokenType.EOF) {
			throw new VLangTokenizerException("No tokens available."); 
		}
		
		// Inače preskoči praznine:
		skipBlanks();
		
		// Ako više nema znakova, generiraj token za kraj izvornog koda programa
		if(curPos>=data.length) {
			currentToken = new VLangToken(VLangTokenType.EOF, null);
			return;
		}

		// Vidi je li trenutni znak neki od onih koji direktno generiraju token:
		VLangTokenType mappedType = mapper.get(Character.valueOf(data[curPos]));
		if(mappedType != null) {
			// Stvori takav token:
			currentToken = new VLangToken(mappedType, null);
			// Postavi trenutnu poziciju na sljedeći znak:
			curPos++;
			return;
		}

		// Ako znak direktno ne generira token, provjeri što je.
		if(Character.isLetter(data[curPos])) {
			int startIndex = curPos;
			curPos++;
			while(curPos<data.length && Character.isLetter(data[curPos])) {
				curPos++;
			}
			int endIndex = curPos;
			String value = new String(data, startIndex, endIndex-startIndex);
			if(keywords.contains(value)) {
				currentToken = new VLangToken(VLangTokenType.KEYWORD, value);
				return;
			}
			currentToken = new VLangToken(VLangTokenType.IDENT, value);
			return;
		}
		
		// Ako pak imamo početak vektorske konstante:
		if(data[curPos]=='[') {
			curPos++;
			skipBlanks();
			List<Double> components = new ArrayList<>();
			components.add(extractNumber());
			while(true) {
				skipBlanks();
				if(curPos>=data.length) throw new VLangTokenizerException("Invalid vector constant.");
				if(data[curPos]==']') {
					curPos++;
					break;
				}
				if(data[curPos]!=',') throw new VLangTokenizerException("Invalid vector constant.");
				curPos++;
				skipBlanks();
				components.add(extractNumber());
			}
			double[] values = new double[components.size()];
			for(int i = 0, n = components.size(); i < n; i++) {
				values[i] = components.get(i).doubleValue();
			}
			currentToken = new VLangToken(VLangTokenType.VECTOR_CONSTANT, new Vector(values));
			return;
		}
		
		// Inače nije ništa što razumijemo:
		throw new VLangTokenizerException("Invalid character found: '"+data[curPos]+"'.");
	}

	/**
	 * Metoda izlučuje decimalni broj u formatu predznak, cijeli dio, opcionalna točka i decimalni dio.
	 * @return decimalni broj zapisan u izvornom kodu programa na trenutnoj poziciji
	 */
	private Double extractNumber() {
		if(curPos>=data.length) throw new VLangTokenizerException("Invalid vector constant.");
		
		// Je li broj negativan?
		boolean negative = false;
		if(data[curPos]=='+') {
			curPos++;
		} else if(data[curPos]=='-') {
			negative = true;
			curPos++;
		}
		
		// Zapamti početak:
		int startIndex = curPos;
		
		// Pređi preko cijelobrojnog dijela:
		while(curPos<data.length && Character.isDigit(data[curPos])) {
			curPos++;
		}
		
		// Ako smo došli do decimalne točke:
		if(curPos<data.length && data[curPos]=='.') {
			curPos++;
			// Pređi preko decimalnog dijela:
			while(curPos<data.length && Character.isDigit(data[curPos])) {
				curPos++;
			}
		}
		
		// Zapamti kraj i dohvati prihvaćeni dio kao string:
		int endIndex = curPos;
		String value = new String(data, startIndex, endIndex - startIndex);
		
		// Ako broj nema znamenaka ili ima samo točku, baci iznimku:
		if(endIndex==startIndex || (endIndex==startIndex+1 && data[startIndex]=='.')) {
			throw new VLangTokenizerException("Invalid decimal number: '"+value+"'.");
		}
		
		// Inače konvertiraj i vrati broj:
		double d = Double.parseDouble(value);
		if(negative) d = -d;
		return Double.valueOf(d);
	}

	/**
	 * Metoda pomiče kazaljku trenutnog znaka tako da preskače sve prazne znakove
	 * (razmaci, prelasci u novi red, tabulatori).
	 */
	private void skipBlanks() {
		while(curPos<data.length) {
			char c = data[curPos];
			if(c==' ' || c=='\t' || c=='\r' || c=='\n') {
				curPos++;
				continue;
			}
			break;
		}
	}
	
}
