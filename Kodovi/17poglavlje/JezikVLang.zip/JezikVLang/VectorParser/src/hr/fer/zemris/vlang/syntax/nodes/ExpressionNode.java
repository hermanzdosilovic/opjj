package hr.fer.zemris.vlang.syntax.nodes;

/**
 * Vršni razred koji predstavlja bilo kakav izraz.
 * 
 * @author marcupic
 */
public class ExpressionNode {

	/**
	 * Konstruktor.
	 */
	public ExpressionNode() {
	}

}
