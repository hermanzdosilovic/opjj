package hr.fer.zemris.vlang.lexical;

import hr.fer.zemris.vlang.VLangException;

/**
 * Iznimka koja opisuje pogreške pri tokenizaciji programa.
 * 
 * @author marcupic
 */
public class VLangTokenizerException extends VLangException {

	private static final long serialVersionUID = 1L;

	/**
	 * Konstruktor.
	 */
	public VLangTokenizerException() {
	}

	/**
	 * Konstruktor.
	 * @param message opis pogreške
	 */
	public VLangTokenizerException(String message) {
		super(message);
	}

}
