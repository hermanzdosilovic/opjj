package test;

import hr.fer.zemris.vlang.lexical.VLangToken;
import hr.fer.zemris.vlang.lexical.VLangTokenType;
import hr.fer.zemris.vlang.lexical.VLangTokenizer;

/**
 * Demonstracija rada tokenizatora.
 * 
 * @author marcupic
 */
public class TestTokenizer {

	/**
	 * Metoda s kojom započinje izvođenje programa. Argumenti se ignoriraju.
	 * @param args argumenti naredbenog retka
	 */
	public static void main(String[] args) {
		String program = "def a, b,c: vector;\r\n" +
				"let a = [1.5, 2.8];\r\n" +
				"let b = [2, 5];\r\n" +
				"let c = a - (b + [1.2,1]);\r\n" +
				"print a, b, c;"
				;
		
		VLangTokenizer tokenizer = new VLangTokenizer(program);
		
		while(true) {
			VLangToken token = tokenizer.getCurrentToken();
			System.out.println("Trenutni token: "+token.getTokenType()
					+", vrijednost '"+token.getValue()+"'");
			if(token.getTokenType() == VLangTokenType.EOF) break;
			tokenizer.nextToken();
		};
	}

}
