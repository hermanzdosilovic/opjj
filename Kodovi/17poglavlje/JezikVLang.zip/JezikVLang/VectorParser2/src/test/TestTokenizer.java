package test;

import hr.fer.zemris.vlang.lexical.VLangTokenType;
import hr.fer.zemris.vlang.lexical.VLangTokenizer;

/**
 * Demonstracija rada tokenizatora.
 * 
 * @author marcupic
 */
public class TestTokenizer {

	/**
	 * Metoda s kojom započinje izvođenje programa. Argumenti se ignoriraju.
	 * @param args argumenti naredbenog retka
	 */
	public static void main(String[] args) {
		String program = "def a, b,c: vector;\r\n" +
				"let a = [1.5, 2.8];\r\n" +
				"let b = [2, 5];\r\n" +
				"let c = a - (b + [1.2,1]);\r\n" +
				"print a, b, c;"
				;
		VLangTokenizer tokenizer = new VLangTokenizer(program);
		while(tokenizer.getCurrentToken().getTokenType()!=VLangTokenType.EOF) {
			System.out.println("Trenutni token: "+tokenizer.getCurrentToken().getTokenType()
					+", vrijednost '"+tokenizer.getCurrentToken().getValue()+"'");
			tokenizer.nextToken();
		}
	}

}
