package hr.fer.zemris.vlang.executors.improved;

import hr.fer.zemris.vlang.VLangException;
import hr.fer.zemris.vlang.Vector;
import hr.fer.zemris.vlang.executors.VLangExecutionException;
import hr.fer.zemris.vlang.syntax.nodes.DefStatement;
import hr.fer.zemris.vlang.syntax.nodes.ExpressionNode;
import hr.fer.zemris.vlang.syntax.nodes.LetStatement;
import hr.fer.zemris.vlang.syntax.nodes.PrintStatement;
import hr.fer.zemris.vlang.syntax.nodes.ProgramNode;
import hr.fer.zemris.vlang.syntax.nodes.VLangNode;

import java.util.HashMap;
import java.util.Map;

/**
 * Poboljšana inačica stroja za izvođenje programa napisanog
 * jezikom <i>vlang</i> koja ne zahtjeva promjene u kodu ako
 * se mijenja broj i vrsta operatora koji se mogu koristiti
 * u izrazima.
 * 
 * @author marcupic
 */
public class ExecutorImproved {

	/**
	 * Vršni čvor programa.
	 */
	private ProgramNode programNode;
	/**
	 * Mapa definiranih varijabli.
	 */
	private Map<String, Vector> variables;
	
	/**
	 * Konstruktor.
	 * @param programNode vršni čvor programa 
	 *        koji treba izvesti
	 */
	public ExecutorImproved(ProgramNode programNode) {
		this.programNode = programNode;
	}

	/**
	 * Metoda izvodi program predan u konstruktoru.
	 * 
	 * @throws VLangExecutionException ako dođe do pogreške 
	 *         pri izvođenju programa
	 */
	public void execute() {
		// Obriši mapu definiranih varijabli
		variables = new HashMap<>();
		// Izvedi svaku naredbu:
		for(VLangNode node : programNode.getStatements()) {
			// Ako je trenutna naredba naredba "def":
			if(node instanceof DefStatement) {
				DefStatement def = (DefStatement)node;
				for(String varName : def.getVariables()) {
					if(variables.containsKey(varName)) {
						throw new VLangException(
							"Variable "+varName+" alredy defined.");
					} else {
						variables.put(varName, null);
					}
				}
				continue;
			}
			// Ako je trenutna naredba naredba "let":
			if(node instanceof LetStatement) {
				LetStatement let = (LetStatement)node;
				if(!variables.containsKey(let.getVarName())) {
					throw new VLangException(
						"Undeclared variable "+let.getVarName() +
						" in left side of let statement.");
				}
				variables.put(
					let.getVarName(), 
					let.getExpression().evaluate(variables));
				continue;
			}
			// Ako je trenutna naredba naredba "print":
			if(node instanceof PrintStatement) {
				PrintStatement print = (PrintStatement)node;
				for(ExpressionNode exp : print.getList()) {
					System.out.println(exp.evaluate(variables));
				}
			}
		}
	}
	
}
