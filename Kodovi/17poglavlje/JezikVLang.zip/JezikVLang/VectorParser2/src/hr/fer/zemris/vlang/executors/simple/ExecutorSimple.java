package hr.fer.zemris.vlang.executors.simple;

import java.util.HashMap;
import java.util.Map;

import hr.fer.zemris.vlang.VLangException;
import hr.fer.zemris.vlang.Vector;
import hr.fer.zemris.vlang.executors.VLangExecutionException;
import hr.fer.zemris.vlang.syntax.nodes.DefStatement;
import hr.fer.zemris.vlang.syntax.nodes.ExpressionNode;
import hr.fer.zemris.vlang.syntax.nodes.LetStatement;
import hr.fer.zemris.vlang.syntax.nodes.NodeAdd;
import hr.fer.zemris.vlang.syntax.nodes.NodeSub;
import hr.fer.zemris.vlang.syntax.nodes.NodeVariable;
import hr.fer.zemris.vlang.syntax.nodes.NodeVector;
import hr.fer.zemris.vlang.syntax.nodes.PrintStatement;
import hr.fer.zemris.vlang.syntax.nodes.ProgramNode;
import hr.fer.zemris.vlang.syntax.nodes.VLangNode;

/**
 * Jednostavna inačica stroja za izvođenje programa napisanog
 * jezikom <i>vlang</i>.
 * 
 * @author marcupic
 */
public class ExecutorSimple {

	/**
	 * Vršni čvor programa.
	 */
	private ProgramNode programNode;
	/**
	 * Mapa definiranih varijabli.
	 */
	private Map<String, Vector> variables;
	
	/**
	 * Konstruktor.
	 * @param programNode vršni čvor programa koji treba izvesti
	 */
	public ExecutorSimple(ProgramNode programNode) {
		this.programNode = programNode;
	}

	/**
	 * Metoda izvodi program predan u konstruktoru.
	 * 
	 * @throws VLangExecutionException ako dođe do pogreške pri izvođenju programa
	 */
	public void execute() {
		// Obriši mapu definiranih varijabli
		variables = new HashMap<>();
		// Izvedi svaku naredbu:
		for(VLangNode node : programNode.getStatements()) {
			// Ako je trenutna naredba naredba "def":
			if(node instanceof DefStatement) {
				DefStatement def = (DefStatement)node;
				for(String varName : def.getVariables()) {
					if(variables.containsKey(varName)) {
						throw new VLangException("Variable "+varName+" alredy defined.");
					} else {
						variables.put(varName, null);
					}
				}
				continue;
			}
			// Ako je trenutna naredba naredba "let":
			if(node instanceof LetStatement) {
				LetStatement let = (LetStatement)node;
				if(!variables.containsKey(let.getVarName())) {
					throw new VLangException("Undeclared variable "+let.getVarName()+" in left side of let statement.");
				}
				Vector v = calculateExpression(let.getExpression());
				variables.put(let.getVarName(), v);
				continue;
			}
			// Ako je trenutna naredba naredba "print":
			if(node instanceof PrintStatement) {
				PrintStatement print = (PrintStatement)node;
				for(ExpressionNode exp : print.getList()) {
					System.out.println(calculateExpression(exp));
				}
			}
		}
	}

	/**
	 * Pomoćna rekurzivna metoda za izračun vrijednosti izraza.
	 * @param node čvor koji predstavlja trenutni izraz
	 * @return izračunata vrijednost izraza
	 */
	private Vector calculateExpression(ExpressionNode node) {
		// Ako je trenutna čvor vektorska konstanta:
		if(node instanceof NodeVector) {
			return ((NodeVector)node).getVector();
		}
		// Ako je trenutna čvor varijabla:
		if(node instanceof NodeVariable) {
			NodeVariable varNode = (NodeVariable)node;
			return getVariable(varNode.getVarName());
		}
		// Ako je trenutna čvor operator zbrajanja:
		if(node instanceof NodeAdd) {
			NodeAdd addOper = (NodeAdd)node;
			Vector left = calculateExpression(addOper.getFirst());
			Vector right = calculateExpression(addOper.getSecond());
			return left.add(right);
		}
		// Ako je trenutna čvor operator oduzimanja:
		if(node instanceof NodeSub) {
			NodeSub subOper = (NodeSub)node;
			Vector left = calculateExpression(subOper.getFirst());
			Vector right = calculateExpression(subOper.getSecond());
			return left.sub(right);
		}
		// Inače imamo pogrešku -- ovdje nismo smjeli doći:
		throw new VLangException("Unknown expression: "+node.getClass().getName()+".");
	}

	/**
	 * Pomoćna metoda za dohvat vrijednosti varijable.
	 * @param varName ime varijable
	 * @return vrijednost varijable
	 * @throws VLangExecutionException ako varijabla nije definirana ili nije inicijalizirana
	 */
	private Vector getVariable(String varName) {
		Vector v = variables.get(varName);
		if(v==null) {
			if(!variables.containsKey(varName)) {
				throw new VLangException("Undeclared variable "+varName+" in expression.");
			} else {
				throw new VLangException("Uninitialized variable "+varName+" in expression.");
			}
		}
		return v;
	}
}
