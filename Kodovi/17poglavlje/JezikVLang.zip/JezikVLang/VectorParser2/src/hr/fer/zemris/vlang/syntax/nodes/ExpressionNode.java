package hr.fer.zemris.vlang.syntax.nodes;

import java.util.Map;

import hr.fer.zemris.vlang.Vector;

/**
 * Vršni razred koji predstavlja bilo kakav izraz.
 * 
 * @author marcupic
 */
public abstract class ExpressionNode {

	/**
	 * Konstruktor.
	 */
	public ExpressionNode() {
	}

	public abstract Vector evaluate(Map<String, Vector> variables);
	
}
