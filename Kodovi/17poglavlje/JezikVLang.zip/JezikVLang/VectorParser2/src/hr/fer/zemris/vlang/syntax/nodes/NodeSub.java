package hr.fer.zemris.vlang.syntax.nodes;

import hr.fer.zemris.vlang.Vector;

import java.util.Map;

/**
 * Model izraza koji predstavlja operator <i>sub</i>, odnosno
 * oduzimanje dvaju drugih izraza.
 * 
 * @author marcupic
 */
public class NodeSub extends NodeBinaryOper {

	/**
	 * Konstruktor objekta koji predstavlja <tt>first - second</tt>.
	 * @param first prvi izraz
	 * @param second drugi izraz
	 */
	public NodeSub(ExpressionNode first, ExpressionNode second) {
		super(first, second);
	}

	@Override
	public Vector evaluate(Map<String, Vector> variables) {
		Vector left = getFirst().evaluate(variables);
		Vector right = getSecond().evaluate(variables);
		return left.sub(right);
	}

}
