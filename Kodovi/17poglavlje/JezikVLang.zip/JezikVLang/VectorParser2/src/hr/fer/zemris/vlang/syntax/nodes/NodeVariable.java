package hr.fer.zemris.vlang.syntax.nodes;

import hr.fer.zemris.vlang.Vector;
import hr.fer.zemris.vlang.executors.VLangExecutionException;

import java.util.Map;

/**
 * Model izraza koji predstavlja varijablu.
 * 
 * @author marcupic
 */
public class NodeVariable extends ExpressionNode {

	/**
	 * Naziv varijable.
	 */
	private String varName;
	
	/**
	 * Konstruktor.
	 * @param varName naziv varijable
	 */
	public NodeVariable(String varName) {
		this.varName = varName;
	}

	/**
	 * Dohvat naziva varijable.
	 * @return naziv varijable
	 */
	public String getVarName() {
		return varName;
	}
	
	@Override
	public Vector evaluate(Map<String, Vector> variables) {
		Vector v = variables.get(varName);
		if(v==null) {
			if(!variables.containsKey(varName)) {
				throw new VLangExecutionException("Undeclared variable "+varName+" in expression.");
			} else {
				throw new VLangExecutionException("Uninitialized variable "+varName+" in expression.");
			}
		}
		return v;
	}
}
