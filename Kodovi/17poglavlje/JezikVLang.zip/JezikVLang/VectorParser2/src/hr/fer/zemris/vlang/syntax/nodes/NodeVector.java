package hr.fer.zemris.vlang.syntax.nodes;

import java.util.Map;

import hr.fer.zemris.vlang.Vector;

/**
 * Model izraza koji predstavlja vektorsku konstantu.
 * 
 * @author marcupic
 */
public class NodeVector extends ExpressionNode {

	/**
	 * Vektorska konstanta.
	 */
	private Vector vector;
	
	/**
	 * Konstruktor.
	 * @param vector vektorska konstanta
	 */
	public NodeVector(Vector vector) {
		this.vector = vector;
	}

	/**
	 * Dohvat vrijednosti vektorske konstante.
	 * @return vektorska konstanta
	 */
	public Vector getVector() {
		return vector;
	}
	
	@Override
	public Vector evaluate(Map<String, Vector> variables) {
		return getVector();
	}
}
