package hr.fer.zemris.vlang.syntax;

import hr.fer.zemris.vlang.syntax.nodes.NodeAdd;
import hr.fer.zemris.vlang.syntax.nodes.NodeSub;
import hr.fer.zemris.vlang.syntax.nodes.NodeVariable;
import hr.fer.zemris.vlang.syntax.nodes.NodeVector;

/**
 * Apstraktni posjetitelj izraza.
 * 
 * @author marcupic
 */
public interface ExpressionNodeVisitor {

	/**
	 * Operacija posjećivanja čvora {@link NodeAdd}.
	 * @param add čvor
	 */
	public void visit(NodeAdd add);
	/**
	 * Operacija posjećivanja čvora {@link NodeSub}.
	 * @param add čvor
	 */
	public void visit(NodeSub sub);
	/**
	 * Operacija posjećivanja čvora {@link NodeVariable}.
	 * @param add čvor
	 */
	public void visit(NodeVariable var);
	/**
	 * Operacija posjećivanja čvora {@link NodeVector}.
	 * @param add čvor
	 */
	public void visit(NodeVector vector);

}
