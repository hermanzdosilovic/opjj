package hr.fer.zemris.vlang.syntax.nodes.visitors;

import hr.fer.zemris.vlang.syntax.ExpressionNodeVisitor;
import hr.fer.zemris.vlang.syntax.nodes.NodeAdd;
import hr.fer.zemris.vlang.syntax.nodes.NodeSub;
import hr.fer.zemris.vlang.syntax.nodes.NodeVariable;
import hr.fer.zemris.vlang.syntax.nodes.NodeVector;

public class ExpressionPrintVisitor 
	implements ExpressionNodeVisitor {

	/**
	 * Izlaz u koji se zapisuje izvorni kod izraza.
	 */
	private StringBuilder sb;
	
	/**
	 * Konstruktor.
	 * @param sb izlaz u koji treba zapisati izvorni kod
	 */
	public ExpressionPrintVisitor(StringBuilder sb) {
		this.sb = sb;
	}

	@Override
	public void visit(NodeAdd add) {
		sb.append('(');
		add.getFirst().accept(this);
		sb.append('+');
		add.getSecond().accept(this);
		sb.append(')');
	}

	@Override
	public void visit(NodeSub sub) {
		sb.append('(');
		sub.getFirst().accept(this);
		sb.append('-');
		sub.getSecond().accept(this);
		sb.append(')');
	}

	@Override
	public void visit(NodeVariable var) {
		String varName = var.getVarName();
		sb.append(varName);
	}

	@Override
	public void visit(NodeVector vector) {
		sb.append(vector.getVector().toString());
	}
}
