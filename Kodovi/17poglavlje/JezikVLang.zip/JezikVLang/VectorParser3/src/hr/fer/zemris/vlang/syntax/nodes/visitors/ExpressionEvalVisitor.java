package hr.fer.zemris.vlang.syntax.nodes.visitors;

import java.util.Map;
import java.util.Stack;

import hr.fer.zemris.vlang.Vector;
import hr.fer.zemris.vlang.executors.VLangExecutionException;
import hr.fer.zemris.vlang.syntax.ExpressionNodeVisitor;
import hr.fer.zemris.vlang.syntax.nodes.NodeAdd;
import hr.fer.zemris.vlang.syntax.nodes.NodeSub;
import hr.fer.zemris.vlang.syntax.nodes.NodeVariable;
import hr.fer.zemris.vlang.syntax.nodes.NodeVector;

public class ExpressionEvalVisitor 
	implements ExpressionNodeVisitor {

	private Stack<Vector> stack = new Stack<>();
	private Map<String, Vector> variables;
	
	public ExpressionEvalVisitor(Map<String, Vector> variables) {
		this.variables = variables;
	}

	@Override
	public void visit(NodeAdd add) {
		add.getFirst().accept(this);
		add.getSecond().accept(this);
		Vector right = stack.pop();
		Vector left = stack.pop();
		stack.push(left.add(right));
	}

	@Override
	public void visit(NodeSub sub) {
		sub.getFirst().accept(this);
		sub.getSecond().accept(this);
		Vector right = stack.pop();
		Vector left = stack.pop();
		stack.push(left.sub(right));
	}

	@Override
	public void visit(NodeVariable var) {
		String varName = var.getVarName();
		Vector v = variables.get(varName);
		if(v==null) {
			if(!variables.containsKey(varName)) {
				throw new VLangExecutionException(
					"Undeclared variable "+varName+" in expression.");
			} else {
				throw new VLangExecutionException(
					"Uninitialized variable "+varName+" in expression.");
			}
		}
		stack.push(v);
	}

	@Override
	public void visit(NodeVector vector) {
		stack.push(vector.getVector());
	}

	public Vector getResult() {
		if(stack.size() != 1) {
			throw new VLangExecutionException(
					"Evaluation of expression failed!");
		}
		return stack.peek();
	}
	
}
