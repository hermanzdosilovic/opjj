package hr.fer.zemris.vlang.executors.visitors;

import hr.fer.zemris.vlang.executors.VLangExecutionException;
import hr.fer.zemris.vlang.syntax.nodes.ProgramNode;
import hr.fer.zemris.vlang.syntax.nodes.visitors.ProgramExecutorVisitor;

/**
 * Inačica stroja za izvođenje programa napisanog
 * jezikom <i>vlang</i> koju ne treba mijenjati 
 * niti ako se dodaju nove naredbe, niti ako dođe do
 * bilo kakve promjene u broju i vrsti operatora i 
 * operanada koji se mogu pojaviti u izrazima.
 * 
 * @author marcupic
 */
public class ExecutorVisitor2 {

	/**
	 * Vršni čvor programa.
	 */
	private ProgramNode programNode;
	
	/**
	 * Konstruktor.
	 * @param programNode vršni čvor programa koji treba izvesti
	 */
	public ExecutorVisitor2(ProgramNode programNode) {
		this.programNode = programNode;
	}

	/**
	 * Metoda izvodi program predan u konstruktoru.
	 * 
	 * @throws VLangExecutionException ako dođe do pogreške 
	 *         pri izvođenju programa
	 */
	public void execute() {
		ProgramExecutorVisitor exec = new ProgramExecutorVisitor();
		programNode.accept(exec);
	}

}
