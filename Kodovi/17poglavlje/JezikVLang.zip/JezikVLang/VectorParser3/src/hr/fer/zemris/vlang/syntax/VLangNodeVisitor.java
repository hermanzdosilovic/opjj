package hr.fer.zemris.vlang.syntax;

import hr.fer.zemris.vlang.syntax.nodes.DefStatement;
import hr.fer.zemris.vlang.syntax.nodes.LetStatement;
import hr.fer.zemris.vlang.syntax.nodes.PrintStatement;
import hr.fer.zemris.vlang.syntax.nodes.ProgramNode;

/**
 * Apstraktni posjetitelj naredbi jezika <i>vlang</i>.
 * 
 * @author marcupic
 */
public interface VLangNodeVisitor {

	/**
	 * Obrada naredbe "def" ({@link DefStatement}).
	 * @param stmt naredba
	 */
	public void visit(DefStatement stmt);
	/**
	 * Obrada naredbe "let" ({@link LetStatement}).
	 * @param stmt naredba
	 */
	public void visit(LetStatement stmt);
	/**
	 * Obrada naredbe "print" ({@link PrintStatement}).
	 * @param stmt naredba
	 */
	public void visit(PrintStatement stmt);
	/**
	 * Obrada slijeda naredbi ({@link ProgramNode}).
	 * @param node slijed naredbi
	 */
	public void visit(ProgramNode node);
	
}
