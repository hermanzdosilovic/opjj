package hr.fer.zemris.vlang.syntax.nodes;

import hr.fer.zemris.vlang.syntax.VLangNodeVisitor;

/**
 * Model naredbe "let" jezika <i>vlang</i>.
 * 
 * @author marcupic
 */
public class LetStatement extends VLangNode {

	/**
	 * Naziv varijable kojoj se dodjeljuje vrijednost. 
	 */
	private String varName;
	/**
	 * Izraz temeljem kojega se dodjeljuje vrijednost.
	 */
	private ExpressionNode expression;
	
	/**
	 * Konstruktor.
	 * @param varName naziv varijable kojoj se dodjeljuje vrijednost
	 * @param expression izraz koji treba izračunati
	 */
	public LetStatement(String varName, ExpressionNode expression) {
		super();
		this.varName = varName;
		this.expression = expression;
	}

	/**
	 * Dohvat naziva varijable koja se definira.
	 * @return naziv varijable
	 */
	public String getVarName() {
		return varName;
	}
	
	/**
	 * Dohvat izraza koji treba izračunati.
	 * @return izraz
	 */
	public ExpressionNode getExpression() {
		return expression;
	}
	
	@Override
	public void accept(VLangNodeVisitor visitor) {
		visitor.visit(this);
	}
}
