package hr.fer.zemris.vlang.syntax.nodes;

import hr.fer.zemris.vlang.syntax.VLangNodeVisitor;

import java.util.ArrayList;
import java.util.List;

/**
 * Model slijeda naredbi programa napisanog jezikom 
 * <i>vlang</i>.
 * 
 * @author marcupic
 */
public class ProgramNode extends VLangNode {

	/**
	 * Slijed nareebi.
	 */
	private List<VLangNode> statements;
	
	/**
	 * Konstruktor.
	 * @param statements slijed naredbi
	 */
	public ProgramNode(List<VLangNode> statements) {
		this.statements = new ArrayList<>(statements);
	}

	/**
	 * Dohvat slijeda naredbi.
	 * @return slijed naredbi
	 */
	public List<VLangNode> getStatements() {
		return new ArrayList<>(statements);
	}
	
	@Override
	public void accept(VLangNodeVisitor visitor) {
		visitor.visit(this);
	}
}
