package hr.fer.zemris.vlang.syntax.nodes.visitors;

import hr.fer.zemris.vlang.syntax.ExpressionNodeVisitor;
import hr.fer.zemris.vlang.syntax.VLangNodeVisitor;
import hr.fer.zemris.vlang.syntax.nodes.DefStatement;
import hr.fer.zemris.vlang.syntax.nodes.ExpressionNode;
import hr.fer.zemris.vlang.syntax.nodes.LetStatement;
import hr.fer.zemris.vlang.syntax.nodes.PrintStatement;
import hr.fer.zemris.vlang.syntax.nodes.ProgramNode;
import hr.fer.zemris.vlang.syntax.nodes.VLangNode;

public class ProgramPrintVisitor implements VLangNodeVisitor {

	/**
	 * Izlaz u koji se zapisuje izvorni kod programa.
	 */
	private StringBuilder sb = new StringBuilder();
	
	@Override
	public void visit(DefStatement stmt) {
		sb.append("def ");
		boolean first = true;
		for(String varName : stmt.getVariables()) {
			if(first) {
				first = false;
			} else {
				sb.append(", ");
			}
			sb.append(varName);
		}
		sb.append(": vector;\r\n");
	}

	@Override
	public void visit(LetStatement stmt) {
		sb.append("let ").append(stmt.getVarName()).append(" = ");
		stmt.getExpression().accept(new ExpressionPrintVisitor(sb));
		sb.append(";\r\n");
	}

	@Override
	public void visit(PrintStatement stmt) {
		ExpressionNodeVisitor expVisitor = new ExpressionPrintVisitor(sb);
		sb.append("print ");
		boolean first = true;
		for(ExpressionNode node : stmt.getList()) {
			if(first) {
				first = false;
			} else {
				sb.append(", ");
			}
			node.accept(expVisitor);
		}
		sb.append(";\r\n");
	}

	@Override
	public void visit(ProgramNode node) {
		for(VLangNode stmt : node.getStatements()) {
			stmt.accept(this);
		}
	}
	
	/**
	 * Dohvat generiranog izvornog koda.
	 * 
	 * @return izvorni kod
	 */
	public String getSourceCode() {
		return sb.toString();
	}
}
