package hr.fer.zemris.vlang.syntax.nodes;

import hr.fer.zemris.vlang.syntax.VLangNodeVisitor;

/**
 * Općeniti čvor stabla programa napisanog jezikom <i>vlang</i>
 * pri čemu konkretne implementacije ovog čvora predstavljaju
 * pojedine naredbe (definicije, dodjeljivanja, ispis).
 * 
 * @author marcupic
 */
public abstract class VLangNode {

	/**
	 * Konstruktor.
	 */
	public VLangNode() {
	}

	/**
	 * Prihvat posjetitelja.
	 * @param visitor posjetitelj
	 */
	public abstract void accept(VLangNodeVisitor visitor);
}
