package hr.fer.zemris.vlang.executors.visitors;

import java.util.HashMap;
import java.util.Map;

import hr.fer.zemris.vlang.Vector;
import hr.fer.zemris.vlang.executors.VLangExecutionException;
import hr.fer.zemris.vlang.syntax.nodes.DefStatement;
import hr.fer.zemris.vlang.syntax.nodes.ExpressionNode;
import hr.fer.zemris.vlang.syntax.nodes.LetStatement;
import hr.fer.zemris.vlang.syntax.nodes.PrintStatement;
import hr.fer.zemris.vlang.syntax.nodes.ProgramNode;
import hr.fer.zemris.vlang.syntax.nodes.VLangNode;
import hr.fer.zemris.vlang.syntax.nodes.visitors.ExpressionEvalVisitor;

/**
 * Inačica stroja za izvođenje programa napisanog
 * jezikom <i>vlang</i> koju ne treba mijenjati ako dođe do
 * bilo kakve promjene u broju i vrsti operatora i operanada
 * koji se mogu pojaviti u izrazima.
 * 
 * @author marcupic
 */
public class ExecutorVisitor1 {

	/**
	 * Vršni čvor programa.
	 */
	private ProgramNode programNode;
	/**
	 * Mapa definiranih varijabli.
	 */
	private Map<String, Vector> variables;
	
	/**
	 * Konstruktor.
	 * @param programNode vršni čvor programa koji treba izvesti
	 */
	public ExecutorVisitor1(ProgramNode programNode) {
		this.programNode = programNode;
	}

	/**
	 * Metoda izvodi program predan u konstruktoru.
	 * 
	 * @throws VLangExecutionException ako dođe do pogreške 
	 *         pri izvođenju programa
	 */
	public void execute() {
		// Obriši mapu definiranih varijabli
		variables = new HashMap<>();
		// Izvedi svaku naredbu:
		for(VLangNode node : programNode.getStatements()) {
			// Ako je trenutna naredba naredba "def":
			if(node instanceof DefStatement) {
				DefStatement def = (DefStatement)node;
				for(String varName : def.getVariables()) {
					if(variables.containsKey(varName)) {
						throw new VLangExecutionException(
							"Variable "+varName+" alredy defined.");
					} else {
						variables.put(varName, null);
					}
				}
				continue;
			}
			// Ako je trenutna naredba naredba "let":
			if(node instanceof LetStatement) {
				LetStatement let = (LetStatement)node;
				if(!variables.containsKey(let.getVarName())) {
					throw new VLangExecutionException(
						"Undeclared variable " + let.getVarName() +
						" in left side of let statement.");
				}
				Vector v = calculateExpression(let.getExpression());
				variables.put(let.getVarName(), v);
				continue;
			}
			// Ako je trenutna naredba naredba "print":
			if(node instanceof PrintStatement) {
				PrintStatement print = (PrintStatement)node;
				for(ExpressionNode exp : print.getList()) {
					System.out.println(calculateExpression(exp));
				}
			}
		}
	}

	/**
	 * Pomoćna rekurzivna metoda za izračun vrijednosti izraza.
	 * @param node čvor koji predstavlja trenutni izraz
	 * @return izračunata vrijednost izraza
	 */
	private Vector calculateExpression(ExpressionNode node) {
		ExpressionEvalVisitor visitor = 
			new ExpressionEvalVisitor(variables);
		node.accept(visitor);
		return visitor.getResult();
	}

}
