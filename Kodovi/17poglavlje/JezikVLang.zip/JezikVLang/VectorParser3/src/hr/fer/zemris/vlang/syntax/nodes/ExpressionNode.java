package hr.fer.zemris.vlang.syntax.nodes;

import hr.fer.zemris.vlang.syntax.ExpressionNodeVisitor;

/**
 * Vršni razred koji predstavlja bilo kakav izraz.
 * 
 * @author marcupic
 */
public abstract class ExpressionNode {

	/**
	 * Konstruktor.
	 */
	public ExpressionNode() {
	}

	/**
	 * Apstraktna metoda koja prihvaća posjetitelja izraza.
	 * 
	 * @param visitor posjetitelj
	 */
	public abstract void accept(ExpressionNodeVisitor visitor);
	
}
