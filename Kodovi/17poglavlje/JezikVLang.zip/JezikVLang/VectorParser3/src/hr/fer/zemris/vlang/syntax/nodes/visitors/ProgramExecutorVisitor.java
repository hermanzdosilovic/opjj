package hr.fer.zemris.vlang.syntax.nodes.visitors;

import java.util.HashMap;
import java.util.Map;

import hr.fer.zemris.vlang.VLangException;
import hr.fer.zemris.vlang.Vector;
import hr.fer.zemris.vlang.syntax.VLangNodeVisitor;
import hr.fer.zemris.vlang.syntax.nodes.DefStatement;
import hr.fer.zemris.vlang.syntax.nodes.ExpressionNode;
import hr.fer.zemris.vlang.syntax.nodes.LetStatement;
import hr.fer.zemris.vlang.syntax.nodes.PrintStatement;
import hr.fer.zemris.vlang.syntax.nodes.ProgramNode;
import hr.fer.zemris.vlang.syntax.nodes.VLangNode;

public class ProgramExecutorVisitor implements VLangNodeVisitor {

	/**
	 * Mapa definiranih varijabli.
	 */
	private Map<String, Vector> variables = new HashMap<>();
	
	@Override
	public void visit(DefStatement stmt) {
		for(String varName : stmt.getVariables()) {
			if(variables.containsKey(varName)) {
				throw new VLangException("Variable "+varName+" alredy defined.");
			} else {
				variables.put(varName, null);
			}
		}
	}

	@Override
	public void visit(LetStatement stmt) {
		if(!variables.containsKey(stmt.getVarName())) {
			throw new VLangException("Undeclared variable "+stmt.getVarName()+" in left side of let statement.");
		}
		Vector v = calculateExpression(stmt.getExpression());
		variables.put(stmt.getVarName(), v);
	}

	@Override
	public void visit(PrintStatement stmt) {
		for(ExpressionNode exp : stmt.getList()) {
			System.out.println(calculateExpression(exp));
		}
	}

	@Override
	public void visit(ProgramNode node) {
		for(VLangNode stmt : node.getStatements()) {
			stmt.accept(this);
		}
	}

	/**
	 * Pomoćna rekurzivna metoda za izračun vrijednosti izraza.
	 * @param node čvor koji predstavlja trenutni izraz
	 * @return izračunata vrijednost izraza
	 */
	private Vector calculateExpression(ExpressionNode node) {
		ExpressionEvalVisitor visitor = new ExpressionEvalVisitor(variables);
		node.accept(visitor);
		return visitor.getResult();
	}
}
