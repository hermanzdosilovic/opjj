package test;

import hr.fer.zemris.vlang.executors.visitors.ExecutorVisitor1;
import hr.fer.zemris.vlang.lexical.VLangTokenizer;
import hr.fer.zemris.vlang.syntax.VLangParser;
import hr.fer.zemris.vlang.syntax.nodes.ProgramNode;

/**
 * Program koji predstavlja demonstraciju izvođenja programa napisanog
 * jezikom <i>vlang</i>. Izvođenje je ostvareno implementacijom
 * {@link ExecutorSimple}.
 * 
 * @author marcupic
 */
public class TestExecutorVisitor1 {

	/**
	 * Metoda s kojom započinje izvođenje programa. Argumenti se ignoriraju.
	 * @param args argumenti naredbenog retka
	 */
	public static void main(String[] args) {
		String program = "def a, b: vector;\r\n" +
				"def c: vector;\r\n" +
				"let a = [1.5, 2.8];\r\n" +
				"let b = [2, 5];\r\n" +
				"let c = a - (b + [1.2,1]);\r\n" +
				"print a, b, c;"
				;
		
		VLangTokenizer tokenizer = new VLangTokenizer(program);
		VLangParser parser = new VLangParser(tokenizer);
		
		ProgramNode programNode = parser.getProgramNode();
		
		new ExecutorVisitor1(programNode).execute();
	}

}
