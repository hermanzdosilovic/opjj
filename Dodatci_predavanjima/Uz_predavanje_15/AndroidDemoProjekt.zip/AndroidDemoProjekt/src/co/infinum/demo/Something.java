package co.infinum.demo;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;


class Something implements Parcelable {
	
	private String var1;

	@Override
	public int describeContents() {
		return 0;
	}
	
	public Something() {
		
	}
	
	public Something(Parcel source) {
		var1 = source.readString();
	}

	@Override
	public void writeToParcel(Parcel dest, int flags) {
		dest.writeString(var1);
		
	}
	
	public static final Creator<Something> CREATOR = new Creator<Something>() {

		@Override
		public Something createFromParcel(Parcel source) {
			return new Something(source);
		}

		@Override
		public Something[] newArray(int size) {
			
			return new Something[size];
		}
	};
	
}