package co.infinum.demo;
import co.infinum.demo.R;
import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.provider.MediaStore;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Toast;


public class MainActivity extends Activity {
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		setContentView(R.layout.activity_main);
		
		Button button = (Button) findViewById(R.id.btnCall);
		button.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				Intent intent = new Intent(
						Intent.ACTION_CALL,
						Uri.parse("tel:1234234")
					);
				startActivity(intent);
			}
		});
		
		Button cameraButton = (Button) findViewById(R.id.btnCamera);
		cameraButton.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
				startActivity(intent);
			}
		});
		
		Button detailsButton = (Button) findViewById(R.id.btnDetails);
		detailsButton.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				Intent intent = new Intent(
						MainActivity.this,
						DetailsActivity.class
					);
				
				intent.putExtra("label", "Moj label 2:");
				intent.putExtra("something", new Something());
				
				startActivityForResult(intent, 0);
			}
		});
		
		Button listButton = (Button) findViewById(R.id.btnList);
		listButton.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				Intent intent = new Intent(
						MainActivity.this,
						ListActivity.class
					);
							
				startActivity(intent);
			}
		});
		
	}
	
	
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		
		if(data != null) {
			String text = data.getExtras().getString("data");
			Toast.makeText(this, text, Toast.LENGTH_LONG).show();
		}

	}

}
