package co.infinum.demo;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

public class ListDetailsActivity extends Activity {
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		setContentView(R.layout.layout_list_details);
		
		TextView messageTextView = (TextView) findViewById(R.id.tvMessage);
		String helloMessage = getIntent().getExtras().getString("message");
		
		messageTextView.setText(helloMessage);
	}
}
