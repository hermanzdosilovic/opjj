package co.infinum.demo;

import java.util.ArrayList;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;

public class ListActivity extends Activity {
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		setContentView(R.layout.activity_list);
		
		ListView listView = (ListView) findViewById(R.id.listView);
		
		final ArrayList<Person> people = new ArrayList<Person>();
		people.add(new Person("Darth", "Vader"));
		people.add(new Person("Chuck", "Norris"));
		people.add(new Person("Bruce", "Lee"));
		people.add(new Person("Stephen", "Segal"));
		
		PersonArrayAdapter adapter = new PersonArrayAdapter(this, people);
		
		listView.setAdapter(adapter);
		
		listView.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				Intent intent = new Intent(ListActivity.this, ListDetailsActivity.class);
				String helloMessage = "Hello " + 
							people.get(position).getName() + " " +
							people.get(position).getLastName();
				
				intent.putExtra("message", helloMessage);
				startActivity(intent);
				
			}
		});
	}

}
