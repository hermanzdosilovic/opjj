package hr.fer.zemris.java.webserver;

import org.junit.Test;
import static org.junit.Assert.*;

public class RequestContextTest {
	
	@Test
	public void RequestContext() {
		RequestContext rc = new RequestContext(System.out, null, null, null);
		
		int size = rc.getParameters().size();
		assertEquals(size, 0);
		
		size = rc.getTemporaryParameters().size();
		assertEquals(size, 0);
		
		size = rc.getPersistentParameters().size();
		assertEquals(size, 0);
		
		rc.write("Test");
		
		rc.getParameterNames();
		assertEquals(null, rc.getPersistentParameter("name"));
		assertEquals(null, rc.getParameter("name"));
		rc.getPersistentParameterNames();
		assertEquals(null, rc.getTemporaryParameter("name"));
		rc.getTemporaryParameterName();
	}
}
