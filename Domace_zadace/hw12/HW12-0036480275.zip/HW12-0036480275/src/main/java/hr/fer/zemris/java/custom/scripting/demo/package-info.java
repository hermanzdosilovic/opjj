/**
 * @author Herman Zvonimir Došilović
 * @version 1.0
 */
package hr.fer.zemris.java.custom.scripting.demo;
