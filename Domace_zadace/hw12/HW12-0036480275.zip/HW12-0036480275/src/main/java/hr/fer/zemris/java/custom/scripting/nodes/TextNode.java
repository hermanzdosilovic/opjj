package hr.fer.zemris.java.custom.scripting.nodes;

/**
 * This class is representation of a piece of text data.
 * @author Herman Zvonimir Došilović
 * @version 1.0
 */
public class TextNode extends Node {

	private String text;

	/**
	 * <b><i>TextNode</b></i><br>
	 * <br>
	 * <code>&nbsp public TextNode(String text)</code><br>
	 * <br>
	 * Constructs new <code>TextNode</code> that represents text data.
	 * @param text
	 *            - text data that this node represents
	 */
	public TextNode(String text) {
		this.text = text;
	}

	/**
	 * <b><i>getText</b></i><br>
	 * <br>
	 * <code>&nbsp public String getText()</code><br>
	 * <br>
	 * @return text data that this node represents
	 */
	public String getText() {
		return text;
	}

	@Override
	public void accept(INodeVisitor visitor) {
		visitor.visitTextNode(this);
	}

}
