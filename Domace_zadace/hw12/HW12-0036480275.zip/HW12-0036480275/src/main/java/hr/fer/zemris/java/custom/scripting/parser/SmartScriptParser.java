package hr.fer.zemris.java.custom.scripting.parser;

import hr.fer.zemris.java.custom.collections.*;
import hr.fer.zemris.java.custom.scripting.nodes.*;
import hr.fer.zemris.java.custom.scripting.tokens.*;

/**
 * Implementation of parser that constructs document tree from given document.<br>
 * Document can consist of:<br>
 * <ul>
 * <li>Tags
 * <li>Text
 * </ul>
 * <b>Tags</b><br>
 * &nbsp&nbsp&nbsp&nbspTag in document is well defined string that is bounded
 * with <code>{$</code> on the beginning, and <code>$}</code> on the end.<br>
 * There are three types of tag that are acceptable in this parser:<br>
 * <ul>
 * <ul>
 * <li><b>FOR</b>
 * <ul>
 * <li>prototype of this tag:
 * <code>{$FOR variable startExpression endExpression stepExpression$}</code>
 * <br>
 * <li><code>stepExpression</code> is not necessary i.e. it can be
 * <code>null</code><br>
 * <li>here are some valid <b>FOR</b>-tags:<br>
 * <ul>
 * <li>{$FOR i 0 10 1$}
 * <li>{$FORi 0 10 1$}
 * <li>{$fOR i 0 10 $}
 * <li>{$ fOr i 0 10 1 $}
 * <li>{$ Fori 0 10 $}
 * <li>{$for counter "this is string" "this is also string"
 * "this is another string" $}
 * </ul>
 * <li>here are some invalid <b>FOR</b>-tags:
 * <ul>
 * <li>{$FOR$}
 * <li>{$for i 2$}
 * <li>{$for "cannot be string" 2$}
 * </ul>
 * <li><b>FOR</b>-tags can nested
 * <li>for every opened <b>FOR</b>-tag there must be one closing tag
 * (<b>END</b>-tag)
 * </ul>
 * <li><b>END</b>
 * <ul>
 * <li>is used for closing <b>FOR</b>-tag:
 * <ul>
 * <code>{$FOR i 0 10 1$}<br>{$END$}</code>
 * </ul>
 * <li>here are some valid <b>END</b>-tags:
 * <ul>
 * <li>{$END$}
 * <li>{$ end$}
 * <li>{$ eNd $}
 * </ul>
 * <li>here are some invalid <b>END</b>-tags:
 * <ul>
 * <li>{$END some_random_string$}
 * <li>{$some_random_string end $}
 * <li>{$randomEnd$}
 * </ul>
 * <li>
 * there can not be more <b>END</b>-tags than <b>FOR</b>-tags, and vise versa.
 * </ul>
 * <li><b>=</b>
 * <ul>
 * <li>prototype of this tag: {$= you can type here what ever you want, and as
 * much as you want $}
 * <li><b>=</b>-tag does not need to be closed with <b>END</b>-tag.
 * <li>this tag can consist of:
 * <ul>
 * <li>strings: sequence of characters that is bounded with "
 * <li>functions: string that begins with <code>@</code> (read section
 * "Functions and Variables")
 * <li>variables
 * <li>numbers: e.g. 2, 3.14159, 17.07 etc.
 * <li>operators: *, /, +, -
 * </ul>
 * </ul>
 * </ul>
 * </ul> <b>Text</b><br>
 * &nbsp&nbsp&nbsp&nbspText is everything that is not a tag.<br>
 * <code>\{</code> is treated as <code>{</code>. <br>
 * <br>
 * <b>Functions and Variables</b>
 * <ul>
 * <li>Valid function name starts with @ after which follows a letter and after
 * than can follow zero or more letters, digits or underscores. If function name
 * is not valid, it is invalid.
 * <li>Valid name of variable starts by letter and after follows zero or more
 * letters, digits or underscores. If name is not valid, it is invalid. This
 * variable names are valid: <code>A7_bb</code>, <code>counter</code>,
 * <code>tmp_34</code>; these are not: <code>_a21</code>, <code>32</code>,
 * <code>3s_ee</code> etc.
 * </ul>
 * <b>Example of document construction</b><br>
 * <br>
 * Let this be document that is given to this parser:
 * <ul>
 * <code>This is a first line.<br>{$FOR i 0 10 1$}<br>
 * This line is inside a FOR-tag.<br>
 * This line is also inside FOR-tag.<br>
 * {$= variable * @function "some random string" one_more_variable$}<br>
 * {$FOR j 0 i 1$}<br>
 * Nested tag.<br>
 * {$END$}<br>
 * One loop was closed.<br>
 * {$END$}<br>
 * {$= "now everything is closed"$}<br>
 * Goodbye.<br></code>
 * </ul>
 * <br>
 * The folowing will be constructed:
 * <ul>
 * <li>[Document Node]
 * <ul>
 * <li>[TEXT]
 * <li>[FOR-tag]
 * <ul>
 * <li>[TEXT]
 * <li>[TEXT]
 * <li>[=-tag]
 * <li>[FOR-tag]
 * <ul>
 * <li>[TEXT]
 * </ul>
 * <li>[TEXT]
 * </ul>
 * <li>[=-tag]
 * <li>[TEXT]
 * </ul>
 * </ul>
 * <b>END</b>-tag is not shown nor stored in document construction because it
 * indicates end of <b>FOR</b>-tag.<br>
 * <br>
 * 
 * @author Herman Zvonimir Došilović
 * @version 1.0
 */
public class SmartScriptParser {

	private String docBody;
	private DocumentNode docRoot;
	private int docLength;
	private ObjectStack docStack;

	/**
	 * <b><i>SmartScriptParser</i></b><br>
	 * <br>
	 * <code>&nbsp public SmartScriptParser(String docBody)</code><br>
	 * <br>
	 * Construct new document representation.
	 * 
	 * @param docBody
	 *            - document to parse
	 */
	public SmartScriptParser(String docBody) {
		try {
			this.docBody = "#" + docBody + "#";
			docLength = this.docBody.length() - 1;
			docStack = new ObjectStack();
			docRoot = new DocumentNode();
			docStack.push(docRoot);
			evaluateDocument();
		}
		catch (RuntimeException e) {
			throw e;
		}
	}

	/**
	 * <b></i>tagBegin</i></b><br>
	 * <br>
	 * <code>&nbsp private boolean tagBegin(int index)</code><br>
	 * <br>
	 * Questions if given index its begining of the tag.
	 * 
	 * @param index
	 *            - index of character to question
	 * @return <code>true</code> if this index is begining of new tag
	 */
	private boolean tagBegin(int index) {
		return docBody.charAt(index - 1) != '\\' && docBody.charAt(index) == '{'
				&& docBody.charAt(index + 1) == '$';
	}

	/**
	 * <b><i>evaluateDocument</b></i><br>
	 * <br>
	 * <code>&nbsp private void evaluateDocument()</code><br>
	 * <br>
	 * This method start document analasys.
	 */
	private void evaluateDocument() {

		for (int i = 1; i < docLength; i++) {
			if (tagBegin(i)) {
				try {
					i = addTag(i);
				}
				catch (SmartScriptParserException e) {
					throw e;
				}
			}
			else {
				i = addText(i);
			}
		}
	}

	/**
	 * <b><i>addTag</i></b><br>
	 * <br>
	 * <code>&nbsp private int addTag(int index)</code><br>
	 * <br>
	 * Adds new tag if closing of brackets is valid.
	 * 
	 * @param index
	 *            - index of potentional tag begin
	 * @return end of some new tag
	 * @throws SmartScriptParserException
	 *             if tag is not closed propertly
	 */
	private int addTag(int index) {

		int endOfTag = docBody.indexOf("$}", index + 2);

		if (endOfTag == -1) {
			throw new SmartScriptParserException("Tag did not closed. Invalid tag.");
		}

		detectTag(docBody.substring(index + 2, endOfTag));

		return endOfTag + 1;
	}

	/**
	 * <b><i>detectTag</i></b><br>
	 * <br>
	 * <code>&nbsp private void detectTag(String tagBody)</code><br>
	 * <br>
	 * Detects type of tag used and proceeds with its argument analasys
	 * 
	 * @param tagBody
	 *            - string within tag brackets
	 * @throws SmartScriptParserException
	 *             if invalid tag type
	 */
	private void detectTag(String tagBody) {
		tagBody = tagBody.trim();
		if (tagBody.compareTo("") == 0) {
			throw new SmartScriptParserException("Invalid tag type.");
		}

		if (tagBody.charAt(0) == '=') {
			addEchoTag(tagBody.substring(1));
		}
		else if (tagBody.length() < 3) {
			throw new SmartScriptParserException("Invalid tag type.");
		}
		else if (tagBody.substring(0, 3).toLowerCase().compareTo("for") == 0) {
			addForTag(tagBody.substring(3));
		}
		else if (tagBody.substring(0, 3).toLowerCase().compareTo("end") == 0) {
			addEndTag(tagBody.substring(3));
		}
		else {
			throw new SmartScriptParserException("Invalid tag type.");
		}
	}

	/**
	 * <b><i>checkVariableName</i></b><br>
	 * <br>
	 * <code>&nbsp private void checkVariableName(String variable)</code><br>
	 * <br>
	 * Check whether given variable name is valid. Valid name of variable starts
	 * by letter and after follows zero or more letters, digits or underscores.
	 * If name is not valid, it is invalid. This variable names are valid:
	 * <code>A7_bb</code>, <code>counter</code>, <code>tmp_34</code>; these are
	 * not: <code>_a21</code>, <code>32</code>, <code>3s_ee</code> etc.
	 * 
	 * @param variable
	 *            - variable name to check
	 * @throws SmartScriptParserException
	 *             if variable name is invalid
	 */
	private void checkVariableName(String variable) {
		if (Character.isLetter(variable.charAt(0)) == false) {
			throw new SmartScriptParserException("Invalid name in tag.");
		}
		for (int i = 1; i < variable.length(); i++) {
			if (Character.isLetter(variable.charAt(i)) != true
					&& Character.isDigit(variable.charAt(i)) != true
					&& variable.charAt(i) != '_') {
				throw new SmartScriptParserException("Invalid name in tag.");
			}
		}
	}

	/**
	 * <b><i>nextSubstring</i></b><br>
	 * <br>
	 * <code>&nbsp private String nextSubstring(String original)</code><br>
	 * <br>
	 * Return next substring bounded with ' ' or with " of given string.
	 * 
	 * @param original
	 *            - string which substring needed
	 * @return next substring
	 */
	private String nextSubstring(String original) {
		StringBuilder sb = new StringBuilder();
		if (original.compareTo("") == 0)
			return "";
		if (original.charAt(0) == '\"') {
			sb.append("\"");
			if (original.length() > 1 && original.indexOf("\"", 1) != -1) {
				sb.append(original.substring(1, original.indexOf("\"", 1)));
				sb.append("\"");
			}
		}
		else {
			for (int i = 0; i < original.length() && original.charAt(i) != ' ' && original.charAt(i) != '\n' && original.charAt(i) != '\r'; i++) {
				sb.append(original.charAt(i));
			}
		}
		return sb.toString();
	}

	/**
	 * <b><i>addForTag</i></b><br>
	 * <br>
	 * <code>&nbsp private void addForTag(String forBody)</code><br>
	 * <br>
	 * Adds new <b>FOR</b>-tag if given forBody is valid.
	 * 
	 * @param forBody
	 *            - body(arguments) of <b>FOR</b>-tag
	 * @throws SmartScriptParserException
	 *             if given argument invalid, if <b>FOR</b>-tag is invalid
	 */
	private void addForTag(String forBody) {
		forBody = forBody.trim();
		if (forBody.compareTo("") == 0) {
			throw new SmartScriptParserException("Invalid FOR tag.");
		}

		String variable = nextSubstring(forBody);
		checkVariableName(variable);
		forBody = forBody.substring(variable.length()).trim();

		String startExpression = nextSubstring(forBody);
		forBody = forBody.substring(startExpression.length()).trim();

		String endExpression = nextSubstring(forBody);
		forBody = forBody.substring(endExpression.length()).trim();

		String stepExpression = nextSubstring(forBody);
		forBody = forBody.substring(stepExpression.length()).trim();

		if (startExpression.compareTo("") == 0 || endExpression.compareTo("") == 0
				|| forBody.length() != 0) {
			throw new SmartScriptParserException(
					"Invalid FOR tag. Invalid number of parameters.");
		}

		TokenVariable tokenVariable = new TokenVariable(variable);

		Token tokenStart = getAttributeType(startExpression);

		Token tokenEnd = getAttributeType(endExpression);

		Token tokenStep = stepExpression.compareTo("") == 0 ? null
				: getAttributeType(stepExpression);

		ForLoopNode forNode = new ForLoopNode(tokenVariable, tokenStart, tokenEnd, tokenStep);

		docStack.push(forNode);
		docRoot.addChildNode(forNode);

	}

	/**
	 * <b><i>analizeString</i></b><br>
	 * <br>
	 * <code>&nbsp private String analizeString(String attribute)</code><br>
	 * <br>
	 * Analizes string. Converts:
	 * <ul>
	 * <li>\\ to \
	 * <li>\" to "
	 * <li>\r to ascii(\r) i.e. 13
	 * <li>\n to ascii(\n) i.e. 10
	 * <li>\t to ascii(\t) i.e. 9
	 * </ul>
	 * 
	 * @param attribute
	 *            - string to analize and convert
	 * @return converte string
	 */
	private String analizeString(String attribute) {
		while (attribute.contains("\\\\")) {
			attribute = attribute.replace("\\\\", "\\");
		}
		while (attribute.contains("\\n")) {
			attribute = attribute.replace("\\n", "\n");
		}
		while (attribute.contains("\\r")) {
			attribute = attribute.replace("\\r", "\r");
		}
		while (attribute.contains("\\t")) {
			attribute = attribute.replace("\\t", "\t");
		}
		while (attribute.contains("\\*")) {
			attribute = attribute.replace("\\\"", "\"");
		}
		return attribute;
	}

	/**
	 * <b><i>getAttributeType</i></b><br>
	 * <br>
	 * <code>&nbsp private Token getAttributeType(String attribute)</code><br>
	 * <br>
	 * Return type of Token used by attribute. Possibilities:
	 * <ul>
	 * <li><code>TokenConstantDouble</code>
	 * <li><code>TokenConstantInteger</code>
	 * <li><code>TokenFunction</code>
	 * <li><code>TokenOperator</code>
	 * <li><code>TokenString</code>
	 * <li><code>TokenVariable</code>
	 * </ul>
	 * 
	 * @param attribute
	 *            - attribute to check Token type
	 * @return new Token type
	 */
	private Token getAttributeType(String attribute) {
		if (attribute.charAt(0) == '\"' && attribute.charAt(attribute.length() - 1) == '\"'
				&& attribute.length() != 1) {
			attribute = analizeString(attribute);
			return new TokenString(attribute);
		}
		else if (attribute.charAt(0) == '*' || attribute.charAt(0) == '/'
				|| attribute.charAt(0) == '-' || attribute.charAt(0) == '+') {
			return new TokenOperator(attribute);
		}
		else {
			try {
				return new TokenConstantInteger(Integer.parseInt(attribute));
			}
			catch (NumberFormatException e) {
				try {
					return new TokenConstantDouble(Double.parseDouble(attribute));
				}
				catch (NumberFormatException f) {
					checkVariableName(attribute);
					return new TokenVariable(attribute);
				}
			}
		}
	}

	/**
	 * <b><i>addEchoTag</b></i><br>
	 * <br>
	 * <code>&nbsp private void addEchoTag(String echoBody)</code><br>
	 * <br>
	 * Adds new <b>=</b>-tag if given echoBody is valid.
	 * 
	 * @param echoBody
	 *            - body(arguments) of <b>=</b>-tag
	 */
	private void addEchoTag(String echoBody) {
		ArrayBackedIndexedCollection arrayTokens = new ArrayBackedIndexedCollection();
		String argument;
		echoBody = echoBody.trim();
		while (echoBody.length() != 0) {
			argument = nextSubstring(echoBody);
			echoBody = echoBody.substring(argument.length());
			echoBody = echoBody.trim();

			Token token;
			if (argument.length() == 0) {
				break;
			}
			else if (argument.charAt(0) == '@') {
				checkVariableName(argument.substring(1));
				token = new TokenFunction(argument);
			}
			else {
				token = getAttributeType(argument);
			}
			arrayTokens.add(token);
		}

		Token[] tokens = new Token[arrayTokens.size()];
		for (int i = 0; i < arrayTokens.size(); i++) {
			tokens[i] = (Token) arrayTokens.get(i);
		}

		Node stackTopNode = (Node) docStack.peek();
		stackTopNode.addChildNode(new EchoNode(tokens));
	}

	/**
	 * <b><i>addEndTag</b></i><br>
	 * <br>
	 * <code>&nbsp private void addEndTag(String endBody)</code><br>
	 * <br>
	 * Adds new <b>END</b>-tag if given endBody is valid.
	 * 
	 * @param endBody
	 *            - body(arguments) of <b>END</b>-tag
	 * @throws SmartScriptParserException
	 *             if given argument invalid, if <b>END</b>-tag is invalid
	 */
	private void addEndTag(String endBody) {
		endBody = endBody.trim();
		if (endBody.compareTo("") != 0) {
			throw new SmartScriptParserException("Invalid END tag.");
		}

		if (docStack.peek() instanceof ForLoopNode) {
			docStack.pop();
		}
		else {
			throw new SmartScriptParserException("Invalid END tag position.");
		}
	}

	/**
	 * <b><i>addText</b></i><br>
	 * <br>
	 * <code>&nbsp private void addText(int index)</code><br>
	 * <br>
	 * Adds new text in document tree. Staring point is <code>index</code>.
	 * 
	 * @param index
	 *            - starting point of new text
	 */
	private int addText(int index) {
		int endOfText = index;
		StringBuilder sb = new StringBuilder();

		for (int i = index; i < docLength; i++) {
			if (tagBegin(i)) {
				endOfText = i - 1;
				break;
			}
//			else if (docBody.charAt(i) == '\r') {
//				sb.append("\\r");
//			}
//			else if (docBody.charAt(i) == '\n') {
//				sb.append("\\n");
//			}
//			else if (docBody.charAt(i) == '\t') {
//				sb.append("\\t");
//			}
			else {
				sb.append(docBody.charAt(i));
				endOfText = i;
			}
		}

		Node stackTopNode = (Node) docStack.peek();
		stackTopNode.addChildNode(new TextNode(sb.toString()));
		return endOfText;
	}

	/**
	 * <b><i>getDocumentNode</i></b><br>
	 * <br>
	 * <code>&nbsp public DocumentNode getDocumentNode()</code><br>
	 * <br>
	 * 
	 * @return root node of entire document. Presentation of document.
	 */
	public DocumentNode getDocumentNode() {
		return docRoot;
	}
}
