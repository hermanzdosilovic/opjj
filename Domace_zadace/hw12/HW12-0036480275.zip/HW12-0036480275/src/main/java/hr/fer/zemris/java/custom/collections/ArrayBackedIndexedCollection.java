package hr.fer.zemris.java.custom.collections;

import java.util.Arrays;

/**
 * Implementation of resizable <code>array-backed</code> collection of objects.
 * Permits all elements (duplicates alse), except <code>null</code>.
 * 
 * @author Herman Zvonimir Došilović
 * @version 1.0
 */
public class ArrayBackedIndexedCollection {

	private int size;
	private int capacity;
	private Object[] elements;

	/**
	 * <b><i>ArrayBackedIndexCollection</i></b><br>
	 * <br>
	 * <code>&nbsp public ArrayBackedIndexCollection()</code><br>
	 * <br>
	 * Constructs an empty collection with an initial capacitiy of 16.
	 */
	public ArrayBackedIndexedCollection() {
		this(16);
	}

	/**
	 * <b><i>ArrayBackedIndexedCollection</i></b><br>
	 * <br>
	 * <code>&nbsp public ArrayBackedIndexedCollection(int initialCapacity)</code>
	 * <br>
	 * <br>
	 * Constructs an empty collection with the specified initial capacity.
	 * 
	 * @param initialCapacity
	 *            - the initial capacity of the collection
	 * @throws IllegalArgumentException
	 *             if the specified initial capacity is less than one
	 */
	public ArrayBackedIndexedCollection(int initialCapacity) {
		if (initialCapacity < 1) {
			throw new IllegalArgumentException(
					"Initial capacity must be greater or equal to 1.");
		}
		capacity = initialCapacity;
		elements = new Object[initialCapacity];
	}

	/**
	 * <b><i>isEmpty</i></b><br>
	 * <br>
	 * <code>&nbsp public boolean isEmpty()</code><br>
	 * <br>
	 * Returns <code>true</code> if this collection contains no objects.
	 * 
	 * @return <code>true</code> if this collection contains no objects,
	 *         <code>false</code> otherwise.
	 */
	public boolean isEmpty() {
		if (size == 0) {
			return true;
		}
		else {
			return false;
		}
	}

	/**
	 * <b><i>size</i></b><br>
	 * <br>
	 * <code>&nbsp public int size()</code><br>
	 * <br>
	 * Returns the number of objects in this collection.
	 * 
	 * @return the number of objects in this collection.
	 */
	public int size() {
		return size;
	}

	/**
	 * <b><i>add</i></b><br>
	 * <br>
	 * <code>&nbsp public void add(Object value)</code><br>
	 * <br>
	 * Appends the element to the end of this collection.
	 * 
	 * @param value
	 *            - element to be appended to this collection
	 * @throws IllegalArgumentException
	 *             if the specified value is <code>null</code>.
	 */
	public void add(Object value) {
		if (value == null) {
			throw new IllegalArgumentException("Object cannot be null.");
		}

		ensureCapacity();

		size++;
		elements[size - 1] = value;
	}

	/**
	 * <b><i>ensureCapacity</i></b><br>
	 * <br>
	 * <code>&nbsp public void ensureCapacity()</code><br>
	 * <br>
	 * Reallocates array <code>elements</code> if needed by doubling its size.
	 * 
	 * @throws NegativeArraySizeException
	 *             if the current array capacity is negative
	 * @throws NullPointerException
	 *             if given array is null
	 */
	private void ensureCapacity() {
		if (size + 1 > capacity) {
			Object[] newArray;

			try {
				newArray = Arrays.copyOf(elements, 2 * capacity);
			}
			catch (NegativeArraySizeException exception) {
				throw exception;
			}
			catch (NullPointerException exception) {
				throw exception;
			}

			elements = newArray;
			capacity *= 2;
		}
	}

	/**
	 * <b><i>get</i></b><br>
	 * <br>
	 * <code>&nbsp public Object get(int index)</code><br>
	 * <br>
	 * Returns the element at the specified position in this collection.
	 * 
	 * @param index
	 *            - index of the element to return
	 * @return the element at the specified position in this collection.
	 * @throws IndexOutOfBoundsException
	 *             if given <code>index</code> is out of range (
	 *             <code>index < 0 || index >= size()</code>)
	 */
	public Object get(int index) {
		if (index < 0 || index >= size) {
			throw new IndexOutOfBoundsException("No object at " + index + ".");
		}
		else {
			return elements[index];
		}
	}

	/**
	 * <b><i>remove</i></b><br>
	 * <br>
	 * <code>&nbsp public void remove(int index)</code><br>
	 * <br>
	 * Removes the element at specified position in this collection. Shifts any
	 * subsequent elements to the left (substracts one from their indices).
	 * 
	 * @param index
	 *            - the index of the element to be removed
	 * @throws IndexOutOfBoundsException
	 *             if given <code>index</code> is out of range (
	 *             <code>index < 0 || index >= size()</code>)
	 */
	public void remove(int index) {
		if (index < 0 || index >= size) {
			throw new IndexOutOfBoundsException("No object at " + index + ".");
		}
		for (int i = index; i < size - 1; i++) {
			elements[i] = elements[i + 1];
		}
		elements[size - 1] = null;
		size--;
	}

	/**
	 * <b><i>insert</i></b><br>
	 * <br>
	 * <code>&nbsp public void insert(Object value, int position)</code><br>
	 * <br>
	 * Inserts the element to the specified position it this collection
	 * 
	 * @param value
	 *            - element to be inserted in this collection
	 * @param position
	 *            - index at which the specified element is to be inserted
	 * @throws IndexOutOfBoundsException
	 *             if given <code>index</code> is out of range (
	 *             <code>index < 0 || index > size()</code>)
	 * @throws NullPointerException
	 *             if given element is <code>null</code>
	 */
	public void insert(Object value, int position) {
		if (position < 0 || position > size) {
			throw new IndexOutOfBoundsException("Element cannot be added at position "
					+ position + ".");
		}
		if (value == null) {
			throw new NullPointerException("null cannot be added in this collection.");
		}

		ensureCapacity();

		size++;
		for (int i = size - 1; i > position; i--) {
			elements[i] = elements[i - 1];
		}
		elements[position] = value;
	}

	/**
	 * <b><i>indexOf</i></b><br>
	 * <br>
	 * <code>&nbsp public in indexOf(Object value)</code><br>
	 * <br>
	 * Returns the index of the first occurrence of the specified element in
	 * this collection, or -1 if this collection does not contain element.
	 * 
	 * @param value
	 *            - element to search for
	 * @return the index of the first occurrence of the specified element in
	 *         this list, or -1 if this list does not contain the element
	 * @throws NullPointerException
	 *             if given element is null
	 */
	public int indexOf(Object value) {
		if (value == null) {
			throw new NullPointerException("This collection does not permit null elements.");
		}
		for (int i = 0; i < size; i++) {
			if (value.equals(elements[i])) {
				return i; // Element is found on position i. Return that
							// position.
			}
		}
		return -1; // No such element in this collection.
	}

	/**
	 * <b><i>contains</i></b><br>
	 * <br>
	 * <code>&nbsp public boolean contains(Object value)</code><br>
	 * <br>
	 * Returns <code>true</code> if this collection contains the specified
	 * element.
	 * 
	 * @param value
	 *            - element whose presence in this collection is to be tested
	 * @return <code>true</code> if this collection contains the specified
	 *         element
	 * @throws NullPointerException
	 *             if given element is null
	 */
	public boolean contains(Object value) {
		if (value == null) {
			throw new NullPointerException("This collection does not permit null elements.");
		}
		for (int i = 0; i < size; i++) {
			if (value.equals(elements[i])) {
				return true; // Element is found.
			}
		}
		return false; // No such element in this collection.
	}

	/**
	 * <b><i>clear</i></b><br>
	 * <br>
	 * <code>&nbsp public void clear()</code><br>
	 * <br>
	 * Removes all of the elements from this collection (optional operation).
	 * The collection will be empty after this method returns.
	 */
	public void clear() {
		for (int i = 0; i < size; i++) {
			elements[i] = null;
		}
		size = 0;
	}
}
