package hr.fer.zemris.java.custom.collections;

/**
 * The <code>ObjectStack</code> class represents a last-in-first-out (LIFO)
 * stack of objects. The usual <code>push</code> and <code>pop</code> operations
 * are provided, as well as a method to <code>peek</code> at the top item on the
 * stack, and a method to test whether the stack is <code>isEmpty</code>.<br>
 * When stack is first created, it contains no items. Permits all objects,
 * except <code>null</code>.
 * 
 * @author Herman Zvonimir Došilović
 * @version 1.0
 */
public class ObjectStack {

	private ArrayBackedIndexedCollection stackAdapter;

	/**
	 * <b><i>ObjectStack</i></b><br>
	 * <br>
	 * <code>&nbsp public ObjectStack()</code><br>
	 * <br>
	 * Creates an empty Stack.
	 */
	public ObjectStack() {
		stackAdapter = new ArrayBackedIndexedCollection();
	}

	/**
	 * <b><i>isEmpty</i></b><br>
	 * <br>
	 * <code>&nbsp public boolean isEmpty()</code><br>
	 * <br>
	 * Tests if this stack is empty.
	 * 
	 * @return <code>true</code> if and only if this stack contains no items;
	 *         <code>false</code> otherwise.
	 */
	public boolean isEmpty() {
		return stackAdapter.isEmpty();
	}

	/**
	 * <b><i>size</i></b><br>
	 * <br>
	 * <code>&nbsp public int size()</code><br>
	 * <br>
	 * Returns the number of objects in this stack.
	 * 
	 * @return the number of objects in this stack.
	 */
	public int size() {
		return stackAdapter.size();
	}

	/**
	 * <b><i>push</i></b><br>
	 * <br>
	 * <code>&nbsp public void push(Object value)</code><br>
	 * <br>
	 * Pushes given object on the stack.
	 * 
	 * @param value
	 *            - object to be pushed on the stack
	 * @throws IllegalArgumentException
	 *             if the specified value is <code>null</code>.
	 */
	public void push(Object value) {
		if (value == null) {
			throw new IllegalArgumentException("Object cannot be null.");
		}

		/*
		 * This won't cause exception in ArrayBackedIndexedCollection class
		 * because of IllegalArgumentException which this method provides.
		 */
		stackAdapter.add(value);
	}

	/**
	 * <b><i>pop</i></b><br>
	 * <br>
	 * <code>&nbsp public Object pop()</code><br>
	 * <br>
	 * Removes last value pushed on stack and returns it.
	 * 
	 * @return last value pushed on stack
	 * @throws EmptyStackException
	 *             if stack contains no elements
	 */
	public Object pop() {
		int stackSize = stackAdapter.size();

		if (stackSize == 0) {
			throw new EmptyStackException("Pop is not allowed. Stack is empty.");
		}

		/*
		 * This won't cause exception in ArrayBackedIndexedCollection class
		 * because of EmptyStackException which this method provides.
		 */
		Object topOfStack = stackAdapter.get(stackSize - 1);
		stackAdapter.remove(stackSize - 1); // remove top of stack element

		return topOfStack; // return remembered top of stack element
	}

	/**
	 * <b><i>peek</i></b><br>
	 * <br>
	 * <code>&nbsp public Object peek()</code><br>
	 * <br>
	 * Return last element placed on stack but does not deletes it from stack.
	 * 
	 * @return last element placed on stack
	 * @throws EmptyStackException
	 *             if stack contains no elements
	 */
	public Object peek() {
		int stackSize = stackAdapter.size();

		if (stackSize == 0) {
			throw new EmptyStackException("Cannot peek in empty stack.");
		}

		/*
		 * Return top of stack element. This won't cause exception in
		 * ArrayBackedIndexedCollection class because of EmptyStackException
		 * which this method provides.
		 */
		return stackAdapter.get(stackSize - 1);
	}

	/**
	 * <b><i>clear</i></b><br>
	 * <br>
	 * <code>&nbsp public void clear()</code><br>
	 * <br>
	 * Removes all elements from stack.
	 */
	public void clear() {
		stackAdapter.clear();
	}
}
