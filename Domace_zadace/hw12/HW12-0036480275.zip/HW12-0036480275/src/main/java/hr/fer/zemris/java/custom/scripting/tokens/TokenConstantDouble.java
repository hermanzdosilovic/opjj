package hr.fer.zemris.java.custom.scripting.tokens;

/**
 * <code>TokenConstantDouble</code> class represent token that contains constant
 * <b><code>double</code></b>.
 * 
 * @author Herman Zvonimir Došilović
 * @version 1.0
 */
public class TokenConstantDouble extends Token {

	private double value;

	/**
	 * <b><i>TokenConstantDouble</i></b><br>
	 * <br>
	 * <code>&nbsp public TokenConstantDouble(double value)</code><br>
	 * <br>
	 * Constructs new token that contains constant <b><code>double</b></code>.
	 * 
	 * @param value
	 *            - constant <b><code>double</b></code> that this token will
	 *            contain
	 */
	public TokenConstantDouble(double value) {
		this.value = value;
	}

	/**
	 * <b><i>asText</i></b><br>
	 * <br>
	 * <code>&nbsp public String asText()</code><br>
	 * <br>
	 * 
	 * @return string represenation of constant <b><code>double</b></code> that
	 *         this token contains
	 */
	@Override
	public String asText() {
		return Double.toString(value);
	}

	/**
	 * <b><i>getValue</i></b><br>
	 * <br>
	 * <code>&nbsp public double getValue()</code><br>
	 * <br>
	 * 
	 * @return constant <b><code>double</b></code> that this token contains
	 */
	public double getValue() {
		return value;
	}
}
