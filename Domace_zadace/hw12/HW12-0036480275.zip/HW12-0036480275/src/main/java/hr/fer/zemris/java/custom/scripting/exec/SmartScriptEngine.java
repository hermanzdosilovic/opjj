package hr.fer.zemris.java.custom.scripting.exec;

import hr.fer.zemris.java.custom.scripting.nodes.DocumentNode;
import hr.fer.zemris.java.custom.scripting.nodes.EchoNode;
import hr.fer.zemris.java.custom.scripting.nodes.ForLoopNode;
import hr.fer.zemris.java.custom.scripting.nodes.INodeVisitor;
import hr.fer.zemris.java.custom.scripting.nodes.TextNode;
import hr.fer.zemris.java.custom.scripting.tokens.Token;
import hr.fer.zemris.java.custom.scripting.tokens.TokenConstantDouble;
import hr.fer.zemris.java.custom.scripting.tokens.TokenConstantInteger;
import hr.fer.zemris.java.custom.scripting.tokens.TokenFunction;
import hr.fer.zemris.java.custom.scripting.tokens.TokenOperator;
import hr.fer.zemris.java.custom.scripting.tokens.TokenString;
import hr.fer.zemris.java.custom.scripting.tokens.TokenVariable;
import hr.fer.zemris.java.webserver.RequestContext;

import java.text.DecimalFormat;
import java.util.Stack;

public class SmartScriptEngine {

	private DocumentNode documentNode;
	private RequestContext requestContext;
	private ObjectMultistack multistack = new ObjectMultistack();

	public SmartScriptEngine(DocumentNode documentNode, RequestContext requestContext) {
		this.documentNode = documentNode;
		this.requestContext = requestContext;
	}

	public void execute() {
		documentNode.accept(visitor);
	}

	private INodeVisitor visitor = new INodeVisitor() {

		@Override
		public void visitTextNode(TextNode node) {
			requestContext.write(node.getText());
		}

		@Override
		public void visitForLoopNode(ForLoopNode node) {
			multistack.push(node.getVariable().asText(),
			        new ValueWrapper(Integer.parseInt(node.getStartExpression().asText())));
			ValueWrapper value = multistack.peek(node.getVariable().asText());
			if (value.numCompare(Integer.parseInt(node.getEndExpression().asText())) < 0) {
				while (true) {
					value = multistack.peek(node.getVariable().asText());
					multistack.pop(node.getVariable().asText());
					multistack.push(node.getVariable().asText(), value);
					for (int i = 0; i < node.numberOfChildren(); i++) {
						node.getChild(i).accept(this);
					}
					value.increment(Integer.parseInt(node.getStepExpression().asText()));
					if (value.numCompare(Integer.parseInt(node.getEndExpression().asText())) > 0) {
						break;
					}
				}
				multistack.pop(node.getVariable().asText());
			}

		}

		@Override
		public void visitEchoNode(EchoNode node) {
			Stack<Object> temporaryStack = new Stack<>();
			Token[] token = node.getTokens();
			for (int i = 0; i < token.length; i++) {
				if (token[i] instanceof TokenConstantDouble) {
					temporaryStack.push(new ValueWrapper(Double.parseDouble(token[i].asText())));
				} else if (token[i] instanceof TokenConstantInteger) {
					temporaryStack.push(new ValueWrapper(Integer.parseInt(token[i].asText())));
				} else if (token[i] instanceof TokenString) {
					temporaryStack.push(token[i].asText().replace("\"", ""));
				} else if (token[i] instanceof TokenVariable) {
					ValueWrapper value = new ValueWrapper(multistack.peek(token[i].asText()).getValue());
					temporaryStack.push(value);
				} else if (token[i] instanceof TokenOperator) {
					ValueWrapper value = doOperation((ValueWrapper) temporaryStack.pop(),
					        (ValueWrapper) temporaryStack.pop(), token[i].asText());
					temporaryStack.push(value);
				} else if (token[i] instanceof TokenFunction) {
					String function = token[i].asText();
					ValueWrapper value1;
					ValueWrapper value2;
					if ("@sin".equals(function)) {
						value1 = (ValueWrapper) temporaryStack.pop();
						value1.setValue(Math.sin(Math.toRadians(Double.parseDouble(value1.getValue().toString()))));
						temporaryStack.push(value1);
					
					} else if ("@decfmt".equals(function)) {
						String format = (String) temporaryStack.pop();
						DecimalFormat decfmt = new DecimalFormat(format);
						value1 = (ValueWrapper) temporaryStack.pop();
						value1.setValue(decfmt.format(Double.parseDouble(value1.getValue().toString())).replace(",",
						        "."));
						temporaryStack.push(value1);
					
					} else if ("@dup".equals(function)) {
						Object o = temporaryStack.pop();
						if (o instanceof ValueWrapper) {
							ValueWrapper value = (ValueWrapper) o;
							ValueWrapper valueCopy = new ValueWrapper(value.getValue().toString());
							temporaryStack.push(value);
							temporaryStack.push(valueCopy);
						} else {
							String value = (String) o;
							String valueCopy = new String(value);
							temporaryStack.push(value);
							temporaryStack.push(valueCopy);
						}
					
					} else if ("@swap".equals(function)) {
						value1 = (ValueWrapper) temporaryStack.pop();
						value2 = (ValueWrapper) temporaryStack.pop();
						temporaryStack.push(value1);
						temporaryStack.push(value2);
					
					} else if ("@setMimeType".equals(function)) {
						String mimeType = (String) temporaryStack.pop();
						requestContext.setMimeType(mimeType);
					
					} else if ("@paramGet".equals(function)) {
						ValueWrapper dv = (ValueWrapper) temporaryStack.pop();
						String name = (String) temporaryStack.pop();
						String value = requestContext.getParameter(name);
						temporaryStack.push(value == null ? dv : new ValueWrapper(value));
					
					} else if ("@pparamGet".equals(function)) {
						ValueWrapper dv;
						if(temporaryStack.peek() instanceof String) {
							dv = new ValueWrapper(temporaryStack.pop());
						}
						else {
							dv = (ValueWrapper)temporaryStack.pop();
						}
						String name = (String) temporaryStack.pop();
						String value = requestContext.getPersistentParameter(name);
						temporaryStack.push(value == null ? dv : new ValueWrapper(value));
					
					} else if ("@pparamSet".equals(function)) {
						String name;
						if(temporaryStack.peek() instanceof ValueWrapper) {
							name = (String)((ValueWrapper)(temporaryStack.pop())).getValue().toString();
						}
						else {
							name = (String)temporaryStack.pop();
						}
						String value;
						if(temporaryStack.peek() instanceof ValueWrapper) {
							value = (String)((ValueWrapper)(temporaryStack.pop())).getValue().toString();
						}
						else {
							value = (String)temporaryStack.pop();
						}
						requestContext.setPersistentParameter(name, value);
					
					} else if ("@pparamDel".equals(function)) {
						String name;
						if(temporaryStack.peek() instanceof ValueWrapper) {
							name = (String)((ValueWrapper)(temporaryStack.pop())).getValue().toString();
						}
						else {
							name = (String)temporaryStack.pop();
						}
						requestContext.getPersistentParameters().remove(name);
					
					} else if ("@tparamGet".equals(function)) {
						ValueWrapper dv;
						if(temporaryStack.peek() instanceof String) {
							dv = new ValueWrapper(temporaryStack.pop());
						}
						else {
							dv = (ValueWrapper)temporaryStack.pop();
						}
						String name = (String) temporaryStack.pop();
						String value = requestContext.getTemporaryParameter(name);
						temporaryStack.push(value == null ? dv : new ValueWrapper(value));
					
					} else if ("@tparamSet".equals(function)) {
						String name;
						if(temporaryStack.peek() instanceof ValueWrapper) {
							name = (String)((ValueWrapper)(temporaryStack.pop())).getValue().toString();
						}
						else {
							name = (String)temporaryStack.pop();
						}
						String value;
						if(temporaryStack.peek() instanceof ValueWrapper) {
							value = (String)((ValueWrapper)(temporaryStack.pop())).getValue().toString();
						}
						else {
							value = (String)temporaryStack.pop();
						}
						requestContext.setTemporaryParameter(name, value);
					
					} else if ("@tparamDel".equals(function)) {
						String name;
						if(temporaryStack.peek() instanceof ValueWrapper) {
							name = (String)((ValueWrapper)(temporaryStack.pop())).getValue().toString();
						}
						else {
							name = (String)temporaryStack.pop();
						}
						requestContext.getTemporaryParameters().remove(name);
					}
				}
			}
			Stack<String> listString = new Stack<>();
			while (!temporaryStack.isEmpty()) {
				listString.push(temporaryStack.pop().toString());
			}
			while (!listString.isEmpty()) {
				requestContext.write(listString.pop());
			}
		}

		private ValueWrapper doOperation(ValueWrapper value1, ValueWrapper value2, String operator) {
			if ("+".equals(operator)) {
				value1.increment(value2.getValue());
			} else if ("-".equals(operator)) {
				value1.decrement(value2.getValue());
			} else if ("/".equals(operator)) {
				value1.divide(value2.getValue());
			} else if ("*".equals(operator)) {
				value1.multiply(value2.getValue());
			}
			return value1;
		}

		@Override
		public void visitDocumentNode(DocumentNode node) {
			for (int i = 0; i < node.numberOfChildren(); i++) {
				node.getChild(i).accept(this);
			}
		}
	};

}
