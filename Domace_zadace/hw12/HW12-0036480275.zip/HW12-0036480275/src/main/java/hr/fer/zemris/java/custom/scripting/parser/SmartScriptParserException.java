package hr.fer.zemris.java.custom.scripting.parser;

/**
 * <code>SmartScriptParserException</code> is a class used for exceptions that
 * <code>SmartScriptParser</code> can throw.
 * 
 * @author Herman Zvonimir Došilović
 * @version 1.0
 */
public class SmartScriptParserException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	/**
	 * <b><i>SmartScriptParserException</b></i><br>
	 * <br>
	 * <code>&nbsp public SmartScriptParserException(String message)</code><br>
	 * <br>
	 * 
	 * @param message
	 *            - message that describes exception
	 */
	public SmartScriptParserException(String message) {
		super(message);
	}

	/**
	 * <b><i>SmartScriptParserException</b></i><br>
	 * <br>
	 * <code>&nbsp public SmartScriptParserException(Throwable cause)</code><br>
	 * <br>
	 * 
	 * @param cause
	 *            - cause of exception
	 */
	public SmartScriptParserException(Throwable cause) {
		super(cause);
	}
}
