package hr.fer.zemris.java.custom.scripting.demo;

import hr.fer.zemris.java.custom.scripting.nodes.WriterVisitor;
import hr.fer.zemris.java.custom.scripting.parser.SmartScriptParser;

import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;

public class TreeWriter {

	public static void main(String[] args) throws IOException {
		if (args.length != 1) {
			System.out.println("Program očekuje jedan argument, put do smartScript datoteke.");
			System.exit(-1);
		}
		List<String> allLines = Files.readAllLines(Paths.get(args[0]), Charset.forName("UTF-8"));
		StringBuilder docBody = new StringBuilder();
		for (String line : allLines) {
			docBody.append(line + "\n");
		}
		SmartScriptParser p = new SmartScriptParser(docBody.toString());
		WriterVisitor visitor = new WriterVisitor();
		p.getDocumentNode().accept(visitor);
	}

}
