package hr.fer.zemris.java.webserver.workers;

import hr.fer.zemris.java.webserver.IWebWorker;
import hr.fer.zemris.java.webserver.RequestContext;

public class EchoParams implements IWebWorker {

	@Override
	public void processRequest(RequestContext context) {
		for(String key : context.getParameters().keySet()) {
			context.write(key + " " + context.getParameter(key) + "\n");
		}
	}

}
