package hr.fer.zemris.java.webserver;

import hr.fer.zemris.java.custom.scripting.exec.SmartScriptEngine;
import hr.fer.zemris.java.custom.scripting.parser.SmartScriptParser;
import hr.fer.zemris.java.webserver.RequestContext.RCCookie;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PushbackInputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.InvalidPathException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Random;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class SmartHttpServer {

	private String address;
	private int port;
	private int workerThreads;
	private int sessionTimeout;
	private Map<String, String> mimeTypes = new HashMap<String, String>();
	private ServerThread serverThread;
	private ExecutorService threadPool;
	private Path documentRoot;
	private Map<String, IWebWorker> workersMap = new HashMap<String, IWebWorker>();
	private Map<String, SessionMapEntry> sessions = new HashMap<String, SmartHttpServer.SessionMapEntry>();
	private Random sessionRandom = new Random();

	public static void main(String[] args) throws FileNotFoundException, IOException {
		if (args.length != 1) {
			System.out.println("Server expects one argument. Path to server properties file.");
			System.exit(-1);
		}
		new SmartHttpServer(args[0]).start();
	}

	public SmartHttpServer(String configFileName) throws FileNotFoundException, IOException {
		Properties properties = new Properties();
		properties.load(new InputStreamReader(new FileInputStream(configFileName), StandardCharsets.UTF_8));
		address = properties.getProperty("server.address");
		port = Integer.parseInt(properties.getProperty("server.port"));
		workerThreads = Integer.parseInt(properties.getProperty("server.workerThreads"));
		documentRoot = Paths.get(properties.getProperty("server.documentRoot"));
		sessionTimeout = Integer.parseInt(properties.getProperty("session.timeout"));
		String mimeConfig = properties.getProperty("server.mimeConfig");
		String workersConfig = properties.getProperty("server.workers");

		properties.clear();
		properties.load(new InputStreamReader(new FileInputStream(mimeConfig), StandardCharsets.UTF_8));
		for (Object key : properties.keySet()) {
			String keyString = (String) key;
			mimeTypes.put(keyString, properties.getProperty(keyString));
		}

		properties.clear();
		properties.load(new InputStreamReader(new FileInputStream(workersConfig), StandardCharsets.UTF_8));
		for (Object key : properties.keySet()) {
			String path = (String) key;
			String classPath = properties.getProperty(path);
			try {
				Class<?> referenceToClass = this.getClass().getClassLoader().loadClass(classPath);
				Object newObject = referenceToClass.newInstance();
				IWebWorker iww = (IWebWorker) newObject;
				workersMap.put(path, iww);
			} catch (ClassNotFoundException | InstantiationException | IllegalAccessException e) {
				e.printStackTrace();
			}
		}
	}

	protected synchronized void start() {
		if (serverThread == null) {
			serverThread = new ServerThread();
		}
		if (serverThread.isAlive()) {
			return;
		}
		serverThread.start();
		threadPool = Executors.newFixedThreadPool(workerThreads);
		// … start server thread if not already running …
		// … init threadpool by Executors.newFixedThreadPool(...); …
	}

	protected synchronized void stop() {
		serverThread.interrupt();
		threadPool.shutdown();
		// … signal server thread to stop running …
		// … shutdown threadpool …
	}

	private static class SessionMapEntry {
		String sid;
		long validUntil;
		Map<String, String> map;

		public SessionMapEntry(String sid, long validUntil) {
			super();
			this.sid = sid;
			this.validUntil = validUntil;
			map = new ConcurrentHashMap<>();
		}

		@SuppressWarnings("unused")
        public String getSid() {
			return sid;
		}

		@SuppressWarnings("unused")
        public void setSid(String sid) {
			this.sid = sid;
		}

		public long getValidUntil() {
			return validUntil;
		}

		public void setValidUntil(long validUntil) {
			this.validUntil = validUntil;
		}

		public Map<String, String> getMap() {
			return map;
		}

		@SuppressWarnings("unused")
        public void setMap(Map<String, String> map) {
			this.map = map;
		}
	}

	protected class ServerThread extends Thread {

		@Override
		public void run() {
			// given in pesudo-code:
			// open serverSocket on specified port
			// while(true) {
			// Socket client = serverSocket.accept();
			// ClientWorker cw = new ClientWorker(client);
			// submit cw to threadpool for execution
			// }
			try {
				@SuppressWarnings("resource")
                ServerSocket ssocket = new ServerSocket(port);

				while (true) {
					Socket client = ssocket.accept();
					ClientWorker cw = new ClientWorker(client);
					threadPool.submit(cw);
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	private class ClientWorker implements Runnable {
		private Socket csocket;
		private PushbackInputStream istream;
		private OutputStream ostream;
		private String version;
		private String method;
		private Map<String, String> params = new HashMap<String, String>();
		private Map<String, String> permPrams = null;
		private List<RCCookie> outputCookies = new ArrayList<RequestContext.RCCookie>();

		public ClientWorker(Socket csocket) {
			super();
			this.csocket = csocket;
		}

		@Override
		public void run() {
			try {
				istream = new PushbackInputStream(csocket.getInputStream());
				ostream = csocket.getOutputStream();
			} catch (IOException e) {
				System.out.println("Greška prilikom čitanja istream/ostream.");
				closeClient();
				e.printStackTrace();
			}

			List<String> request = readRequest();
			System.out.println(request);
			
			checkSession(request);
			
			RequestContext rc = new RequestContext(ostream, params, permPrams, outputCookies);
			if (request.isEmpty()) {
				sendError(rc, 400);
				return;
			}

			String firstLine = request.get(0);
			String[] parts = firstLine.split(" ");
			if (parts.length != 3) {
				sendError(rc, 400);
				return;
			}

			method = parts[0];
			String requestedPath = parts[1];
			version = parts[2];

			if (!"GET".equalsIgnoreCase(method)
			        || (!"HTTP/1.0".equalsIgnoreCase(version) && !"HTTP/1.1".equalsIgnoreCase(version))) {
				sendError(rc, 400);
				return;
			}

			int index = requestedPath.indexOf("?");
			String path = requestedPath;
			if (index != -1) {
				path = requestedPath.substring(0, index);
				parseParams(requestedPath.substring(index + 1));
			}

			if (path.startsWith("/ext/")) {
				String className = path.substring(5);

				Class<?> referenceToClass;
				try {
					referenceToClass = this.getClass().getClassLoader()
					        .loadClass("hr.fer.zemris.java.webserver.workers." + className);
				} catch (ClassNotFoundException e) {
					sendError(rc, 404);
					closeClient();
					return;
				}

				Object newObject;
				try {
					newObject = referenceToClass.newInstance();
				} catch (InstantiationException | IllegalAccessException e) {
					sendError(rc, 400);
					closeClient();
					return;
				}
				IWebWorker iww = (IWebWorker) newObject;
				iww.processRequest(rc);
				closeClient();
				return;
			}

			Path realPath;
			try {
				realPath = documentRoot.resolve("." + path);
				String root = documentRoot.toFile().getCanonicalPath();
				String realPathString = realPath.toFile().getCanonicalPath();
				if (!realPathString.startsWith(root)) {
					sendError(rc, 403);
					return;
				}
			} catch (InvalidPathException | IOException e) {
				sendError(rc, 403);
				return;
			}

			if (!Files.exists(realPath) || !Files.isReadable(realPath)) {
				sendError(rc, 404);
				return;
			}

			int dot = realPath.getFileName().toString().lastIndexOf(".");
			if (dot == -1) {
				sendError(rc, 404);
				return;
			}
			String ekstenzija = realPath.getFileName().toString().substring(dot + 1);

			String mimeType = mimeTypes.get(ekstenzija);
			if (mimeType == null) {
				mimeType = "application/octet-stream";
			}

			if ("smscr".equals(ekstenzija)) {
				String docBody;
				try {
					docBody = new String(Files.readAllBytes(realPath), "UTF-8");
					new SmartScriptEngine(new SmartScriptParser(docBody).getDocumentNode(), rc).execute();
				} catch (IOException e) {
					throw new RuntimeException("Error while reading file: " + realPath);
				}
				finally {
					closeClient();
				}
				return;
			}

			rc.setMimeType(mimeType);
			byte[] data;
			try {
				data = Files.readAllBytes(realPath);
				rc.write(data);
			} catch (IOException e) {
				throw new RuntimeException("Error while reading file: " + realPath);
			}
			finally {
				closeClient();
			}

		}

		private void parseParams(String allParameters) {
			String[] parameters = allParameters.split("&");
			for (String parameter : parameters) {
				String[] keyValue = parameter.split("=");
				params.put(keyValue[0], keyValue[1]);
			}
		}

		private void sendError(RequestContext rc, int errorCode) {
			rc.setStatusCode(errorCode);
			rc.write(getStatus(errorCode));
			closeClient();
		}

		private String getStatus(int errorCode) {
			if (errorCode == 400) {
				return "HTTP/1.1 400 Bad Request\r\n";
			} else if (errorCode == 403) {
				return "HTTP/1.1 403 Forbidden\r\n";
			} else if (errorCode == 404) {
				return "HTTP/1.1 404 Not Found\r\n";
			}
			return "HTTP/1.1 " + errorCode + " OK\r\n";
		}
		
		private void checkSession(List<String> request) {
			String sidCandidate = null;
			
			for(String r : request) {
				if(!r.startsWith("Cookie:")) {
					continue;
				}
				String[] cookies = r.substring(7).split(";");
				for(int i = 0; i < cookies.length; ++i) {
					String[] cookie = cookies[i].split("=");
					String name = cookie[0].trim();
					String value = cookie[1].trim().replaceAll("\"", "");
					if("sid".equals(name)) {
						sidCandidate = value;
					}
				}
			}
			
			synchronized(address) {
				if(sidCandidate == null) {
					createSID();
				} else {
					long currentTime = System.currentTimeMillis();
					System.out.println(sidCandidate);
					SessionMapEntry entry = sessions.get(sidCandidate);
					if(entry == null || entry.getValidUntil() < currentTime) {
						sessions.remove(entry);
						createSID();
					} else {
						entry.setValidUntil(currentTime+sessionTimeout);
						permPrams = entry.getMap();
					}
				}
			}
		}

		private void createSID() {
			String sid = "";
			
			for(int i = 0; i < 20; ++i) {
				sid += "ABCDEFGHIJKLMNOPQRSTUVWXYZ".charAt(sessionRandom.nextInt(26));
			}
			
			long validUntil = System.currentTimeMillis() + sessionTimeout;
			SessionMapEntry entry = new SessionMapEntry(sid, validUntil);
			sessions.put(sid, entry);
			outputCookies.add(new RCCookie("sid", sid, sessionTimeout, address, "/"));
			permPrams = entry.getMap();
		}
		
		private List<String> readRequest() {
			List<String> requests = new ArrayList<>();
			BufferedReader reader = new BufferedReader(new InputStreamReader(new BufferedInputStream(istream),
			        StandardCharsets.ISO_8859_1));
			while (true) {
				String line = null;
				try {
					line = reader.readLine();
				} catch (IOException e) {
					System.out.println("Greška prilikom čitanja requesta.");
					e.printStackTrace();
				}
				if (line.isEmpty()) {
					break;
				}
				requests.add(line);
			}
			return requests;
		}

		private void closeClient() {
			try {
				csocket.close();
			} catch (IOException ignorable) {
			}
		}
	}

}
