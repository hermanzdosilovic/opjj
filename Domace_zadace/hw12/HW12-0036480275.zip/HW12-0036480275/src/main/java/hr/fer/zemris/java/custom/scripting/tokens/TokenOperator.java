package hr.fer.zemris.java.custom.scripting.tokens;

/**
 * <code>TokenOperator</code> class represent token that contains operator.
 * Supported operators are:
 * <ul>
 * <li>* - multiplication
 * <li>/ - division
 * <li>+ - addition
 * <li>- - substraction
 * </ul>
 * 
 * @author Herman Zvonimir Došilović
 * @version 1.0
 */
public class TokenOperator extends Token {

	private String symbol;

	/**
	 * <b><i>TokenOperator</i></b><br>
	 * <br>
	 * <code>&nbps public TokenOperator(String symbol)</code><br>
	 * <br>
	 * Constructs new token that contains operator symbol.
	 * 
	 * @param value
	 *            - operator symbol that this token will contain
	 */
	public TokenOperator(String symbol) {
		this.symbol = symbol;
	}

	/**
	 * <b><i>asText</i></b><br>
	 * <br>
	 * <code>&nbsp public String asText()</code><br>
	 * <br>
	 * 
	 * @return string represenation of operator symbol that this token contains
	 */
	@Override
	public String asText() {
		return symbol;
	}

	/**
	 * <b><i>getSymbol</i></b><br>
	 * <br>
	 * <code>&nbsp public String getSymbol()</code><br>
	 * <br>
	 * 
	 * @return operator symbol that this token contains
	 */
	public String getSymbol() {
		return symbol;
	}
}
