package hr.fer.zemris.java.custom.scripting.tokens;

/**
 * <code>Token</code> class is base class that represents token. All other
 * tokens inherits from this class.
 * 
 * @author Herman Zvonimir Došilović
 * @version 1.0
 */
public class Token {

	/**
	 * <b><i>asText</i></b><br>
	 * <br>
	 * <code>&nbsp public String asText()</code><br>
	 * <br>
	 * 
	 * @return empty string
	 */
	public String asText() {
		return "";
	}
}
