package hr.fer.zemris.java.webserver;

import java.io.IOException;
import java.io.OutputStream;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * @author Herman Zvonimir Došilović
 * @version 1.0
 */
public class RequestContext {
	
	/**
	 * @author Herman Zvonimir Došilović
	 * @version 1.0
	 */
	public static class RCCookie {
		
		private String name;
		private String value;
		private String domain;
		private String path;
		private Integer maxAge;

		public RCCookie(String name, String value, Integer maxAge, String domain, String path) {
			this.name = name;
			this.value = value;
			this.domain = domain;
			this.path = path;
			this.maxAge = maxAge;
		}

		public String getName() {
			return name;
		}

		public String getValue() {
			return value;
		}

		public String getDomain() {
			return domain;
		}

		public String getPath() {
			return path;
		}

		public Integer getMaxAge() {
			return maxAge;
		}

	}

	private OutputStream outputStream;
	private Charset charset;
	public String encoding;
	public int statusCode = 200;
	public String statusText = "OK";
	public String mimeType = "text/html";
	private Map<String, String> parameters;
	private Map<String, String> temporaryParameters;
	private Map<String, String> persistentParameters;
	private List<RCCookie> outputCookies;
	private boolean headerGenerated = false;

	public RequestContext(OutputStream outputStream, Map<String, String> parameters,
	        Map<String, String> persistentParameters, List<RCCookie> outputCookies) {
		if (outputStream == null) {
			throw new RuntimeException("output stream cannot be null");
		}
		this.outputStream = outputStream;

		if (parameters == null) {
			this.parameters = new HashMap<>();
		} else {
			this.parameters = parameters;
		}

		if (persistentParameters == null) {
			this.persistentParameters = new HashMap<>();
		} else {
			this.persistentParameters = persistentParameters;
		}

		if (outputCookies == null) {
			this.outputCookies = new ArrayList<>();
		} else {
			this.outputCookies = outputCookies;
		}
		temporaryParameters = new HashMap<>();
		setEncoding("UTF-8");
	}

	public Map<String, String> getParameters() {
		return parameters;
	}

	public Map<String, String> getTemporaryParameters() {
		return temporaryParameters;
	}

	public void setTemporaryParameters(Map<String, String> temporaryParameters) {
		this.temporaryParameters = temporaryParameters;
	}

	public Map<String, String> getPersistentParameters() {
		return persistentParameters;
	}

	public void setPersistentParameters(Map<String, String> persistentParameters) {
		this.persistentParameters = persistentParameters;
	}
	
	public void setPersistentParameter(String name, String value) {
		persistentParameters.put(name, value);
    }
	
	public String getParameter(String name) {
		return parameters.get(name);
	}

	public Set<String> getParameterNames() {
		return new HashSet<>(parameters.keySet());
	}

	public String getPersistentParameter(String name) {
		return persistentParameters.get(name);
	}

	public Set<String> getPersistentParameterNames() {
		return new HashSet<>(persistentParameters.keySet());
	}

	public void removePersistentParameter(String name) {
		persistentParameters.remove(name);
	}

	public String getTemporaryParameter(String name) {
		return temporaryParameters.get(name);
	}

	public Set<String> getTemporaryParameterName() {
		return new HashSet<>(temporaryParameters.keySet());
	}

	public void setTemporaryParameter(String name, String value) {
		temporaryParameters.put(name, value);
	}

	public void removeTemporaryParameter(String name) {
		temporaryParameters.remove(name);
	}

	public void setEncoding(String encoding) {
		if (headerGenerated) {
			throw new RuntimeException("header already generated, no modification allowed");
		}
		this.encoding = encoding;
		setCharset();
	}

	private void setCharset() {
		charset = Charset.forName(encoding);
	}

	public void setMimeType(String mimeType) {
		if (headerGenerated) {
			throw new RuntimeException("header already generated, no modification allowed");
		}
		this.mimeType = mimeType;
	}

	public void setStatusCode(int statusCode) {
		if (headerGenerated) {
			throw new RuntimeException("header already generated, no modification allowed");
		}
		this.statusCode = statusCode;
	}

	public void setStatusText(String statusText) {
		if (headerGenerated) {
			throw new RuntimeException("header already generated, no modification allowed");
		}
		this.statusText = statusText;
	}

	public void addRCCookie(RCCookie rcCookie) {
		outputCookies.add(rcCookie);
	}

	public RequestContext write(byte[] data) {
		if (!headerGenerated) {
			generateHeader();
		}

		try {
			outputStream.write(data);
		} catch (IOException e) {
			throw new RuntimeException("error while writing to stream");
		}

		return this;
	}

	public RequestContext write(String data) {
		return write(data.getBytes(charset));
	}

	private void generateHeader() {
		headerGenerated = true;

		String header = "HTTP/1.1 " + statusCode + " " + statusText + "\r\n" + "Content-Type: " + mimeType;
		if (mimeType.startsWith("text/")) {
			header += "; charset=" + encoding;
		}
		header += "\r\n";

		for (RCCookie cookie : outputCookies) {
			header += "Set-Cookie: " + cookie.getName() + "=\"" + cookie.getValue() + "\"";
			if (cookie.getDomain() != null) {
				header += "; Domain=" + cookie.getDomain();
			}
			if (cookie.getPath() != null) {
				header += "; Path=" + cookie.getPath();
			}
			if (cookie.getMaxAge() != null) {
				header += "; maxAge=" + cookie.getMaxAge();
			}
			header += "\r\n";
		}
		header += "\r\n";

		try {
			outputStream.write(header.getBytes(StandardCharsets.ISO_8859_1));
		} catch (IOException e) {
			throw new RuntimeException("error while writing to stream");
		}
	}

}
