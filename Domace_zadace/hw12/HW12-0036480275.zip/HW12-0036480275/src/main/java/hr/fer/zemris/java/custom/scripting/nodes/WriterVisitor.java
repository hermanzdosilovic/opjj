package hr.fer.zemris.java.custom.scripting.nodes;

public class WriterVisitor implements INodeVisitor {

	@Override
	public void visitTextNode(TextNode node) {
		System.out.println(node.getText());
	}

	@Override
	public void visitForLoopNode(ForLoopNode node) {
		System.out.format("FOR %s %s %s", node.getVariable().asText(), node.getStartExpression().asText(), node.getEndExpression().asText());
		if(node.getStepExpression() != null) {
			System.out.println(" " + node.getStepExpression().asText());
		}
		for(int i = 0; i < node.numberOfChildren(); i++) {
			node.getChild(i).accept(this);
		}
	}

	@Override
	public void visitEchoNode(EchoNode node) {
		System.out.print("ECHO ");
		for(int i = 0; i < node.getTokens().length; i++) {
			System.out.print(node.getTokens()[i].asText() + " ");
		}
		System.out.println();
	}

	@Override
	public void visitDocumentNode(DocumentNode node) {
		for(int i = 0; i < node.numberOfChildren(); i++) {
			node.getChild(i).accept(this);
		}
	}

}
