package hr.fer.zemris.java.custom.scripting.tokens;

/**
 * <code>TokenFunction</code> class represent token that contains function name.
 * Valid function name starts with @ after which follows a letter and after than
 * can follow zero or more letters, digits or underscores. If function name is
 * not valid, it is invalid.
 * 
 * @author Herman Zvonimir Došilović
 * @version 1.0
 */
public class TokenFunction extends Token {

	private String name;

	/**
	 * <b><i>TokenFunction</i></b><br>
	 * <br>
	 * <code>&nbsp public TokenFunction(String name)</code><br>
	 * <br>
	 * Constructs new token that contains constant function name.
	 * 
	 * @param value
	 *            - function name that this token will contain
	 */
	public TokenFunction(String name) {
		this.name = name;
	}

	/**
	 * <b><i>asText</i></b><br>
	 * <br>
	 * <code>&nbsp public String asText()</code><br>
	 * <br>
	 * 
	 * @return string represenation of function name that this token contains
	 */
	@Override
	public String asText() {
		return name;
	}

	/**
	 * <b><i>getName</i></b><br>
	 * <br>
	 * <code>&nbsp public String getName()</code><br>
	 * <br>
	 * 
	 * @return function name that this token contains
	 */
	public String getName() {
		return name;
	}
}
