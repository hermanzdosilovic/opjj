package hr.fer.zemris.web.radionice;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;

public class RadioniceBazaTest {

	@Test
	public void radioiceBazaTest() {
		RadioniceBaza baza = RadioniceBaza.ucitaj("./baza");
		Path d = null;
		try {
			d = Files.createTempDirectory(Paths.get("."), null);
		} catch (IOException e) {
			e.printStackTrace();
		}
		baza.snimi(d.toString());

		RadioniceBaza baza2 = RadioniceBaza.ucitaj(d.toString());
		baza.provijeriIspravnostOpcija();
		baza2.provijeriIspravnostOpcija();

		List<Radionica> rad1 = new ArrayList<>(baza.getRadionice().values());
		List<Radionica> rad2 = new ArrayList<>(baza.getRadionice().values());
		Collections.sort(rad1);
		Collections.sort(rad2);
		if (rad1.size() != rad2.size()) {
			throw new InconsistentDatabaseException();
		}
		for (int i = 0; i < rad1.size(); i++) {
			Assert.assertEquals(rad1.get(i), rad2.get(i));
		}

		File file = new File(d.toUri());
		File[] files = file.listFiles();
		for (File f : files) {
			f.delete();
		}
		file.delete();
	}

	@Test(expected = InconsistentDatabaseException.class)
	public void radioniceBazaTest2() {
		RadioniceBaza baza = RadioniceBaza.ucitaj("./baza");
		Radionica radionica = baza.getRadionice().get("1");
		radionica.getOprema().add(new Opcija("101", "USB stick"));
		Path d = null;
		try {
			d = Files.createTempDirectory(Paths.get("."), null);
		} catch (IOException e) {
			e.printStackTrace();
		}

		try {
			baza.snimi(d.toString());
		}
		finally {
			File file = new File(d.toUri());
			File[] files = file.listFiles();
			for (File f : files) {
				f.delete();
			}
			file.delete();
		}
	}
}
