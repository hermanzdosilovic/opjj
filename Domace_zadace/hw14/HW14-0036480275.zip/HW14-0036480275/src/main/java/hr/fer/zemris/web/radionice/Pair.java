package hr.fer.zemris.web.radionice;

public class Pair implements Comparable<Pair> {

	private Long first;
	private Long second;

	public Pair(Long first, Long second) {
		super();
		this.first = first;
		this.second = second;
	}

	public Long getFirst() {
		return first;
	}

	public void setFirst(Long first) {
		this.first = first;
	}

	public Long getSecond() {
		return second;
	}

	public void setSecond(Long second) {
		this.second = second;
	}

	@Override
    public int compareTo(Pair o) {
		if(this.getFirst().compareTo(o.getFirst()) == 0) {
			return this.getSecond().compareTo(o.getSecond());
		}
	    return this.getFirst().compareTo(o.getFirst());
    }
	
	@Override
	public String toString() {
	    return first + "\t" + second;
	}
}
