package hr.fer.zemris.web.servleti;

import hr.fer.zemris.web.radionice.Opcija;
import hr.fer.zemris.web.radionice.Radionica;
import hr.fer.zemris.web.radionice.RadioniceBaza;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * @author Herman Zvonimir Došilović
 * @version 1.0
 */
@WebServlet("/edit")
public class Edit extends HttpServlet {

	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		if (req.getSession().getAttribute("current.user") == null) {
			req.setAttribute("poruka", "Niste logirani.");
			req.getRequestDispatcher("/WEB-INF/pages/Greska.jsp").forward(req, resp);
			return;
		}

		Long id = null;
		try {
			id = Long.valueOf(req.getParameter("id"));
		} catch (Exception ex) {
			req.setAttribute("poruka", "Primljeni su neispravni parametri.");
			req.getRequestDispatcher("/WEB-INF/pages/Greska.jsp").forward(req, resp);
			return;
		}

		RadioniceBaza baza = RadioniceBaza.ucitaj(req.getServletContext().getRealPath("/WEB-INF/baza"));

		Radionica r = baza.getRadionice().get(id.toString());
		if (r == null) {
			req.setAttribute("poruka", "Traženi zapis ne postoji.");
			req.getRequestDispatcher("/WEB-INF/pages/Greska.jsp").forward(req, resp);
			return;
		}

		FormularForm f = new FormularForm();
		f.popuni(r);
		req.setAttribute("formular", f);

		List<Opcija> oprema = new ArrayList<>();
		for (String key : baza.getOprema().keySet()) {
			oprema.add(new Opcija(key, baza.getOprema().get(key)));
		}
		List<Opcija> publika = new ArrayList<>();
		for (String key : baza.getPublika().keySet()) {
			publika.add(new Opcija(key, baza.getPublika().get(key)));
		}
		List<Opcija> trajanje = new ArrayList<>();
		for (String key : baza.getTrajanje().keySet()) {
			trajanje.add(new Opcija(key, baza.getTrajanje().get(key)));
		}
		req.setAttribute("trajanje", trajanje);
		req.setAttribute("oprema", oprema);
		req.setAttribute("publika", publika);

		req.getRequestDispatcher("/WEB-INF/pages/Formular.jsp").forward(req, resp);
	}

}
