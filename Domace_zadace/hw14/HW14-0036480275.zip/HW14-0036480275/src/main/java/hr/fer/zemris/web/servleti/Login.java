package hr.fer.zemris.web.servleti;

import hr.fer.zemris.web.radionice.User;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * @author Herman Zvonimir Došilović
 * @version 1.0
 */
@WebServlet("/login")
public class Login extends HttpServlet {

	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		req.setAttribute("username", "");
		req.setAttribute("password", "");
		req.getRequestDispatcher("/WEB-INF/pages/Login.jsp").forward(req, resp);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String metoda = req.getParameter("metoda");
		if ("Odustani".equals(metoda)) {
			resp.sendRedirect(req.getServletContext().getContextPath() + "/");
			return;
		}
		
		String username = req.getParameter("username");
		String password = req.getParameter("password");
		
		User korisnik = provjeri(username, password);
		
		if (korisnik == null) {
			req.setAttribute("poruka", "Krivi username ili password.");
			req.setAttribute("username", username);
			req.setAttribute("password", password);
			req.getRequestDispatcher("/WEB-INF/pages/Login.jsp").forward(req, resp);
			return;
		}

		req.getSession().setAttribute("current.user", korisnik);
		resp.sendRedirect(req.getServletContext().getContextPath() + "/");
	}

	private User provjeri(String username, String password) {
		if ("aante".equals(username) && "tajna".equals(password)) {
			return new User("aante", "tajna", "Ante", "Anić");
		}
		return null;
	}
}
