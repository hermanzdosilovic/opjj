package hr.fer.zemris.web.servleti;

import hr.fer.zemris.web.radionice.Opcija;
import hr.fer.zemris.web.radionice.Radionica;
import hr.fer.zemris.web.radionice.RadioniceBaza;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;

/**
 * @author Herman Zvonimir Došilović
 * @version 1.0
 */
public class FormularForm {

	private Long id;
	private String naziv;
	private String datum;
	private Set<Opcija> oprema;
	private Opcija trajanje;
	private Set<Opcija> publika;
	private Integer maxPolaznika;
	private String email;
	private String dopuna;
	private Map<String, String> greske = new HashMap<>();

	public FormularForm() {
		id = (long) 0;
		oprema = new HashSet<>();
		publika = new HashSet<>();
		naziv = "";
		maxPolaznika = 0;
		email = "";
		dopuna = "";
		datum = "";
	}

	public void popuni(Radionica r) {
		id = r.getId();
		naziv = r.getNaziv();
		datum = r.getDatum();
		oprema = r.getOprema();
		trajanje = r.getTrajanje();
		publika = r.getPublika();
		maxPolaznika = r.getMaksPolaznika();
		email = r.getEmail();
		dopuna = r.getDopuna();
	}

	public void popuniIzHttpRequesta(HttpServletRequest req) {
		try {
			this.id = Long.parseLong(pripremi(req.getParameter("id")));
		} catch (NumberFormatException e) {
			id = (long) 0;
		}

		this.naziv = pripremi(req.getParameter("naziv"));
		this.datum = pripremi(req.getParameter("datum"));
		this.email = pripremi(req.getParameter("email"));
		try {
			this.maxPolaznika = Integer.parseInt(pripremi(req.getParameter("makspolaznika")));
		} catch (NumberFormatException e) {
			maxPolaznika = 0;
		}
		this.dopuna = pripremi(req.getParameter("dopuna"));
		this.oprema = new HashSet<>();
		if (req.getParameterValues("_oprema_") != null) {
			for (String o : req.getParameterValues("_oprema_")) {
				String[] opcija = o.split("\t");
				oprema.add(new Opcija(opcija[0], opcija[1]));
			}
		}
		String[] opcija = req.getParameter("_trajanje_").split("\t");
		this.trajanje = new Opcija(opcija[0], opcija[1]);

		publika = new HashSet<>();
		if (req.getParameterValues("_publika_") != null) {
			for (String o : req.getParameterValues("_publika_")) {
				opcija = o.split("\t");
				publika.add(new Opcija(opcija[0], opcija[1]));
			}
		}

	}

	public void validiraj() {
		greske.clear();

		if (this.naziv.isEmpty()) {
			greske.put("naziv", "Naziv je obavezan!");
		}

		if (this.datum.isEmpty()) {
			greske.put("datum", "Datum je obavezan!");
		} else {
			Pattern p = Pattern.compile("^\\d\\d\\d\\d-\\d\\d-\\d\\d$");
			Matcher m = p.matcher(this.datum);
			if (!m.matches()) {
				greske.put("datum", "Neispravan format datuma!");
			}
		}

		if (this.email.isEmpty()) {
			greske.put("email", "E-Mail je obavezan!");
		} else {
			int l = email.length();
			int p = email.indexOf('@');
			if (l < 3 || p == -1 || p == 0 || p == l - 1) {
				greske.put("email", "E-Mail je neispravnog formata!");
			}
		}

		if (maxPolaznika < 10 || maxPolaznika > 50) {
			greske.put("makspolaznika", "Mora biti izmedu 10 i 50!");
		}

//		if (oprema.isEmpty()) {
//			greske.put("oprema", "Odaberite opremu!");
//		}

		if (publika.isEmpty()) {
			greske.put("publika", "Odaberite publiku!");
		}
	}

	private String pripremi(String parameter) {
		if (parameter == null) {
			return "";
		}
		return parameter.trim();
	}

	public boolean imaGresaka() {
		return !greske.isEmpty();
	}

	public boolean imaGreske(String key) {
		return greske.containsKey(key);
	}

	public String dohvatiGresku(String key) {
		return greske.get(key);
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getDatum() {
		return datum;
	}

	public void setDatum(String datum) {
		this.datum = datum;
	}

	public String getNaziv() {
		return naziv;
	}

	public void setNaziv(String naziv) {
		this.naziv = naziv;
	}

	public Set<Opcija> getOprema() {
		return oprema;
	}

	public void setOprema(Set<Opcija> oprema) {
		this.oprema = oprema;
	}

	public Opcija getTrajanje() {
		return trajanje;
	}

	public void setTrajanje(Opcija trajanje) {
		this.trajanje = trajanje;
	}

	public Set<Opcija> getPublika() {
		return publika;
	}

	public void setPublika(Set<Opcija> publika) {
		this.publika = publika;
	}

	public Integer getMaxPolaznika() {
		return maxPolaznika;
	}

	public void setMaxPolaznika(Integer maxPolaznika) {
		this.maxPolaznika = maxPolaznika;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getDopuna() {
		return dopuna;
	}

	public void setDopuna(String dopuna) {
		this.dopuna = dopuna;
	}

	public void popuniURecord(Radionica r, RadioniceBaza baza) {
		r.setNaziv(naziv);
		r.setDatum(datum);
		r.setDopuna(dopuna);
		r.setEmail(email);
		if(id == 0) {
			id = baza.getMaxId() + 1;
			baza.setMaxId(id + 1);
		}
		r.setId(id);
		r.setMaksPolaznika(maxPolaznika);
		r.setOprema(oprema);
		r.setPublika(publika);
		r.setTrajanje(trajanje);
    }

}
