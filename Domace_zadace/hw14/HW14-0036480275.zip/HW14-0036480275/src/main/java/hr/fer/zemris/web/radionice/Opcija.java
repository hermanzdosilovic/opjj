package hr.fer.zemris.web.radionice;

/**
 * @author Herman Zvonimir Došilović
 * @version 1.0
 */
public class Opcija implements Comparable<Opcija> {

	private String id;
	private String vrijednost;

	public Opcija(String id, String vrijednost) {
		try {
			long value = Long.parseLong(id);
			if (value <= 0) {
				throw new RuntimeException("id mora biti pozitivan");
			}
		} catch (NumberFormatException e) {
			throw new RuntimeException("ilegalna vrijednost id-a");
		}
		this.id = id;
		this.vrijednost = vrijednost;
	}

	public String getVrijednost() {
		return vrijednost;
	}

	public void setVrijednost(String vrijednost) {
		this.vrijednost = vrijednost;
	}

	public String getId() {
		return id;
	}

	@Override
	public int compareTo(Opcija o) {
		Long firstID = Long.parseLong(id);
		Long secondID = Long.parseLong(o.getId());
		return firstID.compareTo(secondID);
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((vrijednost == null) ? 0 : vrijednost.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Opcija other = (Opcija) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (vrijednost == null) {
			if (other.vrijednost != null)
				return false;
		} else if (!vrijednost.equals(other.vrijednost))
			return false;
		return true;
	}
	
	@Override
	public String toString() {
	    return "ID: " + id + ", Vrijednost: " + vrijednost;
	}
}
