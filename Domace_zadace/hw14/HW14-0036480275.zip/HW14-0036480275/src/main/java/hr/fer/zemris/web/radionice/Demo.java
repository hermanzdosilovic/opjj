package hr.fer.zemris.web.radionice;

import java.io.IOException;
import java.util.Map;

public class Demo {

	public static void main(String[] args) throws IOException {
		RadioniceBaza baza = RadioniceBaza.ucitaj("./baza");
		baza.snimi(".");
		baza = RadioniceBaza.ucitaj(".");
		Map<String, Radionica> m = baza.getRadionice();
		for (Radionica s : m.values()) {
			System.out.println(s);
			System.out.println("--------------------------------------");
		}
		baza.snimi(".");
		baza.provijeriIspravnostOpcija();
	}

}
