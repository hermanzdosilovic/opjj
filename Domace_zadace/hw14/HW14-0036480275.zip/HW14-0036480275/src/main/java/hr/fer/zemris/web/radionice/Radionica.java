package hr.fer.zemris.web.radionice;

import java.util.HashSet;
import java.util.Set;

/**
 * @author Herman Zvonimir Došilović
 * @version 1.0
 */
public class Radionica implements Comparable<Radionica> {

	Long id;
	String naziv;
	String datum;
	Set<Opcija> oprema;
	Opcija trajanje;
	Set<Opcija> publika;
	Integer maksPolaznika;
	String email;
	String dopuna;

	public Radionica() {
		oprema = new HashSet<>();
		publika = new HashSet<>();
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getNaziv() {
		return naziv;
	}

	public void setNaziv(String naziv) {
		this.naziv = naziv;
	}

	public String getDatum() {
		return datum;
	}

	public void setDatum(String datum) {
		this.datum = datum;
	}

	public Set<Opcija> getOprema() {
		return oprema;
	}

	public void setOprema(Set<Opcija> oprema) {
		if(oprema == null) {
			this.oprema = new HashSet<>();
		}
		else {
			this.oprema = oprema;
		}
	}

	public Opcija getTrajanje() {
		return trajanje;
	}

	public void setTrajanje(Opcija trajanje) {
		this.trajanje = trajanje;
	}

	public Set<Opcija> getPublika() {
		return publika;
	}

	public void setPublika(Set<Opcija> publika) {
		if(publika == null) {
			this.publika = new HashSet<>();
		}
		else {
			this.publika = publika;
		}
	}

	public Integer getMaksPolaznika() {
		return maksPolaznika;
	}

	public void setMaksPolaznika(Integer maksPolaznika) {
		this.maksPolaznika = maksPolaznika;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getDopuna() {
		return dopuna;
	}

	public void setDopuna(String dopuna) {
		this.dopuna = dopuna;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder("");
		sb.append("ID:\t" + id + "\n");
		sb.append("Naziv:\t" + naziv + "\n");
		sb.append("Datum:\t" + datum + "\n");
		sb.append("Oprema:\n");
		for (Opcija o : oprema) {
			sb.append("\t" + o + "\n");
		}
		sb.append("Trajanje:\n\t" + trajanje + "\n");
		sb.append("Publika:\n");
		for (Opcija o : publika) {
			sb.append("\t" + o + "\n");
		}
		sb.append("Maks polaznika:\t" + maksPolaznika + "\n");
		sb.append("Email:\t" + email + "\n");
		sb.append("Dopuna:\n");
		sb.append("\t" + dopuna);

		return sb.toString();
	}

	@Override
	public int compareTo(Radionica o) {
		Long idSecond = o.getId();
		return id.compareTo(idSecond);
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((datum == null) ? 0 : datum.hashCode());
		result = prime * result + ((dopuna == null) ? 0 : dopuna.hashCode());
		result = prime * result + ((email == null) ? 0 : email.hashCode());
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((maksPolaznika == null) ? 0 : maksPolaznika.hashCode());
		result = prime * result + ((naziv == null) ? 0 : naziv.hashCode());
		result = prime * result + ((oprema == null) ? 0 : oprema.hashCode());
		result = prime * result + ((publika == null) ? 0 : publika.hashCode());
		result = prime * result + ((trajanje == null) ? 0 : trajanje.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Radionica other = (Radionica) obj;
		if (datum == null) {
			if (other.datum != null)
				return false;
		} else if (!datum.equals(other.datum))
			return false;
		if (dopuna == null) {
			if (other.dopuna != null)
				return false;
		} else if (!dopuna.equals(other.dopuna))
			return false;
		if (email == null) {
			if (other.email != null)
				return false;
		} else if (!email.equals(other.email))
			return false;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (maksPolaznika == null) {
			if (other.maksPolaznika != null)
				return false;
		} else if (!maksPolaznika.equals(other.maksPolaznika))
			return false;
		if (naziv == null) {
			if (other.naziv != null)
				return false;
		} else if (!naziv.equals(other.naziv))
			return false;
		if (oprema == null) {
			if (other.oprema != null)
				return false;
		} else if (!oprema.equals(other.oprema))
			return false;
		if (publika == null) {
			if (other.publika != null)
				return false;
		} else if (!publika.equals(other.publika))
			return false;
		if (trajanje == null) {
			if (other.trajanje != null)
				return false;
		} else if (!trajanje.equals(other.trajanje))
			return false;
		return true;
	}

}
