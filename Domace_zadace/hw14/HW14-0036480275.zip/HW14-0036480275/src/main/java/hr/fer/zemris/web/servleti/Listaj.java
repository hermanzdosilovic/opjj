package hr.fer.zemris.web.servleti;

import hr.fer.zemris.web.radionice.Radionica;
import hr.fer.zemris.web.radionice.RadioniceBaza;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * @author Herman Zvonimir Došilović
 * @version 1.0
 */
@WebServlet("/listaj")
public class Listaj extends HttpServlet{

    private static final long serialVersionUID = 1L;

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        RadioniceBaza baza = RadioniceBaza.ucitaj(req.getServletContext().getRealPath("/WEB-INF/baza"));
        List<Radionica> list = new ArrayList<>(baza.getRadionice().values());
        Collections.sort(list, new Comparator<Radionica>() {

			@SuppressWarnings("deprecation")
            @Override
            public int compare(Radionica o1, Radionica o2) {
	            if(o1.getDatum().compareTo(o2.getDatum()) == 0) {
	            	return o1.getNaziv().compareTo(o2.getNaziv());
	            }
	            Date d1 = new Date();
	            String dat1 = o1.getDatum();
	            String year = dat1.substring(0, dat1.indexOf('-'));
	            dat1 = dat1.substring(dat1.indexOf('-') + 1);
	            String month = dat1.substring(0, dat1.indexOf('-'));
	            String day = dat1.substring(dat1.indexOf('-') + 1);
	            d1.setYear(Integer.parseInt(year));
	            d1.setMonth(Integer.parseInt(month));
	            d1.setDate(Integer.parseInt(day));
	            
	            Date d2 = new Date();
	            dat1 = o2.getDatum();
	            year = dat1.substring(0, dat1.indexOf('-'));
	            dat1 = dat1.substring(dat1.indexOf('-') + 1);
	            month = dat1.substring(0, dat1.indexOf('-'));
	            day = dat1.substring(dat1.indexOf('-') + 1);
	            d2.setYear(Integer.parseInt(year));
	            d2.setMonth(Integer.parseInt(month));
	            d2.setDate(Integer.parseInt(day));
	            return d1.compareTo(d2);
            }
		});
        
        req.setAttribute("radionice", list);
        req.getRequestDispatcher("/WEB-INF/pages/Listaj.jsp").forward(req, resp);
    }
}
