package hr.fer.zemris.web.radionice;

public class User {

	private String login;
	private String zaporka;
	private String ime;
	private String prezime;

	public User(String login, String zaporka, String ime, String prezime) {
		super();
		this.login = login;
		this.zaporka = zaporka;
		this.ime = ime;
		this.prezime = prezime;
	}

	public String getLogin() {
		return login;
	}

	public void setLogin(String login) {
		this.login = login;
	}

	public String getZaporka() {
		return zaporka;
	}

	public void setZaporka(String zaporka) {
		this.zaporka = zaporka;
	}

	public String getIme() {
		return ime;
	}

	public void setIme(String ime) {
		this.ime = ime;
	}

	public String getPrezime() {
		return prezime;
	}

	public void setPrezime(String prezime) {
		this.prezime = prezime;
	}
	
	@Override
	public String toString() {
	    return ime + " " + prezime;
	}
}
