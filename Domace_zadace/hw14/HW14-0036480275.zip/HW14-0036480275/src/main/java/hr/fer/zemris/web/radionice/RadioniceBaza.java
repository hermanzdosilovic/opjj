package hr.fer.zemris.web.radionice;

import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Razred predstavlja bazu podataka radionice.
 * @author Herman Zvonimir Došilović
 * @version 1.0
 */
public class RadioniceBaza {

	/** Vršni direktorij baze podataka radionice. */
	private String direktorij;

	private Map<String, String> oprema;

	private Map<String, String> trajanje;

	private Map<String, String> publika;

	private Map<String, Radionica> radionice;

	private Map<String, Set<Opcija>> radioniceOprema;

	private Map<String, Set<Opcija>> radionicePublika;

	private Long maxId = (long) 1;

	/**
	 * Konstruktor baze podataka radionice.
	 * @param direktorij vršni direktorij baze podataka radionice.
	 */
	private RadioniceBaza(String direktorij) {
		this.direktorij = direktorij;
		oprema = new HashMap<>();
		trajanje = new HashMap<>();
		publika = new HashMap<>();
		radionice = new HashMap<>();
		radioniceOprema = new HashMap<>();
		radionicePublika = new HashMap<>();
	}

	/**
	 * Učitava bazu podataka iz danog vršnog direktorija svih datoteka koje su potrebne bazi podataka.
	 * @param direktorij vršni direktorij baze podataka.
	 * @return bazu podataka
	 * @throws IOException
	 */
	public static RadioniceBaza ucitaj(String direktorij) {
		RadioniceBaza radioniceBaza = new RadioniceBaza(direktorij);
		if (!Files.exists(Paths.get(direktorij), LinkOption.NOFOLLOW_LINKS)) {
			throw new RuntimeException("ne postoji dani direktorij: " + direktorij);
		}

		radioniceBaza.setOprema(procitaj(direktorij + "/oprema.txt"));
		radioniceBaza.setPublika(procitaj(direktorij + "/publika.txt"));
		radioniceBaza.setTrajanje(procitaj(direktorij + "/trajanje.txt"));

		radioniceBaza.setRadioniceOprema(procitajSet(direktorij + "/radionice_oprema.txt", radioniceBaza.getOprema()));
		radioniceBaza
		        .setRadionicePublika(procitajSet(direktorij + "/radionice_publika.txt", radioniceBaza.getPublika()));

		Map<String, Radionica> radioniceMap = procitajRadionice(direktorij + "/radionice.txt", radioniceBaza);
		radioniceBaza.setRadionice(radioniceMap);

		return radioniceBaza;
	}

	private static Map<String, Radionica> procitajRadionice(String datoteka, RadioniceBaza radioniceBaza) {
		Map<String, Radionica> map = new HashMap<>();
		if (!Files.exists(Paths.get(datoteka), LinkOption.NOFOLLOW_LINKS)) {
			return map;
		}

		List<String> retci;
		try {
			retci = Files.readAllLines(Paths.get(datoteka), StandardCharsets.UTF_8);
		} catch (IOException e) {
			throw new RuntimeException("greška prilikom čitanja: " + datoteka);
		}

		for (String redak : retci) {
			String[] zapis = redak.split("\t");
			Radionica radionica = new Radionica();

			// u zapis[0] je id
			Long id;
			try {
				if ("".equals(zapis[0])) {
					id = radioniceBaza.getMaxId();
					radioniceBaza.setMaxId(id + 1);
				} else {
					id = Long.parseLong(zapis[0]);
				}
				if (id <= 0) {
					throw new RuntimeException("id mora biti pozitivan");
				}
				radioniceBaza.setMaxId(Math.max(radioniceBaza.getMaxId(), id));

			} catch (NumberFormatException e) {
				throw new RuntimeException("ilegalna vrijednost id-a");
			}
			radionica.setId(id);

			// u zapis[1] je naziv, ne smije biti prazan
			if ("".equals(zapis[1])) {
				throw new RuntimeException("naziv radionice ne smije biti prazan");
			}
			radionica.setNaziv(zapis[1]);

			// u zapis[2] je datum, ne smije biti prazan
			if ("".equals(zapis[2])) {
				throw new RuntimeException("datum radionice ne smije biti prazan");
			}
			Pattern p = Pattern.compile("^\\d\\d\\d\\d-\\d\\d-\\d\\d$");
			Matcher m = p.matcher(zapis[2]);
			if(!m.matches()) {
				throw new RuntimeException("neispravan datum");
			}
			radionica.setDatum(zapis[2]);

			// u zapis[3] je broj polaznika, mora biti zadano i iz intervala [10, 50]
			Integer brojPolaznika;
			try {
				if ("".equals(zapis[3])) {
					throw new RuntimeException("maks broj polaznika mora biti zadan");
				}
				brojPolaznika = Integer.parseInt(zapis[3]);
				if (brojPolaznika < 10 || brojPolaznika > 50) {
					throw new RuntimeException("broj polaznika mora biti iz intervala [10, 50]");
				}
				radionica.setMaksPolaznika(brojPolaznika);
			} catch (NumberFormatException e) {
				throw new RuntimeException("ilegalna vrijdnost broja polaznika");
			}

			// u zapis[4] je trajanje, mora biti zadano
			if ("".equals(zapis[4])) {
				throw new RuntimeException("trajanje mora biti zadano");
			}
			if (radioniceBaza.getTrajanje().get(zapis[4]) == null) {
				throw new RuntimeException("ne postoji zapis danom trajanju");
			}
			radionica.setTrajanje(new Opcija(zapis[4], radioniceBaza.getTrajanje().get(zapis[4])));

			// u zapis[5] je email, mora biti zadan
			if ("".equals(zapis[5])) {
				throw new RuntimeException("email mora biti zadan");
			}
			radionica.setEmail(zapis[5]);

			// u zapis[6] su dodatne upute
			if (zapis.length == 7) {
				String dopuna = zapis[6].replace("\\\\", "\\");
				dopuna = dopuna.replace("\\t", "\t");
				dopuna = dopuna.replace("\\n", "\n");
				dopuna = dopuna.replace("\\r", "\r");
				radionica.setDopuna(dopuna);
			} else {
				radionica.setDopuna("");
			}

			radionica.setOprema(radioniceBaza.getRadioniceOprema().get(id.toString()));
			radionica.setPublika(radioniceBaza.getRadionicePublika().get(id.toString()));

			map.put(id.toString(), radionica);
		}

		return map;
	}

	private static Map<String, Set<Opcija>> procitajSet(String datoteka, Map<String, String> mapa) {
		Map<String, Set<Opcija>> map = new HashMap<>();
		if (!Files.exists(Paths.get(datoteka), LinkOption.NOFOLLOW_LINKS)) {
			return map;
		}

		List<String> retci;
		try {
			retci = Files.readAllLines(Paths.get(datoteka), StandardCharsets.UTF_8);
		} catch (IOException e) {
			throw new RuntimeException("greška prilikom čitanja: " + datoteka);
		}

		for (String redak : retci) {
			String[] zapis = redak.split("\t");
			if (!map.containsKey(zapis[0])) {
				map.put(zapis[0], new HashSet<Opcija>());
				map.get(zapis[0]).add(new Opcija(zapis[1], mapa.get(zapis[1])));
			} else {
				map.get(zapis[0]).add(new Opcija(zapis[1], mapa.get(zapis[1])));
			}
		}

		return map;
	}

	private static Map<String, String> procitaj(String datoteka) {
		Map<String, String> map = new HashMap<>();
		if (!Files.exists(Paths.get(datoteka), LinkOption.NOFOLLOW_LINKS)) {
			return map;
		}

		List<String> retci;
		try {
			retci = Files.readAllLines(Paths.get(datoteka), StandardCharsets.UTF_8);
		} catch (IOException e) {
			throw new RuntimeException("greška prilikom čitanja: " + datoteka);
		}

		for (String redak : retci) {
			String[] zapis = redak.split("\t");
			map.put(new String(zapis[0]), new String(zapis[1]));
		}

		return map;
	}

	public void snimi() {
		this.snimi(direktorij);
	}

	public void snimi(String direktorij) {
		provijeriIspravnostOpcija();
		Set<Opcija> set = new HashSet<>();
		List<Opcija> list = new ArrayList<>();
		for(Radionica r : radionice.values()) {
			set.addAll(r.getOprema());
		}
		for(String id : oprema.keySet()) {
			set.add(new Opcija(id, oprema.get(id)));
		}
		list = new ArrayList<>(set);
		Collections.sort(list);
		zapisi(direktorij + "/oprema.txt", list);
		
		set.clear();
		for(Radionica r : radionice.values()) {
			set.addAll(r.getPublika());
		}
		for(String id : publika.keySet()) {
			set.add(new Opcija(id, publika.get(id)));
		}
		list = new ArrayList<>(set);
		Collections.sort(list);
		zapisi(direktorij + "/publika.txt", list);
		
		set.clear();
		for(Radionica r : radionice.values()) {
			set.add(r.getTrajanje());
		}
		for(String id : trajanje.keySet()) {
			set.add(new Opcija(id, trajanje.get(id)));
		}
		list = new ArrayList<>(set);
		Collections.sort(list);
		zapisi(direktorij + "/trajanje.txt", list);

		BufferedWriter bw;
		try {
			bw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(direktorij + "/radionice_oprema.txt"),
			        StandardCharsets.UTF_8));
			List<Radionica> l = new ArrayList<>(radionice.values());
			Collections.sort(l);
			List<Pair> p = new ArrayList<>();
			for (Radionica r : l) {
				for (Opcija o : r.getOprema()) {
					p.add(new Pair(r.getId(), Long.parseLong(o.getId())));
				}
			}
			Collections.sort(p);
			for(Pair pair : p) {
				bw.write(pair + "\n");
			}
			bw.close();
		} catch (IOException e) {
			throw new RuntimeException("io greška: " + direktorij + "/radionice_oprema.txt");
		}
		try {
			bw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(direktorij + "/radionice_publika.txt"),
			        StandardCharsets.UTF_8));
			List<Radionica> l = new ArrayList<>(radionice.values());
			Collections.sort(l);
			List<Pair> p = new ArrayList<>();
			for (Radionica r : l) {
				for (Opcija o : r.getPublika()) {
					p.add(new Pair(r.getId(), Long.parseLong(o.getId())));
				}
			}
			Collections.sort(p);
			for(Pair pair : p) {
				bw.write(pair + "\n");
			}
			bw.close();
		} catch (IOException e) {
			throw new RuntimeException("io greška: " + direktorij + "/radionice_oprema.txt");
		}

		try {
			bw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(direktorij + "/radionice.txt"),
			        StandardCharsets.UTF_8));
			List<Radionica> l = new ArrayList<>(radionice.values());
			Collections.sort(l);
			for (Radionica r : l) {
				bw.write(toString(r) + "\n");
			}
			bw.close();
		} catch (IOException e) {
			throw new RuntimeException("io greška: " + direktorij + "/radionice_oprema.txt");
		}
	}

	private String toString(Radionica r) {
		StringBuilder sb = new StringBuilder("");
		sb.append(r.getId() + "\t");
		sb.append(r.getNaziv() + "\t");
		sb.append(r.getDatum() + "\t");
		sb.append(r.getMaksPolaznika() + "\t");
		sb.append(r.getTrajanje().getId() + "\t");
		sb.append(r.getEmail() + "\t");
		sb.append(r.getDopuna().replace("\\", "\\\\").replace("\n", "\\n").replace("\t", "\\t").replace("\r", "\\r"));
	    return sb.toString();
    }

	private void zapisi(String datoteka, List<Opcija> set) {
		BufferedWriter bw;
		try {
			bw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(datoteka), StandardCharsets.UTF_8));
			for (Opcija o : set) {
				bw.write(o.getId() + "\t" + o.getVrijednost() + "\n");
			}
			bw.close();
		} catch (IOException e) {
			throw new RuntimeException("datoteka ne postoji: " + datoteka);
		}
	}

	public String getDirektorij() {
		return direktorij;
	}

	public void setDirektorij(String direktorij) {
		this.direktorij = direktorij;
	}

	public Map<String, String> getOprema() {
		return oprema;
	}

	public void setOprema(Map<String, String> oprema) {
		this.oprema = oprema;
	}

	public Map<String, String> getTrajanje() {
		return trajanje;
	}

	public void setTrajanje(Map<String, String> trajanje) {
		this.trajanje = trajanje;
	}

	public Map<String, String> getPublika() {
		return publika;
	}

	public void setPublika(Map<String, String> publika) {
		this.publika = publika;
	}

	public Map<String, Radionica> getRadionice() {
		return radionice;
	}

	public void setRadionice(Map<String, Radionica> radionice) {
		this.radionice = radionice;
	}

	public Map<String, Set<Opcija>> getRadioniceOprema() {
		return radioniceOprema;
	}

	public void setRadioniceOprema(Map<String, Set<Opcija>> radioniceOprema) {
		this.radioniceOprema = radioniceOprema;
	}

	public Map<String, Set<Opcija>> getRadionicePublika() {
		return radionicePublika;
	}

	public void setRadionicePublika(Map<String, Set<Opcija>> radionicePublika) {
		this.radionicePublika = radionicePublika;
	}

	public Long getMaxId() {
		return maxId;
	}

	public void setMaxId(Long maxId) {
		this.maxId = maxId;
	}
	
	public void provijeriIspravnostOpcija() {
		RadioniceBaza baza = ucitaj(this.direktorij);
		List<Radionica> radionice = new ArrayList<>(this.getRadionice().values());
		
		Set<Opcija> opcijeOprema = new HashSet<>();
		for(String key : baza.getOprema().keySet()) {
			opcijeOprema.add(new Opcija(key, baza.getOprema().get(key)));
		}
		for(Radionica r : radionice) {
			for(Opcija o : r.getOprema()) {
				if(!opcijeOprema.contains(o)) {
					throw new InconsistentDatabaseException();
				}
			}
		}
		
		Set<Opcija> opcijePublika = new HashSet<>();
		for(String key : baza.getPublika().keySet()) {
			opcijePublika.add(new Opcija(key, baza.getPublika().get(key)));
		}
		for(Radionica r : radionice) {
			for(Opcija o : r.getPublika()) {
				if(!opcijePublika.contains(o)) {
					throw new InconsistentDatabaseException();
				}
			}
		}
	}
	
	public void snimi(Radionica r) {
		if(r.getId() == null) {
			r.setId(maxId);
			maxId += 1;
		}
		
		radioniceOprema.remove(r.getId().toString());
		radioniceOprema.put(r.getId().toString(), r.getOprema());
		
		radionicePublika.remove(r.getId().toString());
		radioniceOprema.put(r.getId().toString(), r.getOprema());
		
		radionice.put(r.getId().toString(), r);
		BufferedWriter bw;
		try {
			bw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(direktorij + "/radionice.txt"),
			        StandardCharsets.UTF_8));
			List<Radionica> l = new ArrayList<>(radionice.values());
			Collections.sort(l);
			for (Radionica rad : l) {
				bw.write(toString(rad) + "\n");
			}
			bw.close();
		} catch (IOException e) {
			throw new RuntimeException("io greška: " + direktorij + "/radionice_oprema.txt");
		}
		
		this.snimi();
	}
}
