package hr.fer.zemris.web.radionice;

public class InconsistentDatabaseException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public InconsistentDatabaseException() {
		super();
	}

	public InconsistentDatabaseException(String message) {
		super(message);
	}

}
