package hr.fer.zemris.java.tecaj.hw5.directory;

import hr.fer.zemris.java.tecaj.hw5.specifier.FilterSpecifier;

import java.io.File;
import java.io.FileFilter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/**
 * Class {@code DirectoryRoot} represents one directory that contains {@code DirectoryObject}.
 * @author Herman Zvonimir Došilović
 * @version 1.0
 */
public class DirectoryRoot implements Directory {

	/** Directory root. */
	private File dirRoot;

	/**
	 * Creates new {@code DirectoryRoot} with given path.
	 * @param path path of directory on file system.
	 * @throws IllegalArgumentException if path is {@code null}.
	 */
	public DirectoryRoot(String path) {
		if (path == null) {
			throw new IllegalArgumentException("Path cannot be null.");
		}

		dirRoot = new File(path);
		if (!dirRoot.isDirectory()) {
			System.err.println("Path does not represent directory.");
			System.exit(-1);
		}
	}

	@Override
	public String getPath() {
		return dirRoot.getAbsolutePath();
	}

	@Override
	public String getName() {
		return dirRoot.getName();
	}

	@Override
	public boolean equals(Object obj) {
		return dirRoot.equals(obj);
	}

	@Override
	public int hashCode() {
		return dirRoot.hashCode();
	}

	@Override
	public List<DirectoryObject> getObjects() {
		List<FileFilter> filters = Collections.emptyList();
		return this.getObjects(filters);
	}
	
	@Override
	public List<DirectoryObject> getObjects(List<FileFilter> filters) {
		List<DirectoryObject> objects = new ArrayList<>();
		FilterSpecifier specifier = new FilterSpecifier(filters);
		for(File f : dirRoot.listFiles()) {
			if(specifier.accept(f)) {
				objects.add(new DirectoryObject(this, f.getName()));
			}
		}
		return objects;
	}

	@Override
	public List<DirectoryObject> getObjects(FileFilter... filters) {
		return this.getObjects(Arrays.asList(filters));
	}

	@Override
	public List<DirectoryObject> getObjects(FileFilter filter) {
		return this.getObjects(Arrays.asList(filter));
	}
}
