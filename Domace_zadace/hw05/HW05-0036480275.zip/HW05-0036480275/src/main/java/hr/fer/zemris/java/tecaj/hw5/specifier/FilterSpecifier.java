package hr.fer.zemris.java.tecaj.hw5.specifier;

import java.io.File;
import java.io.FileFilter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * {@code FilterSpecifier} class represents filter specifiers.
 * @author Herman Zvonimir Došilović
 */
public class FilterSpecifier implements FileFilter {

	private List<FileFilter> filters;
	boolean reverse = false;
	
	/**
	 * Create new filter specifier.
	 * @param filters filters for filter specifier.
	 */
	public FilterSpecifier(List<FileFilter> filters) {
		if (filters.size() == 0) {
			this.filters = new ArrayList<>(Arrays.asList(FilterSpecifier.ALL));
		}
		else {
			this.filters = new ArrayList<>(filters);
		}
	}

	/**
	 * Create new filter specifier.
	 * @param filters filters for filter specifier.
	 */
	public FilterSpecifier(FileFilter... filters) {
		this(Arrays.asList(filters));
	}

	/**
	 * Create new filter specifier.
	 * @param filters filters for filter specifier.
	 */
	public FilterSpecifier(FileFilter filter) {
		this(Arrays.asList(filter));
	}

	/**
	 * Accepts only object whose size is less than or equal to SIZE.
	 */
	public static final class sSIZE implements FileFilter {

		private int size;

		public sSIZE(int size) {
			this.size = size;
		}

		@Override
		public boolean accept(File pathname) {
			if (pathname.length() <= size) {
				return true;
			}
			return false;
		}

	};

	/**
	 * Accepts only objects who are files (not directories).
	 */
	public static final FileFilter f = new FileFilter() {
		@Override
		public boolean accept(File pathname) {
			return !pathname.isDirectory();
		}
	};

	/**
	 * Accepts only objects whose size of name is less than or equal to SIZE.
	 */
	public static final class lSIZE implements FileFilter {

		private int size;

		public lSIZE(int size) {
			this.size = size;
		}

		@Override
		public boolean accept(File pathname) {
			if (pathname.getName().length() <= size) {
				return true;
			}
			return false;
		}

	};

	/**
	 * Accepts only files with extension.
	 */
	public static final FileFilter e = new FileFilter() {
		@Override
		public boolean accept(File pathname) {
			if (pathname.isDirectory()) {
				return false;
			}
			return pathname.getName().contains(".");
		}
	};
	
	/**
	 * Accepts all objects.
	 */
	private static final FileFilter ALL = new FileFilter() {
		@Override
		public boolean accept(File pathname) {
			return true;
		}
	};

	@Override
	public boolean accept(File pathname) {
		boolean accepts = true;
		for (FileFilter fileFilter : filters) {
			accepts &= (reverse ^ fileFilter.accept(pathname));
		}
		return accepts;
	}
	
	public void reverseOrder(boolean value) {
		reverse = value;
	}
}
