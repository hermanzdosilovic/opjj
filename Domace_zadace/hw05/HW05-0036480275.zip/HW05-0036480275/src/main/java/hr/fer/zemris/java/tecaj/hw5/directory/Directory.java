package hr.fer.zemris.java.tecaj.hw5.directory;

import java.io.FileFilter;
import java.util.List;

/**
 * Interface {@code Directory} represents one directory in the file system.
 * @author Herman Zvonimir Došilović
 * @version 1.0
 */
public interface Directory {

	/**
	 * Returns full (absolute) path of directory.
	 * @return full (absolute) path of directory.
	 */
	String getPath();

	/**
	 * Returns name of directory.
	 * @return name of directory.
	 */
	String getName();

	/**
	 * Returns objects that directory contains.
	 * @return objects that directory contains.
	 */
	List<DirectoryObject> getObjects();
	
	/**
	 * Returns filtered objects.
	 * @param filters list of filters to apply on objects. 
	 * @return filtered objects.
	 */
	List<DirectoryObject> getObjects(List<FileFilter> filters);
	
	/**
	 * Returns filtered objects.
	 * @param filters list of filters to apply on objects. 
	 * @return filtered objects.
	 */
	List<DirectoryObject> getObjects(FileFilter ... filters);
	
	/**
	 * Returns filtered objects.
	 * @param filter filter to apply on objects. 
	 * @return filtered objects.
	 */
	List<DirectoryObject> getObjects(FileFilter filter);
}
