package hr.fer.zemris.java.tecaj_2.jcomp.impl;

import hr.fer.zemris.java.tecaj_2.jcomp.*;

/**
 * Razred {@code RegistersImpl} implementira sučelje {@code Registers} koje predstavlja sve registre u procesoru.
 * Postoje registri opće namjene za čiji rad služe metode {@linkplain #getRegisterValue(int)} i
 * {@linkplain #setRegisterValue(int, Object)},
 * programsko brojilo koje predstavlja adresu sljedeće instrukcije koju
 * treba izvesti (metode {@linkplain #getProgramCounter()}, {@linkplain #incrementProgramCounter()},
 * {@linkplain #setProgramCounter(int)}),
 * te registar zastavice (metode {@linkplain #getFlag()}, {@linkplain #setFlag(boolean)}).
 * Za razliku od klasičnih procesorskih registara koji pohranjuju samo
 * brojeve i fiksne su širine, registri opće namjene koje ovdje koristimo mogu
 * pohranjivati proizvoljno velike objekte različitih tipova
 * ({@link String}, {@link Integer}).
 * @author Herman Zvonimir Došilović
 * @version 1.0
 */
public class RegistersImpl implements Registers {

	/** Broj registara koji će procesoru biti na raspolaganju. */
	private final int regsLen;

	/** Predstavlja registre procesora. Svaki indeks predstavlja jedan registar. */
	private Object[] registers;

	/** Predstavlja programsko brojilo u procesoru. */
	private int programCounter = 0;

	/** Predstavlja zastavicu . */
	private boolean flag = false;

	/**
	 * Stvara nove registre koje će procesoru biti na raspolaganju.
	 * @param regsLen broj registara koje će procesoru biti na raspolaganju.
	 * @throws IllegalArgumentException ako broj registara nije pozitivan.
	 */
	public RegistersImpl(final int regsLen) {
		if (regsLen <= 0) {
			throw new IllegalArgumentException("Broj registara mora biti pozitivan.");
		}
		this.regsLen = regsLen;
		this.registers = new Object[this.regsLen];
	}

	/**
	 * Dohvaća objekt pohranjen u zadanom registru.
	 * @param index broj registra; brojevi idu od 0.
	 * @return objekt pohranjen u tom registru
	 * @throws IllegalArgumentException ako je {@code index} izvan granica registra (
	 *             {@code index < 0 || index >= regsLen}).
	 */
	@Override
	public Object getRegisterValue(final int index) {
		if (index < 0 || index >= this.regsLen) {
			throw new IllegalArgumentException("Ne postoji registar sa indeksom " + index + ".");
		}
		return this.registers[index];
	}

	/**
	 * Metoda u zadani registar upisuje predani objekt.
	 * @param index broj registra; brojevi idu od 0.
	 * @param value vrijednost koju treba upisati
	 * @throws IllegalArgumentException ako je {@code index} izvan granica registra (
	 *             {@code index < 0 || index >= regsLen}).
	 */
	@Override
	public void setRegisterValue(final int index, final Object value) {
		if (index < 0 || index >= this.regsLen) {
			throw new IllegalArgumentException("Ne postoji registar sa indeksom " + index + ".");
		}
		this.registers[index] = value;
	}

	/**
	 * Metoda za očitavanje vrijednosti programskog brojila.
	 * @return vrijednost programskog brojila
	 */
	@Override
	public int getProgramCounter() {
		return this.programCounter;
	}

	/**
	 * Metoda za postavljanje vrijednosti programskog brojila.
	 * @param value nova vrijednost programskog brojila
	 * @throws IllegalArgumentException ako je {@code value} negativan.
	 */
	@Override
	public void setProgramCounter(final int value) {
		if (value < 0) {
			throw new IllegalArgumentException("Programsko brojilo ne može biti postavljeno na negativnu vrijednost.");
		}
		this.programCounter = value;
	}

	/**
	 * Metoda uvećava vrijednost programskog brojila za 1.
	 */
	@Override
	public void incrementProgramCounter() {
		this.programCounter++;
	}

	/**
	 * Metoda za dohvat vrijednosti zastavice.
	 * @return vrijednost zastavice
	 */
	@Override
	public boolean getFlag() {
		return this.flag;
	}

	/**
	 * Metoda za postavljanje vrijednosti zastavice.
	 * @param value nova vrijednost zastavice
	 */
	@Override
	public void setFlag(final boolean value) {
		this.flag = value;
	}

}
