package hr.fer.zemris.java.tecaj_2.jcomp.impl.instructions;

import hr.fer.zemris.java.tecaj_2.jcomp.Computer;
import hr.fer.zemris.java.tecaj_2.jcomp.Instruction;
import hr.fer.zemris.java.tecaj_2.jcomp.InstructionArgument;

import java.util.List;

/**
 * Razred {@code InstrDecrement} predstavlja razred koji implementira instrukciju <i>increment</i>
 * <p>
 * {@code increment rx}
 * </p>
 * @author Herman Zvonimir Došilović
 * @version 1.0
 */
public class InstrIncrement implements Instruction {

	/** Predstavlja registar koji treba uvećati za 1 */
	public final int rx;
	
	/**
	 * Stvara novu instrukciju {@code increment}.
	 * @param arguments argumenti instrukcije {@code increment}.
	 * @throws IllegalArgumentException ako broj argumenata nije jednak 1.
	 */
	public InstrIncrement(List<InstructionArgument> arguments) {
		if (arguments.size() != 1) {
			throw new IllegalArgumentException("Instrukcija increment očekuje jedan argument.");
		}
		if(!arguments.get(0).isRegister()) {
			throw new IllegalArgumentException("increment: argument treba biti registar.");
		}
		this.rx = (int) arguments.get(0).getValue();
	}

	@Override
	public boolean execute(Computer computer) {
		if (computer.getRegisters().getRegisterValue(rx) instanceof String) {
			throw new IllegalArgumentException("increment: registar ne može biti String.");
		}
		final int valueX = (int) computer.getRegisters().getRegisterValue(rx);
		computer.getRegisters().setRegisterValue(rx, valueX + 1);
		return false;
	}

}
