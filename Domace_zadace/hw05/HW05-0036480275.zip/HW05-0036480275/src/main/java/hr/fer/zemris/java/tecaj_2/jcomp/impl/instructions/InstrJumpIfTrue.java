package hr.fer.zemris.java.tecaj_2.jcomp.impl.instructions;

import hr.fer.zemris.java.tecaj_2.jcomp.Computer;
import hr.fer.zemris.java.tecaj_2.jcomp.Instruction;
import hr.fer.zemris.java.tecaj_2.jcomp.InstructionArgument;

import java.util.List;

/**
 * Razred {@code InstrJump} predstavlja razred koji implementira instrukciju <i>jumpIfTrue</i>
 * <p>
 * {@code jumpIfTrue lokacija}
 * </p>
 * ako je zastavica {@code flag} = 1 tada pc <- lokacija.
 * @author Herman Zvonimir Došilović
 * @version 1.0
 */
public class InstrJumpIfTrue implements Instruction {

	/** Sadrži memorijsku lokaciju na koju treba skočiti. */
	private final int lokacija;

	/**
	 * Stvara novu instrukciju {@code jumpIfTrue}.
	 * @param arguments argumenti instrukcije {@code jumpIfTrue}.
	 * @throws IllegalArgumentException ako broj argumenata nije jedan 1.
	 */
	public InstrJumpIfTrue(List<InstructionArgument> arguments) {
		if (arguments.size() != 1) {
			throw new IllegalArgumentException("Instrukcija jump očekuje jedan argument.");
		}
		if (!arguments.get(0).isNumber()) {
			throw new IllegalArgumentException("jump: argument treba biti broj.");
		}
		this.lokacija = (int) arguments.get(0).getValue();
	}

	@Override
	public boolean execute(Computer computer) {
		if (computer.getRegisters().getFlag()) {
			computer.getRegisters().setProgramCounter(lokacija);
		}
		return false;
	}

}
