package hr.fer.zemris.java.tecaj.hw5;

import hr.fer.zemris.java.tecaj.hw5.directory.Directory;
import hr.fer.zemris.java.tecaj.hw5.directory.DirectoryEnchanter;
import hr.fer.zemris.java.tecaj.hw5.directory.DirectoryRoot;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Herman Zvonimir Došilović
 */
public class Dir {

	public static void main(String[] args) {
		if (args.length == 0) {
			System.err.println("Program očekuje barem jedan argument.");
			System.exit(-1);
		}

		List<String> specifiers = new ArrayList<>();

		if (args.length > 1) {
			for (int i = 1; i < args.length; i++) {
				specifiers.add(args[i]);
			}
		}

		Directory dir = new DirectoryRoot(args[0]);
		DirectoryEnchanter dirEnchanter = new DirectoryEnchanter(dir, specifiers);

		dirEnchanter.tableOnScreen();
	}

}
