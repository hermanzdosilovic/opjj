package hr.fer.zemris.java.tecaj_2.jcomp.impl.instructions;

import hr.fer.zemris.java.tecaj_2.jcomp.*;

import java.util.List;

/**
 * Razred {@code InstrDecrement} predstavlja razred koji implementira instrukciju <i>decrement</i>
 * <p>
 * {@code decrement rx}
 * </p>
 * @author Herman Zvonimir Došilović
 * @version 1.0
 */
public class InstrDecrement implements Instruction {

	/** Predstavlja registar koji treba umanjiti za 1 */
	public final int rx;
	
	/**
	 * Stvara novu instrukciju {@code decrement}.
	 * @param arguments argumenti instrukcije {@code decrement}.
	 * @throws IllegalArgumentException ako broj argumenata nije jednak 1.
	 */
	public InstrDecrement(List<InstructionArgument> arguments) {
		if (arguments.size() != 1) {
			throw new IllegalArgumentException("Instrukcija decrement očekuje jedan argument.");
		}
		if(!arguments.get(0).isRegister()) {
			throw new IllegalArgumentException("decrement: argument treba biti registar.");
		}
		this.rx = (int) arguments.get(0).getValue();
	}

	@Override
	public boolean execute(Computer computer) {
		if (computer.getRegisters().getRegisterValue(rx) instanceof String) {
			throw new IllegalArgumentException("decrement: registar ne može biti String.");
		}
		final int valueX = (int) computer.getRegisters().getRegisterValue(rx);
		computer.getRegisters().setRegisterValue(rx, valueX - 1);
		return false;
	}

}
