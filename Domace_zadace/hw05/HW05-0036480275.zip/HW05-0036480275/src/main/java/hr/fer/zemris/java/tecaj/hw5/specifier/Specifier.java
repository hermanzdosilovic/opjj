package hr.fer.zemris.java.tecaj.hw5.specifier;

/**
 * Interface {@code Specifier} represents one specifier.
 * @author Herman Zvonimir Došilović
 * @version 1.0
 */
public interface Specifier {
}
