package hr.fer.zemris.java.tecaj_2.jcomp.impl.instructions;

import hr.fer.zemris.java.tecaj_2.jcomp.*;

import java.util.List;

/**
 * Razred {@code InstrAdd} predstavlja razred koji implementira instrukciju <i>add</i>.
 * <p>
 * {@code add rx, ry, rz}
 * </p>
 * @author Herman Zvonimir Došilović
 * @version 1.0.
 */
public class InstrAdd implements Instruction {

	/** Registar u koji treba postaviti vrijednost rezultate. */
	public final int rx;

	/** Prvi registar koji se zbraja. */
	public final int ry;

	/** Drugi registar koji se zbraja. */
	public final int rz;

	/**
	 * Stvara novu instrukciju {@code add}.
	 * @param arguments argumenti instrukcije {@code add}.
	 * @throws IllegalArgumentException ako broj argumenata nije jednak 3.
	 */
	public InstrAdd(List<InstructionArgument> arguments) {
		if (arguments.size() != 3) {
			throw new IllegalArgumentException("Instrukcija add očekuje 3 argumenta.");
		}
		if (!arguments.get(0).isRegister()) {
			throw new IllegalArgumentException("add: prvi argument treba biti registar.");
		}
		if (!arguments.get(1).isRegister()) {
			throw new IllegalArgumentException("add: drugi argument treba biti registar.");
		}
		if (!arguments.get(2).isRegister()) {
			throw new IllegalArgumentException("add: treći argument treba biti registar.");
		}

		this.rx = (int) arguments.get(0).getValue();
		this.ry = (int) arguments.get(1).getValue();
		this.rz = (int) arguments.get(2).getValue();
	}

	@Override
	public boolean execute(Computer computer) {
		final Object valueY;
		final Object valueZ;
		valueY = (Integer) computer.getRegisters().getRegisterValue(ry);
		valueZ = (Integer) computer.getRegisters().getRegisterValue(rz);
		computer.getRegisters().setRegisterValue(rx, (int) valueY + (int) valueZ);
		return false;
	}

}
