/**
 * @author Herman Zvonimir Došilović
 */
package hr.fer.zemris.java.tecaj_2.jcomp.impl;
