package hr.fer.zemris.java.tecaj_2.jcomp.impl;

import hr.fer.zemris.java.tecaj_2.jcomp.*;

/**
 * Razred {@code MemoryImpl} implementira sučelje {@code Memory} koje predstavlja memoriju računala. Za razliku
 * od klasične memorije računala koja je bajtno orijentirana,
 * naša memorija na svakoj lokaciji može pohraniti proizvoljno
 * veliki objekt, a koristit ćemo Stringove i Integere.
 * @author Herman Zvonimir Došilović
 * @version 1.0
 */
public class MemoryImpl implements Memory {

	/** Veličina memorije. */
	private final int size;

	/** Predstavlja memoriju. Svaki indeks je jedna memorijska lokacija. */
	private Object[] memory;

	/**
	 * Stvara novu memoriju čija je veličina dana sa <i>size</i>.
	 * @param size veličina memorije.
	 * @throws IllegalArgumentException ako veličina memorije nije pozitivna.
	 */
	public MemoryImpl(final int size) {
		if (size <= 0) {
			throw new IllegalArgumentException("Veličina memorije mora biti pozitivna.");
		}
		this.size = size;
		this.memory = new Object[this.size];
	}

	/**
	 * Metoda za postavljanje vrijednosti na zadanu lokaciju.
	 * @param location memorijska adresa
	 * @param value objekt koji treba pohraniti na zadanu adresu
	 * @throws IllegalArgumentException ako je {@code location} izvan granica memorije (
	 *             {@code location < 0 || location >= size}).
	 */
	@Override
	public void setLocation(final int location, final Object value) {
		if (location < 0 || location >= this.size) {
			throw new IllegalArgumentException("Memorijska lokacija " + location + " ne postoji.");
		}
		this.memory[location] = value;
	}

	/**
	 * Metoda za dohvat vrijednosti sa zadane lokacije.
	 * @param location memorijska adresa
	 * @return objekt pohranjen na traženoj lokaciji
	 * @throws IllegalArgumentException ako je {@code location} izvan granica memorije (
	 *             {@code location < 0 || location >= size}).
	 */
	@Override
	public Object getLocation(final int location) {
		if (location < 0 || location >= this.size) {
			throw new IllegalArgumentException("Memorijska lokacije " + location + " ne postoji.");
		}
		return this.memory[location];
	}

}
