package hr.fer.zemris.java.tecaj_2.jcomp.impl;

import hr.fer.zemris.java.tecaj_2.jcomp.*;

/**
 * <p>
 * Upravljački sklop računala. Ovaj razred "izvodi" program odnosno predstavlja impulse takta za sam procesor.
 * </p>
 * <p>
 * Razred definira samo jednu metodu {@linkplain #go(Computer)} čiji se pseudo-kod može zapisati ovako:
 * 
 * <pre>
 *   stavi program counter na 0
 *   ponavljaj do beskonačnosti
 *   | dohvati instrukciju iz memorije s lokacije program countera
 *   | uvećaj program counter za 1
 *   | izvrši instrukciju; ako je instrukcija vratila true, prekini petlju
 *   kraj petlje
 *   vrati true
 * </pre>
 * 
 * </p>
 * @author Herman Zvonimir Došilović
 * @version 1.0
 */
public class ExecutionUnitImpl implements ExecutionUnit {

	@Override
	public boolean go(Computer computer) {
		computer.getRegisters().setProgramCounter(0);
		int pc = computer.getRegisters().getProgramCounter();
		Instruction instruction;
		while (true) {
			pc = computer.getRegisters().getProgramCounter();
			instruction = (Instruction) computer.getMemory().getLocation(pc);
			computer.getRegisters().incrementProgramCounter();
			if (instruction.execute(computer))
				break;
		}
		return true;
	}

}
