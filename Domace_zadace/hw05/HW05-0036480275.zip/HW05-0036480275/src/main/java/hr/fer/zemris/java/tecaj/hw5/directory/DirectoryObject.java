package hr.fer.zemris.java.tecaj.hw5.directory;

import java.io.File;
import java.io.FileFilter;
import java.util.Collections;
import java.util.List;

/**
 * Class {@code DirectoryObject} represents object who is member of {@code DirectoryRoot}.
 * @author Forall360
 */
public class DirectoryObject implements Directory {

	/** Directory object. */
	private File dirObject;

	/**
	 * Creates new {@code DirectoryObject} with specified {@code DirectoryRoot}, and name of object.
	 * @param dirRoot root of object.
	 * @param name of object.
	 * @throws IllegalArgumentException if name is {@code null}.
	 */
	public DirectoryObject(DirectoryRoot dirRoot, String name) {
		if (name == null) {
			throw new IllegalArgumentException("Path cannot be null.");
		}

		dirObject = new File(dirRoot.getPath(), name);
	}

	/**
	 * @see java.io.File#length()
	 */
	public long length() {
		return dirObject.length();
	}

	/**
	 * @see java.io.File#lastModified()
	 */
	public long lastModified() {
		return dirObject.lastModified();
	}

	/**
	 * Compares type of {@code DirectoryObject}.
	 * @param obj {@code DirectoryObject} to compare with.
	 * @return Returns 0 if both object are of the same type. Returns -1 if
	 *         this {@code DirectoryObject} is directory, and {@code obj} is not. Returns 1 if this
	 *         {@code DirectoryObject} is
	 *         not directory, and {@code obj} is.
	 */
	public int typeCompare(DirectoryObject obj) {
		if (this.isDirectory() && obj.isDirectory() || (!this.isDirectory() && !obj.isDirectory())) {
			return 0;
		}
		else if (this.isDirectory() && !obj.isDirectory()) {
			return -1;
		}
		else {
			return 1;
		}
	}

	/**
	 * @see java.io.File#isDirectory()
	 */
	public boolean isDirectory() {
		return dirObject.isDirectory();
	}

	/**
	 * Compares type of {@code DirectoryObject}.
	 * @param obj {@code DirectoryObject} to compare with.
	 * @return Returns 0 if both object are of the same type. Returns -1 if
	 *         this {@code DirectoryObject} is directory, and {@code obj} is not. Returns 1 if this
	 *         {@code DirectoryObject} is
	 *         not directory, and {@code obj} is.
	 */
	public int executableCompare(DirectoryObject obj) {
		if (this.isExecutable() && obj.isExecutable()) {
			return 0;
		}
		else if (this.isExecutable() && !obj.isExecutable()) {
			return -1;
		}
		else {
			return 1;
		}
	}

	/**
	 * @see java.io.File#canExecute()
	 */
	private boolean isExecutable() {
		return dirObject.canExecute();
	}
	
	/**
	 * @see java.io.File#isHidden()
	 */
	public boolean isHidden() {
		return dirObject.isHidden();
	}
	
	@Override
	public String getPath() {
		return dirObject.getPath();
	}

	@Override
	public String getName() {
		return dirObject.getName();
	}

	@Override
	public boolean equals(Object obj) {
		return dirObject.equals(obj);
	}

	@Override
	public int hashCode() {
		return dirObject.hashCode();
	}

	@Override
	public List<DirectoryObject> getObjects() {
		return Collections.emptyList();
	}

	@Override
	public List<DirectoryObject> getObjects(List<FileFilter> filters) {
		return this.getObjects();
	}

	@Override
	public List<DirectoryObject> getObjects(FileFilter... filters) {
		return this.getObjects();
	}

	@Override
	public List<DirectoryObject> getObjects(FileFilter filter) {
		return this.getObjects();
	}
}
