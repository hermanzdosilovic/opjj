package hr.fer.zemris.java.tecaj_2.jcomp.impl.instructions;

import hr.fer.zemris.java.tecaj_2.jcomp.Computer;
import hr.fer.zemris.java.tecaj_2.jcomp.Instruction;
import hr.fer.zemris.java.tecaj_2.jcomp.InstructionArgument;

import java.util.List;

/**
 * Razred {@code InstrTestEquals} predstavlja razred koji implementira instrkuciju <i>testEquals</i>.
 * <p>
 * {@code testEquals rx, ry}
 * </p>
 * koja postavalja zastavicu {@code flag} na {@code true} ako su sadržaji registara {@code rx} i {@code ry} isti,
 * odnosno false ako nisu.
 * @author Forall360
 */
public class InstrTestEquals implements Instruction {

	/** Predstavlja prvi registar. */
	public final int rx;

	/** Predstavalj drugi registar. */
	public final int ry;

	/**
	 * Stvara novu instrukciju {@code testEquals}.
	 * @param arguments argumenti instrukcije {@code testEquals}.
	 * @throws IllegalArgumentException ako broj argumenata nije jedank 2.
	 */
	public InstrTestEquals(List<InstructionArgument> arguments) {
		if (arguments.size() != 2) {
			throw new IllegalArgumentException("Instrukcija testEquals očekuje dva argumenta.");
		}
		if (!arguments.get(0).isRegister()) {
			throw new IllegalArgumentException("testEquals: prvi argument treba biti registar.");
		}
		if (!arguments.get(1).isRegister()) {
			throw new IllegalArgumentException("testEquals: drugi argument treba biti registar.");
		}

		this.rx = (int) arguments.get(0).getValue();
		this.ry = (int) arguments.get(1).getValue();
	}

	@Override
	public boolean execute(Computer computer) {
		final Object valueX;
		final Object valueY;
		valueX = (Integer) computer.getRegisters().getRegisterValue(rx);
		valueY = (Integer) computer.getRegisters().getRegisterValue(ry);

		if (valueX.equals(valueY)) {
			computer.getRegisters().setFlag(true);
		}
		else {
			computer.getRegisters().setFlag(false);
		}

		return false;
	}

}
