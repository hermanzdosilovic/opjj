package hr.fer.zemris.java.tecaj_2.jcomp.impl.instructions;

import hr.fer.zemris.java.tecaj_2.jcomp.Computer;
import hr.fer.zemris.java.tecaj_2.jcomp.Instruction;
import hr.fer.zemris.java.tecaj_2.jcomp.InstructionArgument;

import java.util.List;

/**
 * Razred {@code InstrLoad} predstavlja razred koji implementira instrukciju <i>load</i>.
 * <p>
 * {@code load rX, memorijskaAdresa}
 * </p>
 * koja uzima sadržaj memorijske lokacije (dobit će to kao broj u drugom argumentu) i pohranjuje taj sadržaj u registar
 * {@code rX} (index će dobiti kao broj u prvom argumentu).
 * @author Herman Zvonimir Došilović
 * @version 1.0
 */
public class InstrLoad implements Instruction {

	/** Index registra u koji treba pospremiti sadržaj sa memorijske adrese. */
	private final int rx;

	/** Memorijska adresa iz koje treba uzeti sadržaj i pospremiti ga u zadani registar. */
	private final int memorijskaAdresa;

	/**
	 * Stvara novu instrukciju {@code load}.
	 * @param arguments argumenti instrukcije {@code load}.
	 * @throws IllegalArgumentException ako broja argumenata nije jednak 2.
	 */
	public InstrLoad(List<InstructionArgument> arguments) {
		if (arguments.size() != 2) {
			throw new IllegalArgumentException("Instrukcija load očekuje 2 argumenta");
		}
		if (!arguments.get(0).isRegister()) {
			throw new IllegalArgumentException("load: prvi argument treba biti registar.");
		}
		if (!arguments.get(1).isNumber()) {
			throw new IllegalArgumentException("load: drugi argument treba biti broj.");
		}

		this.rx = (int) arguments.get(0).getValue();
		this.memorijskaAdresa = (int) arguments.get(1).getValue();
	}

	@Override
	public boolean execute(Computer computer) {
		Object memoryContent = computer.getMemory().getLocation(memorijskaAdresa);
		computer.getRegisters().setRegisterValue(rx, memoryContent);
		return false;
	}

}
