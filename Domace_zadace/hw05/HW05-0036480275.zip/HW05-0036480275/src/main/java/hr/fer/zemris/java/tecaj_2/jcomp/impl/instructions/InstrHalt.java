package hr.fer.zemris.java.tecaj_2.jcomp.impl.instructions;

import hr.fer.zemris.java.tecaj_2.jcomp.Computer;
import hr.fer.zemris.java.tecaj_2.jcomp.Instruction;
import hr.fer.zemris.java.tecaj_2.jcomp.InstructionArgument;

import java.util.List;

/**
 * Razred {@code InstrHalt} implementira instrukciju <i>halt</i> koja zaustavlja rad procesora.
 * @author Herman Zvonimir Došilović
 * @version 1.0
 */
public class InstrHalt implements Instruction {

	/**
	 * Stvara novu instrukciju {@code halt}.
	 * @param arguments argumenti instrukcije {@code halt}.
	 * @throws IllegalArgumentException ako je broj argumenata različit od 0.
	 */
	public InstrHalt(List<InstructionArgument> arguments) {
		if (arguments.size() != 0) {
			throw new IllegalArgumentException("Instrukcija halt ne očekuje nikakve argumente.");
		}
	}

	@Override
	public boolean execute(Computer computer) {
		return true;
	}

}
