package hr.fer.zemris.java.tecaj_2.jcomp.impl.instructions;

import hr.fer.zemris.java.tecaj_2.jcomp.InstructionArgument;

public class NumberArgument implements InstructionArgument {

	Integer number;
	
	public NumberArgument(int number) {
		this.number = new Integer(number);
	}
	
	@Override
	public boolean isRegister() {
		return false;
	}

	@Override
	public boolean isString() {
		return false;
	}

	@Override
	public boolean isNumber() {
		return true;
	}

	@Override
	public Object getValue() {
		return number;
	}

}
