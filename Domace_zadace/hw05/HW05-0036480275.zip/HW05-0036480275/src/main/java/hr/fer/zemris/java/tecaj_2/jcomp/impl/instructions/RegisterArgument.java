package hr.fer.zemris.java.tecaj_2.jcomp.impl.instructions;

import hr.fer.zemris.java.tecaj_2.jcomp.InstructionArgument;

public class RegisterArgument implements InstructionArgument {
	
	Integer register;
	
	public RegisterArgument(Integer register) {
		this.register = new Integer(register);
	}
	
	@Override
	public boolean isRegister() {
		return true;
	}

	@Override
	public boolean isString() {
		return false;
	}

	@Override
	public boolean isNumber() {
		return false;
	}

	@Override
	public Object getValue() {
		return register;
	}

}
