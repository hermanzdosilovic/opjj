package hr.fer.zemris.java.tecaj.hw5.specifier;

import hr.fer.zemris.java.tecaj.hw5.directory.DirectoryObject;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

/**
 * Class {@code SortSpecifier} represents specifiers for sorting objects.
 * @author Herman Zvonimir Došilović
 * @version 1.0
 */
public class SortSpecifier implements Specifier, Comparator<DirectoryObject> {

	private List<Comparator<DirectoryObject>> sortComparators;
	
	/**
	 * Create new {@code SortSpecifier} with specified comparators.
	 * @param comparators for sort specifier
	 */
	public SortSpecifier(List<Comparator<DirectoryObject>> comparators) {
		sortComparators = new ArrayList<>(comparators);
	}
	
	/**
	 * Create new {@code SortSpecifier} with specified comparators.
	 * @param comparators for sort specifier
	 */
	@SafeVarargs
	public SortSpecifier(Comparator<DirectoryObject>... comparators) {
		this(Arrays.asList(comparators));
	}
	
	/**
	 * Create new {@code SortSpecifier} with specified comparator.
	 * @param comparator comparator for sort specifier
	 */
	public SortSpecifier(Comparator<DirectoryObject> comparator) {
		this(Arrays.asList(comparator));
	}

	@Override
	public int compare(DirectoryObject o1, DirectoryObject o2) {
		int compareResult;
		for (Comparator<DirectoryObject> comparator : sortComparators) {
			compareResult = comparator.compare(o1, o2);
			if (compareResult != 0) {
				return compareResult;
			}
		}
		return 0;
	}

	/**
	 * Sorted by size; method {@code length()} is called for both directories and files. Smaller size first.
	 */
	public static final Comparator<DirectoryObject> s = new Comparator<DirectoryObject>() {

		@Override
		public int compare(DirectoryObject o1, DirectoryObject o2) {
			return (int) (o1.length() - o2.length());
		}

	};

	/**
	 * Sorted by name; lexicographical less goes first.
	 */
	public static final Comparator<DirectoryObject> n = new Comparator<DirectoryObject>() {

		@Override
		public int compare(DirectoryObject o1, DirectoryObject o2) {
			return o1.getName().compareTo(o2.getName());
		}
	};

	/**
	 * Sorted by last time modification; {@code lastModified()} is invoked. Earlier modified files go first.
	 */
	public static final Comparator<DirectoryObject> m = new Comparator<DirectoryObject>() {

		@Override
		public int compare(DirectoryObject o1, DirectoryObject o2) {
			return (int) (o1.lastModified() - o2.lastModified());
		}
	};

	/**
	 * Sorted by type; directories go before files.
	 */
	public static final Comparator<DirectoryObject> t = new Comparator<DirectoryObject>() {

		@Override
		public int compare(DirectoryObject o1, DirectoryObject o2) {
			return o1.typeCompare(o2);
		}
	};

	/**
	 * Sorted by name length; file with shorter name goes first.
	 */
	public static final Comparator<DirectoryObject> l = new Comparator<DirectoryObject>() {

		@Override
		public int compare(DirectoryObject o1, DirectoryObject o2) {
			return o1.getName().length() - o2.getName().length();
		}
	};

	/**
	 * Sorted by execution type; files that can execute go first.
	 */
	public static final Comparator<DirectoryObject> e = new Comparator<DirectoryObject>() {

		@Override
		public int compare(DirectoryObject o1, DirectoryObject o2) {
			return o1.executableCompare(o2);
		}
	};
}
