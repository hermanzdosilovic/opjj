package hr.fer.zemris.java.tecaj_2.jcomp.impl.instructions;

import hr.fer.zemris.java.tecaj_2.jcomp.Computer;
import hr.fer.zemris.java.tecaj_2.jcomp.Instruction;
import hr.fer.zemris.java.tecaj_2.jcomp.InstructionArgument;

import java.util.List;

/**
 * Razred {@code InstrJump} predstavlja razred koji implementira instrukciju <i>jump</i>
 * <p>
 * {@code jump lokacija}
 * </p>
 * @author Herman Zvonimir Došilović
 * @version 1.0
 */
public class InstrJump implements Instruction {

	/** Sprema memorijsku lokaciju na koju treba skočiti. */
	private final int lokacija;

	/**
	 * Stvara novu instrukciju {@code load}.
	 * @param arguments argumenti instrukcije {@code load}.
	 * @throws IllegalArgumentException ako broj argumenata nije jednak 1.
	 */
	public InstrJump(List<InstructionArgument> arguments) {
		if (arguments.size() != 1) {
			throw new IllegalArgumentException("Instrukcija jump očekuje jedan argument.");
		}
		if (!arguments.get(0).isNumber()) {
			throw new IllegalArgumentException("jump: argument treba biti broj.");
		}
		this.lokacija = (int) arguments.get(0).getValue();
	}

	@Override
	public boolean execute(Computer computer) {
		computer.getRegisters().setProgramCounter(lokacija);
		return false;
	}

}
