package hr.fer.zemris.java.tecaj_2.jcomp;

import hr.fer.zemris.java.tecaj_2.jcomp.impl.ComputerImpl;
import hr.fer.zemris.java.tecaj_2.jcomp.impl.ExecutionUnitImpl;
import hr.fer.zemris.java.tecaj_2.jcomp.parser.InstructionCreatorImpl;
import hr.fer.zemris.java.tecaj_2.jcomp.parser.ProgramParser;

/**
 * Razred služi za simuliranje rada mikroprocesora.
 * @author Herman Zvonimir Došilović
 * @version 1.0
 */
public class Simulator {

	/**
	 * Početak programa. Program kao jedini argument naredbenog retka prima stazu do datoteke sa asemblerskim kodom
	 * programa
	 * koji je potrebno prevesti i pokrenuti
	 * @param args argumenti naredbenog retka
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		if (args.length != 1) {
			throw new IllegalArgumentException("Program očekuje jedan argument.");
		}
		// Stvori računalo s 256 memorijskih lokacija i 16 registara
		Computer comp = new ComputerImpl(256, 16);

		// Stvori objekt koji zna stvarati primjerke instrukcija
		InstructionCreator creator = new InstructionCreatorImpl("hr.fer.zemris.java.tecaj_2.jcomp.impl.instructions");

		// Napuni memoriju računala programom iz datoteke; instrukcije stvaraj
		// uporabom predanog objekta za stvaranje instrukcija
		ProgramParser.parse(args[0], comp, creator);

		// Stvori izvršnu jedinicu
		ExecutionUnit exec = new ExecutionUnitImpl();

		// Izvedi program
		exec.go(comp);
	}

}
