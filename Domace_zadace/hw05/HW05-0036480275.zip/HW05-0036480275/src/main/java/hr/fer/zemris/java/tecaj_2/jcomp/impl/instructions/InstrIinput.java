package hr.fer.zemris.java.tecaj_2.jcomp.impl.instructions;

import hr.fer.zemris.java.tecaj_2.jcomp.Computer;
import hr.fer.zemris.java.tecaj_2.jcomp.Instruction;
import hr.fer.zemris.java.tecaj_2.jcomp.InstructionArgument;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.List;

/**
 * Razred {@code InstrIinput} predstavlja razred koji implementira instrukciju <i>iinput</i>
 * <p>
 * {@code iinput lokacija}
 * </p>
 * Čita redak s tipkovnice. Sadržaj tumači kao Integer i njew zapisuje na zadanu memorijsku lokaciju.
 * Dodatno postavlja zastavicu {@code flag} na {@code true} ako je sve u redu, odnosno na {@code false} ako konverzija
 * nije uspjela
 * ili je drugi problem s čitanjem.
 * @author Forall360
 */
public class InstrIinput implements Instruction {

	/** Predstavlja lokaciju na koju treba zapisati učitani podatak */
	private final int lokacija;

	/**
	 * Stvara novu instrukciju {@code iinput}.
	 * @param arguments argumenti instrukcije {@code iinput}.
	 * @throws IllegalArgumentException ako broj argumenata instrukcije nije jedank 1.
	 */
	public InstrIinput(List<InstructionArgument> arguments) {
		if (arguments.size() != 1) {
			throw new IllegalArgumentException("Instrukcija iinput očekuje jedan argument.");
		}
		if (!arguments.get(0).isNumber()) {
			throw new IllegalArgumentException("iinput: prvi argument treba biti broj.");
		}

		this.lokacija = (int) arguments.get(0).getValue();
	}

	@Override
	public boolean execute(Computer computer) {
		BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
		int value = 0;
		String line = null;
		try {
			line = reader.readLine();
			value = Integer.parseInt(line);
		}
		catch (IOException e) {
			e.printStackTrace();
		}
		catch (NumberFormatException e) {
			computer.getRegisters().setFlag(false);
			return false;
		}
		computer.getMemory().setLocation(lokacija, value);
		computer.getRegisters().setFlag(true);
		return false;
	}
}
