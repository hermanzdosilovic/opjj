package hr.fer.zemris.java.tecaj_2.jcomp.impl;

import hr.fer.zemris.java.tecaj_2.jcomp.*;

/**
 * Razred {@code ComputerImpl} implementira sučelje {@code Computer} koje predstavlja podatkovni
 * dio računala.
 * @author Herman Zvonimir Došilović
 * @version 1.0
 */
public class ComputerImpl implements Computer {

	/** Predstavlja registre računala. */
	private final Registers registers;

	/** Prestavalja memoriju računala. */
	private final Memory memory;

	/**
	 * Stvara novo računalo sa željenim brojem memorijskih lokacija i brojem registara.
	 * @param size broj memorijskih lokacija
	 * @param regsLen broj registara
	 */
	public ComputerImpl(final int size, final int regsLen) {
		try {
			this.memory = new MemoryImpl(size);
			this.registers = new RegistersImpl(regsLen);
		}
		catch (IllegalArgumentException e) {
			throw e;
		}
	}

	/**
	 * Metoda koja vraća registre računala.
	 * @return registri
	 */
	@Override
	public Registers getRegisters() {
		return this.registers;
	}

	/**
	 * Metoda koja vraća memoriju računala.
	 * @return memorija računala
	 */
	@Override
	public Memory getMemory() {
		return this.memory;
	}

}
