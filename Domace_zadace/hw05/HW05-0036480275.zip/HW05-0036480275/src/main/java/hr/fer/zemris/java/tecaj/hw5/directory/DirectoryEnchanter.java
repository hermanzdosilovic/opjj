package hr.fer.zemris.java.tecaj.hw5.directory;

import hr.fer.zemris.java.tecaj.hw5.specifier.FilterSpecifier;
import hr.fer.zemris.java.tecaj.hw5.specifier.SortSpecifier;
import hr.fer.zemris.java.tecaj.hw5.specifier.WriteSpecifier;

import java.io.FileFilter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Enchantes a specified directory with given arguments (specifiers).
 * @author Herman Zvonimir Došilović
 * @version 1.0
 */
public class DirectoryEnchanter {

	private DirectoryRoot dirRoot;
	private List<Comparator<DirectoryObject>> sortSpecifier;
	private List<FileFilter> filterSpecifier;
	private List<WriteSpecifier> writeSpecifiers;
	private List<Boolean> indent;
	/**
	 * Creates new {@code DirectoryEnchanter}. {@code DirectoryEnchanter} enchants {@code dirRoot} with
	 * specified arguments.
	 * @param dirRoot directory to enchant.
	 * @param specifiers enchant directory with these specifiers.
	 */
	public DirectoryEnchanter(Directory dirRoot, List<String> specifiers) {
		this.dirRoot = (DirectoryRoot) dirRoot;
		sortSpecifier = new ArrayList<>();
		filterSpecifier = new ArrayList<>();
		writeSpecifiers = new ArrayList<>();
		indent = new ArrayList<>();
		parseSpecifiers(specifiers);
		if(writeSpecifiers.size() == 0) {
			writeSpecifiers.addAll(Arrays.asList(WriteSpecifier.t, WriteSpecifier.n, WriteSpecifier.s));
			indent.addAll(Arrays.asList(false, false, true));
		}
	}

	private void parseSpecifiers(List<String> specifiers) {
		Pattern s = Pattern.compile("^\\-s:.+$");
		Pattern f = Pattern.compile("^\\-f:.+$");
		Pattern w = Pattern.compile("^\\-w:.+$");
		Matcher sort;
		Matcher filter;
		Matcher write;
		
		for (String spec : specifiers) {
			sort = s.matcher(spec);
			filter = f.matcher(spec);
			write = w.matcher(spec);
			
			if (sort.find()) {
				addSortSpecifier(spec.substring(spec.indexOf(':') + 1));
			}
			else if (filter.find()) {
				addFilterSpecifier(spec.substring(spec.indexOf(':') + 1));
			}
			else if (write.find()) {
				addWriteSpecifier(spec.substring(spec.indexOf(':') + 1));
			}
			else {
				System.err.println(spec + " is invalid specifier.");
			}
		}
	}
	
	private void addWriteSpecifier(String argument) {
		Pattern w = Pattern.compile("^[ntsmh]$");
		Matcher write = w.matcher(argument);
		if(!write.find()) {
			System.err.println("Invalid write specifier.");
			return;
		}
		
		WriteSpecifier newWriteSpecifier;
		
		if(argument.contains("n")) {
			newWriteSpecifier = new WriteSpecifier(WriteSpecifier.n);
			indent.add(false);
		}
		else if(argument.contains("t")) {
			newWriteSpecifier = new WriteSpecifier(WriteSpecifier.t);
			indent.add(false);
		}
		else if(argument.contains("s")) {
			newWriteSpecifier = new WriteSpecifier(WriteSpecifier.s);
			indent.add(true);
		}
		else if(argument.contains("m")) {
			newWriteSpecifier = new WriteSpecifier(WriteSpecifier.m);
			indent.add(false);
		}
		else {
			newWriteSpecifier = new WriteSpecifier(WriteSpecifier.h);
			indent.add(false);
		}
		
		writeSpecifiers.add(newWriteSpecifier);
		
	}
	private void addFilterSpecifier(String argument) {
		Pattern f = Pattern.compile("^\\-?[sfle]\\d*$");
		Matcher filter = f.matcher(argument);
		FilterSpecifier newFilterSpecifier;

		if (!filter.find()) {
			System.err.println("Invalid filter specifier.");
			return;
		}

		if (argument.contains("s")) {
			f = Pattern.compile("^\\-?s\\d+$");
			filter = f.matcher(argument);
			if (!filter.find()) {
				System.err.println("Invalid filter specifier.");
				return;
			}
			newFilterSpecifier = new FilterSpecifier(new FilterSpecifier.sSIZE(Integer.parseInt(argument
					.substring(argument.indexOf("s") + 1))));
		}
		else if (argument.contains("l")) {
			f = Pattern.compile("^\\-?l\\d+$");
			filter = f.matcher(argument);
			if (!filter.find()) {
				System.err.println("Invalid filter specifier.");
				return;
			}
			newFilterSpecifier = new FilterSpecifier(new FilterSpecifier.lSIZE(Integer.parseInt(argument
					.substring(argument.indexOf("l") + 1))));
		}
		else if (argument.contains("f")) {
			f = Pattern.compile("^\\-?f$");
			filter = f.matcher(argument);
			if (!filter.find()) {
				System.err.println("Invalid filter specifier.");
				return;
			}
			newFilterSpecifier = new FilterSpecifier(FilterSpecifier.f);
		}
		else {
			f = Pattern.compile("^\\-?e$");
			filter = f.matcher(argument);
			if (!filter.find()) {
				System.err.println("Invalid filter specifier.");
				return;
			}
			newFilterSpecifier = new FilterSpecifier(FilterSpecifier.e);
		}

		if (argument.contains("-")) {
			newFilterSpecifier.reverseOrder(true);
		}

		filterSpecifier.add(newFilterSpecifier);
	}

	private void addSortSpecifier(String argument) {
		Pattern s = Pattern.compile("^\\-?[snmtle]$");
		Matcher sort = s.matcher(argument);
		Comparator<DirectoryObject> newSortSpecifier;

		if (!sort.find()) {
			System.err.println("Invalid sort specifier.");
			return;
		}

		if (argument.contains("s")) {
			newSortSpecifier = new SortSpecifier(SortSpecifier.s);
		}
		else if (argument.contains("n")) {
			newSortSpecifier = new SortSpecifier(SortSpecifier.n);
		}
		else if (argument.contains("m")) {
			newSortSpecifier = new SortSpecifier(SortSpecifier.m);
		}
		else if (argument.contains("t")) {
			newSortSpecifier = new SortSpecifier(SortSpecifier.t);
		}
		else if (argument.contains("l")) {
			newSortSpecifier = new SortSpecifier(SortSpecifier.l);
		}
		else {
			newSortSpecifier = new SortSpecifier(SortSpecifier.e);
		}

		if (argument.contains("-")) {
			newSortSpecifier = (Comparator<DirectoryObject>) Collections.reverseOrder(newSortSpecifier);
		}

		sortSpecifier.add(newSortSpecifier);
	}

	public List<DirectoryObject> getEnchantedDirectory() {
		List<DirectoryObject> objects = new ArrayList<>(dirRoot.getObjects(filterSpecifier));
		Collections.sort(objects, new SortSpecifier(sortSpecifier));
		return objects;
	}
	
	public void tableOnScreen() {
		List<List<String>> table = new ArrayList<>();
		int[] maxlen = new int[writeSpecifiers.size()];
		for(DirectoryObject obj : this.getEnchantedDirectory()) {
			WriteSpecifier w = new WriteSpecifier(writeSpecifiers);
			table.add(w.getData(obj));
			int i = 0;
			for(String s : w.getData(obj)) {
				if(maxlen[i] <= s.length()) {
					maxlen[i] = s.length() + 1;
				}
				i++;
			}
		}
		printFrame(maxlen);
		for(int i = 0; i < table.size(); i++) {
			for(int j = 0; j < table.get(i).size(); j++) {
				if(indent.get(j)) {
					System.out.printf("|%" + (maxlen[j] - table.get(i).get(j).length()) + "s" +"%s ", "", table.get(i).get(j));
				}
				else {
					System.out.printf("| %s%" + (maxlen[j] - table.get(i).get(j).length()) + "s", table.get(i).get(j), " ");
				}
			}
			System.out.println("|");
		}
		printFrame(maxlen);
		
	}
	
	public void printFrame(int[] maxlen) {
		for(int i = 0; i < maxlen.length; i++) {
			System.out.print("+");
			for(int j = 0; j <= maxlen[i]; j++)
				System.out.print("-");
		}
		System.out.print("+\n");
	}
}
