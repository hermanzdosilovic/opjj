package hr.fer.zemris.java.tecaj_2.jcomp.impl.instructions;

import java.util.List;

import hr.fer.zemris.java.tecaj_2.jcomp.Computer;
import hr.fer.zemris.java.tecaj_2.jcomp.Instruction;
import hr.fer.zemris.java.tecaj_2.jcomp.InstructionArgument;

/**
 * Razred {@code InstrEcho} prestavlja razred koji implementira instrukciju <i>echo</i>.
 * <p>
 * {@code echo rX}
 * </p>
 * koja uzima sadržaj registra rX i ispisuje ga na ekran (pozivom metode {@code System.out.print()}).
 * @author Herman Zvonimir Došilović
 * @version 1.0
 */
public class InstrEcho implements Instruction {

	/** Index registra čiji sadržaj treba ispisati. */
	private final int rx;

	/**
	 * Stvara novu instrukciju {@code echo}.
	 * @param arguments argumenti instrukcije {@code echo}.
	 * @throws IllegalArgumentException ako je broj argumenata različit od 1.
	 */
	public InstrEcho(List<InstructionArgument> arguments) {
		if (arguments.size() != 1) {
			throw new IllegalArgumentException("Instrukcija echo očekuje jedan argument.");
		}
		if (!arguments.get(0).isRegister()) {
			throw new IllegalArgumentException("echo: argument treba biti registar.");
		}
		this.rx = (int) arguments.get(0).getValue();
	}

	@Override
	public boolean execute(Computer computer) {
		System.out.print(computer.getRegisters().getRegisterValue(rx).toString());
		return false;
	}

}
