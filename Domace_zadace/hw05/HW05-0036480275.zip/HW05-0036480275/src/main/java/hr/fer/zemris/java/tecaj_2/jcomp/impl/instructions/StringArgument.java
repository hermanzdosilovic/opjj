package hr.fer.zemris.java.tecaj_2.jcomp.impl.instructions;

import hr.fer.zemris.java.tecaj_2.jcomp.InstructionArgument;

public class StringArgument implements InstructionArgument {
	
	String string;
	
	public StringArgument(String string) {
		this.string = new String(string);
	}
	
	@Override
	public boolean isRegister() {
		return false;
	}

	@Override
	public boolean isString() {
		return true;
	}

	@Override
	public boolean isNumber() {
		return false;
	}

	@Override
	public Object getValue() {
		return string;
	}

}
