package hr.fer.zemris.java.tecaj.hw5.specifier;

import hr.fer.zemris.java.tecaj.hw5.directory.DirectoryObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

public class WriteSpecifier {
	
	private List<WriteSpecifier> writeSpecifiers;
	
	public WriteSpecifier(List<WriteSpecifier> specifiers) {
		this.writeSpecifiers = new ArrayList<>(specifiers);
	}
	
	public WriteSpecifier(WriteSpecifier ... specifiers) {
		this(Arrays.asList(specifiers));
	}
	
	public WriteSpecifier(WriteSpecifier specifier) {
		this(Arrays.asList(specifier));
	}
	
	public static final WriteSpecifier n = new WriteSpecifier() {
		public List<String> getData(DirectoryObject dirObject) {
			return Arrays.asList(dirObject.getName());
		}
	};
	
	public static final WriteSpecifier t = new WriteSpecifier() {
		public List<String> getData(DirectoryObject dirObject) {
			if(dirObject.isDirectory()) {
				return Arrays.asList("d");
			}
			return Arrays.asList("f");
		}
	};
	
	public static final WriteSpecifier s = new WriteSpecifier() {
		public List<String> getData(DirectoryObject dirObject) {
			return Arrays.asList(String.format("%d", dirObject.length()));
		}
	};
	
	public static final WriteSpecifier m = new WriteSpecifier() {
		public List<String> getData(DirectoryObject dirObject) {
			Date date = new Date(dirObject.lastModified());
			SimpleDateFormat sdf = new SimpleDateFormat("yyy-MM-dd HH:mm:ss");
			String formatiraniDatum = sdf.format(date);
			return Arrays.asList(formatiraniDatum);
		}
	};
	
	public static final WriteSpecifier h = new WriteSpecifier() {
		public List<String> getData(DirectoryObject dirObject) {
			if(dirObject.isHidden()) {
				return Arrays.asList("h");
			}
			return Arrays.asList(" ");
		}
	};
	
	public List<String> getData(DirectoryObject dirObject) {
		List<String> strings = new ArrayList<>();
		for(WriteSpecifier ws : writeSpecifiers) {
			strings.addAll(ws.getData(dirObject));
		}
		return strings;
	}
}
