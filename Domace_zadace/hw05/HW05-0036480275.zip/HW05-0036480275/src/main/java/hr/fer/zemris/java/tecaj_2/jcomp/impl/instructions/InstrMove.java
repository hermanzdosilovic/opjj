package hr.fer.zemris.java.tecaj_2.jcomp.impl.instructions;

import hr.fer.zemris.java.tecaj_2.jcomp.Computer;
import hr.fer.zemris.java.tecaj_2.jcomp.Instruction;
import hr.fer.zemris.java.tecaj_2.jcomp.InstructionArgument;

import java.util.List;

/**
 * Razred {@code InstrMove} predstavlja razred koji implementira instrukciju <i>move</i>
 * <p>
 * {@code move rx, ry}
 * </p>
 * @author Herman Zvonimir Došilović
 * @version 1.0
 */
public class InstrMove implements Instruction {

	/** Predstavlja odredišni registar. */
	public final int rx;

	/** Predstavlja izvorišni registar. */
	public final int ry;

	/**
	 * Stvara novu instrukciju {@code move}.
	 * @param arguments argumenti instrukcije {@code move}.
	 * @throws IllegalArgumentException ako broj argumenata nije 2.
	 */
	public InstrMove(List<InstructionArgument> arguments) {
		if (arguments.size() != 2) {
			throw new IllegalArgumentException("Instrukcija move očekuje dva argumenta.");
		}
		if (!arguments.get(0).isRegister()) {
			throw new IllegalArgumentException("move: prvi argument treba biti registar.");
		}
		if (!arguments.get(1).isRegister()) {
			throw new IllegalArgumentException("move: drugi argument treba biti registar.");
		}

		this.rx = (int) arguments.get(0).getValue();
		this.ry = (int) arguments.get(1).getValue();
	}

	@Override
	public boolean execute(Computer computer) {
		Object valueY = computer.getRegisters().getRegisterValue(ry);
		computer.getRegisters().setRegisterValue(rx, valueY);
		return false;
	}

}
