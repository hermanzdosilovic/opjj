package hr.fer.zemris.java.tecaj_2.comp.impl;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import hr.fer.zemris.java.tecaj_2.jcomp.Computer;
import hr.fer.zemris.java.tecaj_2.jcomp.InstructionArgument;
import hr.fer.zemris.java.tecaj_2.jcomp.Registers;
import hr.fer.zemris.java.tecaj_2.jcomp.impl.instructions.InstrDecrement;
import hr.fer.zemris.java.tecaj_2.jcomp.impl.instructions.NumberArgument;
import hr.fer.zemris.java.tecaj_2.jcomp.impl.instructions.RegisterArgument;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;

public class InstructionDecrementTest {

	@Mock
	Computer c = mock(Computer.class);
	Registers r = mock(Registers.class);
	InstrDecrement inst;

	@Before
	public void setup() {
		c = mock(Computer.class);
		r = mock(Registers.class);
		when(c.getRegisters()).thenReturn(r);
	}

	@Test
	public void testInstrDecrementValidArgumnets() {
		when(c.getRegisters()).thenReturn(r);
		when(r.getRegisterValue(0)).thenReturn(1);

		inst = new InstrDecrement(Arrays.asList((InstructionArgument) new RegisterArgument(0)));
		inst.execute(c);

		verify(c, times(3)).getRegisters();
		verify(r, times(2)).getRegisterValue(0);
		verify(r, times(1)).setRegisterValue(0, 0);
	}

	@Test(expected = IllegalArgumentException.class)
	public void TestInstrDecrementInvalidArgumentsFirstTest() {
		List<InstructionArgument> args = new ArrayList<>();
		inst = new InstrDecrement(args);
	}

	@Test(expected = IllegalArgumentException.class)
	public void TestInstrDecrementInvalidArgumentsSecondTest() {
		List<InstructionArgument> args = new ArrayList<>();
		args.add((InstructionArgument) new NumberArgument(2));
		inst = new InstrDecrement(args);
	}
}
