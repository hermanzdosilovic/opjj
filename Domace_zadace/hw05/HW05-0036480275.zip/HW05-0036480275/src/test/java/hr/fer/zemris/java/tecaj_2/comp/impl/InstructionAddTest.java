package hr.fer.zemris.java.tecaj_2.comp.impl;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import hr.fer.zemris.java.tecaj_2.jcomp.Computer;
import hr.fer.zemris.java.tecaj_2.jcomp.Instruction;
import hr.fer.zemris.java.tecaj_2.jcomp.InstructionArgument;
import hr.fer.zemris.java.tecaj_2.jcomp.Registers;
import hr.fer.zemris.java.tecaj_2.jcomp.impl.instructions.InstrAdd;
import hr.fer.zemris.java.tecaj_2.jcomp.impl.instructions.NumberArgument;
import hr.fer.zemris.java.tecaj_2.jcomp.impl.instructions.RegisterArgument;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.Test;

public class InstructionAddTest {

	@Test
	public void testAddInstruction() {
		Computer c = mock(Computer.class);
		Registers r = mock(Registers.class);
		when(c.getRegisters()).thenReturn(r);

		when(r.getRegisterValue(0)).thenReturn(0);
		when(r.getRegisterValue(1)).thenReturn(1);
		when(r.getRegisterValue(2)).thenReturn(2);
		Instruction inst = new InstrAdd(Arrays.asList(new RegisterArgument(0), new RegisterArgument(1),
				(InstructionArgument) new RegisterArgument(2)));
		inst.execute(c);

		verify(c, times(3)).getRegisters();
		verify(r, times(1)).setRegisterValue(0, 3);
		verify(r, times(1)).getRegisterValue(1);
		verify(r, times(1)).getRegisterValue(2);
	}

	@Test(expected = IllegalArgumentException.class)
	public void testAddInstructionInvalidArgumentsFirst() {
		Computer c = mock(Computer.class);
		Registers r = mock(Registers.class);
		Instruction inst;
		List<InstructionArgument> args = new ArrayList<>();
		args.add(new NumberArgument(0));
		inst = new InstrAdd(args);
	}

	@Test(expected = IllegalArgumentException.class)
	public void testAddInstructionInvalidArgumentsSecond() {
		Computer c = mock(Computer.class);
		Registers r = mock(Registers.class);
		Instruction inst;
		List<InstructionArgument> args = new ArrayList<>();
		args.add(new NumberArgument(0));
		args.add(new RegisterArgument(1));
		args.add(new RegisterArgument(2));
		inst = new InstrAdd(args);
	}

	@Test(expected = IllegalArgumentException.class)
	public void testAddInstructionInvalidArgumentsThird() {
		Computer c = mock(Computer.class);
		Registers r = mock(Registers.class);
		Instruction inst;
		List<InstructionArgument> args = new ArrayList<>();
		args.add(new RegisterArgument(1));
		args.add(new NumberArgument(0));
		args.add(new RegisterArgument(2));
		inst = new InstrAdd(args);
	}

	@Test(expected = IllegalArgumentException.class)
	public void testAddInstructionInvalidArgumentsFourth() {
		Computer c = mock(Computer.class);
		Registers r = mock(Registers.class);
		Instruction inst;
		List<InstructionArgument> args = new ArrayList<>();
		args.add(new RegisterArgument(1));
		args.add(new RegisterArgument(2));
		args.add(new NumberArgument(0));
		inst = new InstrAdd(args);
	}
}
