package hr.fer.zemris.java.tecaj_2.comp.impl;

import static org.junit.Assert.*;
import org.junit.Test;

import hr.fer.zemris.java.tecaj_2.jcomp.Memory;
import hr.fer.zemris.java.tecaj_2.jcomp.impl.MemoryImpl;

public class MemoryImplTest {
	
	@Test
	public void testMemoryImplConstructorValidArguments() {
		int size = 10; // valid
		new MemoryImpl(size);
	}
	
	@Test (expected = IllegalArgumentException.class)
	public void testMemoryImplConstructorInvalidArguments() {
		int size = -20; // invalid
		new MemoryImpl(size);
	}
	
	@Test
	public void testSetGetLocationValidArguments() {
		int index = 1;
		int size = 10;
		int value = 7;
		Memory mem = new MemoryImpl(size);
		mem.setLocation(index, value);
		assertEquals("Values are not the same", value, mem.getLocation(index));
	}
	
	@Test (expected = IllegalArgumentException.class)
	public void testSetLocationInvalidArgumentFirstTest() {
		int index = -1; // invalid
		int size = 10;
		Memory mem = new MemoryImpl(size);
		mem.setLocation(index, 10);
	}
	
	@Test (expected = IllegalArgumentException.class)
	public void testSetLocationInvalidArgumentSecondTest() {
		int index = 21; // invalid
		int size = 10;
		Memory mem = new MemoryImpl(size);
		mem.setLocation(index, 10);
	}
	
	@Test (expected = IllegalArgumentException.class)
	public void testGetLocationInvalidArgumentFirstTest() {
		int index = -1;
		Memory mem = new MemoryImpl(10);
		mem.getLocation(index);
	}
	
	@Test (expected = IllegalArgumentException.class)
	public void testGetLocationInvalidArgumentSecondTest() {
		int index = 21;
		Memory mem = new MemoryImpl(10);
		mem.getLocation(index);
	}
}
