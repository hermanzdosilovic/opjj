package hr.fer.zemris.java.tecaj_2.comp.impl;

import static junit.framework.Assert.*;
import hr.fer.zemris.java.tecaj_2.jcomp.Registers;
import hr.fer.zemris.java.tecaj_2.jcomp.impl.RegistersImpl;

import org.junit.Test;

public class RegistersImplTest {
	
	@Test (expected = IllegalArgumentException.class)
	public void testRegisterImplConstructorWithInvalidArguments() {
		int registerSize = -1; // invalid size;
		new RegistersImpl(registerSize);
	}
	/** Tests methods setRegisterValue() with valid arguments. */
	@Test
	public void testSetRegisterValueValidArguments() {
		int registerSize = 10;
		int value = 6;
		int index = 1;
		Registers register = new RegistersImpl(registerSize);
		register.setRegisterValue(index, value);
	}

	/** Tests methods setRegisterValue() with invalid arguments. */
	@Test (expected = IllegalArgumentException.class)
	public void testSetRegisterValueInvalidArgumentsFirstTest() {
		int registerSize = 10;
		int value = 6;
		int index = -1; // invalid index
		Registers register = new RegistersImpl(registerSize);
		register.setRegisterValue(index, value);
	}
	
	/** Tests methods setRegisterValue() with invalid arguments. */
	@Test (expected = IllegalArgumentException.class)
	public void testSetRegisterValueInvalidArgumentsSecondTest() {
		int registerSize = 10;
		int value = 6;
		int index = registerSize + 2;; // invalid index
		Registers register = new RegistersImpl(registerSize);
		register.setRegisterValue(index, value);
	}
	
	/** Tests methods getRegisterValue() with valid arguments. */
	@Test
	public void testGetRegisterValueValidArguments() {
		int registerSize = 10;
		int index = 0; // valid index
		Registers register = new RegistersImpl(registerSize);
		register.getRegisterValue(index);
	}
	
	/** Tests methods getRegisterValue() with invalid arguments. */
	@Test (expected = IllegalArgumentException.class)
	public void testGetRegisterValueInvalidArgumentsFirstTest() {
		int registerSize = 10;
		int index = -1; // invalid index
		Registers register = new RegistersImpl(registerSize);
		register.getRegisterValue(index);
	}
	
	/** Tests methods getRegisterValue() with invalid arguments. */
	@Test (expected = IllegalArgumentException.class)
	public void testGetRegisterValueInvalidArgumentsSecondTest() {
		int registerSize = 10;
		int index = registerSize + 2; // invalid index
		Registers register = new RegistersImpl(registerSize);
		register.getRegisterValue(index);
	}
	
	@SuppressWarnings("deprecation")
	@Test
	public void testSetGetProgramCounter() {
		int registerSize = 10;
		int pc = 20;
		Registers register = new RegistersImpl(registerSize);
		register.setProgramCounter(pc);
		assertEquals("PC is not the same.", pc, register.getProgramCounter());
	}
	
	@Test (expected = IllegalArgumentException.class)
	public void testSetPRogramCounterInvalidArguments() {
		int registerSize = 10;
		int pc = -1; // invalid pc value
		Registers register = new RegistersImpl(registerSize);
		register.setProgramCounter(pc);
	}
	
	@Test
	public void testIncrementProgramCounter() {
		int registerSize = 10;
		Registers register = new RegistersImpl(registerSize);
		register.incrementProgramCounter();
	}
	
	@SuppressWarnings("deprecation")
	@Test
	public void testGetSetFlag() {
		int registerSize = 10;
		Registers register = new RegistersImpl(registerSize);
		boolean flag = true;
		register.setFlag(flag);
		assertEquals("Flag is not the same.", register.getFlag(), flag);
	}
}
