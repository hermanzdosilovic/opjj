package hr.fer.zemris.java.tecaj_2.comp.impl;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import hr.fer.zemris.java.tecaj_2.jcomp.Computer;
import hr.fer.zemris.java.tecaj_2.jcomp.Instruction;
import hr.fer.zemris.java.tecaj_2.jcomp.InstructionArgument;
import hr.fer.zemris.java.tecaj_2.jcomp.Registers;
import hr.fer.zemris.java.tecaj_2.jcomp.impl.instructions.InstrMove;
import hr.fer.zemris.java.tecaj_2.jcomp.impl.instructions.NumberArgument;
import hr.fer.zemris.java.tecaj_2.jcomp.impl.instructions.RegisterArgument;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import static org.mockito.Mockito.*;

public class MoveTest {
	
	@Test
	public void testMoveInstr() {
		Computer c = mock(Computer.class);
		Registers r = mock(Registers.class);
		when(c.getRegisters()).thenReturn(r);
		when(r.getRegisterValue(0)).thenReturn(0);
		when(r.getRegisterValue(1)).thenReturn(1);
		List<InstructionArgument> args = new ArrayList<>();
		Instruction inst;
		args.add(new RegisterArgument(0));
		args.add(new RegisterArgument(1));
		inst = new InstrMove(args);
		inst.execute(c);
		verify(c, times(2)).getRegisters();
		verify(r, times(1)).getRegisterValue(1);
		verify(r, times(1)).setRegisterValue(0, 1);
	}
	
	@Test (expected = IllegalArgumentException.class)
	public void illegalNumberOfArguments() {
		Computer c = mock(Computer.class);
		Registers r = mock(Registers.class);
		List<InstructionArgument> args = new ArrayList<>();
		Instruction inst = new InstrMove(args);
	}
	
	@Test (expected = IllegalArgumentException.class)
	public void illegalNumberOfArgumentsSecondTest() {
		Computer c = mock(Computer.class);
		Registers r = mock(Registers.class);
		List<InstructionArgument> args = new ArrayList<>();
		args.add(new NumberArgument(0));
		args.add(new RegisterArgument(1));
		Instruction inst = new InstrMove(args);
	}
	
	@Test (expected = IllegalArgumentException.class)
	public void illegalNumberOfArgumentsThirdTest() {
		Computer c = mock(Computer.class);
		Registers r = mock(Registers.class);
		List<InstructionArgument> args = new ArrayList<>();
		args.add(new RegisterArgument(0));
		args.add(new NumberArgument(1));
		Instruction inst = new InstrMove(args);
	}
}
