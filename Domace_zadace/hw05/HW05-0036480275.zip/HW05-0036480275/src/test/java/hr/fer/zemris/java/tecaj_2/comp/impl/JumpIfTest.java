package hr.fer.zemris.java.tecaj_2.comp.impl;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import hr.fer.zemris.java.tecaj_2.jcomp.Computer;
import hr.fer.zemris.java.tecaj_2.jcomp.Instruction;
import hr.fer.zemris.java.tecaj_2.jcomp.InstructionArgument;
import hr.fer.zemris.java.tecaj_2.jcomp.Registers;
import hr.fer.zemris.java.tecaj_2.jcomp.impl.instructions.InstrJump;
import hr.fer.zemris.java.tecaj_2.jcomp.impl.instructions.InstrJumpIfTrue;
import hr.fer.zemris.java.tecaj_2.jcomp.impl.instructions.NumberArgument;
import hr.fer.zemris.java.tecaj_2.jcomp.impl.instructions.RegisterArgument;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.Test;

public class JumpIfTest {

	@Test
	public void jumpTestValid() {
		Computer c = mock(Computer.class);
		Registers r = mock(Registers.class);
		when(c.getRegisters()).thenReturn(r);
		when(r.getFlag()).thenReturn(true);
		
		Instruction instr = new InstrJumpIfTrue(Arrays.asList((InstructionArgument) new NumberArgument(2)));
		instr.execute(c);
		
		verify(c, times(2)).getRegisters();
		verify(r, times(1)).getFlag();
		verify(r, times(1)).setProgramCounter(2);
	}
	
	@Test (expected = IllegalArgumentException.class)
	public void jumpTestInvalidSize() {
		Computer c = mock(Computer.class);
		List<InstructionArgument> args = new ArrayList<>();
		Instruction instr = new InstrJumpIfTrue(args);
		instr.execute(c);
	}
	
	@Test (expected = IllegalArgumentException.class)
	public void jumpTestInvalidArgument() {
		Computer c = mock(Computer.class);
		List<InstructionArgument> args = new ArrayList<>();
		args.add((InstructionArgument) new RegisterArgument(0));
		Instruction instr = new InstrJumpIfTrue(args);
		instr.execute(c);
	}
}
