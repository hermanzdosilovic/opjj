package hr.fer.zemris.java.tecaj_2.comp.impl;

import static org.junit.Assert.assertEquals;
import hr.fer.zemris.java.tecaj_2.jcomp.Computer;
import hr.fer.zemris.java.tecaj_2.jcomp.Memory;
import hr.fer.zemris.java.tecaj_2.jcomp.Registers;
import hr.fer.zemris.java.tecaj_2.jcomp.impl.ComputerImpl;

import org.junit.Test;

public class ComputerImplTest {
	
	@Test
	public void testComputerImplConstructorValidArguments() {
		new ComputerImpl(20, 30);
	}
	
	@Test (expected = IllegalArgumentException.class)
	public void testComputerImpleConstructorInvalidArguments() {
		new ComputerImpl(-20, 30);
	}
	
	@Test
	public void testGetRegisters() {
		Computer comp = new ComputerImpl(20, 30);
		Registers reg = comp.getRegisters();
		assertEquals("Registers are not the same.", reg, comp.getRegisters());
	}
	
	@Test
	public void testGetMemory() {
		Computer comp = new ComputerImpl(20, 30);
		Memory mem = comp.getMemory();
		assertEquals("Memory is not the same.", mem, comp.getMemory());
	}
	
}
