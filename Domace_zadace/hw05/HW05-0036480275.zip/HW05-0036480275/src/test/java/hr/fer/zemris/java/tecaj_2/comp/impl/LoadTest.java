package hr.fer.zemris.java.tecaj_2.comp.impl;

import java.util.ArrayList;
import java.util.List;

import hr.fer.zemris.java.tecaj_2.jcomp.Computer;
import hr.fer.zemris.java.tecaj_2.jcomp.Instruction;
import hr.fer.zemris.java.tecaj_2.jcomp.InstructionArgument;
import hr.fer.zemris.java.tecaj_2.jcomp.Memory;
import hr.fer.zemris.java.tecaj_2.jcomp.Registers;
import hr.fer.zemris.java.tecaj_2.jcomp.impl.instructions.InstrLoad;
import hr.fer.zemris.java.tecaj_2.jcomp.impl.instructions.InstrMove;
import hr.fer.zemris.java.tecaj_2.jcomp.impl.instructions.NumberArgument;
import hr.fer.zemris.java.tecaj_2.jcomp.impl.instructions.RegisterArgument;

import org.junit.Test;

import static org.mockito.Mockito.*;

public class LoadTest {
	
	@Test
	public void loadTest() {
		Computer c = mock(Computer.class);
		Memory m = mock(Memory.class);
		Registers r = mock(Registers.class);
		when(c.getMemory()).thenReturn(m);
		when(c.getRegisters()).thenReturn(r);
		when(m.getLocation(0)).thenReturn(0);
		List<InstructionArgument> args = new ArrayList<>();
		args.add(new RegisterArgument(0));
		args.add(new NumberArgument(0));
		Instruction instr = new InstrLoad(args);
		instr.execute(c);
		verify(c, times(1)).getRegisters();
		verify(r, times(1)).setRegisterValue(0, 0);
		verify(m, times(1)).getLocation(0);
		verify(c, times(1)).getMemory();
	}
	
	@Test (expected = IllegalArgumentException.class)
	public void illegalNumberOfArguments() {
		Computer c = mock(Computer.class);
		Registers r = mock(Registers.class);
		List<InstructionArgument> args = new ArrayList<>();
		Instruction inst = new InstrLoad(args);
	}
	
	@Test (expected = IllegalArgumentException.class)
	public void illegalNumberOfArgumentsSecondTest() {
		Computer c = mock(Computer.class);
		Registers r = mock(Registers.class);
		List<InstructionArgument> args = new ArrayList<>();
		args.add(new NumberArgument(0));
		args.add(new RegisterArgument(1));
		Instruction inst = new InstrLoad(args);
	}
	
	@Test (expected = IllegalArgumentException.class)
	public void illegalNumberOfArgumentsThirdTest() {
		Computer c = mock(Computer.class);
		Registers r = mock(Registers.class);
		List<InstructionArgument> args = new ArrayList<>();
		args.add(new RegisterArgument(0));
		args.add(new RegisterArgument(1));
		Instruction inst = new InstrLoad(args);
	}
}
