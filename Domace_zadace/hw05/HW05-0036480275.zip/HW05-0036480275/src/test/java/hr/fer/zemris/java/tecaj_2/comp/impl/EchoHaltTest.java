package hr.fer.zemris.java.tecaj_2.comp.impl;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import hr.fer.zemris.java.tecaj_2.jcomp.Computer;
import hr.fer.zemris.java.tecaj_2.jcomp.Instruction;
import hr.fer.zemris.java.tecaj_2.jcomp.InstructionArgument;
import hr.fer.zemris.java.tecaj_2.jcomp.Registers;
import hr.fer.zemris.java.tecaj_2.jcomp.impl.instructions.InstrEcho;
import hr.fer.zemris.java.tecaj_2.jcomp.impl.instructions.InstrHalt;
import hr.fer.zemris.java.tecaj_2.jcomp.impl.instructions.NumberArgument;
import hr.fer.zemris.java.tecaj_2.jcomp.impl.instructions.RegisterArgument;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.mockito.Mock;

import static org.mockito.Mockito.*;

public class EchoHaltTest {
	
	@Mock
	Computer c = mock(Computer.class);
	Registers r = mock(Registers.class);
	
	@Test
	public void echoTest() {
		List<InstructionArgument> args = new ArrayList<>();
		args.add(new RegisterArgument(0));
		when(c.getRegisters()).thenReturn(r);
		when(r.getRegisterValue(0)).thenReturn(0);
		Instruction instr = new InstrEcho(args);
		instr.execute(c);
		
		verify(c, times(1)).getRegisters();
		verify(r, times(1)).getRegisterValue(0);
	}
	
	@Test (expected = IllegalArgumentException.class)
	public void echoTestWrongArguments() {
		List<InstructionArgument> args = new ArrayList<>();
		Instruction instr = new InstrEcho(args);
	}
	
	@Test (expected = IllegalArgumentException.class)
	public void echoTestWrongAgumentsSecond() {
		List<InstructionArgument> args = new ArrayList<>();
		args.add(new NumberArgument(0));
		Instruction instr = new InstrEcho(args);
	}
	
	@Test (expected = IllegalArgumentException.class)
	public void haltWrong() {
		List<InstructionArgument> args = new ArrayList<>();
		args.add(new NumberArgument(0));
		Instruction instr = new InstrHalt(args);
	}
	
	@Test
	public void haltTest() {
		List<InstructionArgument> args = new ArrayList<>();
		Instruction instr = new InstrHalt(args);
		instr.execute(c);
	}
}
