package hr.fer.zemris.java.filechecking.lexical;

import hr.fer.zemris.java.filechecking.lexical.FCToken;
import hr.fer.zemris.java.filechecking.lexical.FCTokenType;
import junit.framework.Assert;

import org.junit.Test;

@SuppressWarnings("deprecation")
public class FCTokenTest {
    
    @Test
    public void tokenTest(){
        FCToken token = new FCToken(FCTokenType.ARGUMENT, "args");
        Assert.assertEquals("Token type not the same.", token.getType(), FCTokenType.ARGUMENT);
    }
}
