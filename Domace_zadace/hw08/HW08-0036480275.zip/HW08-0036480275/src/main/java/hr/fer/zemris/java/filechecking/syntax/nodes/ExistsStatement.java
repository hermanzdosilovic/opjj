package hr.fer.zemris.java.filechecking.syntax.nodes;

import hr.fer.zemris.java.filechecking.syntax.nodes.visitors.FCNodeVisitor;

public class ExistsStatement extends FCNode {
    
    private String type;
    private String file;
    private ProgramNode statements;
    private String failMessage;
    private boolean invert;
    
    public ExistsStatement(String type, String file, String failMessage, ProgramNode statements, boolean invert) {
        this.type = type;
        this.file = file;
        this.statements = statements;
        this.failMessage = failMessage;
        this.invert = invert;
    }
    
    @Override
    public boolean accept(FCNodeVisitor visitor) {
        return visitor.visit(this);
    }
    
    public String getType() {
        return type;
    }
    
    public ProgramNode getStatements() {
        return statements;
    }
    
    public String getFailMessage() {
        return failMessage;
    }
    
    public boolean invert() {
        return invert;
    }
    
    public String getFile() {
        return file;
    }

}
