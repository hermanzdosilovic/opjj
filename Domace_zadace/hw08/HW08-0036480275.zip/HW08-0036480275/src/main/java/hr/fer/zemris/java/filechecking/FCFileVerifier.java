package hr.fer.zemris.java.filechecking;

import hr.fer.zemris.java.filechecking.syntax.nodes.ProgramNode;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class FCFileVerifier {

    private File file;
    private String fileName;
    private String program;
    private Map<String, Object> initialData;
    
    private List<String> errors;
    
    private ProgramNode programNode;
    private ProgramExecutorVisitor programExecutor;
    
    public FCFileVerifier(File file, String fileName, String program, Map<String, Object> initialData) {
        this.file = file;
        this.fileName = fileName;
        this.program = program;
        this.initialData = initialData;
        errors = new ArrayList<>();
        FCProgramChecker verifier = new FCProgramChecker(this.program);
        programNode = verifier.getProgramNode();
        start();
    }

    private void start() {
        String newFileName = file.getAbsolutePath();
        newFileName = newFileName.substring(0, newFileName.lastIndexOf(File.separatorChar)) + File.separator + fileName + File.separator;
        file = new File(newFileName);
        if(!file.exists()) {
            errors.add("File does not exists. " + newFileName);
            return;
        }
        
        programExecutor = new ProgramExecutorVisitor(initialData, fileName, file);
        execute();
    }
    
    private void execute() {
        programNode.accept(programExecutor);
    }

    public boolean hasErrors() {
        return !errors().isEmpty();
    }
    
    public List<String> errors() {
        List<String> errors = programExecutor.getErrors();
        errors.addAll(this.errors);
        return errors;
    }

}
