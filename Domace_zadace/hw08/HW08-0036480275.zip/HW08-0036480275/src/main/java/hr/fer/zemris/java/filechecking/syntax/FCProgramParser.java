package hr.fer.zemris.java.filechecking.syntax;

import hr.fer.zemris.java.filechecking.lexical.FCProgramTokenizer;
import hr.fer.zemris.java.filechecking.lexical.FCTokenType;
import hr.fer.zemris.java.filechecking.syntax.nodes.DefStatement;
import hr.fer.zemris.java.filechecking.syntax.nodes.ExistsStatement;
import hr.fer.zemris.java.filechecking.syntax.nodes.FCNode;
import hr.fer.zemris.java.filechecking.syntax.nodes.FailStatement;
import hr.fer.zemris.java.filechecking.syntax.nodes.FilenameStatement;
import hr.fer.zemris.java.filechecking.syntax.nodes.FormatStatement;
import hr.fer.zemris.java.filechecking.syntax.nodes.ProgramNode;
import hr.fer.zemris.java.filechecking.syntax.nodes.TerminateNode;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class FCProgramParser {

    private FCProgramTokenizer tokenizer;

    private ProgramNode programNode;

    private List<String> errors;
    
    private static Set<String> fileArguments;
    static {
        fileArguments = new HashSet<>();
        fileArguments.add("f");
        fileArguments.add("fi");
        fileArguments.add("file");
        fileArguments.add("d");
        fileArguments.add("di");
        fileArguments.add("dir");
    }
    
    private static Set<String> fileFormats;
    static {
        fileFormats = new HashSet<>();
        fileFormats.add("zip");
    }
    
    public FCProgramParser(FCProgramTokenizer tokenizer) {
        this.tokenizer = tokenizer;
    }

    public void execute() {
        List<FCNode> statements = new ArrayList<>();
        errors = new ArrayList<>();
        boolean closedParenthesisExpected = false;
        if(tokenizer.getCurrentToken().getType() == FCTokenType.OPEN_PARENTHESIS) {
            closedParenthesisExpected = true;
        }
        tokenizer.nextToken();
        while (true) {
            if (tokenizer.getCurrentToken().getType() == FCTokenType.EOF) {
                break;
            }
            if (tokenizer.getCurrentToken().getType() == FCTokenType.CLOSED_PARENTHESIS) {
                if(!closedParenthesisExpected) {
                    errors.add("Closed parenthesis is not expected.");
                    tokenizer.nextToken();
                }
                else {
                    break;
                }
            }
            boolean invert = false;
            if (tokenizer.getCurrentToken().getType() == FCTokenType.EXCLAMATION_MARK) {
                invert = true;
                tokenizer.nextToken();
                if (tokenizer.getCurrentToken().getType() != FCTokenType.KEYWORD ||
                        tokenizer.getCurrentToken().getValue().equals("def")) {
                    errors.add("After ! keyword expected, but was " + tokenizer.getCurrentToken().getValue());
                    continue;
                }
            }

            if ("terminate".equals(tokenizer.getCurrentToken().getValue())) {
                statements.add(new TerminateNode());
                tokenizer.nextToken();
                continue;
            }

            if ("def".equals(tokenizer.getCurrentToken().getValue())) {
                tokenizer.nextToken();
                statements.add(parseDef());
                tokenizer.nextToken();
                continue;
            }
            
            if (tokenizer.getCurrentToken().getType() == FCTokenType.KEYWORD) {
                statements.add(parseKeyword(invert));
                continue;
            }
            
            errors.add("Unexpected keyword found. " + tokenizer.getCurrentToken().getType());
            tokenizer.nextToken();
        }
        programNode = new ProgramNode(statements);
    }

    private FCNode parseKeyword(boolean invert) {
        if("exists".equals(tokenizer.getCurrentToken().getValue())) {
            return parseExists(invert);
        }
        if("fail".equals(tokenizer.getCurrentToken().getValue())) {
            return parseFail(invert);
        }
        if("format".equals(tokenizer.getCurrentToken().getValue())) {
            return parseFormat(invert);
        }
        if("filename".equals(tokenizer.getCurrentToken().getValue())){
            return parseFilename(invert);
        }
        errors.add("Unknown keyword encountered " + tokenizer.getCurrentToken().getValue());
        return null;
    }

    private FCNode parseFilename(boolean invert) {
        tokenizer.nextToken();
        String fileName;
        boolean insensitive = false;
        if(tokenizer.getCurrentToken().getType() == FCTokenType.REGULARSTRING) {
            fileName = (String) tokenizer.getCurrentToken().getValue();
        }
        else if(tokenizer.getCurrentToken().getType() == FCTokenType.INSENSITIVESTRING) {
            fileName = (String) tokenizer.getCurrentToken().getValue();
            insensitive = true;
        }
        else {
            errors.add("Regular or insensitive string is expected after fail message but was " + tokenizer.getCurrentToken().getType());
            return null;
        }
        tokenizer.nextToken();
        String failMessage = "";
        if(tokenizer.getCurrentToken().getType() == FCTokenType.FAILSTRING) {
            failMessage = (String) tokenizer.getCurrentToken().getValue();
            tokenizer.nextToken();
        }
        ProgramNode statements = null;
        if(tokenizer.getCurrentToken().getType() == FCTokenType.OPEN_PARENTHESIS) {
            FCProgramParser existsParser = new FCProgramParser(tokenizer);
            existsParser.execute();
            statements = existsParser.getProgramNode();
            if(tokenizer.getCurrentToken().getType() == FCTokenType.CLOSED_PARENTHESIS) {
                tokenizer.nextToken();
            }
            else {
                errors.add("Closed parenthesis expected but was " + tokenizer.getCurrentToken().getType());
                return null;
            }
            errors.addAll(existsParser.getErrors());
        }
        return new FilenameStatement(fileName, failMessage, statements, invert, insensitive);
    }

    private FCNode parseFormat(boolean invert) {
        tokenizer.nextToken();
        String format = "";
        if(tokenizer.getCurrentToken().getType() == FCTokenType.ARGUMENT) {
            format = (String) tokenizer.getCurrentToken().getValue();
            if(!fileFormats.contains(format)) {
                errors.add("Unsupported file format " + format);
                return null;
            }
        }
        tokenizer.nextToken();
        String failMessage = "";
        if(tokenizer.getCurrentToken().getType() == FCTokenType.FAILSTRING) {
            failMessage = (String) tokenizer.getCurrentToken().getValue();
            tokenizer.nextToken();
        }
        ProgramNode statements = null;
        if(tokenizer.getCurrentToken().getType() == FCTokenType.OPEN_PARENTHESIS) {
            FCProgramParser existsParser = new FCProgramParser(tokenizer);
            existsParser.execute();
            statements = existsParser.getProgramNode();
            if(tokenizer.getCurrentToken().getType() == FCTokenType.CLOSED_PARENTHESIS) {
                tokenizer.nextToken();
            }
            else {
                errors.add("Closed parenthesis expected but was " + tokenizer.getCurrentToken().getType());
                return null;
            }
            errors.addAll(existsParser.getErrors());
        }
        return new FormatStatement(format, failMessage, statements, invert);
    }

    private FCNode parseFail(boolean invert) {
        tokenizer.nextToken();
        String failMessage;
        if(tokenizer.getCurrentToken().getType() == FCTokenType.FAILSTRING) {
            failMessage = (String) tokenizer.getCurrentToken().getValue();
        }
        else {
            errors.add("Fail string is expected after fail message but was " + tokenizer.getCurrentToken().getType());
            return null;
        }
        tokenizer.nextToken();
        ProgramNode statements = null;
        if(tokenizer.getCurrentToken().getType() == FCTokenType.OPEN_PARENTHESIS) {
            FCProgramParser existsParser = new FCProgramParser(tokenizer);
            existsParser.execute();
            statements = existsParser.getProgramNode();
            if(tokenizer.getCurrentToken().getType() == FCTokenType.CLOSED_PARENTHESIS) {
                tokenizer.nextToken();
            }
            else {
                errors.add("Closed parenthesis expected but was " + tokenizer.getCurrentToken().getType());
                return null;
            }
            errors.addAll(existsParser.getErrors());
        }
        return new FailStatement(failMessage, statements, invert);
    }

    private FCNode parseExists(boolean invert) {
        tokenizer.nextToken();
        String type;
        if(tokenizer.getCurrentToken().getType() == FCTokenType.ARGUMENT) {
            type = (String) tokenizer.getCurrentToken().getValue();
            if(!fileArguments.contains(type)) {
                errors.add("Unknow file argument " + type);
            }
        }
        else {
            errors.add("File argument expected. Not " + tokenizer.getCurrentToken().getType());
            return null;
        }
        
        tokenizer.nextToken();
        String file;
        if(tokenizer.getCurrentToken().getType() == FCTokenType.REGULARSTRING) {
            file = (String) tokenizer.getCurrentToken().getValue();
        }
        else {
            errors.add("Regular string expected. But was " + tokenizer.getCurrentToken().getType());
            return null;
        }
        
        tokenizer.nextToken();
        String failMessage = "";
        if(tokenizer.getCurrentToken().getType() == FCTokenType.FAILSTRING) {
            failMessage = (String) tokenizer.getCurrentToken().getValue();
            tokenizer.nextToken();
        }
        
        ProgramNode statements = null;
        if(tokenizer.getCurrentToken().getType() == FCTokenType.OPEN_PARENTHESIS) {
            FCProgramParser existsParser = new FCProgramParser(tokenizer);
            existsParser.execute();
            statements = existsParser.getProgramNode();
            if(tokenizer.getCurrentToken().getType() == FCTokenType.CLOSED_PARENTHESIS) {
                tokenizer.nextToken();
            }
            else {
                errors.add("Closed parenthesis expected but was " + tokenizer.getCurrentToken().getType());
                return null;
            }
            errors.addAll(existsParser.getErrors());
        }
        
        return new ExistsStatement(type, file, failMessage, statements, invert);
    }

    public ProgramNode getProgramNode() {
        return programNode;
    }

    private FCNode parseDef() {
        String id = "";
        if (tokenizer.getCurrentToken().getType() != FCTokenType.ARGUMENT) {
            errors.add("Argument is expected after def statement, but was " + tokenizer.getCurrentToken().getType());
        }
        else {
            id = (String) tokenizer.getCurrentToken().getValue();
        }

        String value = "";
        tokenizer.nextToken();
        if (tokenizer.getCurrentToken().getType() != FCTokenType.REGULARSTRING) {
            errors.add("Regular string is expected after argument of def statement, but was "
                    + tokenizer.getCurrentToken().getType());
        }
        else {
            value = (String) tokenizer.getCurrentToken().getValue();
        }
        
        return new DefStatement(id, value);
    }

    public List<String> getErrors() {
        return errors;
    }
}
