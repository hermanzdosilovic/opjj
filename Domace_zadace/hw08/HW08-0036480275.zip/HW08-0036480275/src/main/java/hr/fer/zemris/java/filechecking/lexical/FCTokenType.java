package hr.fer.zemris.java.filechecking.lexical;

public enum FCTokenType {
    
    KEYWORD,
    ARGUMENT,
    REGULARSTRING,
    INSENSITIVESTRING,
    FAILSTRING,
    OPEN_PARENTHESIS,
    CLOSED_PARENTHESIS,
    EXCLAMATION_MARK,
    EOF,
    START
}
