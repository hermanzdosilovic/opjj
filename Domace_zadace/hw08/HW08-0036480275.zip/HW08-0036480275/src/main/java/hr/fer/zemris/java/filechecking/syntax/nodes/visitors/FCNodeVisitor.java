package hr.fer.zemris.java.filechecking.syntax.nodes.visitors;

import hr.fer.zemris.java.filechecking.syntax.nodes.DefStatement;
import hr.fer.zemris.java.filechecking.syntax.nodes.ExistsStatement;
import hr.fer.zemris.java.filechecking.syntax.nodes.FailStatement;
import hr.fer.zemris.java.filechecking.syntax.nodes.FilenameStatement;
import hr.fer.zemris.java.filechecking.syntax.nodes.FormatStatement;
import hr.fer.zemris.java.filechecking.syntax.nodes.ProgramNode;
import hr.fer.zemris.java.filechecking.syntax.nodes.TerminateNode;

public interface FCNodeVisitor {

    boolean visit(ProgramNode programNode);

    boolean visit(DefStatement defStatement);

    boolean visit(ExistsStatement existsStatement);

    boolean visit(TerminateNode terminateNode);

    boolean visit(FailStatement failStatement);
    
    boolean visit(FormatStatement formatStatement);

    boolean visit(FilenameStatement filenameStatement);
    
}
