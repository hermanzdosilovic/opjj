package hr.fer.zemris.java.filechecking;

import hr.fer.zemris.java.filechecking.lexical.FCProgramTokenizer;
import hr.fer.zemris.java.filechecking.lexical.FCToken;
import hr.fer.zemris.java.filechecking.syntax.FCProgramParser;
import hr.fer.zemris.java.filechecking.syntax.nodes.ProgramNode;

import java.util.ArrayList;
import java.util.List;

public class FCProgramChecker {
    
    private FCProgramTokenizer tokenizer;
    private FCProgramParser parser;
    
    public FCProgramChecker(String program) {
        tokenizer = new FCProgramTokenizer(program);
        parser = new FCProgramParser(tokenizer);
        parser.execute();
    }
    
    public List<FCToken> getTokens() {
        return tokenizer.getTokens();
    }

    public List<String> errors() {
        List<String> errors = new ArrayList<>(tokenizer.getErrors());
        errors.addAll(parser.getErrors());
        return errors;
    }
    
    public boolean hasErrors() {
        return !this.errors().isEmpty();
    }

    public ProgramNode getProgramNode() {
        return parser.getProgramNode();
    }
}
