package hr.fer.zemris.java.filechecking.lexical;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class FCProgramTokenizer {

    private char[] program;
    private char pc;

    private List<FCToken> tokens;
    private List<String> errors;

    private FCToken currentToken;

    private static Set<String> keywords;
    static {
        keywords = new HashSet<>();
        keywords.add("terminate");
        keywords.add("def");
        keywords.add("filename");
        keywords.add("exists");
        keywords.add("format");
        keywords.add("fail");
    }

    private static Map<Character, FCTokenType> simpleTokens;
    static {
        simpleTokens = new HashMap<>();
        simpleTokens.put('{', FCTokenType.OPEN_PARENTHESIS);
        simpleTokens.put('}', FCTokenType.CLOSED_PARENTHESIS);
    }

    private static Map<Character, FCTokenType> stringToken;
    static {
        stringToken = new HashMap<>();
        stringToken.put('i', FCTokenType.INSENSITIVESTRING);
        stringToken.put('"', FCTokenType.REGULARSTRING);
        stringToken.put('@', FCTokenType.FAILSTRING);
    }

    public FCProgramTokenizer(String program) {
        this.program = program.toCharArray();
        tokens = new ArrayList<>();
        errors = new ArrayList<>();
        currentToken = new FCToken(FCTokenType.START, null);
        pc = 0;
    }

    public FCToken getCurrentToken() {
        return currentToken;
    }

    public List<FCToken> getTokens() {
        return tokens;
    }

    public List<String> getErrors() {
        return errors;
    }

    public boolean hasErrors() {
        return !errors.isEmpty();
    }

    public void nextToken() {
        boolean errorCaught = false;
        try {
            extractNextToken();
        }
        catch (RuntimeException error) {
            errors.add(error.getMessage());
            errorCaught = true;
        }
        if (errorCaught == false)
            tokens.add(currentToken);
    }

    private void extractNextToken() {
        if (currentToken != null && currentToken.getType() == FCTokenType.EOF) {
            throw new RuntimeException("EOF already reached.");
        }

        skipBlanks();

        if (pc >= program.length) {
            currentToken = new FCToken(FCTokenType.EOF, null);
            return;
        }

        if (simpleTokens.containsKey(program[pc])) {
            currentToken = new FCToken(simpleTokens.get(program[pc]), null);
            pc++;
            return;
        }

        if (program[pc] == '!') {
            pc++;
            if (pc < program.length && isValidArgumentCharacter(pc)) {
                currentToken = new FCToken(FCTokenType.EXCLAMATION_MARK, null);
            }
            else {
                throw new RuntimeException("Character '!' should not be alone.");
            }
            return;
        }

        if (isValidArgumentStart(pc) || program[pc] == '@') {
            argumentMode();
            return;
        }

         if(program[pc] == '"') {
             stringMode();
             return;
         }

        throw new RuntimeException("Unsupported character found on position " + (int)pc + ": " + program[pc++]);
    }

    private void argumentMode() {
        if ((program[pc] == 'i' || program[pc] == '@') && (pc + 1 < program.length && program[pc + 1] == '"')) {
            stringMode();
            return;
        }
        if(program[pc] == '@') {
            pc++;
            throw new RuntimeException("Unsuported character found: @ at position " + (int)(pc - 1));
        }
        int startIndex = pc;
        while(pc < program.length && isValidArgumentCharacter(pc)) {
            pc++;
        }
        String founded = new String(program, startIndex, pc - startIndex);
        if(keywords.contains(founded)) {
            currentToken = new FCToken(FCTokenType.KEYWORD, founded);
        }
        else {
            currentToken = new FCToken(FCTokenType.ARGUMENT, founded);
        }
    }

    private void stringMode() {
        FCTokenType stringTokenType = stringToken.get(program[pc]);
        if (program[pc] == 'i' || program[pc] == '@') {
            pc += 2;
        }
        else {
            pc++;
        }
        
        boolean stringClosed = false;
        boolean variableOpened = false;
        boolean errorFound = false;
        int startIndex = pc;
        while(pc < program.length) {
            
            if(program[pc] == '"') {
                stringClosed = true;
                pc++;
                break;
            }
            
            if(program[pc] == '$') {
                pc++;
                if(pc < program.length && program[pc] == '{') {
                    pc++;
                    if(variableOpened == true) {
                        errors.add("Multiple variables opened at position " + (int)(pc - 1) + ".");
                        errorFound = true;
                        continue;
                    }
                    variableOpened = true;
                    continue;
                }
                errors.add("Unsupported character in string: $ at position " + (int)(pc - 1) + ".");
                errorFound = true;
                continue;
            }
            
            if(program[pc] == '}') {
                pc++;
                if(variableOpened == false) {
                    errors.add("Closed unopened variable at position " + (int)(pc - 1) + ".");
                    errorFound = true;
                }
                else {
                    variableOpened = false;
                }
                continue;
            }
            
            if(supportedCharacter(pc)) {
                pc++;
                continue;
            }
            
            errors.add("Unknown character at position " + (int)(pc) +": " + program[pc++] );
            errorFound = true;
        }
        
        if(!stringClosed) {
            errors.add("String is not closed.");
            errorFound = true;
        }
        if(variableOpened) {
            errors.add("Variable not closed");
            errorFound = true;
        }
        if(stringClosed && !variableOpened) {
            currentToken = new FCToken(stringTokenType, new String(program, startIndex, pc - startIndex - 1));
        }
        if(errorFound) {
            throw new RuntimeException("Invalid String at position " + (int)startIndex + ".");
        }
    }

    private boolean supportedCharacter(char newPC) {
        return isValidArgumentCharacter(newPC) || program[newPC] == ':' || program[newPC] == '/' || isBlank() || program[newPC] == '-';
    }

    private void skipBlanks() {
        while (pc < program.length) {
            if (isBlank())
                pc++;
            else
                break;
        }
    }

    private boolean isBlank() {
        return program[pc] == ' ' || program[pc] == '\t' || program[pc] == '\r' || program[pc] == '\n';
    }

    private boolean isValidArgumentStart(int newPC) {
        return Character.isLetter(program[newPC]) || program[newPC] == '_';
    }

    private boolean isValidArgumentCharacter(int newPC) {
        return Character.isLetter(program[newPC]) || program[newPC] == '_' || Character.isDigit(program[newPC])
                || program[newPC] == '.';
    }
}
