package hr.fer.zemris.java.filechecking.syntax.nodes;

import hr.fer.zemris.java.filechecking.syntax.nodes.visitors.FCNodeVisitor;

public class FormatStatement extends FCNode {

    private String format;
    private String failMessage;
    private ProgramNode statements;
    private boolean invert;

    public FormatStatement(String format, String failMessage, ProgramNode statements, boolean invert) {
        this.format = format;
        this.failMessage = failMessage;
        this.statements = statements;
        this.invert = invert;
    }

    @Override
    public boolean accept(FCNodeVisitor visitor) {
        return visitor.visit(this);
    }
    
    public String getFormat() {
        return format;
    }
    
    public String getFailMessage() {
        return failMessage;
    }
    
    public boolean invert() {
        return invert;
    }
    
    public ProgramNode getStatements() {
        return statements;
    }
}
