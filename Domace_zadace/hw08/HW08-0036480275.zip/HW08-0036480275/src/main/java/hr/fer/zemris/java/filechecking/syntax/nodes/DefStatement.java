package hr.fer.zemris.java.filechecking.syntax.nodes;

import hr.fer.zemris.java.filechecking.syntax.nodes.visitors.FCNodeVisitor;

public class DefStatement extends FCNode {

    private String id;
    private String value;

    public DefStatement(String id, String value) {
        this.id = id;
        this.value = value;
    }

    @Override
    public boolean accept(FCNodeVisitor visitor) {
        return visitor.visit(this);
    }

    public String getID() {
        return id;
    }

    public String getValue() {
        return value;
    }
}
