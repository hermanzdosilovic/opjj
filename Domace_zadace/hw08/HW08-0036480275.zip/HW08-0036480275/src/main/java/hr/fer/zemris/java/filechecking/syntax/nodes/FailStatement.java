package hr.fer.zemris.java.filechecking.syntax.nodes;

import hr.fer.zemris.java.filechecking.syntax.nodes.visitors.FCNodeVisitor;

public class FailStatement extends FCNode {

    private String failMessage;
    private ProgramNode statements;
    private boolean invert;
    
    public FailStatement(String failMessage, ProgramNode statements, boolean invert) {
        this.failMessage = failMessage;
        this.statements = statements;
        this.invert = invert;
    }

    @Override
    public boolean accept(FCNodeVisitor visitor) {
        return visitor.visit(this);
    }
    
    public String getFailMessage() {
        return failMessage;
    }
    
    public ProgramNode getStatements(){
        return statements;
    }
    
    public boolean invert() {
        return invert;
    }

}
