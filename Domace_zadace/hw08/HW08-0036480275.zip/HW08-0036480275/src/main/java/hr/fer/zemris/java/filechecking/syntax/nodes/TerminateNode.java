package hr.fer.zemris.java.filechecking.syntax.nodes;

import hr.fer.zemris.java.filechecking.syntax.nodes.visitors.FCNodeVisitor;

public class TerminateNode extends FCNode {

    @Override
    public boolean accept(FCNodeVisitor visitor) {
        return visitor.visit(this);
    }

}
