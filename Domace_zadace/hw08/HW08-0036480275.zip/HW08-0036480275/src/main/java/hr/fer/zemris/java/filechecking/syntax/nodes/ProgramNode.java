package hr.fer.zemris.java.filechecking.syntax.nodes;

import hr.fer.zemris.java.filechecking.syntax.nodes.visitors.FCNodeVisitor;

import java.util.List;

public class ProgramNode extends FCNode {

    private List<FCNode> statements;

    public ProgramNode(List<FCNode> statements) {
        this.statements = statements;
    }

    @Override
    public boolean accept(FCNodeVisitor visitor) {
        return visitor.visit(this);
    }

    public List<FCNode> getStatements() {
        return statements;
    }

}
