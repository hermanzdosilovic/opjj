package hr.fer.zemris.java.filechecking;

import hr.fer.zemris.java.filechecking.syntax.nodes.DefStatement;
import hr.fer.zemris.java.filechecking.syntax.nodes.ExistsStatement;
import hr.fer.zemris.java.filechecking.syntax.nodes.FCNode;
import hr.fer.zemris.java.filechecking.syntax.nodes.FailStatement;
import hr.fer.zemris.java.filechecking.syntax.nodes.FilenameStatement;
import hr.fer.zemris.java.filechecking.syntax.nodes.FormatStatement;
import hr.fer.zemris.java.filechecking.syntax.nodes.ProgramNode;
import hr.fer.zemris.java.filechecking.syntax.nodes.TerminateNode;
import hr.fer.zemris.java.filechecking.syntax.nodes.visitors.FCNodeVisitor;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipFile;

public class ProgramExecutorVisitor implements FCNodeVisitor {

    private Map<String, Object> initialData;
    private String fileName;
    private List<String> errors;
    private File file;

    public ProgramExecutorVisitor(Map<String, Object> initialData, String fileName, File file) {
        this.file = file;
        this.initialData = initialData;
        this.fileName = fileName;
        this.errors = new ArrayList<>();
    }

    @Override
    public boolean visit(ProgramNode programNode) {
        for (FCNode statement : programNode.getStatements()) {
            if (statement.accept(this) == true) {
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean visit(DefStatement defStatement) {
        String value = parseString(defStatement.getValue());
        initialData.put(defStatement.getID(), value);
        return false;
    }

    @Override
    public boolean visit(ExistsStatement existsStatement) {
        String fileName = parseString(existsStatement.getFile());
        boolean result = existsStatement.invert();
        ZipFile zip = null;
        try {
            zip = new ZipFile(file.getAbsoluteFile());
        }
        catch (IOException e) {
            errors.add(e.getMessage());
            return false;
        }

        if (zip.getEntry(fileName) == null) {
            result ^= false;
        }
        else {
            result ^= true;
        }
        if (result == false) {
            if (existsStatement.getFailMessage().equals("")) {
                errors.add(fileName + " does " + (!existsStatement.invert() ? "not " : "") + "exist.");
            }
            else {
                errors.add(existsStatement.getFailMessage());
            }
        }
        try {
            zip.close();
        }
        catch (IOException e) {
            errors.add(e.getMessage());
        }
        if (result == true) {
            ProgramNode statements = existsStatement.getStatements();
            if (statements != null) {
                return statements.accept(this);
            }
        }
        return false;
    }

    @Override
    public boolean visit(TerminateNode terminateNode) {
        return true;
    }

    @Override
    public boolean visit(FailStatement failStatement) {
        boolean result = failStatement.invert() ^ false;
        if (result == false) {
            if (failStatement.getFailMessage().equals("")) {
                errors.add("Fail statement executed.");
            }
            else {
                errors.add(failStatement.getFailMessage());
            }
        }
        if (result == true) {
            ProgramNode statements = failStatement.getStatements();
            if (statements != null) {
                return statements.accept(this);
            }
        }
        return false;
    }

    @Override
    public boolean visit(FormatStatement formatStatement) {
        boolean result = formatStatement.invert();
        result ^= formatStatement.getFormat().equals(fileName.substring(fileName.lastIndexOf('.') + 1));
        if (result == false) {
            if (formatStatement.getFailMessage().equals("")) {
                errors.add("Format is " + (!formatStatement.invert() ? "not " : "") + "supported: "
                        + fileName.substring(fileName.lastIndexOf('.') + 1));
            }
            else {
                errors.add(formatStatement.getFailMessage());
            }
        }
        if (result == true) {
            ProgramNode statements = formatStatement.getStatements();
            if (statements != null) {
                return statements.accept(this);
            }
        }
        return false;
    }

    @Override
    public boolean visit(FilenameStatement filenameStatement) {
        String nameOfFile = parseString(filenameStatement.getFileName());
        boolean result = filenameStatement.invert();
        if (filenameStatement.isInsensitive()) {
            result ^= nameOfFile.toLowerCase().equals(fileName.toLowerCase());
        }
        else {
            result ^= nameOfFile.equals(fileName);
        }
        if (result == false) {
            if (filenameStatement.getFailMessage().equals("")) {
                errors.add("File does " + (!filenameStatement.invert() ? "not " : "") + "exists: " + nameOfFile);
            }
            else {
                errors.add(filenameStatement.getFailMessage());
            }
        }
        if (result == true) {
            ProgramNode statements = filenameStatement.getStatements();
            if (statements != null) {
                return statements.accept(this);
            }
        }
        return false;
    }

    private String parseString(String fileNameMasked) {
        StringBuilder sb = new StringBuilder("");
        for (int i = 0; i < fileNameMasked.length(); i++) {
            if (fileNameMasked.charAt(i) != '$') {
                sb.append(fileNameMasked.charAt(i));
            }
            else {
                i += 2;
                int startIndex = i;
                while (fileNameMasked.charAt(i) != '}') {
                    i++;
                }
                String content = fileNameMasked.substring(startIndex, i);
                content = content.trim();
                while (content.endsWith(" ")) {
                    content = content.substring(0, content.length() - 1);
                }
                if (initialData.get(content) != null) {
                    sb.append(initialData.get(content));
                    continue;
                }
                errors.add("Invalid variable: " + content);
            }
        }
        String unmasked = sb.toString();
        if (unmasked.contains(":")) {
            sb = new StringBuilder("");
            sb.append(unmasked.substring(0, unmasked.indexOf(':'))).append("/");
            int i = unmasked.indexOf(":") + 1;
            for (; i < unmasked.length(); i++) {
                if (unmasked.charAt(i) == '.') {
                    sb.append("/");
                }
                else {
                    sb.append(unmasked.charAt(i));
                }
            }
        }

        return sb.toString();
    }

    public List<String> getErrors() {
        return errors;
    }
}
