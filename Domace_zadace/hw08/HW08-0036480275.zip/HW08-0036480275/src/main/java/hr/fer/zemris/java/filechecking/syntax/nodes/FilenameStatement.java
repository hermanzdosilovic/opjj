package hr.fer.zemris.java.filechecking.syntax.nodes;

import hr.fer.zemris.java.filechecking.syntax.nodes.visitors.FCNodeVisitor;

public class FilenameStatement extends FCNode {
    
    private String fileName;
    private ProgramNode statements;
    private String failMessage;
    private boolean invert;
    private boolean insensitive;
    
    public FilenameStatement(String fileName, String failMessage, ProgramNode statements, boolean invert, boolean insensitive) {
        this.fileName = fileName;
        this.statements = statements;
        this.failMessage = failMessage;
        this.invert = invert;
        this.insensitive = insensitive;
    }

    @Override
    public boolean accept(FCNodeVisitor visitor) {
        return visitor.visit(this);
    }
    
    public String getFileName() {
        return fileName;
    }
    
    public boolean invert() {
        return invert;
    }
    
    public boolean isInsensitive() {
        return insensitive;
    }
    
    public String getFailMessage() {
        return failMessage;
    }
    
    public ProgramNode getStatements() {
        return statements;
    }
}
