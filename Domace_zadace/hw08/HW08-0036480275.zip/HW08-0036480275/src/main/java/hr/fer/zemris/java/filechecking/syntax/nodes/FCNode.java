package hr.fer.zemris.java.filechecking.syntax.nodes;

import hr.fer.zemris.java.filechecking.syntax.nodes.visitors.FCNodeVisitor;

public abstract class FCNode {
    
    public abstract boolean accept(FCNodeVisitor visitor);
    
}
