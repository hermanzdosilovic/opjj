package hr.fer.zemris.java.filechecking.lexical;

public class FCToken {
    
    private FCTokenType type;
    private Object value;
    
    public FCToken(FCTokenType type, Object value) {
        if(type == null)
            throw new RuntimeException("Type ne moze biti null.");
        this.type = type;
        this.value = value;
    }
    
    public FCTokenType getType() {
        return type;
    }
    
    public Object getValue() {
        return value;
    }
}
