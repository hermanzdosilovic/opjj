package hr.fer.zemris.java.filechecking;

import hr.fer.zemris.java.filechecking.execution.Executor;
import hr.fer.zemris.java.filechecking.lexical.Tokenizer;
import hr.fer.zemris.java.filechecking.syntax.Parser;
import hr.fer.zemris.java.filechecking.syntax.nodes.ProgramNode;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class FCFileVerifier {
	
	private File file;
	private String fileName;
	private String program;
	private Map<String, Object> initialData;
	private List<String> errors;
	private ProgramNode programNode;
	
	public FCFileVerifier(File file, String fileName, String program,
			Map<String, Object> initialData) {
		super();
		this.file = file;
		this.fileName = fileName;
		this.program = program;
		this.initialData = initialData;
		this.errors = new ArrayList<>();
		checkFile();
	}
	
	private void checkFile() {
		Parser parser = new Parser(new Tokenizer(program));
		programNode = parser.getProgramNode();
		Executor executor = new Executor(file, fileName, programNode, initialData);
		errors.addAll(executor.getErrors());
	}
	
	public boolean hasErrors() {
		return !errors.isEmpty();
	}
	
	public List<String> errors() {
		return errors;
	}
}
