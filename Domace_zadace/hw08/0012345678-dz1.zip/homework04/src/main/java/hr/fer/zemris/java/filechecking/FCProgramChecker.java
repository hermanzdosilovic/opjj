package hr.fer.zemris.java.filechecking;

import hr.fer.zemris.java.filechecking.lexical.Tokenizer;
import hr.fer.zemris.java.filechecking.lexical.TokenizerException;
import hr.fer.zemris.java.filechecking.syntax.Parser;
import hr.fer.zemris.java.filechecking.syntax.SyntaxException;

import java.util.ArrayList;
import java.util.List;

public class FCProgramChecker {
	
	private String program;
	private List<String> errors;
	
	public FCProgramChecker(String program) {
		super();
		this.program = program;
		this.errors = new ArrayList<>();
		checkProgram();
	}

	private void checkProgram() {
		try {
			new Parser(new Tokenizer(program));
		} catch(TokenizerException e) {
			errors.add(e.getMessage());
			return;
		} catch(SyntaxException e) {
			errors.add(e.getMessage());
			return;
		} catch(RuntimeException e) {
			errors.add(e.getMessage());
			return;
		}
	}
	
	public boolean hasErrors() {
		return !errors.isEmpty();
	}
	
	public List<String> errors() {
		return errors;
	}
}
