package hr.fer.zemris.linearna;

import org.junit.Test;

import static org.junit.Assert.*;

public class VectorTest {
    
    @Test (expected = IllegalArgumentException.class)
    public void constructVectorFirstTest() {
        new Vector();
    }
    
    @Test (expected = IllegalArgumentException.class)
    public void constructVectorSecondTest() {
        new Vector(null);
    }
    
    @Test (expected = IllegalArgumentException.class)
    public void getVectorFirstTest() {
        IVector a = new Vector(1, 2, 3);
        int index = -1; // illegal value;
        a.get(index);
    }
    
    @Test (expected = IllegalArgumentException.class)
    public void getVectorSecondTest() {
        IVector a = new Vector(1, 2, 3);
        int index = 3; // illegal value;
        a.get(index);
    }
    
    @Test
    public void getVectorThirdTest() {
        IVector a = new Vector(1, 2, 3);
        assertEquals("Values on index 0 are not the same.", 1, a.get(0), 1e-8);
        assertEquals("Values on index 1 are not the same.", 2, a.get(1), 1e-8);
        assertEquals("Values on index 2 are not the same.", 3, a.get(2), 1e-8);
    }
    
    @Test (expected = UnmodifiableObjectException.class)
    public void setVectorUnmodifiableObjectTest() {
        IVector a = new Vector(true, false, 1, 2, 3, 4, 5);
        a.set(0, 2);
    }
    
    @Test (expected = IllegalArgumentException.class)
    public void setVectorFirstTestInvalidArguments() {
        IVector a = new Vector(false, false, 1, 2, 3, 4, 5);
        a.set(-1, 2);
    }
    
    @Test (expected = IllegalArgumentException.class)
    public void setVectorSecondTestInvalidArguments() {
        IVector a = new Vector(false, false, 1, 2, 3, 4, 5);
        a.set(8, 2);
    }
    
    @Test
    public void setVectorTest() {
        IVector a = new Vector(1, 2, 3);
        IVector b = new Vector(false, true, 1, 2, 3);
        b.set(1, 60.123);
        a.set(0, 20);
        assertEquals("Values on index 0 are not the same.", 20, a.get(0), 1e-8);
        assertEquals("Values on index 1 are not the same.", 60.123, b.get(1), 1e-8);
    }
    
    @Test
    public void getDimensionsTest() {
        IVector a = new Vector(1, 2, 3);
        assertEquals("Dimensions are not the same.", 3, a.getDimension());
    }
    
    @Test
    public void copyTest() {
        IVector a = new Vector(1, 2, 3);
        IVector b = a.copy();
        for(int i = 0; i < a.getDimension(); i++) {
            assertEquals("Value on position " + i + " is not the same", b.get(i), a.get(i), 1e-8);
        }
    }
    
    @Test (expected = IllegalArgumentException.class)
    public void copyPartIllegalTest() {
        IVector a = new Vector(1, 2, 3);
        a.copyPart(-1);
    }
    
    @Test
    public void copyPartTest() {
        IVector a = new Vector(1, 2, 3);
        IVector b = a.copyPart(a.getDimension());
        for(int i = 0; i < a.getDimension(); i++) {
            assertEquals("Value on position " + i + " is not the same", b.get(i), a.get(i), 1e-8);
        }
    }
    
    @Test (expected = IllegalArgumentException.class)
    public void newInstanceIllegalTest() {
        IVector a = new Vector(1, 2, 3);
        a.newInstance(-1);
    }
    
    @Test
    public void newInstanceTest() {
        IVector a = new Vector(1, 2, 3);
        IVector b = a.newInstance(a.getDimension());
        for(int i = 0; i < b.getDimension(); i++) {
            assertEquals("Value on position " + i + " is not the same", b.get(i), 0, 1e-8);
        }
    }
    
    @Test (expected = IllegalArgumentException.class)
    public void parseSimpleIllegalArgument() {
        Vector.parseSimple(" ");
    }
    
    @Test (expected = IllegalArgumentException.class)
    public void parseSimpleIllegalArgumentSecondTest() {
        Vector.parseSimple(null);
    }
    
    @Test
    public void parseSimpleTest() {
        IVector a = Vector.parseSimple("1 2 3 4");
        IVector b = new Vector(1, 2, 3, 4);
        for(int i = 0; i < a.getDimension(); i++) {
            assertEquals("Value on position " + i + " is not the same", b.get(i), a.get(i), 1e-8);
        }
    }
}
