package hr.fer.zemris.linearna;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import static org.junit.Assert.*;

public class AbstractVectorTest {
    
    @Test (expected = IncompatibleOperandException.class)
    public void addTestIncompatibleTest() {
        IVector a = new Vector(1, 2, 3);
        IVector b = new Vector(2, 3);
        a.add(b);
    }
    
    @Test
    public void addTest() {
        IVector a = new Vector(1, 2, 3);
        IVector b = new Vector(1, 2, 3);
        IVector expected = new Vector(2, 4, 6);
        a.add(b);
        for(int i = 0; i < a.getDimension(); i++) {
            assertEquals("Values on position " + i + " are not the same.", expected.get(i), a.get(i), 1e-8);
        }
    }
    
    @Test
    public void nAddTest() {
        IVector a = new Vector(1, 2, 3);
        IVector b = new Vector(1, 2, 3);
        IVector expected = new Vector(2, 4, 6);
        IVector actual = a.nAdd(b);
        for(int i = 0; i < a.getDimension(); i++) {
            assertEquals("Values on position " + i + " are not the same.", expected.get(i), actual.get(i), 1e-8);
        }
    }
    
    @Test (expected = IncompatibleOperandException.class)
    public void subTestIncompatibleTest() {
        IVector a = new Vector(1, 2, 3);
        IVector b = new Vector(2, 3);
        a.sub(b);
    }
    
    @Test
    public void subTest() {
        IVector a = new Vector(1, 2, 3);
        IVector b = new Vector(-1, -2, -3);
        IVector expected = new Vector(2, 4, 6);
        a.sub(b);
        for(int i = 0; i < a.getDimension(); i++) {
            assertEquals("Values on position " + i + " are not the same.", expected.get(i), a.get(i), 1e-8);
        }
    }
    
    @Test
    public void nSubTest() {
        IVector a = new Vector(1, 2, 3);
        IVector b = new Vector(-1, -2, -3);
        IVector expected = new Vector(2, 4, 6);
        IVector actual = a.nSub(b);
        for(int i = 0; i < a.getDimension(); i++) {
            assertEquals("Values on position " + i + " are not the same.", expected.get(i), actual.get(i), 1e-8);
        }
    }
    
    @Test
    public void scalarMultiplyTest() {
        IVector a = new Vector(1, 2, 3);
        IVector expected = new Vector(2, 4, 6);
        a.scalarMultiply(2);
        for(int i = 0; i < a.getDimension(); i++) {
            assertEquals("Values on position " + i + " are not the same.", expected.get(i), a.get(i), 1e-8);
        }
    }
    
    @Test
    public void nScalarMultiplyTest() {
        IVector a = new Vector(1, 2, 3);
        IVector expected = new Vector(2, 4, 6);
        IVector actual = a.nScalarMultiply(2);
        for(int i = 0; i < a.getDimension(); i++) {
            assertEquals("Values on position " + i + " are not the same.", expected.get(i), actual.get(i), 1e-8);
        }
    }
    
    @Test
    public void normTest() {
        IVector a = new Vector(3, 4);
        assertEquals("Norm is not correct.", 5, a.norm(), 1e-8);
    }
    
    @Test
    public void noralizeTest() {
        IVector a = new Vector(3, 4);
        IVector b = new Vector(3 / 5.0, 4 / 5.0);
        a.normalize();
        for(int i = 0; i < a.getDimension(); i++) {
            assertEquals("Values on postion " + i + " are not the same.", b.get(i), a.get(i), 1e-8);
        }
    }
    
    @Test
    public void nNormalizeTest() {
        IVector a = new Vector(3, 4);
        IVector b = new Vector(3 / 5.0, 4 / 5.0);
        IVector actual = a.nNormalize();
        for(int i = 0; i < a.getDimension(); i++) {
            assertEquals("Values on postion " + i + " are not the same.", b.get(i), actual.get(i), 1e-8);
        }
    }
    
    @Test (expected = IncompatibleOperandException.class)
    public void scalarProductTestInvalidArguments() {
        IVector a = new Vector(2, 3);
        IVector b = new Vector(1, 2, 3);
        a.scalarProduct(b);
    }
    
    @Test
    public void scalarProductTest() {
        IVector a = new Vector(1, 0);
        IVector b = new Vector(0, 1);
        assertEquals("Scalar products are not the same.", 0, a.scalarProduct(b), 1e-8);
    }
    
    @Test (expected = IncompatibleOperandException.class)
    public void cosineTestInvalidArgumets() {
        IVector a = new Vector(2, 3);
        IVector b = new Vector(1, 2, 3);
        a.cosine(b);
    }
    
    @Test
    public void cosineTest() {
        IVector a = new Vector(1, 0);
        IVector b = new Vector(0, 1);
        assertEquals("Cosine is not correct.", 0, a.cosine(b), 1e-8);
    }
    
    @Test (expected = IncompatibleOperandException.class)
    public void nVectorProductTestIllegalArguments() {
        IVector a = new Vector(1, 2, 3);
        IVector b = new Vector(3, 4);
        a.nVectorProduct(b);
    }
    
    @Test (expected = IncompatibleOperandException.class)
    public void nVectorProductSecondTestIllegalArguments() {
        IVector a = new Vector(1, 2);
        IVector b = new Vector(3, 4);
        a.nVectorProduct(b);
    }
    
    @Test
    public void nVectorProductTest() {
        IVector a = new Vector(1, 0, 0);
        IVector b = new Vector(0, 1, 0);
        IVector expected = new Vector(0, 0, 1);
        IVector actual = a.nVectorProduct(b);
        
        for(int i = 0; i < expected.getDimension(); i++) {
            assertEquals("Values at position " + i + " are not the same.", expected.get(i), actual.get(i), 1e-8);
        }
        
        a = new Vector(20, 30, 150);
        b = new Vector(42.7, 42.8, 1.414213);
        expected = new Vector(-6377.57361, 6376.71574, -425); /* calculated with: http://onlinemschool.com/math/assistance/vector/multiply1/ */
        actual = a.nVectorProduct(b);
        for(int i = 0; i < expected.getDimension(); i++) {
            assertEquals("Values at position " + i + " are not the same.", expected.get(i), actual.get(i), 1e-8);
        }
    }
    
    @Test
    public void nFromHomogeniusTest() {
        IVector a = new Vector(1, 2, 3);
        IVector b = a.nFromHomogeneus();
        IVector expected = new Vector(1 / 3.0, 2 / 3.0);
        for(int i = 0; i < b.getDimension(); i++) {
            assertEquals("Values at position " + i + " are not the same.", expected.get(i), b.get(i), 1e-8);
        }
    }
    
    @Test
    public void toArrayTest() {
        IVector a = new Vector(1, 2, 3, 4, 5, 6, 7);
        double[] actual = a.toArray();
        double[] expected = {1, 2, 3, 4, 5, 6, 7};
        assertArrayEquals("Arrays are not the same.", expected, actual, 1e-8);
    }
    
    @Test
    public void toStringPrecisionTest() {
        IVector a = new Vector(1, 2, 3, 4, 5);
        int precision = 3;
        List<String> elements = new ArrayList<>();
        for(int i = 0; i < a.getDimension(); i++) {
            elements.add(String.format("%." + precision + "f", a.get(i)).replace(",", "."));
        }
        String actual = a.toString();
        assertEquals("Strings are not the same.", elements.toString(), actual);
    }
    
    @Test
    public void toRowMatrixTest() {
        IVector a = new Vector(1, 2, 3, 4, 5);
        IMatrix actual = a.toRowMatrix(true);
        IMatrix expected = new Matrix(1, 5, new double[][]{
                {1, 2, 3, 4, 5}
        }, true);
        for(int i = 0; i < a.getDimension(); i++) {
            assertEquals("Values at location " + i + " are not the same.", expected.get(0, i), actual.get(0, i), 1e-8);
        }
        
        a.set(0, 7);
        a.set(1, 42);
        expected = new Matrix(1, 5, new double[][]{
                {7, 42, 3, 4, 5}
        }, true);
        for(int i = 0; i < a.getDimension(); i++) {
            assertEquals("Values at location " + i + " are not the same.", expected.get(0, i), actual.get(0, i), 1e-8);
        }
        
        actual = a.toRowMatrix(false);
        a.set(0, 100);
        a.set(1, 200);
        a.set(2, 300);
        a.set(3, 123);
        a.set(4, 500);
        for(int i = 0; i < a.getDimension(); i++) {
            assertEquals("Values at location " + i + " are not the same.", expected.get(0, i), actual.get(0, i), 1e-8);
        }
    }
    
    @Test
    public void toColumnMatrixTest() {
        IVector a = new Vector(1, 2, 3, 4, 5);
        IMatrix actual = a.toColumnMatrix(true);
        IMatrix expected = new Matrix(5, 1, new double[][]{
                {1}, {2}, {3}, {4}, {5}
        }, true);
        for(int i = 0; i < a.getDimension(); i++) {
            assertEquals("Values at location " + i + " are not the same.", expected.get(i, 0), actual.get(i, 0), 1e-8);
        }
        
        a.set(0, 7);
        a.set(1, 42);
        expected = new Matrix(5, 1, new double[][]{
                {7}, {42}, {3}, {4}, {5}
        }, true);
        for(int i = 0; i < a.getDimension(); i++) {
            assertEquals("Values at location " + i + " are not the same.", expected.get(i, 0), actual.get(i, 0), 1e-8);
        }
        
        actual = a.toColumnMatrix(false);
        a.set(0, 100);
        a.set(1, 200);
        a.set(2, 300);
        a.set(3, 123);
        a.set(4, 500);
        for(int i = 0; i < a.getDimension(); i++) {
            assertEquals("Values at location " + i + " are not the same.", expected.get(i, 0), actual.get(i, 0), 1e-8);
        }
    }
}
