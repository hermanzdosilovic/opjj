package hr.fer.zemris.linearna;

/**
 * @author Herman Zvonimir Došilović
 * @version 1.0.
 */
public class MatrixTransponseView extends AbstractMatrix {

    private IMatrix original;
    public MatrixTransponseView(IMatrix original) {
        this.original = original;
    }

    @Override
    public int getRowsCount() {
        return this.original.getColsCount();
    }

    @Override
    public int getColsCount() {
        return this.original.getRowsCount();
    }

    @Override
    public double get(int row, int col) {
        return this.original.get(col, row);
    }

    @Override
    public IMatrix set(int row, int col, double value) {
        this.original.set(col, row, value);
        return this;
    }

    @Override
    public IMatrix copy() {
        return new MatrixTransponseView(this.original.copy());
    }

    @Override
    public IMatrix newInstance(int rows, int cols) {
        return new Matrix(rows, cols);
    }

}
