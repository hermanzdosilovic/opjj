package hr.fer.zemris.linearna.demo;

import hr.fer.zemris.linearna.IVector;
import hr.fer.zemris.linearna.Vector;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;

/**
 * @author Herman Zvonimir Došilović
 * @version 1.0.
 */
public class Prog5 {

    public static void main(String[] args) throws IOException {
        double[] firstElements;
        double[] secondElements;

        firstElements = getElements("Enter your first vector please: ");
        secondElements = getElements("Enter your second vector please: ");

        checkElements(firstElements, secondElements);

        IVector n = new Vector(firstElements);
        IVector m = new Vector(secondElements);
        
        double norm = n.norm();
        double scalar = 2 * (double)(1 / (norm * norm)) * n.scalarProduct(m);
        
        IVector r = n.scalarMultiply(scalar).sub(m);

        System.out.println("Here is your solution:");
        System.out.println(r);
    }

    public static double[] getElements(String message) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in, StandardCharsets.UTF_8));
        double[] elements;
        
        System.out.print(message);
        String line = reader.readLine();
        
        String[] stringElements = line.trim().split(" ");
        elements = new double[stringElements.length];
        for(int i = 0; i < stringElements.length; i++) {
            try {
                elements[i] = Double.parseDouble(stringElements[i]);
            }
            catch(NumberFormatException e) {
                throw new NumberFormatException(stringElements[i] + " is not a number!");
            }
        }
        
        return elements;
    }
    
    public static void checkElements(double[] first, double[] second) {
        if((first.length != 3 && first.length != 2) || (second.length != 3 && second.length != 2)) {
            System.err.println("You can only work with 2D and 3D vectors.");
            System.exit(-1);
        }
        else if(first.length != second.length) {
            System.err.println("Vectors must be of the same type.");
            System.exit(-1);
        }
    }
}
