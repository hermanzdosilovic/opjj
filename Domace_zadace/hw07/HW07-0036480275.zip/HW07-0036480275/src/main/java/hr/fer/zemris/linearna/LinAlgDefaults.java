package hr.fer.zemris.linearna;

/**
 * @author Herman Zvonimir Došilović
 * @version 1.0.
 */
public class LinAlgDefaults {

    public static IMatrix defaultMatrix(int rows, int cols) {
        return new Matrix(rows, cols);
    }

    public static IVector defaultVector(int dimension) {
        return new Vector(new double[dimension]);
    }

}
