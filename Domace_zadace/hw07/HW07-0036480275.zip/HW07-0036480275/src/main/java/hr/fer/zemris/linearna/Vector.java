package hr.fer.zemris.linearna;

import java.util.Arrays;

/**
 * @author Herman Zvonimir Došilović
 * @version 1.0.
 */
public class Vector extends AbstractVector {

    private double elements[];
    private int dimension;
    private boolean readOnly = false;

    public Vector(double... elements) {
        this(false, false, elements);
    }

    public Vector(boolean readOnly, boolean takeOver, double... elements) {
        if (elements == null || elements.length == 0) {
            throw new IllegalArgumentException();
        }
        if (takeOver == true) {
            this.elements = elements;
        }
        else {
            this.elements = Arrays.copyOf(elements, elements.length);
        }
        this.readOnly = readOnly;
        this.dimension = this.elements.length;
    }

    @Override
    public double get(int index) {
        if (index < 0 || index >= this.dimension) {
            throw new IllegalArgumentException();
        }
        return elements[index];
    }

    @Override
    public IVector set(int index, double value) throws UnmodifiableObjectException {
        if (readOnly == true) {
            throw new UnmodifiableObjectException();
        }
        if (index < 0 || index >= this.dimension) {
            throw new IllegalArgumentException();
        }
        elements[index] = value;
        return this;
    }

    @Override
    public int getDimension() {
        return this.dimension;
    }

    @Override
    public IVector copy() {
        return copyPart(this.dimension);
    }

    @Override
    public IVector copyPart(int n) {
        if (n < 0) {
            throw new IllegalArgumentException();
        }
        return new Vector(false, false, Arrays.copyOf(this.elements, n));
    }

    @Override
    public IVector newInstance(int dimension) {
        if (dimension < 0) {
            throw new IllegalArgumentException();
        }
        return new Vector(new double[dimension]);
    }

    public static IVector parseSimple(String line) {
        if (line == null) {
            throw new IllegalArgumentException();
        }

        line = line.replaceAll("\\s+", " ");
        String[] stringElements = line.split(" ");
        if (stringElements.length == 0) {
            throw new IllegalArgumentException();
        }

        double[] elements = new double[stringElements.length];
        for (int i = 0; i < stringElements.length; i++) {
            elements[i] = Double.parseDouble(stringElements[i]);
        }

        return new Vector(elements);
    }

}
