package hr.fer.zemris.linearna;

/**
 * @author Herman Zvonimir Došilović
 * @version 1.0.
 */
public class MatrixSubMatrixView extends AbstractMatrix {
    
    private IMatrix original;
    private int[] rowIndexes;
    private int[] colIndexes;
    
    public MatrixSubMatrixView(IMatrix original, int row, int col) {
        if(row < 0 || row >= original.getRowsCount() || col < 0 || col >= original.getColsCount()) {
            throw new IllegalArgumentException();
        }
        
        this.original = original;
        this.rowIndexes = new int[]{row};
        this.colIndexes = new int[]{col};
    }
    
    @Override
    public int getRowsCount() {
        return this.original.getRowsCount() - this.rowIndexes.length;
    }

    @Override
    public int getColsCount() {
        return this.original.getColsCount() - this.colIndexes.length;
    }

    @Override
    public double get(int row, int col) {
        if(row < 0 || row >= this.getRowsCount() || col < 0 || col >= this.getColsCount()) {
            throw new IllegalArgumentException();
        }
        
        row = adaptBounds(this.rowIndexes, row);
        col = adaptBounds(this.colIndexes, col);
        
        return this.original.get(row, col);
    }

    @Override
    public IMatrix set(int row, int col, double value) {
        if(row < 0 || row >= this.getRowsCount() || col < 0 || col >= this.getColsCount()) {
            throw new IllegalArgumentException();
        }
        
        row = adaptBounds(this.rowIndexes, row);
        col = adaptBounds(this.colIndexes, col);
        this.original.set(row, col, value);
        
        return this;
    }

    @Override
    public IMatrix copy() {
        return new MatrixSubMatrixView(this.original.copy(), this.rowIndexes[0], this.colIndexes[0]);
    }

    @Override
    public IMatrix newInstance(int rows, int cols) {
        return new MatrixSubMatrixView(new Matrix(rows + 1, cols + 1), rows, cols);
    }
    
    private int adaptBounds(int[] bounds, int bound) {
        for(int i = 0; i < bounds.length && bounds[i] <= bound; i++) {
            bound++;
        }
        
        return bound;
    }
    
}
