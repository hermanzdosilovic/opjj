package hr.fer.zemris.linearna;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Herman Zvonimir Došilović
 * @version 1.0.
 */
public abstract class AbstractMatrix implements IMatrix {

    @Override
    public abstract int getRowsCount();

    @Override
    public abstract int getColsCount();

    @Override
    public abstract double get(int row, int col);

    @Override
    public abstract IMatrix set(int row, int col, double value);

    @Override
    public abstract IMatrix copy();

    @Override
    public abstract IMatrix newInstance(int rows, int cols);

    @Override
    public IMatrix nTranspose(boolean liveView) {
        if (liveView == true) {
            return new MatrixTransponseView(this);
        }
        return new MatrixTransponseView(this.copy());
    }

    @Override
    public IMatrix add(IMatrix other) {
        if (other.getColsCount() != this.getColsCount() || other.getRowsCount() != this.getRowsCount()) {
            throw new IncompatibleOperandException();
        }

        for (int i = 0; i < this.getRowsCount(); i++) {
            for (int j = 0; j < this.getColsCount(); j++) {
                this.set(i, j, this.get(i, j) + other.get(i, j));
            }
        }

        return this;
    }

    @Override
    public IMatrix nAdd(IMatrix other) {
        return this.copy().add(other);
    }

    @Override
    public IMatrix sub(IMatrix other) {
        if (other.getColsCount() != this.getColsCount() || other.getRowsCount() != this.getRowsCount()) {
            throw new IncompatibleOperandException();
        }

        for (int i = 0; i < this.getRowsCount(); i++) {
            for (int j = 0; j < this.getColsCount(); j++) {
                this.set(i, j, this.get(i, j) - other.get(i, j));
            }
        }

        return this;
    }

    @Override
    public IMatrix nSub(IMatrix other) {
        return this.copy().sub(other);
    }

    @Override
    public IMatrix nMultiply(IMatrix other) {
        if (this.getColsCount() != other.getRowsCount()) {
            throw new IncompatibleOperandException();
        }

        IMatrix newMatrix = new Matrix(this.getRowsCount(), other.getColsCount());
        for (int i = 0; i < newMatrix.getRowsCount(); i++) {
            for (int j = 0; j < newMatrix.getColsCount(); j++) {
                double element = 0;
                for (int k = 0; k < this.getColsCount(); k++) {
                    element += this.get(i, k) * other.get(k, j);
                }
                newMatrix.set(i, j, element);
            }
        }

        return newMatrix;
    }

    @Override
    public double determinant() throws IncompatibleOperandException {
        if (this.getColsCount() != this.getRowsCount()) {
            throw new IncompatibleOperandException();
        }
        
        if(this.getColsCount() == 1) {
            return this.get(0, 0);
        }
        
        if (this.getColsCount() == 2) {
            return this.get(0, 0) * this.get(1, 1) - this.get(0, 1) * this.get(1, 0);
        }

        double det = 0;
        for (int i = 0; i < this.getRowsCount(); i++) {
            det += (i % 2 == 0 ? 1 : -1) * this.get(i, 0) * this.subMatrix(i, 0, false).determinant();
        }

        return det;
    }

    @Override
    public IMatrix subMatrix(int row, int col, boolean liveView) {
        if (liveView == true) {
            return new MatrixSubMatrixView(this, row, col);
        }

        return new MatrixSubMatrixView(this.copy(), row, col);
    }

    @Override
    public IMatrix nInvert() {
        if (this.getColsCount() != this.getRowsCount() || this.determinant() == 0) {
            throw new UnsupportedOperationException();
        }

        IMatrix invert = this.copy();
        for (int i = 0; i < invert.getRowsCount(); i++) {
            for (int j = 0; j < invert.getColsCount(); j++) {
                invert.set(i, j, ((i + j) % 2 == 0 ? 1 : -1) * this.subMatrix(i, j, true).determinant());
            }
        }

        return invert.nTranspose(true).scalarMultiply(1 / this.determinant());
    }

    @Override
    public double[][] toArray() {
        double[][] elements = new double[this.getRowsCount()][this.getColsCount()];

        for (int i = 0; i < this.getRowsCount(); i++) {
            for (int j = 0; j < this.getColsCount(); j++) {
                elements[i][j] = this.get(i, j);
            }
        }

        return elements;
    }

    @Override
    public IVector toVector(boolean liveView) {
        return null;
    }

    @Override
    public IMatrix nScalarMultiply(double value) {
        return this.copy().scalarMultiply(value);
    }

    @Override
    public IMatrix scalarMultiply(double value) {
        for (int i = 0; i < this.getRowsCount(); i++) {
            for (int j = 0; j < this.getColsCount(); j++) {
                this.set(i, j, this.get(i, j) * value);
            }
        }

        return this;
    }

    @Override
    public IMatrix makeIdentity() {
        for (int i = 0; i < this.getRowsCount(); i++) {
            for (int j = 0; j < this.getColsCount(); j++) {
                if (i == j) {
                    this.set(i, j, 1);
                }
                else {
                    this.set(i, j, 0);
                }
            }
        }

        return this;
    }

    public String toString(int precision) {
        List<String> elements = new ArrayList<>();
        StringBuilder sb = new StringBuilder("");

        for (int i = 0; i < this.getRowsCount(); i++) {
            for (int j = 0; j < this.getColsCount(); j++) {
                elements.add(String.format("%." + precision + "f", this.get(i, j)).replace(",", "."));
            }
            sb.append(elements.toString() + "\n");
            elements.clear();
        }

        return sb.toString();
    }

    @Override
    public String toString() {
        return this.toString(3);
    }

}
