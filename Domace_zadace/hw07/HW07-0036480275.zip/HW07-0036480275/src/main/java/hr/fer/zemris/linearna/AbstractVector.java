package hr.fer.zemris.linearna;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Herman Zvonimir Došilović
 * @version 1.0.
 */
public abstract class AbstractVector implements IVector {

    @Override
    public abstract double get(int index);

    @Override
    public abstract IVector set(int index, double value) throws UnmodifiableObjectException;

    @Override
    public abstract int getDimension();

    @Override
    public abstract IVector copy();

    @Override
    public abstract IVector copyPart(int n);

    @Override
    public abstract IVector newInstance(int dimension);

    @Override
    public IVector add(IVector other) throws IncompatibleOperandException {
        if (this.getDimension() != other.getDimension()) {
            throw new IncompatibleOperandException();
        }

        for (int i = this.getDimension() - 1; i >= 0; i--) {
            this.set(i, this.get(i) + other.get(i));
        }

        return this;
    }

    @Override
    public IVector nAdd(IVector other) throws IncompatibleOperandException {
        return this.copy().add(other);
    }

    @Override
    public IVector sub(IVector other) throws IncompatibleOperandException {
        if (this.getDimension() != other.getDimension()) {
            throw new IncompatibleOperandException();
        }

        for (int i = this.getDimension() - 1; i >= 0; i--) {
            this.set(i, this.get(i) - other.get(i));
        }

        return this;
    }

    @Override
    public IVector nSub(IVector other) throws IncompatibleOperandException {
        return this.copy().sub(other);
    }

    @Override
    public IVector scalarMultiply(double byValue) {
        for (int i = this.getDimension() - 1; i >= 0; i--) {
            this.set(i, this.get(i) * byValue);
        }

        return this;
    }

    @Override
    public IVector nScalarMultiply(double byValue) {
        return this.copy().scalarMultiply(byValue);
    }

    @Override
    public double norm() {
        double sum = 0;
        for (int i = 0; i < this.getDimension(); i++) {
            sum += this.get(i) * this.get(i);
        }

        return Math.sqrt(sum);
    }

    @Override
    public IVector normalize() {
        double norma = this.norm();
        for (int i = 0; i < this.getDimension(); i++) {
            this.set(i, this.get(i) / norma);
        }

        return this;
    }

    @Override
    public IVector nNormalize() {
        return this.copy().normalize();
    }

    @Override
    public double cosine(IVector other) throws IncompatibleOperandException {
        if (this.getDimension() != other.getDimension()) {
            throw new IncompatibleOperandException();
        }

        double cos = this.scalarProduct(other) / (this.norm() * other.norm());
        return cos;
    }

    @Override
    public double scalarProduct(IVector other) throws IncompatibleOperandException {
        if (this.getDimension() != other.getDimension()) {
            throw new IncompatibleOperandException();
        }

        double sProduct = 0;
        for (int i = 0; i < this.getDimension(); i++) {
            sProduct += other.get(i) * this.get(i);
        }

        return sProduct;
    }

    @Override
    public IVector nVectorProduct(IVector other) throws IncompatibleOperandException {
        if (this.getDimension() != other.getDimension() || this.getDimension() != 3) {
            throw new IncompatibleOperandException();
        }

        IVector product = this.copy();
        product.set(0, this.get(1) * other.get(2) - this.get(2) * other.get(1));
        product.set(1, this.get(2) * other.get(0) - this.get(0) * other.get(2));
        product.set(2, this.get(0) * other.get(1) - this.get(1) * other.get(0));

        return product;
    }

    @Override
    public IVector nFromHomogeneus() {
        IVector fromHomogeneus = this.copyPart(this.getDimension() - 1);
        double last = this.get(this.getDimension() - 1);
        for (int i = 0; i < fromHomogeneus.getDimension(); i++) {
            fromHomogeneus.set(i, fromHomogeneus.get(i) / last);
        }

        return fromHomogeneus;
    }

    @Override
    public IMatrix toRowMatrix(boolean liveView) {
        if (liveView == true) {
            return new MatrixVectorView(this, true);
        }
        return new MatrixVectorView(this.copy(), true);
    }

    @Override
    public IMatrix toColumnMatrix(boolean liveView) {
        if (liveView == true) {
            return new MatrixVectorView(this, false);
        }
        return new MatrixVectorView(this.copy(), false);
    }

    @Override
    public double[] toArray() {
        double[] elements = new double[this.getDimension()];
        for (int i = 0; i < this.getDimension(); i++) {
            elements[i] = this.get(i);
        }
        return elements;
    }

    public String toString(int precision) {
        List<String> elements = new ArrayList<>();
        for (int i = 0; i < this.getDimension(); i++) {
            elements.add(String.format("%." + precision + "f", this.get(i)).replace(",", "."));
        }

        return elements.toString();
    }

    @Override
    public String toString() {
        return this.toString(3);
    }

}
