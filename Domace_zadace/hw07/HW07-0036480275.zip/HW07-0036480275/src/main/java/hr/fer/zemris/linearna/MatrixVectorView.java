package hr.fer.zemris.linearna;

/**
 * @author Herman Zvonimir Došilović
 * @version 1.0.
 */
public class MatrixVectorView extends AbstractMatrix {

    private boolean asRowMatrix;
    private IVector original;
    private int rows = 1;
    private int cols = 1;

    public MatrixVectorView(IVector original, boolean asRowMatrix) {
        this.original = original;
        this.asRowMatrix = asRowMatrix;
        if (this.asRowMatrix) {
            cols = original.getDimension();
        }
        else {
            rows = original.getDimension();
        }
    }

    @Override
    public int getRowsCount() {
        return this.rows;
    }

    @Override
    public int getColsCount() {
        return this.cols;
    }

    @Override
    public double get(int row, int col) {
        if (row < 0 || row >= this.rows || col < 0 || col >= this.cols) {
            throw new IllegalArgumentException();
        }
        return this.original.get(Math.max(row, col));
    }

    @Override
    public IMatrix set(int row, int col, double value) {
        if (row < 0 || row >= this.rows || col < 0 || col >= this.cols) {
            throw new IllegalArgumentException();
        }
        this.original.set(Math.max(row, col), value);

        return this;
    }

    @Override
    public IMatrix copy() {
        return new Matrix(this.rows, this.cols, new double[][] { this.original.toArray() }, false);
    }

    @Override
    public IMatrix newInstance(int rows, int cols) {
        return new Matrix(rows, cols);
    }

}
