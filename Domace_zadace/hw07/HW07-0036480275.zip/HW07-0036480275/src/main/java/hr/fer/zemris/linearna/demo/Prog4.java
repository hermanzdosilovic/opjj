package hr.fer.zemris.linearna.demo;

import hr.fer.zemris.linearna.IMatrix;
import hr.fer.zemris.linearna.Matrix;

/**
 * @author Herman Zvonimir Došilović
 * @version 1.0.
 */
public class Prog4 {

    public static void main(String[] args) {
        IMatrix a = Matrix.parseSimple("1 5 3 | 0 0 8 | 1 1 1");
        IMatrix b = Matrix.parseSimple("3 | 4 | 1");
        IMatrix r = a.nInvert().nMultiply(b);
        System.out.println("Rjesenje sustava je: ");
        System.out.println(r);
    }

}
