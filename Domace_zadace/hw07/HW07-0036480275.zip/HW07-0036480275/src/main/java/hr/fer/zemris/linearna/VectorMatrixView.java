package hr.fer.zemris.linearna;

import java.util.Arrays;

/**
 * @author Herman Zvonimir Došilović
 * @version 1.0.
 */
public class VectorMatrixView extends AbstractVector {

    private IMatrix original;
    private int dimension;
    private boolean rowMatrix;

    public VectorMatrixView(IMatrix original) {
        this.original = original;
        if (original.getRowsCount() == 1) {
            rowMatrix = true;
        }
        dimension = Math.max(original.getRowsCount(), original.getColsCount());
    }

    @Override
    public double get(int index) {
        if (rowMatrix) {
            return this.original.get(0, index);
        }
        return this.original.get(index, 0);
    }

    @Override
    public IVector set(int index, double value) throws UnmodifiableObjectException {
        if (rowMatrix) {
            this.original.set(0, index, value);
        }
        else {
            this.original.set(index, 0, value);
        }
        return this;
    }

    @Override
    public int getDimension() {
        return this.dimension;
    }

    @Override
    public IVector copy() {
        return copyPart(this.dimension);
    }

    @Override
    public IVector copyPart(int n) {
        if (n < 0) {
            throw new IllegalArgumentException();
        }
        if (rowMatrix == false) {
            return new Vector(false, false, Arrays.copyOf(this.original.nTranspose(true).toArray()[0], n));
        }
        return new Vector(false, false, Arrays.copyOf(this.original.toArray()[0], n));
    }

    @Override
    public IVector newInstance(int dimension) {
        if (dimension < 0) {
            throw new IllegalArgumentException();
        }
        return new Vector(new double[dimension]);
    }

}
