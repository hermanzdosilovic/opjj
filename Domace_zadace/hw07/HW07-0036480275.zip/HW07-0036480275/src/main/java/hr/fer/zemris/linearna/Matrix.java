package hr.fer.zemris.linearna;

import java.util.Arrays;

/**
 * @author Herman Zvonimir Došilović
 * @version 1.0.
 */
public class Matrix extends AbstractMatrix {

    protected double[][] elements;
    protected int rows;
    protected int cols;

    public Matrix(int rows, int cols) {
        this(rows, cols, null, false);
    }

    public Matrix(int rows, int cols, double[][] elements, boolean useGiven) {
        if (rows <= 0 || cols <= 0) {
            throw new IllegalArgumentException();
        }

        if (elements == null && useGiven == true) {
            throw new IllegalArgumentException();
        }

        if (useGiven == true) {
            this.elements = elements;
        }

        else {
            this.elements = new double[rows][cols];
            if (elements != null) {
                for (int i = 0; i < elements.length; i++) {
                    this.elements[i] = Arrays.copyOf(elements[i], cols);
                }
            }
        }

        this.rows = rows;
        this.cols = cols;
    }

    @Override
    public int getRowsCount() {
        return this.rows;
    }

    @Override
    public int getColsCount() {
        return this.cols;
    }

    @Override
    public double get(int row, int col) {
        if (row < 0 || row >= this.rows || col < 0 || col >= this.cols) {
            throw new IllegalArgumentException();
        }

        return elements[row][col];
    }

    @Override
    public IMatrix set(int row, int col, double value) {
        if (row < 0 || row >= this.rows || col < 0 || col >= this.cols) {
            throw new IllegalArgumentException();
        }

        this.elements[row][col] = value;

        return this;
    }

    @Override
    public IMatrix copy() {
        return new Matrix(this.rows, this.cols, this.elements, false);
    }

    @Override
    public IMatrix newInstance(int rows, int cols) {
        return new Matrix(rows, cols);
    }
    
    public static IMatrix parseSimple(String line) {
        if(line == null) {
            throw new IllegalArgumentException();
        }
        
        String[] rows = line.trim().split("\\|");
        double[][] elements = new double[rows.length][];
        int width = 0;
        for(int i = 0; i < rows.length; i++) {
            String[] column = rows[i].trim().split(" ");
            elements[i] = new double[column.length];
            width = Math.max(width, column.length);
            for(int j = 0; j < column.length; j++) {
                elements[i][j] = Double.parseDouble(column[j]);
            }
        }
        
        return new Matrix(elements.length, width, elements, false);
    }
}
