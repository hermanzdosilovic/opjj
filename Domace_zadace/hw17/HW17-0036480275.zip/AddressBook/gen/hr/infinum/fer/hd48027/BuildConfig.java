/** Automatically generated file. DO NOT MODIFY */
package hr.infinum.fer.hd48027;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}