package hr.infinum.fer.hd48027;

import hr.infinum.fer.hd48027.exception.AddressBookException;
import hr.infinum.fer.hd48027.model.Contact;
import hr.infinum.fer.hd48027.model.ContactAdapter;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import android.app.ListActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ListView;

/**
 * Main activity of my first Android application.
 * 
 * @author Herman Zvonimir Došilović
 * @version 1.0
 */
public class HomeActivity extends ListActivity {

	/** Represents address book i.e. all available contacts. */
	public static List<Contact> addressBook = new ArrayList<>();

	/** Filename in which all contact information is stored. */
	public static final String FILENAME = "people.json";

	/** Unique name of position parameter that is used between intents. */
	public static final String POSITION = "hr.infinum.fer.hd48027.position";

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_home);
		if (addressBook.isEmpty()) {
			this.readAllContacts();
		}
		this.updateList();
	}

	/**
	 * Reads all contacts from file and saves them into
	 * <code>address book</code>
	 */
	private void readAllContacts() {
		try {
			JSONParser jsonParser = new JSONParser();

			JSONObject jsonObject = (JSONObject) jsonParser.parse(new BufferedReader(new InputStreamReader(getAssets()
					.open(FILENAME), "UTF-8")));

			JSONArray jsonArray = (JSONArray) jsonObject.get("people");

			@SuppressWarnings("unchecked")
			Iterator<JSONObject> iterator = jsonArray.iterator();
			while (iterator.hasNext()) {
				JSONObject object = (JSONObject) iterator.next().get("person");
				addressBook.add(new Contact(object.get("name").toString(), object.get("phone").toString(), object.get(
						"email").toString(), object.get("facebook_profile").toString(), object.get("note").toString()));
			}

		} catch (ParseException e) {
			throw new AddressBookException("Error ocurredd while parsing document " + FILENAME, e);
		} catch (UnsupportedEncodingException e) {
			throw new AddressBookException("Unsupported encoding.", e);
		} catch (IOException e) {
			throw new AddressBookException("Error with IO operation.", e);
		}
	}

	/**
	 * Updates list adapter for this list view.
	 */
	private void updateList() {
		Collections.sort(addressBook);
		setListAdapter(new ContactAdapter(this, addressBook));
	}

	@Override
	protected void onListItemClick(ListView l, View v, int position, long id) {
		Intent intent = new Intent(this, ProfileActivity.class);
		intent.putExtra(POSITION, position);
		startActivity(intent);
	}

	/**
	 * Action for adding new contact.
	 * 
	 * @param view
	 *            - view on which event occurred
	 */
	public void addNewContact(View view) {
		Intent intent = new Intent(this, AddContactActivity.class);
		startActivity(intent);
	}

	@Override
	protected void onResume() {
		super.onResume();
		updateList();
	}

}
