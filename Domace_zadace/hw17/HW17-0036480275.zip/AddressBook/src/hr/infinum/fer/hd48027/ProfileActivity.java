package hr.infinum.fer.hd48027;

import hr.infinum.fer.hd48027.model.Contact;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.View;
import android.widget.TextView;

/**
 * ProfileActivity shows information about contact.
 * 
 * @author Herman Zvonimir Došilović
 * @version 1.0
 */
public class ProfileActivity extends ActionBarActivity {

	/** Contact which user wants to view. */
	private Contact contact;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_profile);

		contact = HomeActivity.addressBook.get(getIntent().getExtras().getInt(HomeActivity.POSITION));

		TextView nameView = (TextView) findViewById(R.id.contactName);
		TextView phoneView = (TextView) findViewById(R.id.contactPhone);
		TextView emailView = (TextView) findViewById(R.id.contactEmail);
		TextView profileView = (TextView) findViewById(R.id.contactProfile);
		TextView noteView = (TextView) findViewById(R.id.contactNote);

		nameView.setText(contact.getName());
		phoneView.setText(contact.getPhone());
		emailView.setText(contact.getEmail());
		profileView.setText(contact.getProfile());
		noteView.setText(contact.getNote());

		setTitle(contact.getName());
	}

	/**
	 * Action performed when user wants to call current contact.
	 * 
	 * @param view
	 *            - view on which action is being performed.
	 */
	public void call(View view) {
		Intent intent = new Intent(Intent.ACTION_CALL, Uri.parse("tel:" + contact.getPhone()));
		startActivity(intent);
	}

	/**
	 * Action performed when user wants to open current contact's profile.
	 * 
	 * @param view
	 *            - view on which action is being performed.
	 */
	public void openProfile(View view) {
		Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(contact.getProfile()));
		startActivity(intent);
	}

	/**
	 * Action performed when user delete contact.
	 * 
	 * @param view
	 *            - view on which action is being performed.
	 */
	public void delete(View view) {
		HomeActivity.addressBook.remove(contact);
		onBackPressed();
	}
}
