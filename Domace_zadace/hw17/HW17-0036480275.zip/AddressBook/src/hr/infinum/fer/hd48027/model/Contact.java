package hr.infinum.fer.hd48027.model;

/**
 * Represents model of one contact in address book.
 * 
 * @author Herman Zvonimir Došilović
 * @version 1.0
 */
public class Contact implements Comparable<Contact> {

	/** Full name of this contact. */
	private String name;

	/** Phone number of this contact. */
	private String phone;

	/** E-mail address of this contact. */
	private String email;

	/** Link to profile of this contact. */
	private String profile;

	/** Note for this contact. */
	private String note;

	/**
	 * Constructs new <code>Contact</code> with given properties.
	 * 
	 * @param name
	 *            - full name of contact
	 * @param phone
	 *            - phone number of contact
	 * @param email
	 *            - e-mail address of contact
	 * @param note
	 *            - note for this contact
	 * @param facebookProfile
	 *            - link to Facebook profile of contact
	 */
	public Contact(String name, String phone, String email, String profile, String note) {
		this.name = name;
		this.phone = phone;
		this.email = email;
		this.profile = profile;
		this.note = note;
	}

	/**
	 * Constructs new <code>Contact</code> with all properties set to
	 * <code>""</code>.
	 */
	public Contact() {
		this("", "", "", "", "");
	}

	/**
	 * Returns full name of this contact.
	 * 
	 * @return full name of this contact.
	 */
	public String getName() {
		return name;
	}

	/**
	 * Sets name to this contact.
	 * 
	 * @param name
	 *            - new name for this contact
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * Returns phone number of this contact.
	 * 
	 * @return phone number of this contact.
	 */
	public String getPhone() {
		return phone;
	}

	/**
	 * Sets phone number to this contact.
	 * 
	 * @param phone
	 *            - new phone number for this contact
	 */
	public void setPhone(String phone) {
		this.phone = phone;
	}

	/**
	 * Returns e-mail address of this contact.
	 * 
	 * @return e-mail address of this contact
	 */
	public String getEmail() {
		return email;
	}

	/**
	 * Sets e-mail address to this contact.
	 * 
	 * @param email
	 *            - new e-mail address for this contact
	 */
	public void setEmail(String email) {
		this.email = email;
	}

	/**
	 * Returns note about this contact.
	 * 
	 * @return note about this contact
	 */
	public String getNote() {
		return note;
	}

	/**
	 * Sets note for this contact.
	 * 
	 * @param note
	 *            - new note for this contact
	 */
	public void setNote(String note) {
		this.note = note;
	}

	/**
	 * Returns link of profile of this contact.
	 * 
	 * @return link of profile of this contact
	 */
	public String getProfile() {
		return profile;
	}

	/**
	 * Sets link of profile to this contact.
	 * 
	 * @param facebookProfile
	 *            - new profile link for this contact
	 */
	public void setProfile(String profile) {
		this.profile = profile;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((email == null) ? 0 : email.hashCode());
		result = prime * result + ((profile == null) ? 0 : profile.hashCode());
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		result = prime * result + ((note == null) ? 0 : note.hashCode());
		result = prime * result + ((phone == null) ? 0 : phone.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Contact other = (Contact) obj;
		if (email == null) {
			if (other.email != null)
				return false;
		} else if (!email.equals(other.email))
			return false;
		if (profile == null) {
			if (other.profile != null)
				return false;
		} else if (!profile.equals(other.profile))
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		if (note == null) {
			if (other.note != null)
				return false;
		} else if (!note.equals(other.note))
			return false;
		if (phone == null) {
			if (other.phone != null)
				return false;
		} else if (!phone.equals(other.phone))
			return false;
		return true;
	}

	@Override
	public int compareTo(Contact another) {
		return name.compareTo(another.getName());
	}

}
