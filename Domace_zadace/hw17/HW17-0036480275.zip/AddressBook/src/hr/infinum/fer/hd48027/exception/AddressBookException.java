package hr.infinum.fer.hd48027.exception;

/**
 * Exception of Address Book.
 * 
 * @author Herman Zvonimir Došilović
 * @version 1.0
 */
public class AddressBookException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	/**
	 * Constructor.
	 */
	public AddressBookException() {
	}

	/**
	 * Constructor.
	 * 
	 * @param message
	 *            - message of error.
	 * @param cause
	 *            - cause of error.
	 */
	public AddressBookException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * Constructor.
	 * 
	 * @param message
	 *            - message of error.
	 */
	public AddressBookException(String message) {
		super(message);
	}

	/**
	 * Constructor.
	 * 
	 * @param cause
	 *            - cause of error.
	 */
	public AddressBookException(Throwable cause) {
		super(cause);
	}

}
