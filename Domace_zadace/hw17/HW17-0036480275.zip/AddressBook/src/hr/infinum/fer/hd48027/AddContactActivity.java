package hr.infinum.fer.hd48027;

import hr.infinum.fer.hd48027.model.Contact;
import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

/**
 * Add contact activity. Activates are run when user wants to add new contacts.
 * 
 * @author Herman Zvonimir Došilović
 * @version 1.0
 */
public class AddContactActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_add_contact);
	}

	/**
	 * Cancel operation of adding new account.
	 * 
	 * @param view
	 *            - view on which task has been executed
	 */
	public void cancel(View view) {
		this.onBackPressed();
	}

	/**
	 * Saves contact to <code>addressBook</code>.
	 * 
	 * @param view
	 *            - view on which task has been executed
	 */
	public void saveContact(View view) {
		TextView nameView = (TextView) findViewById(R.id.newName);
		TextView phoneView = (TextView) findViewById(R.id.newPhone);
		TextView emailView = (TextView) findViewById(R.id.newEmail);
		TextView profileView = (TextView) findViewById(R.id.newProfile);
		TextView noteView = (TextView) findViewById(R.id.newNote);

		String name = nameView.getText().toString();
		String phone = phoneView.getText().toString();
		String email = emailView.getText().toString();
		String profile = profileView.getText().toString();
		String note = noteView.getText().toString();

		Contact contact = new Contact(name, phone, email, profile, note);
		HomeActivity.addressBook.add(contact);

		this.onBackPressed();
	}

}
