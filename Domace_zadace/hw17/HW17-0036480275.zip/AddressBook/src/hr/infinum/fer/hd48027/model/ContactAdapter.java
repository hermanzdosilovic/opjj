package hr.infinum.fer.hd48027.model;

import hr.infinum.fer.hd48027.R;

import java.util.List;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

/**
 * ContactAdapter which knows how to display contacts on screen.
 * 
 * @author Herman Zvonimir Došilović
 * @version 1.0
 */
public class ContactAdapter extends ArrayAdapter<Contact> {

	/**
	 * Constructor.
	 * 
	 * @param context
	 *            - information about application environment
	 * @param contacts
	 *            - list that this environment knows to display
	 */
	public ContactAdapter(Context context, List<Contact> contacts) {
		super(context, 0, contacts);
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		if (convertView == null) {
			LayoutInflater inflater = LayoutInflater.from(getContext());
			convertView = inflater.inflate(R.layout.activity_home_item, parent, false);
		}

		TextView nameView = (TextView) convertView.findViewById(R.id.name);
		TextView phoneView = (TextView) convertView.findViewById(R.id.phone);
		TextView emailView = (TextView) convertView.findViewById(R.id.email);

		nameView.setText(getItem(position).getName());
		phoneView.setText(getItem(position).getPhone());
		emailView.setText(getItem(position).getEmail());

		return convertView;
	}
}
