package hr.fer.zemris.java.tecaj.hw1;

import java.lang.Math;

/**
 * @author Herman Zvonimir Došilović
 */
public class Roots {

	public static void main(String[] args) {
		if(args.length != 3) {
			System.err.println("Invalid number of arguments. Program expects 3 arguments.");
			System.exit(1);
		}
		else if(Integer.parseInt(args[2]) <= 1) {
			System.err.println("Invalid root argument. Must be greater than 1.");
			System.exit(1);
		}
		complexRoots(Float.parseFloat(args[0]), Float.parseFloat(args[1]), Integer.parseInt(args[2]));
	}
	
	/**
	 * Method prints on standard input n-th root of complex number
	 * @param Re real part of complex number
	 * @param Im imaginary part of complex number
	 * @param n root to calculate. Must be greater than 1
	 */
	static void complexRoots(float Re, float Im, int n) {
		double modulus = Math.sqrt(Re * Re + Im * Im);
		modulus = Math.pow(modulus, 1 / (double) n);
		
		double argument = Math.atan(Im / Re);
		
		System.out.println("You requested calculation of " + n + ". roots. Solutions are:");
		for(int k = 0; k < n; k++) {
			Re = (float) (modulus * Math.cos((argument + 2 * k * Math.PI) / (double) n));
			Im = (float) (modulus * Math.sin((argument + 2 * k * Math.PI) / (double) n));
			System.out.println((k + 1) + ") " + (int) Re + (Im < 0 ? " - " : " + ") + (int) Math.abs(Im) + "i");
		}
	}
}
