package hr.fer.zemris.java.tecaj.hw1;

/**
 * @author Herman Zvonimir Došilović
 */
class ProgramStabla {
	
	static class CvorStabla {
		CvorStabla lijevi;
		CvorStabla desni;
		String podatak;
	}
	
	public static void main(String[] args) {
		CvorStabla cvor = null;
		
		cvor = ubaci(cvor, "Jasna");
		cvor = ubaci(cvor, "Ana");
		cvor = ubaci(cvor, "Ivana");
		cvor = ubaci(cvor, "Anamarija");
		cvor = ubaci(cvor, "Vesna");
		cvor = ubaci(cvor, "Kristina");
		
		System.out.println("Ispisujem stablo inorder:");
		ispisiStablo(cvor);
		
		cvor = okreniPoredakStabla(cvor);
		
		System.out.println("Ispisujem okrenuto stablo inorder:");
		ispisiStablo(cvor);
		
		int vel = velicinaStabla(cvor);
		System.out.println("Stablo sadrzi elemenata: "+vel);
		
		boolean pronaden = sadrziPodatak(cvor, "Ivana");
		System.out.println("Trazeni podatak je pronaden: "+pronaden);
	}
	
	/**
	 * Ispituje postoji li podatak u stablu
	 * @param korijen korijen stabla
	 * @param podatak podatak koji zelimo znati dali postoji
	 * @return true ako podatak postoji, false ako podatak ne postoji u stablu
	 */
	static boolean sadrziPodatak(CvorStabla korijen, String podatak) {
		if(korijen == null)
			return false;
		else if(podatak.compareTo(korijen.podatak) == 0)
			return true;
		else if(podatak.compareTo(korijen.podatak) < 1)
			return sadrziPodatak(korijen.lijevi, podatak);
		else
			return sadrziPodatak(korijen.desni, podatak);
	}
	
	/**
	 * Racuna broj cvorova u stablu ili podstablu
	 * @param cvor cvor od kojeg pocinje. Korijen stabla ili podstabla
	 * @return broj cvorova u stablu ili podstablu
	 */
	static int velicinaStabla(CvorStabla cvor) {
		if(cvor == null)
			return 0;
		else
			return 1 + velicinaStabla(cvor.desni) + velicinaStabla(cvor.lijevi);
	}
	
	/**
	 * Metoda koja ubacuje novi cvor u stablo
	 * @param korijen korijen stabla u kojeg se ubacuje novi cvor
	 * @param podatak koji treba upisati u novi cvor
	 * @return korijen stabla
	 */
	static CvorStabla ubaci(CvorStabla korijen, String podatak) {
		if(korijen == null) {
			CvorStabla noviCvor = new CvorStabla();
			noviCvor.podatak = podatak;
			noviCvor.desni = null;
			noviCvor.lijevi = null;
			return noviCvor;
		}
		else if(podatak.compareTo(korijen.podatak) < 1)
			korijen.lijevi = ubaci(korijen.lijevi, podatak);
		else
			korijen.desni = ubaci(korijen.desni, podatak);
		return korijen;
	}
	
	/**
	 * Ispisuje stablo inorder
	 * @param cvor cvor od kojeg pocinje
	 */
	static void ispisiStablo(CvorStabla cvor) {
		if(cvor != null) {
			ispisiStablo(cvor.lijevi);
			System.out.println(cvor.podatak);
			ispisiStablo(cvor.desni);
		}
	}
	
	/**
	 * Metoda okrece poredak stabla
	 * @param korijen korijen stabla
	 * @return korijen stabla
	 */
	static CvorStabla okreniPoredakStabla(CvorStabla korijen) {
		if(korijen == null)
			return null;
		
		CvorStabla cvor = new CvorStabla();
		cvor = korijen.lijevi;
		korijen.lijevi = korijen.desni;
		korijen.desni = cvor;
		
		okreniPoredakStabla(korijen.lijevi);
		okreniPoredakStabla(korijen.desni);
		
		return korijen;
	}
}