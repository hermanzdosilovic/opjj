package hr.fer.zemris.java.tecaj.hw1;

/**
 * @author Herman Zvonimir Došilović
 */
public class HofstadterQ {

	public static void main(String[] args) {
		long requestedNumber = Long.parseLong(args[0]);
		if(requestedNumber < 0) {
			System.err.println("Error! Number must be positive.");
			System.exit(1);
		}
		
		long hofstadterResult = hofstadterQ(requestedNumber);
		System.out.println("You requested calculation of " + requestedNumber +
				". number of Hofstadter's Q-sequence. The requested number is " + hofstadterResult + ".");
	}
	
	/**
	 * Method calculates i-th number of Hofstadter's Q-sequence.
	 * @param i i-th number of Hofstadter's Q-sequence to calculate
	 * @return i-th number of Hofstadter's Q-sequence
	 */
	static long hofstadterQ(long i) {
		if(i == 1 || i == 2)
			return 1;
		else
			return hofstadterQ(i - hofstadterQ(i - 1)) + hofstadterQ(i - hofstadterQ(i - 2));
	}
}
