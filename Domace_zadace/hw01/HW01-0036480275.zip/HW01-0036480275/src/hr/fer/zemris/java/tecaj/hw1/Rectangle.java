package hr.fer.zemris.java.tecaj.hw1;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;

/**
 * @author Herman Zvonimir Došilović
 */
public class Rectangle {

	public static void main(String[] args) throws IOException {
		/*
		 * User did not provide valid number of arguments.
		 * Zero arguments are considered valid.
		 * If no arguments are given, program reads data from standard input.
		 */
		if(args.length != 2 && args.length != 0) {
			System.out.println("Invalid number of arguments was provided.");
			return;
		}
		
		double width;
		double height;
		
		if(args.length == 2) {
			width = Integer.parseInt(args[0]);
			height = Integer.parseInt(args[1]);
		}
		else {
			width = getValue("Width");
			height = getValue("Height");
		}
		
		double area = width * height;
		double perimeter = 2 * (width + height);
		System.out.println("You have specified a rectangle with width " + width + " and height " +
				height + ". Its area is " + area + " and its perimeter is " + perimeter +".");
	}
	
	/**
	 * Method that reads user's input number and returns first valid number.
	 * @param valueName name or type of value that user needs to enter
	 * @return first valid input number
	 */
	public static double getValue(String valueName) throws IOException {
		
		BufferedReader reader = new BufferedReader(
				new InputStreamReader(new BufferedInputStream(System.in))
				);
		double inputNumber = -1;
		String userInput;
		
		do
		{
			System.out.print("Please provide " + valueName.toLowerCase() + ": ");
			userInput = reader.readLine().trim();
			
			if(userInput.isEmpty())
				System.out.println("Nothing was given.");
			else {
				inputNumber = Double.parseDouble(userInput);
				if(inputNumber < 0)
					System.out.println(valueName + " is negative.");
			}
		} while(inputNumber <= 0);
		
		return inputNumber;
	}
}
