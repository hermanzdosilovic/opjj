package hr.fer.zemris.java.tecaj.hw1;

/**
 * @author Herman Zvonimir Došilović
 */
class ProgramListe {

	static class CvorListe {
		CvorListe sljedeci;
		String podatak;
	}
	
	public static void main(String[] args) {
		CvorListe cvor = null;
		
		cvor = ubaci(cvor, "Jasna");
		cvor = ubaci(cvor, "Ana");
		cvor = ubaci(cvor, "Ivana");
		
		System.out.println("Ispisujem listu uz originalni poredak:");
		ispisiListu(cvor);
		
		cvor = sortirajListu(cvor);
		
		System.out.println("Ispisujem listu nakon sortiranja:");
		ispisiListu(cvor);
		
		int vel = velicinaListe(cvor);
		System.out.println("Lista sadrzi elemenata: "+vel);
	}
	
	/**
	 * Metoda koja računa broj čvorova u listi.
	 * @param cvor prvi cvor liste (list head)
	 * @return broj čvorova u listi
	 */
	static int velicinaListe(CvorListe cvor) {
		if(cvor == null)
			return 0;
		else
			return 1 + velicinaListe(cvor.sljedeci);
	}
	
	/**
	 * Metoda koja dodaje čvor na početak liste.
	 * @param prvi trenutni prvi čvor liste (list head)
	 * @param podatak podatak koji treba upisati u novi čvor liste
	 * @return novi čvor liste
	 */
	static CvorListe ubaci(CvorListe prvi, String podatak) {
		CvorListe noviCvor = new CvorListe();
		noviCvor.podatak = podatak;
		noviCvor.sljedeci = prvi;
		return noviCvor;
	}
	
	/**
	 * Metoda koja ispisuje podatke koje se nalaze u listi počevši od prvo čvora (list head)
	 * @param cvor prvi čvor liste (list head)
	 */
	static void ispisiListu(CvorListe cvor) {
		System.out.println(cvor.podatak);
		if(cvor.sljedeci == null)
			return;
		else
			ispisiListu(cvor.sljedeci);
	}
	
	/**
	 * Metoda koja leksikografski uzlazno sortira listu
	 * @param cvor prvi čvor liste
	 * @return prvi čvor liste
	 */
	static CvorListe sortirajListu(CvorListe cvor) {
		int duljinaListe = velicinaListe(cvor);
		CvorListe glavaListe = new CvorListe();
		String podatakTrenutnogCvora, podatakSljedecegCvora;
		
		glavaListe = cvor;
		for(int i = 0; i < duljinaListe - 1; i++) {
			cvor = glavaListe;
			
			for(int j = 0; j < duljinaListe - 1 - i; j++) {
				podatakTrenutnogCvora = cvor.podatak;
				podatakSljedecegCvora = cvor.sljedeci.podatak;
				
				if(podatakTrenutnogCvora.compareTo(podatakSljedecegCvora) > 0) {
					cvor.podatak = podatakSljedecegCvora;
					cvor.sljedeci.podatak = podatakTrenutnogCvora;
				}
				
				cvor = cvor.sljedeci;
			}
		}
		
		return glavaListe;
	}
}