package hr.fer.zemris.java.tecaj.hw1;

/**
 * @author Herman Zvonimir Došilović
 */
public class NumberDecomposition {

	public static void main(String[] args) {
		if(args.length != 1) {
			System.err.println("Invalid number of arguments. Program expects 1 argument.");
			System.exit(1);
		}
		else if(Integer.parseInt(args[0]) <= 1) {
			System.err.println("Argument must be greater than 1");
			System.exit(1);
		}
		
		int number = Integer.parseInt(args[0]);
		System.out.println("You requested decomposition of number " + number + " onto prime factors. Here they are:");
		for(int i = 2, count = 1; i <= number; ) {
			if(number % i == 0) {
				System.out.println(count + ". " + i);
				number /= i;
				count++;
			}
			else
				i++;
		}
	}

}
