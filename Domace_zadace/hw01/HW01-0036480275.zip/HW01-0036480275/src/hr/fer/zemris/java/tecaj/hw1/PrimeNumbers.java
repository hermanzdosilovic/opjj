package hr.fer.zemris.java.tecaj.hw1;

/**
 * @author Herman Zvonimir Došilović
 */
public class PrimeNumbers {

	public static void main(String[] args) {
		if(args.length != 1) {
			System.err.println("Invalid number of arguments. Program expects 1 argument.");
			System.exit(1);
		}
		else if(Integer.parseInt(args[0]) <= 0) {
			System.err.println("Argument must be positive.");
			System.exit(1);
		}
		
		int numberOfPrimes = Integer.parseInt(args[0]);
		System.out.println("You requested calculation of " + numberOfPrimes + " prime numbers. Here they are:");
		for(int i = 2, count = 1; count <= numberOfPrimes; i++) {
			boolean isPrime = true;
			for(int j = 2; isPrime == true && j < i; j++)
				if(i % j == 0)
					isPrime = false;
			if(isPrime == true) {
				System.out.println(count + ". " + i);
				count++;
			}
		}
	}

}
