package hr.fer.zemris.java.sorters;

import java.util.Random;

import static junit.framework.Assert.*;

import org.junit.Test;

public class QSortParallelTest {
    
    @SuppressWarnings("deprecation")
    @Test
    public void QSortParallelMainTest() {
        int test = 10;
        Random rand = new Random();
        while(--test != 0) {
            int size = rand.nextInt()%100_001 + 150_000; // [150_000, 250_000]
            int[] data = new int[size];
            for(int i = 0; i < size; i++) {
                data[i] = rand.nextInt();
            }
            QSortParallel.sort(data);
            assertEquals("Niz nije sortiran!", true, QSortParallel.isSorted(data));
        }
    }
    
    @SuppressWarnings("deprecation")
    @Test
    public void QSortParallelMainTestTwo() {
        int test = 10;
        Random rand = new Random();
        while(--test != 0) {
            int size = rand.nextInt()%100_001 + 150_000; // [150_000, 250_000]
            int[] data = new int[size];
            for(int i = 0; i < size; i++) {
                data[i] = rand.nextInt();
            }
            QSortParallel.sort(data);
            data[0] ^= data[data.length - 1] ^= data[0] ^= data[data.length - 1];
            assertEquals("Niz ne bi trebao biti sortiran.", false, QSortParallel.isSorted(data));
        }
    }
}
