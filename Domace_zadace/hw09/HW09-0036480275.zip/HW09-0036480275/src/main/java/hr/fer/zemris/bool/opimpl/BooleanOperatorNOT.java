package hr.fer.zemris.bool.opimpl;

import hr.fer.zemris.bool.BooleanOperator;
import hr.fer.zemris.bool.BooleanSource;
import hr.fer.zemris.bool.BooleanValue;

import java.util.Arrays;

/**
 * Class {@code BooleanOperatorNOT} represents implementation of {@code NOT} boolean operator.
 * @author Herman Zvonimir Došilović
 * @version 1.0
 */
public class BooleanOperatorNOT extends BooleanOperator {

    private BooleanValue value;

    /**
     * Constructs new {@code BooleanOperatorNOT} with specified list of sources based on which final result is
     * calculated.
     * @param newSource list of sources based on which final result is calculated.
     */
    public BooleanOperatorNOT(final BooleanSource newSource) {
        super(Arrays.asList(newSource));
    }

    /**
     * Returns {@code BooleanValue} of final result.
     * @return value of final result.
     */
    @Override
    public final BooleanValue getValue() {
        if (getSources().get(0).getValue() == BooleanValue.DONT_CARE)
            value = BooleanValue.DONT_CARE;
        else if (getSources().get(0).getValue() == BooleanValue.FALSE)
            value = BooleanValue.TRUE;
        else
            value = BooleanValue.FALSE;
        return value;
    }

}
