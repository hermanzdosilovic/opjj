package hr.fer.zemris.bool;

/**
 * Interface {@code NamedBooleanSource} extends {@code BooleanSource}. Interface {@code NamdeBooleanSource} provides
 * {@code BooleanSource} with defined name.
 * @author Herman Zvonimir Došilović
 * @version 1.0
 */
public interface NamedBooleanSource extends BooleanSource {

    /**
     * Provides name of {@code BooleanSource}.
     * @return name of {@code BooleanSource}.
     */
    String getName();

}
