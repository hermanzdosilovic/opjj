package hr.fer.zemris.bool.fimpl;

import hr.fer.zemris.bool.BooleanFunction;
import hr.fer.zemris.bool.BooleanOperator;
import hr.fer.zemris.bool.BooleanValue;
import hr.fer.zemris.bool.BooleanVariable;

import java.util.ArrayList;
import java.util.List;
import java.util.SortedSet;
import java.util.TreeSet;

/**
 * @author Herman Zvonimir Došilović
 */
public class OperatorTreeBF implements BooleanFunction {
    
    private String name;
    private List<BooleanVariable> domain;
    private BooleanOperator operatorTree;
    
    public OperatorTreeBF(String name, List<BooleanVariable> domain, BooleanOperator operatorTree) {
        this.name = name;
        this.domain = new ArrayList<>(domain);
        this.operatorTree = operatorTree;
    }
    
    public List<BooleanVariable> getDomain() {
        return domain;
    }
    
    public String getName() {
        return name;
    }
    
    public Iterable<Integer> mintermIterable() {
        return getSomeTable(0);
    }
    
    public Iterable<Integer> maxtermIterable() {
        return getSomeTable(1);
    }
    
    public Iterable<Integer> dontcareIterable() {
        return getSomeTable(2);
    }
    
    private SortedSet<Integer> getSomeTable(int minterm) {
        SortedSet<Integer> s = new TreeSet<>();
        int N = 1 << domain.size();
        for(int z = 0; z < N; z++){
            int i = z;
            for(int j = domain.size() - 1; j >= 0; j--) {
                if(i % 2 == 1) {
                    domain.get(j).setValue(BooleanValue.TRUE);
                }
                else
                    domain.get(j).setValue(BooleanValue.FALSE);
                i /= 2;
            }
            if(operatorTree.getValue() == BooleanValue.TRUE && minterm == 0) {
                s.add(z);
            }
            else if(operatorTree.getValue() == BooleanValue.FALSE && minterm == 1) {
                s.add(z);
            }
            else if(operatorTree.getValue() == BooleanValue.DONT_CARE && minterm == 2) {
                s.add(z);
            }
        }
        return s;
    }

    @Override
    public BooleanValue getValue() {
        return operatorTree.getValue();
    }

    @Override
    public boolean hasMinterm(int index) {
        for(int i : mintermIterable()) {
            if (i == index)
                return true;
        }
        return false;
    }

    @Override
    public boolean hasMaxterm(int index) {
        for(int i : maxtermIterable()) {
            if (i == index)
                return true;
        }
        return false;
    }

    @Override
    public boolean hadDontCare(int index) {
        if(!hasMaxterm(index) && !hasMinterm(index))
            return true;
        return false;
    }
}
