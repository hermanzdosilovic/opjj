package hr.fer.zemris.bool.opimpl;

import java.util.List;

import hr.fer.zemris.bool.BooleanOperator;
import hr.fer.zemris.bool.BooleanSource;
import hr.fer.zemris.bool.BooleanValue;

/**
 * Class {@code BooleanOperatorOR} represents implementation of {@code OR} boolean operator.
 * @author Herman Zvonimir Došilović
 * @version 1.0
 */
public class BooleanOperatorOR extends BooleanOperator {
    
    private BooleanValue value;
    
    /**
     * Constructs new {@code BooleanOperatorOR} with specified list of sources based on which final result is
     * calculated.
     * @param newSource list of sources based on which final result is calculated.
     */
    public BooleanOperatorOR(final List<BooleanSource> newSource) {
        super(newSource);
        
    }

    /**
     * Returns {@code BooleanValue} of final result.
     * @return value of final result.
     */
    @Override
    public final BooleanValue getValue() {
        value = BooleanValue.FALSE;
        for(BooleanSource source : getSources()) {
            if(value == BooleanValue.TRUE || source.getValue() == BooleanValue.TRUE)
                value = BooleanValue.TRUE;
            else
                value = BooleanValue.FALSE;
        }
        return value;
    }

}
