/**
 * @author Herman Zvonimir Došilović
 */
package hr.fer.zemris.bool.fimpl;
