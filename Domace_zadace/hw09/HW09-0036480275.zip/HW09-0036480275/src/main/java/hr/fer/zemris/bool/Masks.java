package hr.fer.zemris.bool;

import java.util.ArrayList;
import java.util.List;

/**
 * Represents multiple masks.
 * @author Herman Zvonimir Došilović
 * @version 1.0
 */
public final class Masks {

    /**
     * Private constructor.
     */
    private Masks() {
    }

    /**
     * Returns list of masks for given arguments.
     * @param length length of every mask
     * @param numbers to represent with every mask
     * @return list of masks for given arguments.
     */
    public static List<Mask> fromIndexes(final int length, final int... numbers) {
        List<Mask> newMasks = new ArrayList<>();
        for (int n : numbers) {
            try {
                newMasks.add(Mask.fromIndex(length, n));
            } catch (IllegalArgumentException e) {
                throw new IllegalArgumentException("Illegal arguments.");
            }
        }
        return newMasks;
    }

    /**
     * Returns list of masks from given arguments.
     * @param masks string representation of every mask
     * @return list of masks from given arguments.
     */
    public static List<Mask> fromStrings(final String... masks) {
        List<Mask> newMasks = new ArrayList<>();
        for (String s : masks) {
            try {
                newMasks.add(Mask.parse(s));
            } catch (IllegalArgumentException e) {
                throw new IllegalArgumentException("Illegal arguments.");
            }
        }
        return newMasks;
    }
}
