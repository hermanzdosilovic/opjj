/**
 * @author Herman Zvonimir Došilović
 * @version 1.0.
 */
package hr.fer.zemris.bool.qmc;