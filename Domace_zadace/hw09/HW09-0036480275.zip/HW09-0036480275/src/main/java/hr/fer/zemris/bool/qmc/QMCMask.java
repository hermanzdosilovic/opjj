package hr.fer.zemris.bool.qmc;

import hr.fer.zemris.bool.Mask;

import java.util.List;

/**
 * Ovaj razred služi za prezentaciju Maski u QMC minimizaciji.
 * On pamti vrijednosti koje neka maska pokriva.
 * Pamti masku.
 * Pamti jeli ta maska mogla biti kombinirana sa nekom drugom maskom.
 * I govori dali je ovo dontCare ili nije dontCare maska.
 * @author Herman Zvonimir Došilović
 *
 */
public class QMCMask {

    private Mask mask;
    private boolean isDontCare;
    private List<Integer> values;
    private boolean isUsed;
    
    public QMCMask(Mask mask, boolean isDontCare, List<Integer> values) {
        this.mask = mask;
        this.isDontCare = isDontCare;
        this.values = values;
    }
    
    /**
     * Postavlja zastavicu isUsed na true. Zastavica isUsed govori dali je ova maska bila 
     * kombinirana sa nekom drugom u bilo kojem trenutku.
     */
    public void setAsUsed() {
        isUsed = true;
    }
    
    /**
     * Vraća true ako je ova maska bila kombinirana sa nekom drugom. Inače false.
     * @return true ako je ova maska bila kombinirana sa nekom drugom. Inače false
     */
    public boolean isUsed() {
        return isUsed;
    }
    
    /**
     * Vraća masku ove QMC maske.
     * @return masku koja predstavlja ovu QMC masku.
     */
    public Mask getMask() {
        return mask;
    }
    
    /**
     * True ako je ovo dontCare maska, false inače.
     * @return true ako je ovo dontCare maska, false inače.
     */
    public boolean isDontCare() {
        return isDontCare;
    }
    
    /**
     * Vrača listu vrijednosti koje ova maska pokriva.
     * @return listu vrijednosti koje ova maska pokriva.
     */
    public List<Integer> getValues() {
        return values;
    }
    
    @Override
    public String toString() {
        return mask.toString() + " " + isDontCare + " " + values.toString();
    }
    
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + (isDontCare ? 1231 : 1237);
        result = prime * result + ((mask == null) ? 0 : mask.hashCode());
        result = prime * result + ((values == null) ? 0 : values.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        QMCMask other = (QMCMask) obj;
        if (isDontCare != other.isDontCare)
            return false;
        if (mask == null) {
            if (other.mask != null)
                return false;
        } else if (!mask.equals(other.mask))
            return false;
        if (values == null) {
            if (other.values != null)
                return false;
        } else if (!values.equals(other.values))
            return false;
        return true;
    }
}
