package hr.fer.zemris.bool.qmc;

import java.util.ArrayList;
import java.util.List;

/**
 * Razred predstavlja grupu maski koje koje koriste prilikom QMC minimizacije.
 * @author Herman Zvonimir Došilović
 *
 */
public class MaskGroup {
    
    /** elementi koji se nalaze u grupi */
    List<QMCMask> masks;
    
    public MaskGroup() {
        masks = new ArrayList<>();
    }
    
    /**
     * Dodaj element u grupu
     * @param mask maska koju želimo dodati
     */
    public void add(QMCMask mask) {
        masks.add(mask);
    }
    
    /**
     * Dohvati element iz grupe na poziciji index
     * @param index pozicija na kojoj želimo dohvatiti element
     * @return element na poziciji index
     */
    public QMCMask get(int index) {
        return getAll().get(index);
    }
    
    /**
     * Vraća veličinu grupe
     * @return veličinu grupe
     */
    public int groupSize() {
        return masks.size();
    }
    
    /**
     * Dodaje sve maske u grupu trenutnu grupu maski.
     * @param masks maske koje treba dodati trenutnoj grupi maski.
     */
    public void addAll(List<QMCMask> masks) {
        this.masks.addAll(masks);
    }
    
    /**
     * Dohvaća sve maske koje se nalaze u grupi.
     * @return maske koje se nalaze u grupi
     */
    public List<QMCMask> getAll() {
        return new ArrayList<>(masks);
    }
    
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((masks == null) ? 0 : masks.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        MaskGroup other = (MaskGroup) obj;
        if (masks == null) {
            if (other.masks != null)
                return false;
        } else if (!masks.equals(other.masks))
            return false;
        return true;
    }
    
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder("");
        sb.append("SubGroup:\n");
        for(int i = 0; i < masks.size(); i++) {
            sb.append("\t\t" + getAll().get(i) + "\n");
        }
        return sb.toString();
    }
    
}
