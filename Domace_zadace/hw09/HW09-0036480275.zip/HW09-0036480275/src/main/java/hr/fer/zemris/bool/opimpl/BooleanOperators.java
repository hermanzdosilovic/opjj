package hr.fer.zemris.bool.opimpl;

import hr.fer.zemris.bool.BooleanOperator;
import hr.fer.zemris.bool.BooleanSource;

import java.util.Arrays;

/**
 * Class {@code BooleanOperators} provides convenient factory methods for producing concrete instances.
 * @author Herman Zvonimir Došilović
 * @version 1.0
 */
public final class BooleanOperators {

    /**
     * Constructor of BooleanOperators.
     */
    private BooleanOperators() {
    }

    /**
     * @param sources for boolean operation {@code AND}.
     * @return {@code BooleanOperator}
     */
    public static BooleanOperator and(final BooleanSource... sources) {
        return new BooleanOperatorAND(Arrays.asList(sources));
    }

    /**
     * @param sources for boolean operation {@code OR}.
     * @return {@code BooleanOperator}
     */
    public static BooleanOperator or(final BooleanSource... sources) {
        return new BooleanOperatorOR(Arrays.asList(sources));
    }

    /**
     * @param sources for boolean operation {@code NOT}.
     * @return {@code BooleanOperator}
     */
    public static BooleanOperator not(final BooleanSource sources) {
        return new BooleanOperatorNOT(sources);
    }

}
