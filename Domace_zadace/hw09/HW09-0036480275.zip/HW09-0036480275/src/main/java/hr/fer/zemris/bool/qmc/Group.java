package hr.fer.zemris.bool.qmc;

import hr.fer.zemris.bool.Mask;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Razred služi za različito grupiraje grupa
 * @author Herman Zvonimir Došilović
 */
public class Group {
    
    /**
     * Stvara grupe iz dane liste maski.
     * @param masks maske u bilo kojem redosljedu
     * @param asProducts odabir želimo li produkte ili ne
     * @return listu MaskGroup-a
     */
    public static List<MaskGroup> makeGroups(List<QMCMask> masks, boolean asProducts) {
        Map<Integer, MaskGroup> groups = new HashMap<>();
        for (QMCMask mask : masks) {
            int countBits;
            if (asProducts) {
                countBits = mask.getMask().getNumberOfZeros();
            } else {
                countBits = mask.getMask().getNumberOfOnes();
            }
            if (groups.containsKey(countBits)) {
                groups.get(countBits).add(mask);
            } else {
                MaskGroup group = new MaskGroup();
                group.add(mask);
                groups.put(countBits, group);
            }
        }
        return new ArrayList<>(groups.values());
    }
    
    /**
     * Kombinira dvije grupe, ako može. Dvije grupe se mogu grupirati u jednu u postupku QMC
     * ako je distanca između svaka dva elementa točno 1.
     * @param maskGroup1 prva grupa
     * @param maskGroup2 druga grupa
     * @return grupirana grupa, ili null ako nije uspio gruprati
     */
    public static MaskGroup combineGroups(MaskGroup maskGroup1, MaskGroup maskGroup2) {
        MaskGroup group = new MaskGroup();

        for (int i = 0; i < maskGroup1.groupSize(); i++) {
            for (int j = 0; j < maskGroup2.groupSize(); j++) {
                QMCMask mask = combineMasks(maskGroup1.get(i), maskGroup2.get(j));
                if (mask != null) {
                    group.add(mask);
                }
            }
        }

        if (group.groupSize() == 0) {
            return null;
        }

        return group;
    }
    
    /**
     * Metoda kombinira maske ako može. Dvije maske mogu se kombinirati ako je njihova distanca 1.
     * @param qmcMask1 prva maska
     * @param qmcMask2 druga maska
     * @return novonastalu QMCMasku, null ako ne može kombinirati maske.
     */
    private static QMCMask combineMasks(QMCMask qmcMask1, QMCMask qmcMask2) {
        Mask mask1 = qmcMask1.getMask();
        Mask mask2 = qmcMask2.getMask();
        Mask mask = Mask.combine(mask1, mask2);

        if (mask == null || mask1.equals(mask2)) {
            return null;
        }

        Set<Integer> values = new HashSet<>(qmcMask1.getValues());

        values.addAll(qmcMask2.getValues());

        boolean isDontCare = qmcMask1.isDontCare() & qmcMask2.isDontCare();

        qmcMask1.setAsUsed();
        qmcMask2.setAsUsed();

        return new QMCMask(mask, isDontCare, new ArrayList<>(values));
    }
    
    /**
     * Grupira PyneGroupe u jednu.
     * @param group1 prva pyne grupa
     * @param group2 druga pyne grupa
     * @return rezultirat kombiniranja group1 i group2
     */
    public static PyneGroup groupPyne(PyneGroup group1, PyneGroup group2) {
        PyneGroup group = new PyneGroup();
        
        for(int i = 0; i < group1.size(); i++) {
            for(int j = 0; j < group2.size(); j++) {
                Set<QMCMask> masks = new HashSet<>();
                masks.addAll(group1.get(i).getAll());
                masks.addAll(group2.get(j).getAll());
                MaskGroup maskGroup = new MaskGroup();
                maskGroup.addAll(new ArrayList<>(masks));
                group.add(maskGroup);
            }
        }
        
        return group;
    }
}
