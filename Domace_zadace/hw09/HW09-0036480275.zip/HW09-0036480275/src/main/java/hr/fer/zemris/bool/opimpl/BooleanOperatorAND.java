package hr.fer.zemris.bool.opimpl;

import java.util.List;

import hr.fer.zemris.bool.BooleanOperator;
import hr.fer.zemris.bool.BooleanSource;
import hr.fer.zemris.bool.BooleanValue;

/**
 * Class {@code BooleanOperatorAND} represents implementation of {@code AND} boolean operator.
 * @author Herman Zvonimir Došilović
 * @version 1.0
 */
public class BooleanOperatorAND extends BooleanOperator {
    
    private BooleanValue value;
    /**
     * Constructs new {@code BooleanOperatorAND} with specified list of sources based on which final result is
     * calculated.
     * @param newSource list of sources based on which final result is calculated.
     */
    public BooleanOperatorAND(final List<BooleanSource> newSource) {
        super(newSource);
    }

    /**
     * Returns {@code BooleanValue} of final result.
     * @return value of final result.
     */
    @Override
    public final BooleanValue getValue() {
        value = BooleanValue.TRUE;
        for(BooleanSource s : getSources()) {
            if((value == BooleanValue.TRUE || value == BooleanValue.FALSE || value == BooleanValue.DONT_CARE) && s.getValue() == BooleanValue.FALSE)
                value = BooleanValue.FALSE;
            else if(value == BooleanValue.TRUE && s.getValue() == BooleanValue.TRUE)
                value = BooleanValue.TRUE;
            else if(value == BooleanValue.TRUE && s.getValue() == BooleanValue.DONT_CARE)
                value = BooleanValue.DONT_CARE;
            else
                value = BooleanValue.DONT_CARE;
        }
        return value;
    }

}
