package hr.fer.zemris.bool.qmc;

import java.util.ArrayList;
import java.util.List;

/**
 * Predstavlja jednu grupu grupi koje sudjeluju u pyne-M djelu minimizacije
 * @author Herman Zvonimir Došilović
 *
 */
public class PyneGroup {

    /**
     * Grupe koje sudjeluju u ovoj pyne grupi.
     */
    private List<MaskGroup> groups;

    public PyneGroup() {
        this.groups = new ArrayList<>();
    }
    
    /**
     * Dodaje grupu u pyne grupu.
     * @param group grupu koju treba dodati.
     */
    public void add(MaskGroup group) {
        groups.add(group);
    }
    
    /**
     * Dohvaća sve grupe iz ove pyne grupe
     * @return sve grupe iz ove pynge grupe
     */
    public List<MaskGroup> getGroups() {
        return new ArrayList<>(groups);
    }
    
    /**
     * Dohvaća grupu na poziciji group.
     * @param group pozicija na kojoj se nalazi tražena grupa.
     * @return grupu na poziciji group
     */
    public MaskGroup get(int group) {
        return getGroups().get(group);
    }
    
    /**
     * 
     * @return Veličinu ove pyne groupe
     */
    public int size() {
        return groups.size();
    }
    
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder("");
        for(MaskGroup group : groups) {
            sb.append("SubGroup:\n");
            for(int i = 0; i < group.groupSize(); i++) {
                sb.append("\t\t" + group.get(i).toString() + "\n");
            }
        }
        
        return sb.toString();
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((groups == null) ? 0 : groups.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        PyneGroup other = (PyneGroup) obj;
        if (groups == null) {
            if (other.groups != null)
                return false;
        } else if (!groups.equals(other.groups))
            return false;
        return true;
    }
    
    
}
