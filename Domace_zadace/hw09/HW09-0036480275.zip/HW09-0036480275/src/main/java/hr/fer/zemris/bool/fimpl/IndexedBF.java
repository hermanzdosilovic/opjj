package hr.fer.zemris.bool.fimpl;

import hr.fer.zemris.bool.BooleanConstant;
import hr.fer.zemris.bool.BooleanFunction;
import hr.fer.zemris.bool.BooleanValue;
import hr.fer.zemris.bool.BooleanVariable;
import hr.fer.zemris.bool.Mask;
import hr.fer.zemris.bool.MaskValue;
import hr.fer.zemris.bool.opimpl.BooleanOperatorNOT;
import hr.fer.zemris.bool.opimpl.BooleanOperators;

import java.util.ArrayList;
import java.util.List;
import java.util.SortedSet;
import java.util.TreeSet;

public class IndexedBF implements BooleanFunction {
    private String name;
    private List<BooleanVariable> domain;
    private boolean indexesAreMinters;
    private List<Integer> indexes;
    private List<Integer> dontCares;

    public IndexedBF(String name, List<BooleanVariable> domain, boolean indexesAreMinters, List<Integer> indexes,
            List<Integer> dontCares) {
        if (domain == null) {
            throw new IllegalArgumentException();
        }
        if (indexes == null && dontCares == null) {
            throw new IllegalArgumentException();
        }
        if (domain.size() == 0 || (indexes.size() == 0 && dontCares.size() == 0)) {
            throw new IllegalArgumentException();
        }
        this.name = name;
        this.domain = new ArrayList<>(domain);
        this.indexesAreMinters = indexesAreMinters;
        this.indexes = new ArrayList<>(indexes);
        this.dontCares = new ArrayList<>(dontCares);
    }

    public String getName() {
        return this.name;
    }

    public List<BooleanVariable> getDomain() {
        return this.domain;
    }

    public Iterable<Integer> mintermIterable() {
        SortedSet<Integer> s = new TreeSet<>();
        s.addAll(indexes);
        if (indexesAreMinters)
            return s;
        SortedSet<Integer> g = new TreeSet<>(generateNumbers());
        g.removeAll(s);
        g.removeAll(dontCares);
        return g;
    }

    public Iterable<Integer> maxtermIterable() {
        SortedSet<Integer> s = new TreeSet<>();
        s.addAll(indexes);
        if (!indexesAreMinters)
            return s;
        SortedSet<Integer> g = new TreeSet<>();
        g.addAll(generateNumbers());
        g.removeAll(s);
        g.removeAll(dontCares);
        return g;
    }

    public Iterable<Integer> dontcareIterable() {
        return dontCares;
    }

    public boolean hasMinterm(int index) {
        for (Integer i : mintermIterable()) {
            if (i == index)
                return true;
        }
        return false;
    }

    public boolean hasMaxterm(int index) {
        for (Integer i : maxtermIterable()) {
            if (i == index)
                return true;
        }
        return false;
    }

    public boolean hadDontCare(int index) {
        if (!hasMinterm(index) && !hasMaxterm(index))
            return true;
        return false;
    }

    private SortedSet<Integer> generateNumbers() {
        int B = 1 << domain.size();
        SortedSet<Integer> s = new TreeSet<>();
        for (int i = 0; i < B; i++) {
            s.add(i);
        }
        return s;
    }

    @SuppressWarnings("unused")
    private BooleanValue sumaProdukata() {
        boolean hasOne = false;
        boolean hasDontCare = false;
        for (int index : indexes) {
            int i = domain.size();
            BooleanVariable[] list = new BooleanVariable[i];
            for (i = i - 1; i >= 0; i--) {
                BooleanVariable b = new BooleanVariable("");
                b.setValue(domain.get(i).getValue());
                if ((index & 1) == 0) {
                    b.setValue(new BooleanOperatorNOT(b).getValue());
                }
                list[i] = b;
                index /= 2;
            }
            BooleanValue bv = BooleanOperators.and(list).getValue();
            if (bv == BooleanValue.TRUE) {
                hasOne = true;
                break;
            } else if (bv == BooleanValue.DONT_CARE) {
                hasDontCare = true;
            }
        }

        if (hasOne) {
            return BooleanValue.TRUE;
        } else if (hasDontCare) {
            return BooleanValue.DONT_CARE;
        } else {
            return BooleanValue.FALSE;
        }
    }

    @SuppressWarnings("unused")
    private BooleanValue produktSuma() {
        boolean hasZero = false;
        boolean hasDontCare = false;
        for (int index : indexes) {
            int i = domain.size();
            BooleanVariable[] list = new BooleanVariable[i];
            for (i = i - 1; i >= 0; i--) {
                BooleanVariable b = new BooleanVariable("");
                b.setValue(domain.get(i).getValue());
                if ((index & 1) == 1) {
                    b.setValue(new BooleanOperatorNOT(b).getValue());
                }
                list[i] = b;
                index /= 2;
            }
            BooleanValue bv = BooleanOperators.or(list).getValue();
            if (bv == BooleanValue.FALSE) {
                hasZero = true;
                break;
            } else if (bv == BooleanValue.DONT_CARE) {
                hasDontCare = true;
            }
        }

        if (hasZero) {
            return BooleanValue.FALSE;
        } else if (hasDontCare) {
            return BooleanValue.DONT_CARE;
        } else {
            return BooleanValue.TRUE;
        }
    }

    private Mask getMask() {
        MaskValue[] values = new MaskValue[this.domain.size()];
        MaskValue value;
        int i = 0;
        for (BooleanVariable var : this.domain) {
            if (BooleanValue.TRUE == var.getValue()) {
                value = MaskValue.ONE;
            } else if (BooleanValue.FALSE == var.getValue()) {
                value = MaskValue.ZERO;
            } else {
                value = MaskValue.DONT_CARE;
            }
            values[i++] = value;
        }
        return new Mask(values);
    }

    public BooleanValue getValue() {
        BooleanVariable result = new BooleanVariable("");
        result.setValue(BooleanValue.FALSE);

        BooleanConstant tmp;
        Mask mask = this.getMask();

        for (Integer i : mask.maskValues()) {
            if (this.hasMinterm(i)) {
                tmp = BooleanConstant.TRUE;
            } else if (this.hasMaxterm(i)) {
                tmp = BooleanConstant.FALSE;
            } else {
                tmp = BooleanConstant.DONT_CARE;
            }
            result.setValue(BooleanOperators.or(result, tmp).getValue());
        }
        
        return result.getValue();
    }
}
