package hr.fer.zemris.bool.qmc;

import hr.fer.zemris.bool.BooleanFunction;
import hr.fer.zemris.bool.fimpl.MaskBasedBF;

/**
 * Razred služi za pozivanje statičke metode za minimizaciju funkcije.
 * @author Herman Zvonimir Došilović
 *
 */
public final class QMCMinimizer {

    public static MaskBasedBF[] minimize(BooleanFunction booleanFunction, boolean želimoDobitiProdukte) {
        if (booleanFunction == null) {
            throw new IllegalArgumentException("Boolean Function cannot be null.");
        }
        
        QMCFunction qmcFunction = new QMCFunction(booleanFunction, želimoDobitiProdukte);
        qmcFunction.minimize();
        
        return qmcFunction.getFunctions();
    }

}
