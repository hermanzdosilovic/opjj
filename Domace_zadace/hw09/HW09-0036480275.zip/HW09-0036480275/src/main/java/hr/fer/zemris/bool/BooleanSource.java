package hr.fer.zemris.bool;

import java.util.List;

/**
 * Interface {@code BooleanSource} represents any source capable of producing legal {@code BooleanValue}. It is capable
 * of producing this value (method {@code getValue()}) and and that it can provide an information based on which
 * variables is this value produced (method {@code getDomain()}).
 * @author Herman Zvonimir Došilović
 * @version 1.0
 */
public interface BooleanSource {

    /**
     * Produces legal {@code BooleanValue}.
     * @return legal {@code BooleanValue}.
     */
    BooleanValue getValue();

    /**
     * Provides an information based on which variables is legal {@code BooleanValue} produced.
     * @return information based on which variables is legal {@code BooleanValue} produced.
     */
    List<BooleanVariable> getDomain();

}
