package hr.fer.zemris.bool;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Class {@code Mask} provides construction and operation on masks.For example, consider a Boolean function defined over
 * variables A, B, C and D (i.e. its domain is {A, B, C, D}).
 * Mask “0x1x” represents all value assignments in which A=0
 * and C=1 (we don't care for B and D); here there are for such assignments which we can specify by more specific masks:
 * “0010”, “0011”, “0110” and “0111”.
 * @author Herman Zvonimir Došilović
 * @version 1.0
 */
public class Mask {

    /** Represents {@code Mask} that is made of {@code MaskValue}. */
    private final List<MaskValue> mask;

    /**
     * Private constructor for making new mask.
     * @param maskValues mask values that make one mask.
     */
    public Mask(final List<MaskValue> maskValues) {
        mask = new ArrayList<>(maskValues);
    }

    /**
     * Constructs new {@code Mask} based on given mask values.
     * @param maskValue mask values for {@code Mask} constructions.
     */
    public Mask(final MaskValue... maskValue) {
        this(Arrays.asList(maskValue));
    }

    /**
     * Returns new mask specified as {@code String} representation. Valid {@code String} representation of mask can have
     * '1', '0' or 'x'. Empty {@code String} is not allowed.
     * @param mask {@code String} representation of mask.
     * @return new mask specified as {@code String} representation.
     */
    public static Mask parse(final String mask) {
        if (mask.replace("1", "").replace("0", "").replace("x", "").length() != 0) {
            throw new IllegalArgumentException("Invalid mask.");
        }

        List<MaskValue> newMask = new ArrayList<>();
        for (int i = 0; i < mask.length(); i++) {
            if (mask.charAt(i) == '1') {
                newMask.add(MaskValue.ONE);
            } else if (mask.charAt(i) == '0') {
                newMask.add(MaskValue.ZERO);
            } else {
                newMask.add(MaskValue.DONT_CARE);
            }
        }

        return new Mask(newMask);
    }

    /**
     * Returns new mask based on number and length of mask. For example: if length ih 4 and number is 5, mask would be
     * "0101".
     * @param length of new mask.
     * @param number to represent that mask.
     * @return new mask specified with given arguments.
     */
    public static Mask fromIndex(final int length, final int number) {
        if (length < Integer.toBinaryString(number).length()) {
            throw new IllegalArgumentException("Invalid arguments.");
        }

        String mask = Integer.toBinaryString(number);
        List<MaskValue> newMask = new ArrayList<>();
        for (int i = 0; i < mask.length(); i++) {
            if (mask.charAt(i) == '1') {
                newMask.add(MaskValue.ONE);
            } else {
                newMask.add(MaskValue.ZERO);
            }
        }

        return new Mask(newMask);
    }

    /**
     * Combines two masks if possible. Two masks can be combined if their distance is 1, and values where there
     * differentiate is 1 or 0. For example: masks "1x00" and "0x00" can be combined into "xx00".
     * @param maskOne first mask to combine
     * @param maskTwo second mask to combine
     * @return combined mask, {@code null} if cannot combine.
     */
    public static Mask combine(final Mask maskOne, final Mask maskTwo) {
        if (maskOne.getSize() != maskTwo.getSize()) {
            return null;
        }

        int distance = 0;
        int size = maskOne.getSize();
        for (int i = 0; i < size; i++) {
            if (maskOne.getValue(i) != maskTwo.getValue(i)) {
                distance++;
            }
        }

        if (distance > 1) {
            return null;
        }

        List<MaskValue> newMask = new ArrayList<>();
        for (int i = 0; i < size; i++) {
            if (maskOne.getValue(i) != maskTwo.getValue(i) && maskOne.getValue(i) != MaskValue.DONT_CARE
                    && maskTwo.getValue(i) != MaskValue.DONT_CARE) {
                newMask.add(MaskValue.DONT_CARE);
            } else {
                newMask.add(maskOne.getValue(i));
            }
        }

        return new Mask(newMask);
    }

    /**
     * Returns length of mask.
     * @return length of mask.
     */
    public final int getSize() {
        return mask.size();
    }

    /**
     * Returns mask value at given index.
     * @param index of wanted value.
     * @return mask value at given index.
     */
    public final MaskValue getValue(final int index) {
        if (index < 0 || index >= this.getSize()) {
            throw new IndexOutOfBoundsException();
        }
        return mask.get(index);
    }

    /**
     * Returns number of {@code ZERO} in mask.
     * @return number of {@code ZERO} in mask.
     */
    public final int getNumberOfZeros() {
        return compute(MaskValue.ZERO);
    }

    /**
     * Returns number of {@code ONE} in mask.
     * @return number of {@code ONE} in mask.
     */
    public final int getNumberOfOnes() {
        return compute(MaskValue.ONE);
    }

    /**
     * Computes how many matches of values are in mask.
     * @param value value to count.
     * @return how many matches of given values are in mask.
     */
    private int compute(final MaskValue value) {
        int howManyValues = 0;
        for (int i = 0; i < this.getSize(); i++) {
            if (this.getValue(i) == value) {
                howManyValues++;
            }
        }
        return howManyValues;
    }

    /**
     * Returns {@code true} if this mask is more general than given mask.
     * @param compareMask mask to compare
     * @return {@code true} if this mask is more general than given mask.
     */
    public final boolean isMoreGeneralThan(final Mask compareMask) {
        if (this.getSize() != compareMask.getSize()) {
            return false;
        }

        for (int i = 0; i < this.getSize(); i++) {
            if (this.getValue(i) != MaskValue.DONT_CARE && compareMask.getValue(i) != MaskValue.DONT_CARE
                    && compareMask.getValue(i) != this.getValue(i)) {
                return false;
            }
        }

        for (int i = 0; i < this.getSize(); i++) {
            if (this.getValue(i) == MaskValue.DONT_CARE && compareMask.getValue(i) != MaskValue.DONT_CARE) {
                return true;
            }
        }

        return false;
    }

    public List<Integer> maskValues() {

        List<Mask> masks = this.breakMask();
        List<Integer> list = new ArrayList<>();

        for (Mask m : masks) {
            list.add(m.maskValue());
        }

        return list;

    }

    private Integer maskValue() {
        int result = 0;
        int size = this.getSize();
        for (int i = 0; i < size; i++) {
            if (this.getValue(i) == MaskValue.ONE) {
                result += 1;
            }
            result *= 2;
        }
        return Integer.valueOf(result / 2);
    }

    private List<Mask> breakMask() {
        List<Mask> list = new ArrayList<>();
        list.add(this);

        boolean doWork;
        
        do {
            doWork = false;
            List<Mask> newList = new ArrayList<>();

            for (Mask mask : list) {
                int maskSize = mask.getSize();
                MaskValue[] mask1 = new MaskValue[maskSize];
                MaskValue[] mask2 = new MaskValue[maskSize];
                int donCares = 0;
                for (int i = 0; i < maskSize; i++) {
                    MaskValue value = mask.getValue(i);
                    if (value == MaskValue.DONT_CARE) {
                        if (donCares == 0) {
                            mask1[i] = MaskValue.ZERO;
                            mask2[i] = MaskValue.ONE;
                        } else {
                            mask1[i] = value;
                            mask2[i] = value;
                        }
                        donCares++;
                    } else {
                        mask1[i] = value;
                        mask2[i] = value;
                    }
                }

                newList.add(new Mask(mask1));
                newList.add(new Mask(mask2));
                doWork = donCares > 1;
            }
            list = newList;

        } while (doWork);

        return list;
    }

    @Override
    public String toString() {
        String maskString = "";
        for (MaskValue value : mask) {
            if (MaskValue.ONE == value) {
                maskString += "1";
            } else if (MaskValue.ZERO == value) {
                maskString += "0";
            } else {
                maskString += "X";
            }
        }
        return maskString;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((mask == null) ? 0 : mask.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Mask other = (Mask) obj;
        if (mask == null) {
            if (other.mask != null)
                return false;
        } else if (!mask.equals(other.mask))
            return false;
        return true;
    }
}
