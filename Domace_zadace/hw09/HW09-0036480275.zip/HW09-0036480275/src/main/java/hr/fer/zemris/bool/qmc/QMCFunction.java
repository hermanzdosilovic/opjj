package hr.fer.zemris.bool.qmc;

import hr.fer.zemris.bool.BooleanFunction;
import hr.fer.zemris.bool.Mask;
import hr.fer.zemris.bool.MaskValue;
import hr.fer.zemris.bool.fimpl.MaskBasedBF;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Ovaj razred predstavlja QMCFunckiju minimizacije.
 * @author Herman Zvonimir Došilović
 *
 */
public class QMCFunction {

    private BooleanFunction function;
    private boolean asProducts;
    private List<QMCMask> masks;
    private List<MaskGroup> groups;
    private Set<QMCMask> unPaired;
    private List<Mask> primary;
    private Map<Integer, MaskGroup> table;
    private List<PyneGroup> pyne;
    private Set<MaskGroup> finalPynes;
    
    public QMCFunction(BooleanFunction booleanFunction, boolean asProducts) {
        function = booleanFunction;
        this.asProducts = asProducts;
        unPaired = new HashSet<>();
    }
    
    /**
     * Korak minimizacije.
     */
    public void minimize() {
        extractAllQMCMasks();

        // Napravi grupe
        groups = Group.makeGroups(masks, asProducts);

        // Grupiraj dok možeš
        while (true) {
            if (!combineAllGroups()) {
                break;
            }
        }

        // Izbaci dontCares
        Iterator<QMCMask> i = unPaired.iterator();
        while (i.hasNext()) {
            if (i.next().isDontCare()) {
                i.remove();
            }
        }

        // Extract primary implicants
        extractPrimaryImplicants();
        
        if(unPaired.size() == 0) {
            return;
        }
        
        // Initialize groups
        initializeGroups();

        // While you can
        while (true) {
            if (!groupThemAll()) {
                break;
            }
        }
        
        finalPynes = new HashSet<>();
        for(PyneGroup pGroup : pyne) {
            for(MaskGroup mGroup : pGroup.getGroups()) {
                finalPynes.add(mGroup);
            }
        }
        
    }
    
    /**
     * Grupira sve produkte suma u sumu produkata. Ova metoda ne radi.
     * @return true ako može grupirati, false ako ne.
     */
    private boolean groupThemAll() {

        if (pyne.size() == 1) {
            return false;
        }
        
        PyneGroup group1 = pyne.get(0);
        pyne.remove(0);

        PyneGroup group2 = pyne.get(0);
        pyne.remove(0);

        PyneGroup group = Group.groupPyne(group1, group2);
        pyne.add(group);

        return true;
    }
    
    /**
     * Stvara početne grupe. Tj. stvara prve produkte suma.
     */
    private void initializeGroups() {
        table = new HashMap<>();

        for (QMCMask mask : unPaired) {

            for (Integer value : mask.getValues()) {
                if (function.hadDontCare(value)) {
                    continue;
                }
                if (table.containsKey(value)) {
                    table.get(value).add(mask);
                } else {
                    MaskGroup group = new MaskGroup();
                    group.add(mask);
                    table.put(value, group);
                }
            }
        }

        groups = new ArrayList<>(table.values());

        pyne = new ArrayList<>();
        for (MaskGroup group : groups) {
            PyneGroup pGroup = new PyneGroup();
            for (int i = 0; i < group.groupSize(); i++) {
                MaskGroup mgroup = new MaskGroup();
                mgroup.add(group.get(i));
                pGroup.add(mgroup);
            }
            pyne.add(pGroup);
        }

    }
    
    /**
     * Vadi van bitne primarne implikante.
     */
    private void extractPrimaryImplicants() {
        table = new HashMap<>();

        for (QMCMask mask : unPaired) {
            for (Integer value : mask.getValues()) {
                if (function.hadDontCare(value)) {
                    continue;
                }
                if (table.containsKey(value)) {
                    table.get(value).add(mask);
                } else {
                    MaskGroup group = new MaskGroup();
                    group.add(mask);
                    table.put(value, group);
                }
            }
        }

        primary = new ArrayList<>();
        for (MaskGroup group : table.values()) {
            if (group.groupSize() == 1) {
                if (!primary.contains(group.get(0).getMask())) {
                    primary.add(group.get(0).getMask());
                }
            }
        }

        Iterator<QMCMask> i = unPaired.iterator();
        while (i.hasNext()) {
            QMCMask qmcMask = i.next();
            for (Mask mask : primary) {
                if (qmcMask.getMask().equals(mask)) {
                    i.remove();
                    break;
                }
            }
        }
    }
    
    /**
     * Kombinira grupe u prvom djelu postupka QMC minimizacije
     * @return true ako je uspjela nešto iskombinirati, false inače.
     */
    private boolean combineAllGroups() {
        boolean iCombined = false;

        List<MaskGroup> freshGroups = new ArrayList<>();
        for (int i = 0; i < groups.size(); i++) {
            for (int j = 0; j < groups.size(); j++) {
                if (i != j) {
                    MaskGroup group = Group.combineGroups(groups.get(i), groups.get(j));
                    if (group != null) {
                        freshGroups.add(group);
                        iCombined = true;
                    }
                }
            }
        }

        for (MaskGroup group : groups) {
            for (int i = 0; i < group.groupSize(); i++) {
                if (!group.get(i).isUsed()) {
                    unPaired.add(group.get(i));
                }
            }
        }

        groups = new ArrayList<>(freshGroups);

        return iCombined;
    }
    
    /**
     * Dohvaća sve maske. Minterme ili maksterme, ovisi šta je već zadano.
     */
    private void extractAllQMCMasks() {
        masks = new ArrayList<>();
        if (asProducts) {
            for (Integer maskValue : function.maxtermIterable()) {
                masks.add(new QMCMask(makeMask(maskValue), false, Arrays.asList(maskValue)));
            }
        } else {
            for (Integer maskValue : function.mintermIterable()) {
                masks.add(new QMCMask(makeMask(maskValue), false, Arrays.asList(maskValue)));
            }
        }
        for (Integer maskValue : function.dontcareIterable()) {
            masks.add(new QMCMask(makeMask(maskValue), true, Arrays.asList(maskValue)));
        }
    }
    
    /**
     * Stvara masku iz njezine vrijednosti.
     * @param maskValue vrijednost maske
     * @return masku
     */
    private Mask makeMask(Integer maskValue) {
        List<MaskValue> maskValues = new ArrayList<>();
        while (maskValue != 0) {
            if (maskValue % 2 == 0) {
                maskValues.add(MaskValue.ZERO);
            } else {
                maskValues.add(MaskValue.ONE);
            }
            maskValue /= 2;
        }
        while (maskValues.size() != function.getDomain().size()) {
            maskValues.add(MaskValue.ZERO);
        }
        Collections.reverse(maskValues);
        return new Mask(maskValues);
    }

    public List<QMCMask> getUnpaired() {
        return new ArrayList<>(unPaired);
    }
    
    /**
     * Vraća sve moguće minimizacije funkcije.
     * @return sve moguće minimizacije funkcije.
     */
    @SuppressWarnings("unchecked")
    public MaskBasedBF[] getFunctions() {
        if(finalPynes == null) {
            MaskBasedBF[] funkcije = new MaskBasedBF[1];
            funkcije[0] = new MaskBasedBF(function.getName(), function.getDomain(), asProducts, primary, Collections.EMPTY_LIST);
            return funkcije;
        }
        
        MaskBasedBF[] funkcije = new MaskBasedBF[finalPynes.size()];
        int i = 0;
        for(MaskGroup group : finalPynes) {
            List<Mask> masks = new ArrayList<>(primary);
            for(QMCMask mask : group.getAll()) {
                masks.add(mask.getMask());
            }
            funkcije[i++] = new MaskBasedBF(function.getName(), function.getDomain(), asProducts, masks, Collections.EMPTY_LIST);
        }
        return funkcije;
    }
}
