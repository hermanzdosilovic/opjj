package hr.fer.zemris.bool;

/**
 * Enum {@code MaskValue} represents values that {@code Mask} can have.
 * @author Herman Zvonimir Došilović
 * @version 1.0
 */
public enum MaskValue {

    /** Represents 0 in mask. */
    ZERO,

    /** Represents 1 in mask. */
    ONE,

    /** Represents X in mask. */
    DONT_CARE;

    /**
     * Constructs enumerations.
     */
    MaskValue() {
    }

}
