package hr.fer.zemris.bool;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Class {@code BooleanOperator} represents abstraction over boolean operators.
 * @author Herman Zvonimir Došilović
 * @version 1.0
 */
public abstract class BooleanOperator implements BooleanSource {

    /** Private list of sources based on which final result is calculated. */
    private List<BooleanSource> source = null;

    /**
     * Constructs new boolean operator. It has list of sources based on which final result is calculated.
     * @param newSource list of sources based on which final result is calculated.
     */
    protected BooleanOperator(final List<BooleanSource> newSource) {
        try {
            source = new ArrayList<BooleanSource>(newSource);
        } catch (NullPointerException e) {
            throw new IllegalArgumentException("List cannot be null.");
        }
    }

    /**
     * Returns list of sources based on which final result is calculated.
     * @return list of sources based on which final result is calculated.
     */
    protected final List<BooleanSource> getSources() {
        return this.source;
    }

    /**
     * Returns list of {@code BooleanValue} used with this {@code BooleanOperator}.
     * @return list of {@code BooleanValue} used with this {@code BooleanOperator}.
     */
    @Override
    public final List<BooleanVariable> getDomain() {
        Set<BooleanVariable> set = new HashSet<>();
        for (BooleanSource source : this.source) {
            set.addAll(source.getDomain());
        }
        return new ArrayList<>(set);
    }

}
