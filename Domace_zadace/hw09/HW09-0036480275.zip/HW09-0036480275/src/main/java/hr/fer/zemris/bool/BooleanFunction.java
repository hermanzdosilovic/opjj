package hr.fer.zemris.bool;

/**
 * Interface {@code BooleanFunction} represents an abstract boolean function.
 * @author Herman Zvonimir Došilović
 * @version 1.0
 */
public interface BooleanFunction extends NamedBooleanSource {

    /**
     * Checks if Boolean function contains appropriate <i>minterm</i>. We say that function contains <i>minterm</i>
     * <b><i>i</i></b> if for inferred value assignment function value is {@code TRUE}.
     * <p>
     * Index uniquely specifies the values for domain's variables. For example, if domain is list {A,B,C}, index 3,
     * binary 011, represents value assignment A=0, B=1, C=1. However, if domain is list {B,C,A}, index 3, binary 011,
     * represents value assignment B=0, C=1, A=1.
     * </p>
     * @param index specifies the values for domain's variables.
     * @return {@code true} if function contains <i>minterm</i> at given index, {@code false} otherwise.
     */
    boolean hasMinterm(final int index);

    /**
     * Checks if Boolean function contains appropriate <i>maxterm</i>. We say that function contains <i>maxterm</i>
     * <b><i>i</i></b> if for inferred value assignment function value is {@code FALSE}.
     * <p>
     * Index uniquely specifies the values for domain's variables. For example, if domain is list {A,B,C}, index 3,
     * binary 011, represents value assignment A=0, B=1, C=1. However, if domain is list {B,C,A}, index 3, binary 011,
     * represents value assignment B=0, C=1, A=1.
     * </p>
     * @param index specifies the values for domain's variables.
     * @return {@code true} if function contains <i>maxterm</i> at given index, {@code false} otherwise.
     */
    boolean hasMaxterm(final int index);

    /**
     * Checks if Boolean function contains appropriate <i>don't care</i>. We say that function contains <i>don't
     * care</i> <b><i>i</i></b> if for inferred value assignment function value is {@code FALSE}.
     * <p>
     * Index uniquely specifies the values for domain's variables. For example, if domain is list {A,B,C}, index 3,
     * binary 011, represents value assignment A=0, B=1, C=1. However, if domain is list {B,C,A}, index 3, binary 011,
     * represents value assignment B=0, C=1, A=1.
     * </p>
     * @param index specifies the values for domain's variables.
     * @return {@code true} if function contains <i>don't care</i> at given index, {@code false} otherwise.
     */
    boolean hadDontCare(final int index);

    /**
     * Returns {@code Integer} table of function <i>minterms</i>.
     * @return {@code Integer} table of function <i>minterms</i>.
     */
    Iterable<Integer> mintermIterable();

    /**
     * Returns {@code Integer} table of function <i>maxterms</i>.
     * @return {@code Integer} table of function <i>maxterms</i>.
     */
    Iterable<Integer> maxtermIterable();

    /**
     * Returns {@code Integer} table of function <i>don't cares</i>.
     * @return {@code Integer} table of function <i>don't cares</i>.
     */
    Iterable<Integer> dontcareIterable();

}
