package test;

import hr.fer.zemris.bool.BooleanFunction;
import hr.fer.zemris.bool.BooleanValue;
import hr.fer.zemris.bool.BooleanVariable;
import hr.fer.zemris.bool.Mask;
import hr.fer.zemris.bool.Masks;
import hr.fer.zemris.bool.fimpl.MaskBasedBF;
import hr.fer.zemris.bool.qmc.QMCMinimizer;

import java.util.Arrays;
import java.util.Collections;

/**
 * Moram komentirati rješenje svog drugog zadatka:
 * Imam bug u drugom zadatku kada je potrebno napraviti onaj zadnji korak: pyne-mcluskey
 * Nisam to stigao ispraviti.
 * Dakle, program ispravno dobiva bitne primarne implikante zadane funkcije, ali ne i sve minimalne oblike
 * zato jer mi ovaj zadnji korak ne radi.
 * Hvala unaprijed na razumjevanju.
 * @author Herman Zvonimir Došilović
 */
public class Primjer4 {

    @SuppressWarnings("unchecked")
    public static void main(String[] args) {
        BooleanVariable varA = new BooleanVariable("A");
        BooleanVariable varB = new BooleanVariable("B");
        BooleanVariable varC = new BooleanVariable("C");
        BooleanVariable varD = new BooleanVariable("D");

        varA.setValue(BooleanValue.FALSE);
        varB.setValue(BooleanValue.FALSE);
        varC.setValue(BooleanValue.FALSE);
        varD.setValue(BooleanValue.FALSE);
        
        BooleanFunction bf = new MaskBasedBF("bf1", Arrays.asList(varA, varB, varC, varD), true, 
                Masks.fromStrings("0100", "0101", "0110", "0111", "1000", "1001", "1010", "1011", "1101", "1110"), Collections.EMPTY_LIST);
    
        boolean želimoDobitiProdukte = false;
        MaskBasedBF[] fje = QMCMinimizer.minimize(bf, želimoDobitiProdukte);
        System.out.println("Minimalnih oblika ima: " + fje.length);
        for(MaskBasedBF f : fje) {
            System.out.println("Mogući minimalni oblik:");
            for(Mask m : f.getMasks()) {
                System.out.println(" " + m);
            }
        }
    }

}
