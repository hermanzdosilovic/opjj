package hr.fer.zemris.java.custom.scripting.nodes;

/**
 * This class is representation of document node. Document node is main node of
 * document. Document node represents entire document.
 * 
 * @author Herman Zvonimir Došilović
 * @version 1.0
 */
public class DocumentNode extends Node {

}
