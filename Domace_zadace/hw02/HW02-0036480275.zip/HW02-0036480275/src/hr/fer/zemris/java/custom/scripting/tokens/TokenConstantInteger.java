package hr.fer.zemris.java.custom.scripting.tokens;

/**
 * <code>TokenConstantInteger</code> class represent token that contains
 * constant <b><code>int</code></b>.
 * 
 * @author Herman Zvonimir Došilović
 * @version 1.0
 */
public class TokenConstantInteger extends Token {

	private int value;

	/**
	 * <b><i>TokenConstantInteger</i></b><br>
	 * <br>
	 * <code>&nbsp public TokenConstantInteger(int value)</code><br>
	 * <br>
	 * Constructs new token that contains constant <b><code>int</b></code>.
	 * 
	 * @param value
	 *            - constant <b><code>int</b></code> that this token will
	 *            contain
	 */
	public TokenConstantInteger(int value) {
		this.value = value;
	}

	/**
	 * <b><i>asText</i></b><br>
	 * <br>
	 * <code>&nbsp public String asText()</code><br>
	 * <br>
	 * 
	 * @return string represenation of constant <b><code>int</b></code> that
	 *         this token contains
	 */
	@Override
	public String asText() {
		return Integer.toString(value);
	}

	/**
	 * <b><i>getValue</i></b><br>
	 * <br>
	 * <code>&nbsp public int getValue()</code><br>
	 * <br>
	 * 
	 * @return constant <b><code>int</b></code> that this token contains
	 */
	public int getValue() {
		return value;
	}

}
