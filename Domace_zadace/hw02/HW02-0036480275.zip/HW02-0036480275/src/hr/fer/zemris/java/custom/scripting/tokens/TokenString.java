package hr.fer.zemris.java.custom.scripting.tokens;

/**
 * <code>TokenFunction</code> class represent token that contains string. In
 * string there are folowing rules:
 * <ul>
 * <li>\\ is treated as single character \
 * <li>\" is treated as single character "
 * <li>\n, \r and \t have its usual meaning (ascii 10, 13 and 9)
 * </ul>
 * For example, "Joe \"Long\" Smith" represents a single string whose value is
 * Joe "Long" Smith.
 * 
 * @author Herman Zvonimir Došilović
 * @version 1.0
 */
public class TokenString extends Token {

	private String value;

	/**
	 * <b><i>TokenString</i></b><br>
	 * <br>
	 * <code>&nbsp public TokenString(String value)</code><br>
	 * <br>
	 * Constructs new token that contains string.
	 * 
	 * @param value
	 *            - string that this token will contain
	 */
	public TokenString(String value) {
		this.value = value;
	}

	/**
	 * <b><i>asText</i></b><br>
	 * <br>
	 * <code>&nbsp public String asText()</code><br>
	 * <br>
	 * 
	 * @return string represenation of string that this token contains
	 */
	@Override
	public String asText() {
		return value;
	}

	/**
	 * <b><i>getValue</i></b><br>
	 * <br>
	 * <code>&nbsp public String getValue()</code><br>
	 * <br>
	 * 
	 * @return string that this token contains
	 */
	public String getValue() {
		return value;
	}
}
