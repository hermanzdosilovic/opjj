package hr.fer.zemris.java.hw2;

import hr.fer.zemris.java.custom.scripting.nodes.*;
import hr.fer.zemris.java.custom.scripting.parser.*;
import hr.fer.zemris.java.custom.scripting.tokens.Token;

/**
 * <code>SmartScriptTester</code> class is used to test work of
 * <code>SmartScriptParser</code> class.
 * 
 * @author Herman Zvonimir Došilović
 * @version 1.0
 */
public class SmartScriptTester {

	/**
	 * <b><i>main</i></b><br>
	 * <br>
	 * <code>&nbsp public static void main(String[] args)</code><br>
	 * <br>
	 * Program entry. <b>Does not use arguments.</b>
	 * 
	 * @param args
	 *            - arguments provided by caller
	 */
	public static void main(String[] args) {
		String docBody = "This is sample text.\r\n{$ FOR i 1 10 1 $}\r\n  This is {$= i $}-th time this message is generated."
				+ "\r\n{$END$}\r\n{$FOR i 0 10 2 $}\r\n  sin({$=i$}^2) = {$= i i * @sin \"\\\\n0.000\" @decfmt $}\r\n{$END$}";
		SmartScriptParser parser = null;
		try {
			parser = new SmartScriptParser(docBody);
		}
		catch (SmartScriptParserException e) {
			System.out.println("Unable to parse document!");
			System.exit(-1);
		}
		catch (Exception e) { // you shall not pass!
			System.out.println("If this line ever executes, you have failed this class!");
			System.exit(-1);
		}
		DocumentNode document = parser.getDocumentNode();
		String originalDocumentBody = createOriginalDocumentBody(document);
		System.out.print(originalDocumentBody);
	}

	/**
	 * <b><i>createOriginalDocumentBody</i></b><br>
	 * <br>
	 * <code>&nbsp public static String createOriginalDocumentBody(Node document)</code>
	 * <br>
	 * <br>
	 * This method creates string representation of document body. For example
	 * if document contains:<br>
	 * <code>This is the first line.<br>{$FOR i 0 10 1 $}<br>Hey I am in loop.<br>Yo! Me to.<br>{$END$}</code>
	 * <br>
	 * <br>
	 * Then your string representation of this document would be:<br>
	 * <code>This is the first line.\r\n<br>FOR i 0 10 1<br>\r\nHey I am in loop.\r\nYo! Me to.\r\n</code>
	 * 
	 * @param document
	 *            - Node of document to be represented as string
	 * @return <code>String</code> representation of given document
	 * @see SmartScriptParser
	 */
	public static String createOriginalDocumentBody(Node document) {
		StringBuilder docBody = new StringBuilder();

		for (int i = 0; i < document.numberOfChildren(); i++) {
			if (document.getChild(i) instanceof TextNode) {
				TextNode textNode = (TextNode) document.getChild(i);
				docBody.append(textNode.getText()).append("\n");
			}
			else if (document.getChild(i) instanceof ForLoopNode) {
				ForLoopNode forNode = (ForLoopNode) document.getChild(i);
				docBody.append("FOR ").append(forNode.getVariable().asText() + " ")
						.append(forNode.getStartExpression().asText() + " ");
				docBody.append(forNode.getEndExpression().asText());
				if (forNode.getStepExpression() != null) {
					docBody.append(" " + forNode.getStepExpression().asText() + "\n");
				}
				docBody.append(createOriginalDocumentBody(document.getChild(i)));
			}
			else if (document.getChild(i) instanceof EchoNode) {
				EchoNode echoNode = (EchoNode) document.getChild(i);
				Token[] tokens = echoNode.getTokens();
				docBody.append("ECHO ");
				for (int index = 0; index < tokens.length; index++) {
					docBody.append(tokens[index].asText() + " ");
				}
				docBody.append("\n");
			}
		}
		return docBody.toString();
	}
}
