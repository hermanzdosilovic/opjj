package hr.fer.zemris.java.custom.scripting.tokens;

/**
 * <code>TokenVariable</code> class represent token that contains variable.
 * Valid name of variable starts by letter and after follows zero or more
 * letters, digits or underscores. If name is not valid, it is invalid. This
 * variable names are valid: <code>A7_bb</code>, <code>counter</code>,
 * <code>tmp_34</code>; these are not: <code>_a21</code>, <code>32</code>,
 * <code>3s_ee</code> etc.
 * 
 * @author Herman Zvonimir Došilović
 * @version 1.0
 */
public class TokenVariable extends Token {

	private String name;

	/**
	 * <b><i>TokenVariable</i></b><br>
	 * <br>
	 * <code>&nbsp public TokenVariable(String name)</code><br>
	 * <br>
	 * Constructs new token that contains variable name.
	 * 
	 * @param name
	 *            - variable name that this token will contain
	 */
	public TokenVariable(String name) {
		this.name = name;
	}

	/**
	 * <b><i>asText</i></b><br>
	 * <br>
	 * <code>&nbsp public String asText()</code><br>
	 * <br>
	 * 
	 * @return string represenation of variable name that this token contains
	 */
	@Override
	public String asText() {
		return name;
	}

	/**
	 * <b><i>getName</i></b><br>
	 * <br>
	 * <code>&nbsp public String getName()</code><br>
	 * <br>
	 * 
	 * @return variable name that this token contains
	 */
	public String getName() {
		return name;
	}
}
