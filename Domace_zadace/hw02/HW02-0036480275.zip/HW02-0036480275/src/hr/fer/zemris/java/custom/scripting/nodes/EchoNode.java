package hr.fer.zemris.java.custom.scripting.nodes;

import hr.fer.zemris.java.custom.scripting.tokens.Token;

/**
 * <code>EchoNode</code> represents a command which generates some textual
 * output dynamically.
 * 
 * @author Herman Zvonimir Došilović
 * @version 1.0
 */
public class EchoNode extends Node {

	private Token[] tokens;

	/**
	 * <b><i>EchoNode</i></b><br>
	 * <br>
	 * <code>&nbsp public EchoNode(Token[] tokens)</code><br>
	 * <br>
	 * Constructs <code>EchoNode</code> with given tokens.
	 * 
	 * @param tokens
	 *            - tokens that <code>EchoNode</code> uses.
	 */
	public EchoNode(Token[] tokens) {
		this.tokens = new Token[tokens.length];
		this.tokens = tokens;
	}

	/**
	 * <b><i>getTokens</i></b><br>
	 * <br>
	 * <code>&nbsp public Token[] getTokens()</code><br>
	 * <br>
	 * Returns tokens that this <code>EchoNode</code> uses.
	 * 
	 * @return tokens that this <code>EchoNode</code> uses
	 */
	public Token[] getTokens() {
		return tokens;
	}

	/**
	 * <b></i>getSize</i></b><br>
	 * <br>
	 * <code>&nbsp public int getSize()</code><br>
	 * <br>
	 * 
	 * @return amount of tokens that this <code>EchoNode</code> uses
	 */
	public int getSize() {
		return tokens.length;
	}
}
