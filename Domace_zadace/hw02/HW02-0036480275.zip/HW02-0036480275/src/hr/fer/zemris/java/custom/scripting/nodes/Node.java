package hr.fer.zemris.java.custom.scripting.nodes;

import hr.fer.zemris.java.custom.collections.*;

/**
 * This class is representation of all graph nodes. It provides folowing
 * operations:
 * <ul>
 * <li> <code>addChildNode</code>
 * <li> <code>numberOfChildern</code>
 * <li> <code>getChild</code>
 * <li> <code>isEmpty</code>
 * </ul>
 * Index of children is set by the order they were added. First added child has
 * index 0, second 1, ..., last <code>size()</code> - 1.
 * 
 * @author Herman Zvonimir Došilović
 * @version 1.0
 * 
 */
public class Node {

	private ArrayBackedIndexedCollection rootNode;

	/**
	 * <b><i>addChildNode</i></b><br>
	 * <br>
	 * <code>&nbsp public void addChildNode(Node child)</code><br>
	 * <br>
	 * Adds child to this node.
	 * 
	 * @param child
	 *            - child to add
	 * @throws IllegalArgumentException
	 *             if given child is <code>null</code>.
	 */
	public void addChildNode(Node child) {
		if (rootNode == null) {
			rootNode = new ArrayBackedIndexedCollection();
		}
		if (child == null) {
			throw new IllegalArgumentException("null cannot be child of node.");
		}

		rootNode.add(child);
	}

	/**
	 * <b><i>numberOfChilder</i></b><br>
	 * <br>
	 * <code>&nbsp public int numberOfChilder()</code><br>
	 * <br>
	 * Return number of childer of this node.
	 * 
	 * @return number of childern of this node
	 */
	public int numberOfChildren() {
		/*
		 * TODO: In some special cases this approach could be potentional flaw.
		 * Should fix this in next version.
		 */
		if (rootNode == null) {
			return 0;
		}
		else {
			return rootNode.size();
		}
	}

	/**
	 * <b><i>getChild</i></b><br>
	 * <br>
	 * <code>&nbsp public Node getChild(int index)</code><br>
	 * <br>
	 * Returns child at given index. Index of children is set by the order they
	 * were added. First added child has index 0, second 1, ..., last
	 * <code>size()</code> - 1.
	 * 
	 * @param index
	 *            - index of child to return
	 * @return child at specified index
	 * @throws ArrayIndexOutOfBoundsException
	 *             if given index is out of range (
	 *             <code>index < 0 || index >= size()</code>)
	 */
	public Node getChild(int index) {
		if (index < 0 || index >= rootNode.size()) {
			throw new ArrayIndexOutOfBoundsException("No child at " + index + ".");
		}
		return (Node) rootNode.get(index);
	}
}
