package hr.fer.zemris.java.custom.scripting.nodes;

import hr.fer.zemris.java.custom.scripting.tokens.*;

/**
 * <code>ForLoopNode</code> class is representation of single for-loop
 * constructor. <code>ForLoopNode</code> must be closed with <i>END</i> tag.
 * 
 * @author Herman Zvonimir Došilović
 * @version 1.0
 */
public class ForLoopNode extends Node {

	private TokenVariable variable;
	private Token startExpression;
	private Token endExpression;
	private Token stepExpression; // Can be null.

	/**
	 * <b><i>ForLoopNode</i></b><br>
	 * <br>
	 * <code>&nbsp public ForLoopNode(TokenVariable variable, Token startExpression, Token endExpression, Token stepExpression)</code>
	 * <br>
	 * <br>
	 * Constructs new <code>ForLoopNode</code>. Valid number of arguments in
	 * <i>FOR</i> tag is 3 or 4.
	 * 
	 * @param variable
	 *            - <code>TokenVariable</code> that this loop uses
	 * @param startExpression
	 *            - <code>Token</code> that represents start of expression in
	 *            this loop
	 * @param endExpression
	 *            - <code>Token</code> that represents end of expression in this
	 *            loop
	 * @param stepExpression
	 *            - <code>Token</code> that represents a step expression in this
	 *            loop. This <code>Token</code> can be <code>null</code>.
	 */
	public ForLoopNode(TokenVariable variable, Token startExpression, Token endExpression,
			Token stepExpression) {

		this.variable = variable;
		this.startExpression = startExpression;
		this.endExpression = endExpression;
		this.stepExpression = stepExpression;
	}

	/**
	 * <b><i>TokenVariable</i></b><br>
	 * <br>
	 * <code>&nbsp public TokenVariable getVariable()</code><br>
	 * <br>
	 * 
	 * @return <code>TokenVariable</code> that this loop uses
	 */
	public TokenVariable getVariable() {
		return variable;
	}

	/**
	 * <b><i>getStartExpression</i></b><br>
	 * <br>
	 * <code>&nbsp public Token getStartExpression()</code><br>
	 * <br>
	 * 
	 * @return <code>Token</code> that represents start of expression of this
	 *         loop
	 */
	public Token getStartExpression() {
		return startExpression;
	}

	/**
	 * <b><i>getEndExpression</i></b><br>
	 * <br>
	 * <code>&nbsp public Token getEndExpression()</code><br>
	 * <br>
	 * 
	 * @return <code>Token</code> that represents end of expression of this loop
	 */
	public Token getEndExpression() {
		return endExpression;
	}

	/**
	 * <b><i>getStepExpression</i></b><br>
	 * <br>
	 * <code>&nbsp public Token getStepExpression()</code><br>
	 * <br>
	 * 
	 * @return <code>Token</code> that represents step expression of this loop
	 */
	public Token getStepExpression() {
		return stepExpression;
	}
}
