package hr.fer.zemris.java.custom.collections;

/**
 * Thrown by methods in the <code>ObjectStack</code> class to indicate that the
 * stack is empty.
 * 
 * @author Herman Zvonimir Došilović
 * @version 1.0
 */
public class EmptyStackException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	/**
	 * <b><i>EmptyStackException</i></b><br>
	 * <br>
	 * <code>&nbsp public EmptyStackException(String message)</code><br>
	 * <br>
	 * Constructs a new EmptyStackException with its error message string.
	 * 
	 * @param message
	 *            - error message
	 */
	public EmptyStackException(String message) {
		super(message);
	}

	/**
	 * <b><i>EmptyStackException</i></b><br>
	 * <br>
	 * <code>&nbsp public EmptyStackException(Throwable cause)</code><br>
	 * <br>
	 * Create a new EmptyStackException with the specified cause.
	 * 
	 * @param cause
	 *            - the caluse
	 */
	public EmptyStackException(Throwable cause) {
		super(cause);
	}

	/**
	 * <b><i>EmptyStackException</i></b><br>
	 * <br>
	 * <code>&nbsp public EmptyStackException(String message, Throwable cause)</code>
	 * <br>
	 * <br>
	 * Create a new EmptyStackException with the specified detail message and
	 * cause.
	 * 
	 * @param message
	 *            - the detail message
	 * @param cause
	 *            - the cause
	 */
	public EmptyStackException(String message, Throwable cause) {
		super(message, cause);
	}
}
