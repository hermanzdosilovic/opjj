package hr.fer.zemris.java.tecaj.hw6.crypto;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.spec.AlgorithmParameterSpec;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

/**
 * Class {@code Crypter} provides methods for encrypt/decrypt given file using AES crypto-algorithm and 128-bit
 * encryption key or calculate and check SHA-1 file digest.
 * @author Herman Zvonimir Došilović
 * @version 1.0.
 */
public final class Crypter {

    /**
     * Encrypts given file using AES crypto-algorithm.
     * @param source path of source file, i.e. path of file to encrypt.
     * @param destination path of destination file, i.e. path of new encrypted file.
     */
    public static void encrypt(final Path source, final Path destination) {
        endecrypt(Cipher.ENCRYPT_MODE, source, destination);
    }

    /**
     * Decrypts given file using AES crypto-algorithm.
     * @param source path of source file, i.e. path of file to decrypt.
     * @param destination path of destination file, i.e. path of new decrypted file.
     */
    public static void decrypt(final Path source, final Path destination) {
        endecrypt(Cipher.DECRYPT_MODE, source, destination);
    }

    /**
     * Calculate and check SHA-1 file digest.
     * @param filePath path of file to check file digest.
     */
    public static void checksha(final Path filePath) {
        FileInputStream inputStream = openInputStream(filePath.toAbsolutePath().toString());

        String shaSignature = getUserInput("Please provide expected sha signature for " + filePath.toString()
                + ":\n> ");

        MessageDigest sha;
        try {
            sha = MessageDigest.getInstance("SHA-1");
        }
        catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("No such algorithm.");
        }

        final int chunkSize = 2048;
        byte[] data = new byte[chunkSize];
        int lengthRead = 0;
        try {
            while ((lengthRead = inputStream.read(data)) != -1) {
                sha.update(data, 0, lengthRead);
            }
        }
        catch (IOException e) {
            throw new RuntimeException("Cannot read from file.");
        }

        byte[] shaData = sha.digest();
        StringBuilder sb = new StringBuilder("");
        for (int i = 0; i < shaData.length; i++) {
            sb.append(Integer.toString((shaData[i] & 0xFF) + 0x100, 16).substring(1));
        }

        String expectedDigest = sb.toString();
        if (expectedDigest.equals(shaSignature)) {
            System.out.printf("Digesting completed. Digest of %s matches expected digest.%n", filePath.getFileName()
                    .toString());
        }
        else {
            System.out.printf(
                    "Digesting completed. Digest of %s does not match the expected digest.%nDigest was: %s%n", filePath
                            .getFileName().toString(), expectedDigest);
        }
    }

    /**
     * Main method for both decryption and encryption. It selects mode based on {@code cryptMode}.
     * @param cryptMode crypting mode.
     * @param source path of source file.
     * @param destination path of destination file.
     */
    private static void endecrypt(final int cryptMode, final Path source, final Path destination) {
        FileInputStream inputStream = openInputStream(source.toAbsolutePath().toString());
        FileOutputStream outputStream = openOutputStream(destination.toAbsolutePath().toString());
        
        String keyText = getUserInput("Please provide password as hex-encoded text (16 bytes, i.e. 32 hex-digits):\n> ");
        String ivText = getUserInput("Please provide initialization vector as hex-encoded text (32 hex-digits):\n> ");

        SecretKeySpec keySpec = new SecretKeySpec(hextobyte(keyText), "AES");
        AlgorithmParameterSpec paramSpec = new IvParameterSpec(hextobyte(ivText));
        Cipher cipher;
        try {
            cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
            cipher.init(cryptMode, keySpec, paramSpec);
        }
        catch (NoSuchAlgorithmException | NoSuchPaddingException e) {
            throw new RuntimeException("No such algorithm.");
        }
        catch (InvalidKeyException | InvalidAlgorithmParameterException e) {
            throw new RuntimeException("Invalid key.");
        }

        final int chunkSize = 2048;
        byte[] data = new byte[chunkSize];
        byte[] chiperData;
        int lengthRead = 0;
        try {
            while ((lengthRead = inputStream.read(data)) != -1) {
                chiperData = cipher.update(data, 0, lengthRead);
                outputStream.write(chiperData);
            }
            chiperData = cipher.doFinal();
            outputStream.write(chiperData);
        }
        catch (IOException e) {
            throw new RuntimeException("File error.");
        }
        catch (IllegalBlockSizeException | BadPaddingException e) {
            throw new RuntimeException("Illegal block size.");
        }

        try {
            inputStream.close();
            outputStream.close();
        }
        catch (IOException e) {
            throw new RuntimeException("File stream error.");
        }

        System.out.printf("%s completed. Generated file %s based on file %s.%n",
                cryptMode == Cipher.DECRYPT_MODE ? "Decription" : "Encrypton", destination, source);
    }

    /**
     * Prompts specified message and asks user for input.
     * @param message message that will be displayed to user.
     * @return user input as {@code String}.
     */
    private static String getUserInput(final String message) {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in, StandardCharsets.UTF_8));
        String userInput;
        try {
            System.out.print(message);
            userInput = reader.readLine();
        }
        catch (IOException e) {
            throw new RuntimeException("Error while reading from standard input.");
        }
        return userInput;
    }

    /**
     * Converts hex based {@code String} to bytes.
     * @param hexString {@code String} to convert.
     * @return converted {@code String} to bytes.
     */
    private static byte[] hextobyte(final String hexString) {
        int len = hexString.length();
        byte[] data = new byte[len / 2];
        for (int i = 0; i < len; i += 2) {
            data[i / 2] = (byte) ((Character.digit(hexString.charAt(i), 16) << 4) + Character.digit(
                    hexString.charAt(i + 1), 16));
        }
        return data;
    }

    /**
     * Opens {@code FileInputStream} with given path.
     * @param path of file to open.
     * @return opened {@code FileInputStream}
     * @throw RuntimeException if error is occurred during opening.
     */
    private static FileInputStream openInputStream(final String path) {
        FileInputStream inputStream;
        try {
            inputStream = new FileInputStream(path);
        }
        catch (FileNotFoundException e) {
            throw new RuntimeException("File not found.");
        }
        catch (SecurityException se) {
            throw new RuntimeException("Cannot read this file.");
        }
        return inputStream;
    }

    /**
     * Opens {@code FileOutputStream} with given path.
     * @param path of file to open.
     * @return opened {@code FileOutputStream}
     * @throw RuntimeException if error is occurred during opening.
     */
    private static FileOutputStream openOutputStream(final String path) {
        FileOutputStream outputStream;
        try {
            outputStream = new FileOutputStream(path);
        }
        catch (FileNotFoundException e) {
            throw new RuntimeException("File not found.");
        }
        catch (SecurityException se) {
            throw new RuntimeException("Cannot read this file.");
        }
        return outputStream;
    }
}
