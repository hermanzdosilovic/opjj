package hr.fer.zemris.java.tecaj.hw6.problem1a;

/**
 * {@code Observer} interface.
 * @author Herman Zvonimir Došilović
 * @version 1.0.
 */
public interface IntegerStorageObserver {

    /**
     * Action which executes when value of observed subject is changed.
     * @param istorage observed subject.
     */
    void valueChanged(final IntegerStorage istorage);

}
