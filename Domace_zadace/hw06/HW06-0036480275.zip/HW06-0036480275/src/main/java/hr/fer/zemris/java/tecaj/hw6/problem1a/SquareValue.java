package hr.fer.zemris.java.tecaj.hw6.problem1a;

/**
 * Instances of {@code SquareValue} class write a square of the integer stored in the {@code IntegerStorage} to the
 * standard output.
 * @author Herman Zvonimir Došilović
 * @version 1.0.
 */
public class SquareValue implements IntegerStorageObserver {

    /**
     * {@code SquareValue} observer action. Writes a square of the integer currently stored in subject.
     * @param istorage {@code IntegerStorage} that this {@code SquareValue} observes.
     */
    @Override
    public final void valueChanged(final IntegerStorage istorage) {
        final int value = istorage.getValue();
        final int squareValue = value * value;
        System.out.printf("Provided new value: %d, square is %d%n", value, squareValue);
    }

}
