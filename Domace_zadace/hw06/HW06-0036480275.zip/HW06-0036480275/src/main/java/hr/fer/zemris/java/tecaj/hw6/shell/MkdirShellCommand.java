package hr.fer.zemris.java.tecaj.hw6.shell;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.IOException;

/**
 * @author Herman Zvonimir Došilović
 * @version 1.0.
 */
public class MkdirShellCommand implements ShellCommand {

    /**
     * Executes {@code mkdir} command.
     */
    @Override
    public ShellStatus executeCommand(BufferedReader in, BufferedWriter out, String[] arguments) {
        if (arguments.length != 1) {
            try {
                out.write("Command mkdir expects one argument.\n");
            }
            catch (IOException e) {
                throw new RuntimeException("Error while writing to stdout.");
            }
        }
        else {
            File file = new File(arguments[0]);
            try {
                if (!file.mkdir()) {
                    out.write("A directory already exists.\n");
                }
                else {
                    out.write("Directory successfuly created.\n");
                }
            }
            catch (IOException e) {
                throw new RuntimeException("Error while writing to stdout.");
            }
        }
        try {
            out.flush();
        }
        catch (IOException e) {
            throw new RuntimeException("Error while writing to stdout.");
        }
        return ShellStatus.CONTINUE;
    }
}
