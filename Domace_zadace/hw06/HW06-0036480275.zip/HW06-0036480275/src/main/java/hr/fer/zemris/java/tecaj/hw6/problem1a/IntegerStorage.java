package hr.fer.zemris.java.tecaj.hw6.problem1a;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * {@code Subject} class which stores one {@code Integer} value.
 * @author Herman Zvonimir Došilović
 * @version 1.0.
 */
public class IntegerStorage {

    /** Integer value that this instance stores. */
    private int value;

    /** Observers of this instance. */
    private List<IntegerStorageObserver> observers;

    /**
     * Constructs new {@code IntegerStorage} instance with initial value given.
     * @param initialValue initial value that this instance will store.
     */
    public IntegerStorage(final int initialValue) {
        this.value = initialValue;
    }

    /**
     * Adds a observer if observer list if not already there.
     * @param observer observer who is tried to be added.
     * @throws IllegalArgumentException {@code null} if given observer is {@code null}.
     */
    public void addObserver(final IntegerStorageObserver observer) {
        if (this.observers == null) {
            this.observers = new CopyOnWriteArrayList<>();
        }
        if (observer == null) {
            throw new IllegalArgumentException("Observer cannot be null.");
        }
        if (this.observers.contains(observer)) {
            return;
        }

        this.observers.add(observer);
    }

    /**
     * Removes given observer from list of observers.
     * @param observer to be removed.
     * @throws IllegalArgumentException if given observer is {@code null}.
     */
    public void removeObserver(final IntegerStorageObserver observer) {
        if (this.observers == null) {
            throw new RuntimeException("Observer cannot be removed.");
        }
        if (observer == null) {
            throw new IllegalArgumentException("Observer cannot be null.");
        }

        this.observers.remove(observer);
    }

    /**
     * Clears list of observers.
     */
    public void clearObservers() {
        if (this.observers == null) {
            return;
        }

        this.observers.clear();
    }

    /**
     * Returns value that this {@code IntegerStorage} holds.
     * @return value that this {@code IntegerStorage} holds.
     */
    public int getValue() {
        return this.value;
    }

    /**
     * Sets new value to this {@code IntegerStorage}. If new value is different that the current value all registered
     * observers are notified.
     * @param value new value for this {@code IntegerStorage}.
     */
    public void setValue(final int value) {
        if (this.value == value) {
            return;
        }

        this.value = value;
        if (this.observers != null) {
            for(IntegerStorageObserver myObserver : this.observers) {
                myObserver.valueChanged(this);
            }
        }
    }

}
