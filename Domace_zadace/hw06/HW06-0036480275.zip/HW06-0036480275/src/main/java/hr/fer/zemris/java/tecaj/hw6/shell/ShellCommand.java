package hr.fer.zemris.java.tecaj.hw6.shell;

import java.io.BufferedReader;
import java.io.BufferedWriter;

/**
 * Interface {@code ShellCommand} specifies all supported shell commands.
 * @author Herman Zvonimir Došilović
 * @version 1.0.
 */
public interface ShellCommand {

    /**
     * Executes command.
     * @param in wrapped {@code stdin}.
     * @param out wrapped {@code stdout}.
     * @param arguments array of user-provided arguments
     * @return {@code ShellStatus}.
     */
    ShellStatus executeCommand(BufferedReader in, BufferedWriter out, String[] arguments);

}
