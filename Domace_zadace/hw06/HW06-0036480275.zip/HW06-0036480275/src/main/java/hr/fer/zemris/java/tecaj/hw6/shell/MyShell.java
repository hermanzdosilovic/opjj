package hr.fer.zemris.java.tecaj.hw6.shell;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Class {@code MyShell} is a command line program.<br>
 * It supports folowing commands:
 * <ul>
 * <i>
 * <li>exit
 * <li>symbol
 * <li>charsets
 * <li>cat
 * <li>ls
 * <li>tree
 * <li>copy
 * <li>mkdir
 * <li>hexdump </i>
 * </ul>
 * <b>exit</b>
 * <ul>
 * Terminates the shell.
 * </ul>
 * <b>symbol</b>
 * <ul>
 * Writes current assigned symbol for given specification.
 * <ul>
 * For example:
 * <ul>
 * <li>"{@code symbol PROMPT}" will output currently assigned PROMPT symbol ('>' by default).
 * <li>"{@code symbol MORELINES}" will output currently assigned MORELINES symbol ('\' by default).
 * <li>"{@code symbol MULTILINE}" will output currently MULTILINE symbol ('|' by default).
 * <li><b>If specification is unknown, users gets warned.</b>
 * </ul>
 * </ul>
 * Changes current assigned symbol to given.
 * <ul>
 * For example:
 * <ul>
 * <li>"{@code symbol PROMPT #}" will change currently assigned PROMPT symbol to # ('>' by default).
 * <li>"{@code symbol MORELINES +}" will change currently assigned MORELINES symbol to + ('\' by default).
 * <li>"{@code symbol MULTILINE !}" will change currently MULTILINE symbol to ! ('|' by default).
 * <li><b>If new symbol consists of more than one chars, user gets warned.</b>
 * </ul>
 * </ul>
 * </ul>
 * <b>charset</b>
 * <ul>
 * Takes no arguments and lists names of supported charsets for your Java platform.
 * </ul>
 * <b>cat</b>
 * <ul>
 * Command {@code cat} takes one or thw arguments. The first argument is path to some file and is mandatory. The second
 * argument is charset name that should be used to interpret chars from bytes. If not provided. a defalut platform
 * charset is used. This command opens given file and writes its content to console.
 * </ul>
 * <b>ls</b>
 * <ul>
 * Takes a single argument - directory - and writes a directory listing (not recursive).
 * </ul>
 * <b>tree</b>
 * <ul>
 * Takes a single argument: directory name and prints a tree structure of directory and subdirectories.
 * </ul>
 * <b>copy</b>
 * <ul>
 * Expects two arguments: source file name and destination file name (i.e. paths and names). If destination file
 * exsists, user is asked to overwrite it.
 * </ul>
 * <b>mkdir</b>
 * <ul>
 * Takes a single argument: document name, and creates the appropriate directory structure.
 * </ul>
 * <b>hexdump</b>
 * <ul>
 * Expects a single argument: file name, and produces hex-output.
 * </ul>
 * @author Herman Zvonimir Došilović
 * @version 1.0.
 */
public final class MyShell {

    /** Maps command names with instances of commands. */
    private static Map<String, ShellCommand> commands;

    /**
     * Program entry. Does not command line arguments.
     * @param args command line arguments. Not in use.
     */
    public static void main(final String[] args) {
        commands = new HashMap<>();
        commands.put("symbol", new SymbolShellCommand());
        commands.put("exit", new ExitShellCommand());
        commands.put("charsets", new CharsetsShellCommand());
        commands.put("cat", new CatShellCommand());
        commands.put("ls", new LsShellCommand());
        commands.put("tree", new TreeShellCommand());
        commands.put("copy", new CopyShellCommand());
        commands.put("mkdir", new MkdirShellCommand());
        commands.put("hexdump", new HexdumpShellCommand());

        System.out.println("Welcome tp MyShell v 1.0");
        ShellStatus status = ShellStatus.CONTINUE;

        do {
            String line = readLineOrLines(ShellSymbol.PROMPT.getSymbol());
            if (line.equals("")) {
                continue;
            }

            String commandName = extractCommand(line);
            line = line.substring(commandName.length()).trim();

            String[] arguments = extractArguments(line);

            if (commands.get(commandName) == null) {
                System.out.println("Invalid command " + commandName);
                continue;
            }

            ShellCommand command = commands.get(commandName);
            try {
                status = command.executeCommand(new BufferedReader(new InputStreamReader(new BufferedInputStream(
                        System.in), StandardCharsets.UTF_8)), new BufferedWriter(new OutputStreamWriter(
                        new BufferedOutputStream(System.out), StandardCharsets.UTF_8)), arguments);
            }
            catch (RuntimeException e) {
                System.out.println("Error: " + e.getMessage());
            }
        }
        while (status != ShellStatus.TERMINATE);
    }

    /**
     * Reads user input line or lines.
     * @return user input line or lines.
     */
    public static String readLineOrLines(final String shellSymbol) {
        System.out.print(shellSymbol + " ");
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in, StandardCharsets.UTF_8));
        StringBuilder sb = new StringBuilder();
        String userLine = "";

        try {
            userLine = reader.readLine();
        }
        catch (IOException e) {
            throw new RuntimeException("Error reading from standard input.");
        }

        userLine = userLine.trim();
        while (userLine.contains("  ")) {
            userLine = userLine.replace("  ", " ");
        }

        if (userLine.endsWith(ShellSymbol.MORELINES.getSymbol())) {
            sb.append(userLine.substring(0, userLine.length() - 1));
            sb.append(readLineOrLines(ShellSymbol.MULTILINE.getSymbol()));
        }
        else {
            sb.append(userLine);
        }
        return sb.toString();
    }

    /**
     * Extracts command from line.
     * @param line line of user input.
     * @return command.
     */
    public static String extractCommand(final String line) {
        if (line.indexOf(' ') != -1) {
            return line.substring(0, line.indexOf(' '));
        }
        else {
            return line;
        }
    }

    /**
     * Extracts arguments from line.
     * @param line line of user input.
     * @return arguments.
     */
    public static String[] extractArguments(String line) {
        List<String> arguments = new ArrayList<>();
        while (!line.equals("")) {
            String nextArgument = extractCommand(line);
            line = line.substring(nextArgument.length()).trim();
            arguments.add(nextArgument);
        }

        String[] stringArguments = new String[arguments.size()];
        int i = 0;
        for (String s : arguments) {
            stringArguments[i++] = new String(s);
        }

        return stringArguments;
    }
}
