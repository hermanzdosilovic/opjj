package hr.fer.zemris.java.tecaj.hw6.problem1b;

/**
 * Instances of {@code ChangeCounter} counts (and writes to the standard output) the number of times value
 * stored integer has been changed since the registration.
 * @author Herman Zvonimir Došilović
 * @version 1.0.
 */
public class ChangeCounter implements IntegerStorageObserver {

    /** Private counter. Counts the number of times value stored integer has been changed since the registration. */
    private int counter = 0;

    /**
     * {@code ChangeCounter} observer action. Writes to the standard output the number of times value stored
     * integer has been changed since the registration.
     * @param istorage {@code IntegerStorageChange} that this {@code ChangeCounter} observes.
     */
    @Override
    public final void valueChanged(final IntegerStorageChange istorage) {
        this.counter++;
        System.out.printf("Number of value changes since tracking: %d%n", this.counter);
    }

}
