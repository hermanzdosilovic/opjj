package hr.fer.zemris.java.tecaj.hw6.shell;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;

public class SymbolShellCommand implements ShellCommand {

    /**
     * Executes shell status command.
     * @param in wrapped {@code stdin}.
     * @param out wrapped {@code stdout}.
     * @param arguments array of user-provided arguments
     * @return {@code ShellStatus}.
     * @throws IOException if input/output error occurred.
     */
    @Override
    public ShellStatus executeCommand(BufferedReader in, BufferedWriter out, String[] arguments) {
        if (arguments.length != 1 && arguments.length != 2) {
            try {
                out.write("Command symbol expects at least one argument.\n");
            }
            catch (IOException e) {
                throw new RuntimeException("Error while writing to stdout.");
            }
        }
        else {
            String argument = null;
            if (arguments.length == 2) {
                argument = arguments[1];
            }
            switch (arguments[0]) {
                case "PROMPT":
                    processSymbol(ShellSymbol.PROMPT, argument, out);
                    break;
                case "MULTILINE":
                    processSymbol(ShellSymbol.MULTILINE, argument, out);
                    break;
                case "MORELINES":
                    processSymbol(ShellSymbol.MORELINES, argument, out);
                    break;
                default:
                    try {
                        out.write("Unknown symbol " + arguments[0] + ".\n");
                    }
                    catch (IOException e) {
                        throw new RuntimeException("Error while writing to stdout.");
                    }

            }
        }
        try {
            out.flush();
        }
        catch (IOException e) {
            throw new RuntimeException("Error while writing to stdout.");
        }
        return ShellStatus.CONTINUE;
    }

    /**
     * Processes the given symbol.
     * @param symbol {@code ShellSymbol} enumeration to change.
     * @param newSymbol assign new symbol.
     * @param out stdout.
     * @throws IOException if input/output error occurred.
     */
    private void processSymbol(ShellSymbol symbol, String newSymbol, BufferedWriter out) {
        try {
            if (newSymbol == null) {
                out.write("Symbol for " + symbol + " is '" + symbol.getSymbol() + "'\n");
            }
            else if (newSymbol.length() != 1) {
                out.write(newSymbol + " cannot be " + symbol + " symbol.\n");
            }
            else {
                out.write("Symbol for " + symbol + " changed from '" + symbol.getSymbol() + "' to '" + newSymbol
                        + "'\n");
                symbol.setSymbol(newSymbol);
            }
        }
        catch (IOException e) {
            throw new RuntimeException("Error while writing to stdout.");
        }
    }
}
