package hr.fer.zemris.java.tecaj.hw6.problem1a;

import java.io.IOException;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;

/**
 * Instances of {@code LogValue} class for each notification open a log file whose path is given in its construction,
 * appends a new row with current value obtained from subject and closes the file.
 * @author Herman Zvonimir Došilović
 * @version 1.0.
 */
public class LogValue implements IntegerStorageObserver {

    /** Path of log file. */
    private final Path path;

    /**
     * Construct new {@code LogValue} with log file whose path is given.
     * @param path path of log file.
     */
    public LogValue(final Path path) {
        this.path = path;
    }

    /**
     * {@code LogValue} observer action. Opens a log file whose path is given in its construction, appends a new row
     * with current value obtained from subject and closes file.
     * @param istorage {@code IntegerStorage} that this {@code LogValue} observers.
     */
    @Override
    public final void valueChanged(final IntegerStorage istorage) {
        try (OutputStream os = Files.newOutputStream(this.path, StandardOpenOption.CREATE, StandardOpenOption.APPEND)) {
            final byte[] data = String.format("%d%n", istorage.getValue()).getBytes(StandardCharsets.UTF_8);
            os.write(data);
        }
        catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

}
