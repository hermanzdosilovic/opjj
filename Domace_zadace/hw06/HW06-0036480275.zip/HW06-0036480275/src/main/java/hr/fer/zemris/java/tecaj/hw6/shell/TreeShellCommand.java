package hr.fer.zemris.java.tecaj.hw6.shell;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.file.FileVisitResult;
import java.nio.file.FileVisitor;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.attribute.BasicFileAttributes;

/**
 * @author Herman Zvonimir Došilović
 * @version 1.0.
 */
public class TreeShellCommand implements ShellCommand {

    /** File visitor. */
    static class Visitor implements FileVisitor<Path> {

        private int indent = 0;
        private BufferedWriter out;

        public Visitor(BufferedWriter out) {
            this.out = out;
        }

        @Override
        public FileVisitResult preVisitDirectory(Path dir, BasicFileAttributes attrs) throws IOException {
            String output;
            if (indent == 0) {
                output = String.format("%s%n", dir);

            }
            else {
                output = String.format("%" + indent + "s%s%n", "", dir.getName(dir.getNameCount() - 1));
            }
            out.write(output);
            indent += 2;
            return FileVisitResult.CONTINUE;
        }

        @Override
        public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) throws IOException {
            String output = String.format("%" + indent + "s%s%n", "", file.getName(file.getNameCount() - 1));
            out.write(output);
            return FileVisitResult.CONTINUE;
        }

        @Override
        public FileVisitResult visitFileFailed(Path file, IOException exc) throws IOException {
            return FileVisitResult.CONTINUE;
        }

        @Override
        public FileVisitResult postVisitDirectory(Path dir, IOException exc) throws IOException {
            indent -= 2;
            return FileVisitResult.CONTINUE;
        }

    }

    /**
     * Executes {@code tree} command.
     */
    @Override
    public ShellStatus executeCommand(BufferedReader in, BufferedWriter out, String[] arguments) {
        if (arguments.length != 1) {
            try {
                out.write("Command tree expects one argument.\n");
            }
            catch (IOException e) {
                throw new RuntimeException("Error while writing to stdout.");
            }
        }
        Path path = Paths.get(arguments[0]);
        if (!path.toFile().isDirectory()) {
            throw new RuntimeException("Path should represent directory.");
        }
        try {
            Files.walkFileTree(path, new Visitor(out));
            out.flush();
        }
        catch (IOException e) {
            throw new RuntimeException("Error while writing to stdout.");
        }
        return ShellStatus.CONTINUE;
    }

}
