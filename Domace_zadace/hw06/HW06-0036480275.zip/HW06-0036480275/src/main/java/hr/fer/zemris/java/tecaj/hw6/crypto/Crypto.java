package hr.fer.zemris.java.tecaj.hw6.crypto;

import java.nio.file.Paths;

/**
 * Class {@code Crypto} allow user to encrypt/decrypt given file using AES crypto-algorithm and 128-bit encryption key
 * or calculate and check SHA-1 file digest.
 * @author Herman Zvonimir Došilović
 * @version 1.0.
 */
public class Crypto {

    /**
     * Program entry. This program uses command line arguments. It supports following arguments:
     * <ul>
     * <i>
     * <li>checksha [path or name of file]
     * <li>encrypt [path or name of source file] [path or name of destination file]
     * <li>decrypt [path or name of source file] [path or name of destination file] </i>
     * </ul>
     * @param args command line arguments.
     */
    public static void main(final String[] args) {
        if (args.length < 2) {
            System.err.println("Program expects at least two arguments.");
            System.exit(-1);
        }
        if (args[0].equals("checksha")) {
            if (args.length != 2) {
                System.err.println("Command checksha expects one argument.");
                System.exit(-1);
            }
            Crypter.checksha(Paths.get(args[1]));
        }
        else if (args[0].equals("encrypt")) {
            if (args.length != 3) {
                System.err.println("Command encrypt expects two argument.");
                System.exit(-1);
            }
            Crypter.encrypt(Paths.get(args[1]), Paths.get(args[2]));
        }
        else if (args[0].equals("decrypt")) {
            if (args.length != 3) {
                System.err.println("Command decrypt expects two argument.");
                System.exit(-1);
            }
            Crypter.decrypt(Paths.get(args[1]), Paths.get(args[2]));
        }
        else {
            System.err.println("Unsupported argument " + args[0]);
            System.exit(-1);
        }
    }

}
