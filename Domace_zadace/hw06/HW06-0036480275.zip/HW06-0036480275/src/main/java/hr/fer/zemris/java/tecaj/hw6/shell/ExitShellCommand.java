package hr.fer.zemris.java.tecaj.hw6.shell;

import java.io.BufferedReader;
import java.io.BufferedWriter;

/**
 * {@code ExitShellCommand} indicates shell to stop with work.
 * @author Herman Zvonimir Došilović
 * @version 1.0.
 */
public class ExitShellCommand implements ShellCommand {

    /**
     * Executes {@code exit} command, which tells terminates shell. {@code exit} command ignores any given arguments.
     * @return {@linkplain ShellStatus#TERMINATE}
     */
    @Override
    public ShellStatus executeCommand(BufferedReader in, BufferedWriter out, String[] arguments) {
        return ShellStatus.TERMINATE;
    }

}
