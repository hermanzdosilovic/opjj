package hr.fer.zemris.java.tecaj.hw6.problem1b;

/**
 * {@code Observer} interface.
 * @author Herman Zvonimir Došilović
 * @version 1.0.
 */
public interface IntegerStorageObserver {

    /**
     * Action which executes when value of observed subject is changed.
     * @param istorageChange observed subject.
     */
    void valueChanged(final IntegerStorageChange istorageChange);

}
