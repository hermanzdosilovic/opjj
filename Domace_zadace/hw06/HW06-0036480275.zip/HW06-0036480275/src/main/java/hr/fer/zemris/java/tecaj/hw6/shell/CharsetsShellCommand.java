package hr.fer.zemris.java.tecaj.hw6.shell;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.Charset;

/**
 * When executed this command lists names of supported charsets for your Java platform.
 * @author Herman Zvonimir Došilović
 * @version 1.0.
 */
public class CharsetsShellCommand implements ShellCommand {

    /**
     * Executes {@code charsets} command.
     */
    @Override
    public ShellStatus executeCommand(BufferedReader in, BufferedWriter out, String[] arguments) {
        try {
            if (arguments.length != 0) {
                out.write("Command charsets takes no arguments.\n");
            }
            else {
                for (String charsetName : Charset.availableCharsets().keySet()) {
                    out.write(charsetName + "\n");
                }
            }
            out.flush();
        }
        catch (IOException e) {
            throw new RuntimeException("Error while writing to stdout.");
        }
        return ShellStatus.CONTINUE;
    }

}
