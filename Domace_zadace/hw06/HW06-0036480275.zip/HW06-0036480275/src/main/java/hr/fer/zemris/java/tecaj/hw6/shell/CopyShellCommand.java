package hr.fer.zemris.java.tecaj.hw6.shell;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

/**
 * @author Herman Zvonimir Došilović
 * @version 1.0.
 */
public class CopyShellCommand implements ShellCommand {

    /**
     * Executes {@code copy} command.
     */
    @Override
    public ShellStatus executeCommand(BufferedReader in, BufferedWriter out, String[] arguments) {
        if (arguments.length != 2) {
            try {
                out.write("Command copy expects two arguments.\n");
            }
            catch (IOException e) {
                throw new RuntimeException("Error while writing to stdout.");
            }
        }
        else {
            File source = new File(arguments[0]);
            File dest = new File(arguments[1]);
            if (!source.exists()) {
                throw new RuntimeException("File " + source.getName() + " does not exsist.");
            }

            if (source.getAbsolutePath().equals(dest.getAbsolutePath())) {
                try {
                    out.write("The file cannot be copied onto itself.\n");
                    out.flush();
                }
                catch (IOException e) {
                    throw new RuntimeException("Error while writing to stdout.");
                }
                return ShellStatus.CONTINUE;
            }

            if (dest.exists()) {
                try {
                    out.write("File " + arguments[1] + " already exsist. Do you want to overwrite it?\n");
                    out.write("Type \"yes\" if you want to overwrite it.\n");
                    out.flush();
                }
                catch (IOException e) {
                    throw new RuntimeException("Error while writing to stdout.");
                }
                String line = MyShell.readLineOrLines(ShellSymbol.PROMPT.getSymbol());
                if (!line.toLowerCase().equals("yes")) {
                    try {
                        out.write("Aborted.\n");
                        out.flush();
                    }
                    catch (IOException e) {
                        throw new RuntimeException("Error while writing to stdout.");
                    }
                    return ShellStatus.CONTINUE;
                }
            }

            InputStream input = null;
            OutputStream output = null;
            try {
                input = new FileInputStream(source);
                output = new FileOutputStream(dest);
                byte[] buf = new byte[1024];
                int bytesRead;
                while ((bytesRead = input.read(buf)) != -1) {
                    output.write(buf, 0, bytesRead);
                }
                input.close();
                output.close();
            }
            catch (IOException e) {
                throw new RuntimeException("IO error occured.");
            }

        }
        try {
            out.write("File successfuly copied.\n");
            out.flush();
        }
        catch (IOException e) {
            throw new RuntimeException("Error while writing to stdout.");
        }
        return ShellStatus.CONTINUE;
    }
}
