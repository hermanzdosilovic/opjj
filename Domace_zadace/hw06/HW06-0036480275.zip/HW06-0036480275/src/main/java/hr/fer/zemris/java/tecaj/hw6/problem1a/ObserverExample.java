package hr.fer.zemris.java.tecaj.hw6.problem1a;

import java.nio.file.Paths;

/**
 * Observer example.
 * @author Herman Zvonimir Došilović
 * @version 1.0.
 */
public class ObserverExample {

    /**
     * Program entry. <b>Does not use command line arguments.</b>
     * @param args command line arguments.
     */
    public static void main(final String[] args) {

        System.out.println("ObserverExample A:");

        IntegerStorage istorage = new IntegerStorage(20);

        IntegerStorageObserver observer = new SquareValue();

        istorage.addObserver(observer);
        istorage.setValue(5);
        istorage.setValue(2);
        istorage.setValue(25);

        istorage.removeObserver(observer);

        istorage.addObserver(new ChangeCounter());
        istorage.addObserver(new DoubleValue());
        istorage.addObserver(new LogValue(Paths.get("./log.txt")));
        istorage.setValue(13);
        istorage.setValue(22);
        istorage.setValue(15);
    }

}
