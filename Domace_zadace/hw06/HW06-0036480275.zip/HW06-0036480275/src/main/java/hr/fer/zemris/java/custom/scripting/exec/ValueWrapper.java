package hr.fer.zemris.java.custom.scripting.exec;

/**
 * Class {@code ValueWrapper} is used to store values of different type on which basic operations can be done.<br>
 * <br>
 * Class provides four arithmetic methods:
 * <ul>
 * <li>{@code public void increment(Object incValue)}
 * <li>{@code public void decrement(Object decValue)}
 * <li>{@code public void multiply(Object mulValue)}
 * <li>{@code public void divide(Object divValue)}
 * </ul>
 * And additional numerical comparasion method:
 * <ul>
 * <li> {@code public int numCompare(Object withValue)}
 * </ul>
 * @author Herman Zvonimir Došilović
 * @version 1.0.
 */
public class ValueWrapper {

    /** Private object representing stored value. */
    private Object value;

    /**
     * Creates new ValueWrapper with specified initial value.<br>
     * Allowed values for {@code ValueWrapper} to store are:
     * <ul>
     * <li>{@code Integer}
     * <li>{@code Double}
     * <li>{@code String}
     * <li>{@code null}
     * </ul>
     * If {@code String} is given as an argument for initial value, it will be converted to decimal
     * value if it represents decimal value e.q. "2.4", "0.1234", "1e-8".<br>
     * {@code String} will be converted to {@code Integer} if it does not represent decimal value e.q. "2", "0", "-1".<br>
     * If {@code null} is given, it will be converted to {@code new Integer(0)} i.e. to integer value zero.
     * @param initialValue
     */
    public ValueWrapper(final Object initialValue) {
        this.value = initialValue;
    }

    /**
     * Returns decimal representation of given object value.
     * @param value object whose value will be returned.
     * @return decimal representation of given object value.
     */
    private Double getValue(final Object value) {
        return Double.parseDouble(value.toString());
    }

    /**
     * Returns value of this {@code ValueWrapper}.
     * @return value of this {@code ValueWrapper}.
     */
    public Object getValue() {
        if (this.value instanceof Integer) {
            return Integer.parseInt(this.value.toString());
        }
        else {
            return Double.parseDouble(this.value.toString());
        }
    }

    /**
     * Sets value of this {@code ValueWrapper} to the given value.
     * @param value new value of this {@code ValueWrapper}.
     */
    public void setValue(Object value) {
        Object setTo = getObjectType(value);
        this.value = setTo;
    }

    /**
     * Increments value stored by this {@code ValueWrapper} for value of given {@code Object}. <br>
     * If either current value or argument is {@code Double}, result will be stored as an instance of {@code Double}.
     * If not, result will be stored as an instance of {@code Integer}.
     * @param incValue {@code Object} whose value will be added to this value.
     */
    public void increment(final Object incValue) {
        this.value = getObjectType(this.value);
        Object incrementValue = getObjectType(incValue);

        Double firstValue = getValue(this.value);
        Double secondValue = getValue(incrementValue);

        this.value = getResult(this.value, incrementValue, firstValue + secondValue);
    }

    /**
     * Decrements value stored by this {@code ValueWrapper} for value of given {@code Object}.
     * If either current value or argument is {@code Double}, result will be stored as an instance of {@code Double}.
     * If not, result will be stored as an instance of {@code Integer}.
     * @param decValue {@code Object} whose value will be subtracted to this value.
     */
    public void decrement(final Object decValue) {
        this.value = getObjectType(this.value);
        Object decrementValue = getObjectType(decValue);

        Double firstValue = getValue(this.value);
        Double secondValue = getValue(decrementValue);

        this.value = getResult(this.value, decrementValue, firstValue - secondValue);
    }

    /**
     * Multiplies value stored by this {@code ValueWrapper} with value of given {@code Object}.
     * If either current value or argument is {@code Double}, result will be stored as an instance of {@code Double}.
     * If not, result will be stored as an instance of {@code Integer}.
     * @param mulValue {@code Object} whose value will be multiplied with this value.
     */
    public void multiply(final Object mulValue) {
        this.value = getObjectType(this.value);
        Object multiplytValue = getObjectType(mulValue);

        Double firstValue = getValue(this.value);
        Double secondValue = getValue(multiplytValue);

        this.value = getResult(this.value, multiplytValue, firstValue * secondValue);
    }

    /**
     * Divides value stored by this {@code ValueWrapper} with value of given {@code Object}.
     * If either current value or argument is {@code Double}, result will be stored as an instance of {@code Double}.
     * If not, result will be stored as an instance of {@code Integer}.
     * @param divValue {@code Object} whose value will be divided from this value.
     */
    public void divide(final Object divValue) {
        this.value = getObjectType(this.value);
        Object divideValue = getObjectType(divValue);

        Double firstValue = getValue(this.value);
        Double secondValue = getValue(divideValue);

        this.value = getResult(this.value, divideValue, firstValue / secondValue);
    }

    /**
     * Method performs numerical comparison between currently stored value in {@code ValueWrapper} and given argument.
     * The method returns an integer less than zero if currently stored value is smaller than argument, and integer
     * greater than zero if currently stored value is larger than argument or an integer 0 if they are equal.
     * <ul>
     * <li>If both values are {@code null}, method will treat them as equal.
     * <li>If one is {@code null} and other is not, method will treat {@code null}-value as integer with value 0.
     * </ul>
     * @param withValue {@code Object} to compare with.
     * @return returns an integer less than zero if currently stored value is smaller than argument, and integer greater
     *         than zero if currently stored value is larger than argument or an integer 0 if they are equal.
     */
    public int numCompare(final Object withValue) {
        Object compareValue = getObjectType(this.value);
        Object compareWithValue = getObjectType(withValue);

        Double firstValue = getValue(compareValue);
        Double secondValue = getValue(compareWithValue);

        Object result = getResult(compareValue, compareWithValue, firstValue - secondValue);
        double resultValue = getValue(result);

        final double error = 10e-7;
        if (Math.abs(resultValue) < error) {
            return 0;
        }
        else if (resultValue > 0) {
            return 1;
        }
        else {
            return -1;
        }
    }

    /**
     * Returns result object from two given objects.
     * If either current value or argument is {@code Double}, result will be stored as an instance of {@code Double}.
     * If not, result will be stored as an instance of {@code Integer}.
     * @param firstValue first Object from who result object will be populated.
     * @param secondValue second Object from who result object will be populated.
     * @param resultValue value that will be stored in result object.
     * @return result object from two given objects.
     */
    private Object getResult(final Object firstValue, final Object secondValue, final Double resultValue) {
        if (firstValue instanceof Double || secondValue instanceof Double) {
            return resultValue;
        }
        else {
            return Integer.valueOf(resultValue.intValue());
        }
    }

    /**
     * For given object returns type of this object.
     * @param value Object whose type needs to be observed.
     * @return returns type of this object.
     * @throws RuntimeException if unsuported type is given.
     */
    private Object getObjectType(final Object value) {
        if (value == null) {
            return Integer.valueOf(0);
        }
        else if (value instanceof Integer) {
            return (Integer) value;
        }
        else if (value instanceof Double) {
            return (Double) value;
        }
        else if (value instanceof String) {
            Object stringValue;
            try {
                stringValue = Integer.parseInt((String) value);
            }
            catch (NumberFormatException e1) {
                try {
                    stringValue = Double.parseDouble((String) value);
                }
                catch (NumberFormatException e2) {
                    throw new RuntimeException("Undefined value given.");
                }
            }
            return stringValue;
        }
        else {
            throw new RuntimeException("Value type unsupported.");
        }
    }

    /**
     * Returns string representation of value stored by this {@code ValueWrapper}.
     * @return string representation of value stored by this {@code ValueWrapper}.
     */
    @Override
    public String toString() {
        return this.value.toString();
    }

}
