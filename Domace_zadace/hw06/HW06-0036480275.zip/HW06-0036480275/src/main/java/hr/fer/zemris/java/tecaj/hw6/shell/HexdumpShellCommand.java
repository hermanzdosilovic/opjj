package hr.fer.zemris.java.tecaj.hw6.shell;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Class {@code HexdumpShellCommand} represents {@code hexdump} command of {@code MyShell}.
 * For given file, it produces hex-output. In rigth part of output all bytes whose value is less than 32 or greater than
 * 127 replaces with ".".
 * For larger files it could take a few seconds to generate hex-output.
 * @author Herman Zvonimir Došilović
 * @version 1.0.
 */
public class HexdumpShellCommand implements ShellCommand {

    /**
     * Executes {@code hexdump} command.
     */
    @Override
    public ShellStatus executeCommand(BufferedReader in, BufferedWriter out, String[] arguments) {
        if (arguments.length != 1) {
            try {
                out.write("Command hexdump expects one argument.");
            }
            catch (IOException e) {
                throw new RuntimeException("Error while writing to stdout.");
            }
        }
        else {
            FileInputStream file = null;
            try {
                file = new FileInputStream(arguments[0]);
            }
            catch (FileNotFoundException e) {
                throw new RuntimeException("File " + arguments[0] + " not found.");
            }
            int data;
            List<String> output = new ArrayList<>();
            String row = "";
            String text = "";
            int cnt = 0;
            int rowCnt = 0;
            row = String.format("%08d: ", rowCnt);
            try {
                while ((data = file.read()) != -1) {
                    cnt++;
                    String number = Integer.toHexString(data);
                    number = number.length() == 1 ? "0" + number : number;
                    row += number;
                    if (data < 32 || data > 127) {
                        text += ".";
                    }
                    else {
                        text += String.format("%c", data);
                    }
                    if (cnt == 8) {
                        row += '|';
                    }
                    else if (cnt == 16) {
                        row += " | " + text;
                        cnt = 0;
                        rowCnt += 16;
                        output.add(row);
                        int zero = Integer.toHexString(rowCnt).length();
                        zero = 8 - zero;
                        String z = "";
                        while (zero-- != 0) {
                            z += "0";
                        }
                        row = String.format("%s%s: ", z, Integer.toHexString(rowCnt));
                        text = "";
                    }
                    else {
                        row += " ";
                    }
                }
                if (cnt != 0) {
                    for (int i = cnt; i < 16; i++) {
                        row += "  ";
                        if (i + 1 == 8) {
                            row += "|";
                        }
                        else {
                            row += " ";
                        }
                    }
                    row += "| " + text;
                    output.add(row);
                }
                for (String line : output) {
                    out.write(line + "\n");
                }
                file.close();
            }
            catch (IOException e) {
                throw new RuntimeException("Error while writing to stdout.");
            }
        }
        try {
            out.flush();
        }
        catch (IOException e) {
            throw new RuntimeException("Error while writing to stdout.");
        }
        return ShellStatus.CONTINUE;
    }

}
