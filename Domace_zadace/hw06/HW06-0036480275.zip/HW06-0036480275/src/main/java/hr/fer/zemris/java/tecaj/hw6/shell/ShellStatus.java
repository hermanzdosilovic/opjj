package hr.fer.zemris.java.tecaj.hw6.shell;

/**
 * Shell status enumerations.
 * @author Herman Zvonimir Došilović
 * @version 1.0.
 */
public enum ShellStatus {

    /** Indicates shell to continue with work. */
    CONTINUE,

    /** Indicates shell to stop with work. */
    TERMINATE;

}
