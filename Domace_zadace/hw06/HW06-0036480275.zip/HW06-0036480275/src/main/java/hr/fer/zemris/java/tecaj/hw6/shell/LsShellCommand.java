package hr.fer.zemris.java.tecaj.hw6.shell;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.attribute.BasicFileAttributeView;
import java.nio.file.attribute.BasicFileAttributes;
import java.nio.file.attribute.FileTime;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * @author Herman Zvonimir Došilović
 * @version 1.0.
 */
public class LsShellCommand implements ShellCommand {

    /**
     * Executes {@code ls} command.
     */
    @Override
    public ShellStatus executeCommand(BufferedReader in, BufferedWriter out, String[] arguments) {
        if (arguments.length != 1) {
            try {
                out.write("Command ls expects one argument.\n");
            }
            catch (IOException e) {
                throw new RuntimeException("Error while writing to stdout.");
            }
        }
        else {
            File file = new File(arguments[0]);
            if (!file.isDirectory()) {
                throw new RuntimeException("Path should represent directory.");
            }
            for (File f : file.listFiles()) {
                String firstColumn = "";
                firstColumn += (f.isDirectory() ? "d" : "-");
                firstColumn += (f.canRead() ? "r" : "-");
                firstColumn += (f.canWrite() ? "w" : "-");
                firstColumn += (f.canExecute() ? "x" : "-");

                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                BasicFileAttributeView faView = Files.getFileAttributeView(f.toPath(), BasicFileAttributeView.class,
                        LinkOption.NOFOLLOW_LINKS);
                BasicFileAttributes attributes;
                try {
                    attributes = faView.readAttributes();
                }
                catch (IOException e) {
                    throw new RuntimeException("Error reading file attributes " + f.getPath() + ".");
                }
                FileTime fileTime = attributes.creationTime();

                String secondColumn = String.format("%10d", f.length());

                String thirdColumn = sdf.format(new Date(fileTime.toMillis()));

                try {
                    out.write(firstColumn + " " + secondColumn + " " + thirdColumn + " " + f.getName() + "\n");
                }
                catch (IOException e) {
                    throw new RuntimeException("Error while writing to stdout.");
                }
            }
        }
        try {
            out.flush();
        }
        catch (IOException e) {
            throw new RuntimeException("Error while writing to stdout.");
        }
        return ShellStatus.CONTINUE;
    }
}
