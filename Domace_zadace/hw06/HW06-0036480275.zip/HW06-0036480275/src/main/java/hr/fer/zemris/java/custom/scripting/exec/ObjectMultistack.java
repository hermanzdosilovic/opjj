package hr.fer.zemris.java.custom.scripting.exec;

import java.util.EmptyStackException;
import java.util.HashMap;
import java.util.Map;

/**
 * {@code ObjectMultistack} class allow the user to store multiple values for same key, and provide a stack-like
 * abstraction. Values that will be associated with those keys will be instances of class {@code ValueWrapper}.
 * @author Herman Zvonimir Došilović
 * @version 1.0.
 */
public class ObjectMultistack {

    /** Inner static class that acts as a node of a single-linked list. */
    private static class MultistackEntry {

        /** Reference to next node. */
        private MultistackEntry next;

        /** Value stored in this node. */
        private ValueWrapper value;

        /**
         * Creates new node. New node will store {@code ValueWrapper} and will point on next {@code MultistackEntry}.
         * @param value value stored in this node.
         * @param nextEntry reference to next node. If {@code null}, this node represents tail of list.
         */
        public MultistackEntry(final ValueWrapper value, final MultistackEntry nextEntry) {
            this.value = value;
            this.next = nextEntry;
        }
    }

    /** Structure that will behave as {@code ObjectMultistack}. */
    private Map<String, MultistackEntry> objectMultistack;

    /**
     * Creates new ObjectMultistack structure.
     */
    public ObjectMultistack() {
        this.objectMultistack = new HashMap<>();
    }

    /**
     * Pushes a {@code ValueWrapper} into the stack in map with given key.
     * @param name key for {@code ValueWrapper}.
     * @param valueWrapper {@code ValueWrapper} to add in map.
     * @throws IllegalArgumentException if {@code name} or {@code valueWrapper} is {@code null}.
     */
    public void push(final String name, final ValueWrapper valueWrapper) {
        if (name == null) {
            throw new IllegalArgumentException("Key cannot be null.");
        }
        if (valueWrapper == null) {
            throw new IllegalArgumentException("Value cannot be null.");
        }

        if (!this.objectMultistack.containsKey(name)) {
            this.objectMultistack.put(name, new MultistackEntry(valueWrapper, null));
            return;
        }

        MultistackEntry multistackEntry = this.objectMultistack.get(name);
        MultistackEntry newMultistackEntry = new MultistackEntry(valueWrapper, multistackEntry);
        this.objectMultistack.put(name, newMultistackEntry);
    }

    /**
     * Pops and returns an element from stack with specified key.
     * @param name key in map.
     * @return element that was on top of stack in given key position. Returns {@code null} if this
     *         {@code ObjectMultistack} does not contains given key.
     * @throws IllegalArgumentException if key is {@code null}.
     * @throws EmptyStackException if this method is called upon empty stack.
     */
    public ValueWrapper pop(final String name) {
        if (name == null) {
            throw new IllegalArgumentException("Key cannot be null.");
        }
        if (!this.objectMultistack.containsKey(name)) {
            throw new EmptyStackException();
        }

        MultistackEntry multistackEntry = this.objectMultistack.get(name);

        ValueWrapper value = multistackEntry.value;
        multistackEntry = multistackEntry.next;

        if (multistackEntry == null) {
            this.objectMultistack.remove(name);
        }
        else {
            this.objectMultistack.put(name, multistackEntry);
        }

        return value;
    }

    /**
     * Peeks and returns element from top of the stack in specified key position.
     * @param name key of {@code ObjectMultistack}.
     * @return element from top of the stack in specified key position.
     * @throws IllegalArgumentException if key is {@code null}.
     * @throws EmptyStackException if this method is called upon empty stack.
     */
    public ValueWrapper peek(final String name) {
        if (name == null) {
            throw new IllegalArgumentException("Key cannot be null.");
        }
        if (!this.objectMultistack.containsKey(name)) {
            throw new EmptyStackException();
        }

        MultistackEntry multistackEntry = this.objectMultistack.get(name);

        ValueWrapper value = multistackEntry.value;

        return value;
    }

    /**
     * Returns {@code true} if stack at given key position is empty, {@code false} otherwise.
     * @param name key position in {@code ObjectMultistack}.
     * @return {@code true} if stack is empty, {@code false} otherwise.
     * @throws IllegalArgumentException if key is {@code null}.
     */
    public boolean isEmpty(final String name) {
        if (name == null) {
            throw new IllegalArgumentException("Key cannot be null.");
        }

        if (!this.objectMultistack.containsKey(name)) {
            return true;
        }

        return false;
    }

}
