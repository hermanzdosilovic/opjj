package hr.fer.zemris.java.tecaj.hw6.shell;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;

/**
 * When executed this command opens given file and writes its content to console.
 * @author Herman Zvonimir Došilović
 * @version 1.0.
 */
public class CatShellCommand implements ShellCommand {

    /**
     * Executes {@code cat} command.
     */
    @Override
    public ShellStatus executeCommand(BufferedReader in, BufferedWriter out, String[] arguments) {
        if (arguments.length != 1 && arguments.length != 2) {
            try {
                out.write("Command cat expects one or two arguments.\n");
            }
            catch (IOException e) {
                throw new RuntimeException("Error while writing to stdout.");
            }
        }
        else {
            Charset charset = Charset.defaultCharset();
            if (arguments.length == 2) {
                try {
                    charset = Charset.forName(arguments[1]);
                }
                catch (IllegalArgumentException e) {
                    throw new RuntimeException("Unsupported charset was given.");
                }
            }
            List<String> fileContent;
            try {
                fileContent = Files.readAllLines(Paths.get(arguments[0]), charset);
            }
            catch (IOException | SecurityException e) {
                throw new RuntimeException("Unable to read " + arguments[0] + ".");
            }
            for (String line : fileContent) {
                try {
                    out.write(line + "\n");
                }
                catch (IOException e) {
                    throw new RuntimeException("Error while writing to stdout.");
                }
            }
        }
        try {
            out.flush();
        }
        catch (IOException e) {
            throw new RuntimeException("Error while writing to stdout.");
        }
        return ShellStatus.CONTINUE;
    }

}
