package hr.fer.zemris.java.tecaj.hw6.problem1a;

/**
 * Instances of {@code DoubleValue} class write to the standard output double value of the current value which is stored
 * in subject, but only first two times since its registration with subject; after writing the double value for the
 * second time, the observer automatically de-registers itself from the subject.
 * @author Herman Zvonimir Došilović
 * @version 1.0.
 */
public class DoubleValue implements IntegerStorageObserver {

    /** Counts how many times double value of the current value was written to the standard output. */
    private int counter = 0;

    /**
     * {@code DoubleValue} observer action. Writes to the standard output double value of the current value which is
     * stored in subject.
     * @param istorage {@code IntegerStorage} that this {@code DoubleValue} observes.
     */
    @Override
    public final void valueChanged(final IntegerStorage istorage) {
        this.counter++;
        final int value = istorage.getValue();
        final int doubleValue = 2 * value;
        System.out.printf("Double value: %d%n", doubleValue);

        if (this.counter == 2) {
            istorage.removeObserver(this);
        }
    }

}
