package hr.fer.zemris.java.tecaj.hw6.problem1b;

import java.nio.file.Paths;

/**
 * Observer example.
 * @author Herman Zvonimir Došilović
 * @version 1.0.
 */
public class ObserverExample {

    /**
     * Program entry. <b>Does not use command line arguments.</b>
     * @param args command line arguments.
     */
    public static void main(final String[] args) {

        System.out.println("ObserverExample B:");

        IntegerStorage istorage = new IntegerStorage(20);

        istorage.addObserver(new SquareValue());
        istorage.addObserver(new ChangeCounter());
        istorage.addObserver(new DoubleValue());
        istorage.addObserver(new LogValue(Paths.get("./log.txt")));

        istorage.setValue(5);
        istorage.setValue(2);
        istorage.setValue(25);
        istorage.setValue(13);
        istorage.setValue(22);
        istorage.setValue(15);
    }

}
