package hr.fer.zemris.java.tecaj.hw6.problem1b;

/**
 * Instances of {@code IntegerStorageChange class} encapsulate (as read-only properties) following information:
 * <ul>
 * <li>a reference to {@code IntegerStorage}.
 * <li>the value of stored integer before the change has occurred.
 * <li>the new value of currently stored integer.
 * </ul>
 * @author Herman Zvonimir Došilović
 * @version 1.0.
 */
public class IntegerStorageChange {

    /** A reference to {@code IntegerStorage}. */
    private IntegerStorage istorage;

    /** The value of stored integer before the change has occurred. */
    private int oldValue;

    /** The new value of currently stored integer. */
    private int newValue;

    /**
     * Creates new instance of {@code IntegerStorageChange}.
     * @param istorage reference to {@code IntegerStorage}.
     * @param oldValue the value of stored integer before the change has occurred.
     * @param newValue the new value of currently stored integer.
     */
    public IntegerStorageChange(final IntegerStorage istorage, final int oldValue, final int newValue) {
        this.istorage = istorage;
        this.oldValue = oldValue;
        this.newValue = newValue;
    }

    /**
     * Returns reference to {@code IntegerStorege}.
     * @return reference to {@code IntegerStorage}.
     */
    public IntegerStorage getIsorage() {
        return this.istorage;
    }

    /**
     * Returns the value of stored integer before the change has occurred.
     * @return the value of stored integer before the change has occurred.
     */
    public int getOldValue() {
        return this.oldValue;
    }

    /**
     * Returns the new value of currently stored integer.
     * @return the new value of currently stored integer.
     */
    public int getNewValue() {
        return this.newValue;
    }
}
