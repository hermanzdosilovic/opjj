package hr.fer.zemris.java.tecaj.hw6.shell;

public enum ShellSymbol {

    /** Prompt symbol of shell. */
    PROMPT(">"),

    /** More lines symbol of shell. */
    MORELINES("\\"),

    /** Represents multiline symbol of shell. */
    MULTILINE("|");

    /** Stores symbol. */
    private String symbol;

    /**
     * Constructor for {@code ShellSymbol}.
     * @param symbol symbol.
     */
    private ShellSymbol(String symbol) {
        this.symbol = symbol;
    }

    /**
     * Set shell symbol to new symbol.
     * @param symbol new symbol.
     */
    public void setSymbol(String symbol) {
        this.symbol = symbol;
    }

    /**
     * Get shell symbol.
     * @return shell symbol.
     */
    public String getSymbol() {
        return this.symbol;
    }
}
