package hr.fer.zemris.java.custom.scripting.exec;

import static org.junit.Assert.*;
import hr.fer.zemris.java.custom.scripting.exec.ValueWrapper;

import org.junit.Assert;
import org.junit.Test;

public class ValueWrapperTest {
    
    @Test (expected = RuntimeException.class)
    public void firstTestWithInvalidArgument() {
        ValueWrapper val = new ValueWrapper(new String("Undefined value given."));
        Double incVal = new Double(1.0123456789);
        val.increment(incVal);
    }
    
    @Test (expected = RuntimeException.class)
    public void secondTestWithInvalidArgument() {
        ValueWrapper val = new ValueWrapper(new Float(2.3));
        Double incVal = new Double(1.0123456789);
        val.increment(incVal);
    }
    
    @Test
    public void firstIncrementTestWithValidArgument() {
        ValueWrapper val = new ValueWrapper(new Integer(1));
        Integer valueData = new Integer(1);
        
        Integer incVal = new Integer(2);
        
        Integer expectedResultVal = valueData + incVal;
        
        val.increment(incVal);
        
        Integer actualResultVal = Integer.parseInt(val.toString());
        
        Assert.assertEquals("Result is not equal.", expectedResultVal, actualResultVal);
    }
    
    @Test
    public void secondIncrementTestWithValidArgument() {
        ValueWrapper val = new ValueWrapper(new Double(1.0123456789));
        Double valueData = new Double(1.0123456789);
        
        Integer incVal = new Integer(2);
        
        Double expectedResultVal = valueData + incVal;
        
        val.increment(incVal);
        
        Double actualResultVal = Double.parseDouble(val.toString());
        
        Assert.assertEquals("Result is not equal.", expectedResultVal, actualResultVal);
    }
    
    @Test
    public void thirdIncrementTestWithValidArgument() {
        ValueWrapper val = new ValueWrapper(new Integer(1));
        Integer valueData = new Integer(1);
        
        Double incVal = new Double(1.0123456789);
        
        Double expectedResultVal = valueData + incVal;
        
        val.increment(incVal);
        
        Double actualResultVal = Double.parseDouble(val.toString());
        
        Assert.assertEquals("Result is not equal.", expectedResultVal, actualResultVal);
    }
    
    @Test
    public void fourthIncrementTestWithValidArgument() {
        ValueWrapper val = new ValueWrapper(new String("1"));
        Integer valueData = new Integer(1);
        
        Double incVal = new Double(1.0123456789);
        
        Double expectedResultVal = valueData + incVal;
        
        val.increment(incVal);
        
        Double actualResultVal = Double.parseDouble(val.toString());
        
        Assert.assertEquals("Result is not equal.", expectedResultVal, actualResultVal);
    }
    
    @Test
    public void fifthIncrementTestWithValidArgument() {
        ValueWrapper val = new ValueWrapper(new String("1.0123456789"));
        Double valueData = new Double(1.0123456789);
        
        Integer incVal = new Integer(2);
        
        Double expectedResultVal = valueData + incVal;
        
        val.increment(incVal);
        
        Double actualResultVal = Double.parseDouble(val.toString());
        
        Assert.assertEquals("Result is not equal.", expectedResultVal, actualResultVal);
    }
    
    @Test
    public void sixthIncrementTestWithValidArgument() {
        ValueWrapper val = new ValueWrapper(null);
        Integer valueData = new Integer(0);
        
        Integer incVal = new Integer(2);
        
        Integer expectedResultVal = valueData + incVal;
        
        val.increment(incVal);
        
        Integer actualResultVal = Integer.parseInt(val.toString());
        
        Assert.assertEquals("Result is not equal.", expectedResultVal, actualResultVal);
    }
    
    @Test
    public void firstDecrementTestWithValidArgument() {
        ValueWrapper val = new ValueWrapper(new Integer(1));
        Integer valueData = new Integer(1);
        
        Integer incVal = new Integer(2);
        
        Integer expectedResultVal = valueData - incVal;
        
        val.decrement(incVal);
        
        Integer actualResultVal = Integer.parseInt(val.toString());
        
        Assert.assertEquals("Result is not equal.", expectedResultVal, actualResultVal);
    }
    
    @Test
    public void secondDecrementTestWithValidArgument() {
        ValueWrapper val = new ValueWrapper(new Double(1.0123456789));
        Double valueData = new Double(1.0123456789);
        
        Integer incVal = new Integer(2);
        
        Double expectedResultVal = valueData - incVal;
        
        val.decrement(incVal);
        
        Double actualResultVal = Double.parseDouble(val.toString());
        
        Assert.assertEquals("Result is not equal.", expectedResultVal, actualResultVal);
    }
    
    @Test
    public void thirdDecrementTestWithValidArgument() {
        ValueWrapper val = new ValueWrapper(new Integer(1));
        Integer valueData = new Integer(1);
        
        Double incVal = new Double(1.0123456789);
        
        Double expectedResultVal = valueData - incVal;
        
        val.decrement(incVal);
        
        Double actualResultVal = Double.parseDouble(val.toString());
        
        Assert.assertEquals("Result is not equal.", expectedResultVal, actualResultVal);
    }
    
    @Test
    public void fourthDecrementTestWithValidArgument() {
        ValueWrapper val = new ValueWrapper(new String("1"));
        Integer valueData = new Integer(1);
        
        Double incVal = new Double(1.0123456789);
        
        Double expectedResultVal = valueData - incVal;
        
        val.decrement(incVal);
        
        Double actualResultVal = Double.parseDouble(val.toString());
        
        Assert.assertEquals("Result is not equal.", expectedResultVal, actualResultVal);
    }
    
    @Test
    public void fifthDecrementTestWithValidArgument() {
        ValueWrapper val = new ValueWrapper(new String("1.0123456789"));
        Double valueData = new Double(1.0123456789);
        
        Integer incVal = new Integer(2);
        
        Double expectedResultVal = valueData - incVal;
        
        val.decrement(incVal);
        
        Double actualResultVal = Double.parseDouble(val.toString());
        
        Assert.assertEquals("Result is not equal.", expectedResultVal, actualResultVal);
    }
    
    @Test
    public void sixthDecrementTestWithValidArgument() {
        ValueWrapper val = new ValueWrapper(null);
        Integer valueData = new Integer(0);
        
        Integer incVal = new Integer(2);
        
        Integer expectedResultVal = valueData - incVal;
        
        val.decrement(incVal);
        
        Integer actualResultVal = Integer.parseInt(val.toString());
        
        Assert.assertEquals("Result is not equal.", expectedResultVal, actualResultVal);
    }
    
    @Test
    public void firstMultiplyTestWithValidArgument() {
        ValueWrapper val = new ValueWrapper(new Integer(1));
        Integer valueData = new Integer(1);
        
        Integer incVal = new Integer(2);
        
        Integer expectedResultVal = valueData * incVal;
        
        val.multiply(incVal);
        
        Integer actualResultVal = Integer.parseInt(val.toString());
        
        Assert.assertEquals("Result is not equal.", expectedResultVal, actualResultVal);
    }
    
    @Test
    public void secondMultiplyTestWithValidArgument() {
        ValueWrapper val = new ValueWrapper(new Double(1.0123456789));
        Double valueData = new Double(1.0123456789);
        
        Integer incVal = new Integer(2);
        
        Double expectedResultVal = valueData * incVal;
        
        val.multiply(incVal);
        
        Double actualResultVal = Double.parseDouble(val.toString());
        
        Assert.assertEquals("Result is not equal.", expectedResultVal, actualResultVal);
    }
    
    @Test
    public void thirdMultiplyTestWithValidArgument() {
        ValueWrapper val = new ValueWrapper(new Integer(1));
        Integer valueData = new Integer(1);
        
        Double incVal = new Double(1.0123456789);
        
        Double expectedResultVal = valueData * incVal;
        
        val.multiply(incVal);
        
        Double actualResultVal = Double.parseDouble(val.toString());
        
        Assert.assertEquals("Result is not equal.", expectedResultVal, actualResultVal);
    }
    
    @Test
    public void fourthMultiplyTestWithValidArgument() {
        ValueWrapper val = new ValueWrapper(new String("1"));
        Integer valueData = new Integer(1);
        
        Double incVal = new Double(1.0123456789);
        
        Double expectedResultVal = valueData * incVal;
        
        val.multiply(incVal);
        
        Double actualResultVal = Double.parseDouble(val.toString());
        
        Assert.assertEquals("Result is not equal.", expectedResultVal, actualResultVal);
    }
    
    @Test
    public void fifthMultiplyTestWithValidArgument() {
        ValueWrapper val = new ValueWrapper(new String("1.0123456789"));
        Double valueData = new Double(1.0123456789);
        
        Integer incVal = new Integer(2);
        
        Double expectedResultVal = valueData * incVal;
        
        val.multiply(incVal);
        
        Double actualResultVal = Double.parseDouble(val.toString());
        
        Assert.assertEquals("Result is not equal.", expectedResultVal, actualResultVal);
    }
    
    @Test
    public void sixthMultiplyTestWithValidArgument() {
        ValueWrapper val = new ValueWrapper(null);
        Integer valueData = new Integer(0);
        
        Integer incVal = new Integer(2);
        
        Integer expectedResultVal = valueData * incVal;
        
        val.multiply(incVal);
        
        Integer actualResultVal = Integer.parseInt(val.toString());
        
        Assert.assertEquals("Result is not equal.", expectedResultVal, actualResultVal);
    }
    
    @Test
    public void firstDivideTestWithValidArgument() {
        ValueWrapper val = new ValueWrapper(new Integer(1));
        Integer valueData = new Integer(1);
        
        Integer incVal = new Integer(2);
        
        Integer expectedResultVal = valueData / incVal;
        
        val.divide(incVal);
        
        Integer actualResultVal = Integer.parseInt(val.toString());
        
        Assert.assertEquals("Result is not equal.", expectedResultVal, actualResultVal);
    }
    
    @Test
    public void secondDivideTestWithValidArgument() {
        ValueWrapper val = new ValueWrapper(new Double(1.0123456789));
        Double valueData = new Double(1.0123456789);
        
        Integer incVal = new Integer(2);
        
        Double expectedResultVal = valueData / incVal;
        
        val.divide(incVal);
        
        Double actualResultVal = Double.parseDouble(val.toString());
        
        Assert.assertEquals("Result is not equal.", expectedResultVal, actualResultVal);
    }
    
    @Test
    public void thirdDivideTestWithValidArgument() {
        ValueWrapper val = new ValueWrapper(new Integer(1));
        Integer valueData = new Integer(1);
        
        Double incVal = new Double(1.0123456789);
        
        Double expectedResultVal = valueData / incVal;
        
        val.divide(incVal);
        
        Double actualResultVal = Double.parseDouble(val.toString());
        
        Assert.assertEquals("Result is not equal.", expectedResultVal, actualResultVal);
    }
    
    @Test
    public void fourthDivideTestWithValidArgument() {
        ValueWrapper val = new ValueWrapper(new String("1"));
        Integer valueData = new Integer(1);
        
        Double incVal = new Double(1.0123456789);
        
        Double expectedResultVal = valueData / incVal;
        
        val.divide(incVal);
        
        Double actualResultVal = Double.parseDouble(val.toString());
        
        Assert.assertEquals("Result is not equal.", expectedResultVal, actualResultVal);
    }
    
    @Test
    public void fifthDivideTestWithValidArgument() {
        ValueWrapper val = new ValueWrapper(new String("1.0123456789"));
        Double valueData = new Double(1.0123456789);
        
        Integer incVal = new Integer(2);
        
        Double expectedResultVal = valueData / incVal;
        
        val.divide(incVal);
        
        Double actualResultVal = Double.parseDouble(val.toString());
        
        Assert.assertEquals("Result is not equal.", expectedResultVal, actualResultVal);
    }
    
    @Test
    public void sixthDivideTestWithValidArgument() {
        ValueWrapper val = new ValueWrapper(null);
        Integer valueData = new Integer(0);
        
        Integer incVal = new Integer(2);
        
        Integer expectedResultVal = valueData / incVal;
        
        val.divide(incVal);
        
        Integer actualResultVal = Integer.parseInt(val.toString());
        
        Assert.assertEquals("Result is not equal.", expectedResultVal, actualResultVal);
    }
    
    @Test
    public void firstTestNumCompareTest() {
        ValueWrapper val = new ValueWrapper(new Integer(1));
        
        Integer expectedResult = new Integer(-1);
        Integer actualResult = val.numCompare(new Integer(2));
        
        assertEquals("Compare results are not the same.", expectedResult, actualResult);
    }
    
    @Test
    public void secondTestNumCompareTest() {
        ValueWrapper val = new ValueWrapper(new Integer(2));
        
        Integer expectedResult = new Integer(1);
        Integer actualResult = val.numCompare(new Integer(1));
        
        assertEquals("Compare results are not the same.", expectedResult, actualResult);
    }
    
    @Test
    public void thirdTestNumCompareTest() {
        ValueWrapper val = new ValueWrapper(new Integer(1));
        
        Integer expectedResult = new Integer(0);
        Integer actualResult = val.numCompare(new Integer(1));
        
        assertEquals("Compare results are not the same.", expectedResult, actualResult);
    }
    
    @Test
    public void fourthTestNumCompareTest() {
        ValueWrapper val = new ValueWrapper(new Double(1.12));
        
        Integer expectedResult = new Integer(-1);
        Integer actualResult = val.numCompare(new Integer(2));
        
        assertEquals("Compare results are not the same.", expectedResult, actualResult);
    }
    
    @Test
    public void fifthTestNumCompareTest() {
        ValueWrapper val = new ValueWrapper(new Double(2.12));
        
        Integer expectedResult = new Integer(1);
        Integer actualResult = val.numCompare(new Integer(1));
        
        assertEquals("Compare results are not the same.", expectedResult, actualResult);
    }
    
    @Test
    public void sixthTestNumCompareTest() {
        ValueWrapper val = new ValueWrapper(new Double(2.12));
        
        Integer expectedResult = new Integer(0);
        Integer actualResult = val.numCompare(new Double(2.12));
        
        assertEquals("Compare results are not the same.", expectedResult, actualResult);
    }
    
    @Test
    public void smallNumberTestNumCompareTest() {
        ValueWrapper val = new ValueWrapper(new Double(0.00012345));
        
        Integer expectedResult = new Integer(1);
        Integer actualResult = val.numCompare(new Double(0.000013131006));
        
        assertEquals("Compare results are not the same.", expectedResult, actualResult);
    }
    
    @Test
    public void stringAsArgumentGiven() {
        ValueWrapper val = new ValueWrapper(new String("10e-5"));
        val.decrement(new Integer(1));
    }
    
    @Test
    public void firstGetValueTest() {
        ValueWrapper val = new ValueWrapper(new Integer(2));
        Integer expectedValue = new Integer(2);
        Integer actualValue = (Integer) val.getValue();
        
        assertEquals("Values are not the same.", expectedValue, actualValue);
    }
    
    @Test
    public void secondGetValueTest() {
        ValueWrapper val = new ValueWrapper(new Double(2.123456789));
        Double expectedValue = new Double(2.123456789);
        Double actualValue = (Double) val.getValue();
        
        assertEquals("Values are not the same.", expectedValue, actualValue);
    }
    
    @Test
    public void setValueTest() {
        ValueWrapper val = new ValueWrapper(new Integer(2));
        val.setValue(new Integer(7));
        Integer expectedValue = new Integer(7);
        Integer actualValue = (Integer) val.getValue();
        
        assertEquals("Values are not the same.", expectedValue, actualValue);
    }
}
