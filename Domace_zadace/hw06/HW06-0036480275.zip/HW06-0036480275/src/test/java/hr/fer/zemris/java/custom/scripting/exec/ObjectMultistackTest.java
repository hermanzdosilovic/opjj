package hr.fer.zemris.java.custom.scripting.exec;

import java.util.EmptyStackException;

import hr.fer.zemris.java.custom.scripting.exec.ObjectMultistack;
import hr.fer.zemris.java.custom.scripting.exec.ValueWrapper;
import static org.junit.Assert.*;

import org.junit.Test;

public class ObjectMultistackTest {
    
    @Test
    public void firstPushPopTest() {
        ObjectMultistack multistack = new ObjectMultistack();
        ValueWrapper expectedValue = new ValueWrapper(new Integer(8));
        
        multistack.push("key", expectedValue);
        
        ValueWrapper actualValue = multistack.pop("key");
        
        assertEquals("Values are not the same.", expectedValue.getValue(), actualValue.getValue());
    }
    
    @Test
    public void secondPushPopTest() {
        ObjectMultistack multistack = new ObjectMultistack();
        ValueWrapper expectedValue = new ValueWrapper(new Integer(8));
        
        multistack.push("key", new ValueWrapper(new Integer(5)));
        multistack.push("key", expectedValue);
        
        ValueWrapper actualValue = multistack.pop("key");
        
        assertEquals("Values are not the same.", expectedValue.getValue(), actualValue.getValue());
    }
    
    @Test (expected = IllegalArgumentException.class)
    public void pushTestWithInvalidFirstArgument() {
        ObjectMultistack multistack = new ObjectMultistack();
        multistack.push(null, new ValueWrapper(new Integer(6)));
    }
    
    @Test (expected = IllegalArgumentException.class)
    public void pushTestWithInvalidSecondArgument() {
        ObjectMultistack multistack = new ObjectMultistack();
        multistack.push("key", null);
    }
    
    @Test (expected = IllegalArgumentException.class)
    public void popTestWithInvalidArgument() {
        ObjectMultistack multistack = new ObjectMultistack();
        multistack.pop(null);
    }
    
    @Test (expected = EmptyStackException.class)
    public void popTestWithEmptyStackException() {
        ObjectMultistack multistack = new ObjectMultistack();
        multistack.push("key", new ValueWrapper(new Integer(8)));
        multistack.pop("key");
        multistack.pop("key");
    }
    
    @Test (expected = IllegalArgumentException.class)
    public void peekTestWithInvalidArgument() {
        ObjectMultistack multistack = new ObjectMultistack();
        multistack.peek(null);
    }
    
    @Test (expected = EmptyStackException.class)
    public void peekTestWithEmptyStackException() {
        ObjectMultistack multistack = new ObjectMultistack();
        multistack.peek("key");
    }
    
    @Test
    public void peekTestWithValidArguments() {
        ObjectMultistack multistack = new ObjectMultistack();
        ValueWrapper expectedValue = new ValueWrapper(new Integer(6));
        multistack.push("key", expectedValue);
        ValueWrapper actualValue = multistack.peek("key");
        assertEquals("Value are not the same.", expectedValue.getValue(), actualValue.getValue());
    }
    
    @Test (expected = IllegalArgumentException.class)
    public void isEmptyTestWithInvalidArguments() {
        ObjectMultistack multistack = new ObjectMultistack();
        multistack.isEmpty(null);
    }
    
    @Test
    public void isEmptyTrueTest() {
        ObjectMultistack multistack = new ObjectMultistack();
        boolean actual = multistack.isEmpty("key");
        assertEquals("States are not the same.", true, actual);
    }
    
    @Test
    public void isEmptyFalseTest() {
        ObjectMultistack multistack = new ObjectMultistack();
        multistack.push("key", new ValueWrapper(new Integer(7)));
        boolean actual = multistack.isEmpty("key");
        assertEquals("States are not the same.", false, actual);
    }
    
    @Test
    public void pushPopisEmptyTest() {
        ObjectMultistack multistack = new ObjectMultistack();
        
        ValueWrapper expectedValue = new ValueWrapper(new Double(123.456));
        
        multistack.push("key", new ValueWrapper(new Integer(1)));
        multistack.push("key", new ValueWrapper(new Integer(2)));
        multistack.push("key", new ValueWrapper(new Integer(3)));
        multistack.push("key", new ValueWrapper(new Double(4)));
        multistack.push("key", new ValueWrapper(expectedValue));
        
        assertEquals("Not a expected value.", expectedValue.getValue(), multistack.peek("key").getValue());
        
        multistack.push("key", new ValueWrapper(new Integer(2)));
        multistack.push("key", new ValueWrapper(new Integer(3)));
        multistack.push("key", new ValueWrapper(new Double(4)));
        multistack.pop("key");
        multistack.pop("key");
        multistack.pop("key");
        
        assertEquals("Not a expected value.", expectedValue.getValue(), multistack.peek("key").getValue());
        
        assertEquals("States are not the same.", false, multistack.isEmpty("key"));
        
        multistack.pop("key");
        assertNotEquals(expectedValue.getValue(), multistack.peek("key").getValue());
        
    }
}
