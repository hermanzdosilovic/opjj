package hr.fer.zemris.java.servlets;

import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class GlasanjeGlasajServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String fileName = req.getServletContext().getRealPath("/WEB-INF/glasanje-rezultati.txt");

		Integer id;
		try {
			id = Integer.parseInt(req.getParameter("id"));
		} catch (RuntimeException ignorable) {
			req.getRequestDispatcher("/WEB-INF/pages/error.jsp").forward(req, resp);
			return;
		}

		if (id == null) {
			req.getRequestDispatcher("/WEB-INF/pages/error.jsp").forward(req, resp);
			return;
		}

		List<String> lines = new ArrayList<>();
		try {
			lines = Files.readAllLines(Paths.get(fileName), StandardCharsets.UTF_8);
		} catch (IOException ignorable) {
		}

		@SuppressWarnings("resource")
        FileOutputStream output = new FileOutputStream(fileName);

		if (lines.isEmpty()) {
			output.write(new String(id + "\t1\n").getBytes(StandardCharsets.UTF_8));
			resp.sendRedirect(req.getContextPath() + "/glasanje-rezultati");
			return;
		}

		boolean newFound = true;
		for (String line : lines) {
			String[] s = line.split("\t");
			if (Integer.parseInt(s[0]) == id) {
				output.write(new String(id + "\t" + (Integer.parseInt(s[1]) + 1) + "\n")
				        .getBytes(StandardCharsets.UTF_8));
				newFound = false;
			} else {
				output.write(new String(line + "\n").getBytes(StandardCharsets.UTF_8));
			}
		}

		if (newFound) {
			output.write(new String(id + "\t1\n").getBytes(StandardCharsets.UTF_8));
			resp.sendRedirect(req.getContextPath() + "/glasanje-rezultati");
			return;
		}
		resp.sendRedirect(req.getContextPath() + "/glasanje-rezultati");

	}
}
