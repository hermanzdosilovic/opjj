package hr.fer.zemris.java.servlets;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

public class XMLMaker extends HttpServlet {

	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		resp.setContentType("application/octet.stream");

		Integer a = null;
		Integer b = null;
		Integer n = null;

		try {
			a = Integer.parseInt(req.getParameter("a"));
			b = Integer.parseInt(req.getParameter("b"));
			n = Integer.parseInt(req.getParameter("n"));
		} catch (RuntimeException e) {
			req.getRequestDispatcher("/WEB-INF/pages/error.jsp").forward(req, resp);
			return;
		}

		if (a == null || b == null || n == null) {
			req.getRequestDispatcher("WEB-INF/pages/error.jsp").forward(req, resp);
			return;
		}
		if (Math.abs(a) > 100 || Math.abs(b) > 100 || n < 1 || n > 5) {
			req.getRequestDispatcher("WEB-INF/pages/error.jsp").forward(req, resp);
			return;
		}

		HSSFWorkbook hwb = new HSSFWorkbook();
		for (int workbook = 0; workbook < n; workbook++) {
			for (int i = 1; i <= n; i++) {
				HSSFSheet sheet = hwb.createSheet("Sheet " + i);
				int rowNumber = 0;
				for (int number = a; number <= b; number++) {
					HSSFRow row = sheet.createRow(rowNumber);
					row.createCell(0).setCellValue(number);
					row.createCell(1).setCellValue(Math.pow(number, i));
					rowNumber++;
				}
			}
		}

		resp.setHeader("Content-Disposition", "attachment;filename=powers.xls");
		hwb.write(resp.getOutputStream());
	}
}
