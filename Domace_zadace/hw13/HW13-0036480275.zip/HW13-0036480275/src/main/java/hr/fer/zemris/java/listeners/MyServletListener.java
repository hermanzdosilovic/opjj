package hr.fer.zemris.java.listeners;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

public class MyServletListener implements ServletContextListener {

	private ServletContext context;
	
	@Override
	public void contextInitialized(ServletContextEvent sce) {
		context = sce.getServletContext();
		context.setAttribute("time", new Integer((int) System.currentTimeMillis()));
	}

	@Override
	public void contextDestroyed(ServletContextEvent sce) {
	}

}
