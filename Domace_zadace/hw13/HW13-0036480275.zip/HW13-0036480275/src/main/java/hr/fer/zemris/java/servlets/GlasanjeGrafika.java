package hr.fer.zemris.java.servlets;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PiePlot3D;
import org.jfree.data.general.DefaultPieDataset;
import org.jfree.data.general.PieDataset;
import org.jfree.util.Rotation;

public class GlasanjeGrafika extends HttpServlet {

    private static final long serialVersionUID = 1L;
    
    @Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		resp.setContentType("image/png");
		PieDataset dataset = createDataset(req);
		JFreeChart chart = createChart(dataset, "");
		ChartUtilities.writeChartAsPNG(resp.getOutputStream(), chart, 700, 500);
	}

	private PieDataset createDataset(HttpServletRequest req) throws IOException {
		DefaultPieDataset resultDataset = new DefaultPieDataset();
		String fileName = req.getServletContext().getRealPath("/WEB-INF/glasanje-rezultati.txt");
		String bands = req.getServletContext().getRealPath("/WEB-INF/glasanje-definicija.txt");
		List<String> rezultati = Files.readAllLines(Paths.get(fileName), StandardCharsets.UTF_8);
		List<String> bandsList = Files.readAllLines(Paths.get(bands), StandardCharsets.UTF_8);
		Map<Integer, Integer> results = new HashMap<>();
		Map<Integer, String> bandMap = new HashMap<>();
		for (String band : bandsList) {
			String[] line = band.split("\t");
			bandMap.put(Integer.parseInt(line[0]), line[1]);
			results.put(Integer.parseInt(line[0]), 0);
		}
		for (String result : rezultati) {
			String[] line = result.split("\t");
			Integer id = Integer.parseInt(line[0]);
			Integer score = Integer.parseInt(line[1]);
			results.put(id, results.get(id) + score);
		}
		for (Integer id : results.keySet()) {
			resultDataset.setValue(bandMap.get(id), results.get(id));
		}
		return resultDataset;

	}

	private JFreeChart createChart(PieDataset dataset, String title) {
		JFreeChart chart = ChartFactory.createPieChart3D(title,          // chart title
		        dataset,                // data
		        true,                   // include legend
		        true, false);

		PiePlot3D plot = (PiePlot3D) chart.getPlot();
		plot.setStartAngle(290);
		plot.setDirection(Rotation.CLOCKWISE);
		plot.setForegroundAlpha(0.5f);
		return chart;

	}
	
}
