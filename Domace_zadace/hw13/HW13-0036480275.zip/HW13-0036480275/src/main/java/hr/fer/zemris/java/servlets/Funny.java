package hr.fer.zemris.java.servlets;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * @author Herman Zvonimir Došilović
 * @version 1.0
 */
public class Funny extends HttpServlet {

    private static final long serialVersionUID = 1L;
    
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
    	ServletContext context = req.getServletContext();
    	InputStream inputStream = context.getResourceAsStream("/WEB-INF/story.txt");
    	BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
    	List<Pair> words = new ArrayList<>();
    	String[] colors = new String[]{"BLUE", "BLACK", "RED", "GREEN", "YELLOW", "CYAN", "PURPLE"};
    	int size = colors.length;
    	Random random = new Random();
    	String line;
    	while((line = reader.readLine()) != null) {
    		String[] lineWords = line.split(" ");
    		for(String word : lineWords) {
    			int rand = random.nextInt() % size;
    			if(rand < 0) {
    				rand *= -1;
    			}
    			words.add(new Pair(word, colors[rand]));
    		}
    		words.add(new Pair("<br>", colors[0]));
    	}
        
    	req.setAttribute("words", words);
    	req.getRequestDispatcher("/WEB-INF/pages/stories/funny.jsp").forward(req, resp);
    }
    
    public static class Pair {

		private String first;
		private String second;

		public Pair(String first, String second) {
			this.first = first;
			this.second = second;
		}

		public String getFirst() {
			return first;
		}

		public void setFirst(String first) {
			this.first = first;
		}

		public String getSecond() {
			return second;
		}

		public void setSecond(String second) {
			this.second = second;
		}

	}
    
}
