package hr.fer.zemris.java.servlets;

import hr.fer.zemris.java.servlets.GlasanjeRezultatiServlet.Pair;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

public class GlasanjeXLS extends HttpServlet {

	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		resp.setContentType("application/octet.stream");
		String fileName = req.getServletContext().getRealPath("/WEB-INF/glasanje-rezultati.txt");
		String bands = req.getServletContext().getRealPath("/WEB-INF/glasanje-definicija.txt");
		List<String> rezultati = Files.readAllLines(Paths.get(fileName), StandardCharsets.UTF_8);
		List<String> bandsList = Files.readAllLines(Paths.get(bands), StandardCharsets.UTF_8);
		Map<Integer, Integer> results = new HashMap<>();
		Map<Integer, String> bandMap = new HashMap<>();
		for (String band : bandsList) {
			String[] line = band.split("\t");
			bandMap.put(Integer.parseInt(line[0]), line[1]);
			results.put(Integer.parseInt(line[0]), 0);
		}
		for (String result : rezultati) {
			String[] line = result.split("\t");
			Integer id = Integer.parseInt(line[0]);
			Integer score = Integer.parseInt(line[1]);
			results.put(id, results.get(id) + score);
		}

		List<Pair> list = new ArrayList<>();
		for (Integer id : results.keySet()) {
			list.add(new Pair(bandMap.get(id), results.get(id).toString()));
		}
		Collections.sort(list, new Comparator<Pair>() {

			@Override
			public int compare(Pair o1, Pair o2) {
				Integer a = Integer.parseInt(o1.getSecond());
				Integer b = Integer.parseInt(o2.getSecond());
				return b.compareTo(a);
			}
		});

		HSSFWorkbook hwb = new HSSFWorkbook();
		HSSFSheet sheet = hwb.createSheet("rezultati");
		for (int i = 0; i < list.size(); i++) {
			HSSFRow row = sheet.createRow(i);
			row.createCell(0).setCellValue(list.get(i).getFirst());
			row.createCell(1).setCellValue(list.get(i).getSecond());
		}

		resp.setHeader("Content-Disposition", "attachment;filename=rezultati.xls");
		hwb.write(resp.getOutputStream());
	}
}
