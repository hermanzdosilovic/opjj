package hr.fer.zemris.java.servlets;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * @author Herman Zvonimir Došilović
 * @version 1.0
 */
public class Squares extends HttpServlet {

	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		Integer a = null;
		Integer b = null;

		try {
			a = Integer.parseInt(req.getParameter("a"));
		} catch (NumberFormatException ignorable) {
			a = 0;
		}

		try {
			b = Integer.parseInt(req.getParameter("b"));
		} catch (NumberFormatException ignorable) {
			b = 20;
		}

		if (a == null) {
			a = 0;
		}

		if (b == null) {
			b = 20;
		}

		if (a > b) {
			a ^= b ^= a ^= b;
		}

		if (b > a + 20) {
			b = a + 20;
		}

		List<Pair> results = new ArrayList<>();

		for (int i = a; i < b; i++) {
			results.add(new Pair(i, i * i));
		}
		
		req.setAttribute("results", results);
		req.getRequestDispatcher("WEB-INF/pages/squares.jsp").forward(req, resp);
	}

	public static class Pair {

		private int first;
		private int second;

		public Pair(int first, int second) {
			this.first = first;
			this.second = second;
		}

		public int getFirst() {
			return first;
		}

		public void setFirst(int first) {
			this.first = first;
		}

		public int getSecond() {
			return second;
		}

		public void setSecond(int second) {
			this.second = second;
		}

	}

}
