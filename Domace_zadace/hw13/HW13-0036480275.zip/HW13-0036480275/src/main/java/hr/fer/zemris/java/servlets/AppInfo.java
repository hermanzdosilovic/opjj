package hr.fer.zemris.java.servlets;

import java.io.IOException;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class AppInfo extends HttpServlet {

    private static final long serialVersionUID = 1L;
    
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        ServletContext context = req.getServletContext();
        Integer time = (Integer) context.getAttribute("time");
        int duration = new Integer((int) System.currentTimeMillis()) - time;
        time = new Integer((int) System.currentTimeMillis());
		long second = (duration / 1000) % 60;
		long minute = (duration / (1000 * 60)) % 60;
		long hour = (duration / (1000 * 60 * 60)) % 24;
		String timeFormated = String.format("%02d:%02d:%02d", hour, minute, second);
        req.setAttribute("servletTime", timeFormated);
        req.getRequestDispatcher("WEB-INF/pages/appinfo.jsp").forward(req, resp);
    }
}
