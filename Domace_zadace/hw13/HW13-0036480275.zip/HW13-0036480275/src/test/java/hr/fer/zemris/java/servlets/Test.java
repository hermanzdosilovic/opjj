package hr.fer.zemris.java.servlets;

import org.junit.Assert;

public class Test {
	
	@org.junit.Test
	public void TestMethod() {
		Assert.assertEquals(true, true);
	}
}
