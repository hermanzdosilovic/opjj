package hr.fer.zemris.javaj.gui.layouts;

import org.junit.Test;

public class LayoutTest {
    
    @Test
    public void LayoutNoTest() {
    }
}
