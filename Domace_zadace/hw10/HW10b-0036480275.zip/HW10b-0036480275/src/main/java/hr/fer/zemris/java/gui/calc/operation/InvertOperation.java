package hr.fer.zemris.java.gui.calc.operation;

import hr.fer.zemris.java.gui.calc.component.CComponent;
import hr.fer.zemris.java.gui.calc.memory.CMemory;

/**
 * Represents invert operation.
 * @author Herman Zvonimir Došilović
 * @version 1.0
 */
public class InvertOperation implements COperation {
    
    private CMemory memory;
    
    @Override
    public void execute() {
        memory.invertOperations();
    }

    @Override
    public void linkWithMemory(CMemory memory, CComponent component) {
        this.memory = memory;
    }

    @Override
    public void calculate() {
    }

    @Override
    public String getType() {
        return null;
    }
}
