package hr.fer.zemris.java.gui.calc.operation;

import hr.fer.zemris.java.gui.calc.component.CComponent;
import hr.fer.zemris.java.gui.calc.memory.CMemory;

/**
 * Represents delete operation. "clr" and "res".
 * @author Herman Zvonimir Došilović
 * @version 1.0
 */
public class DeleteOperation implements COperation {

    private CMemory memory;
    private String operation;
    
    public DeleteOperation(String type) {
        this.operation = type;
    }
    
    @Override
    public void execute() {
        memory.setAndDisplay("0");
        if (operation.equals("res")){
            memory.reset();
        }
    }

    @Override
    public void linkWithMemory(CMemory memory, CComponent component) {
        this.memory = memory;
    }

    @Override
    public void calculate() {
        // TODO Auto-generated method stub
        
    }

    @Override
    public String getType() {
        // TODO Auto-generated method stub
        return null;
    }

}
