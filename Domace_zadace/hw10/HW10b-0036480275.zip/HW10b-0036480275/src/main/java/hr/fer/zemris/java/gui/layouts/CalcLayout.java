package hr.fer.zemris.java.gui.layouts;

import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Insets;
import java.awt.LayoutManager2;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class CalcLayout implements LayoutManager2 {

    private int space;

    private final int maxRows = 5;
    private final int maxColumns = 7;

    private final int extendedRow = 1;
    private final int extendedColumnLowerBound = 2;
    private final int extendedColumnUpperBound = 5;

    private boolean[][] locationUsed;
    private Map<RCPosition, Component> component;

    public CalcLayout() {
        this(0);
    }

    public CalcLayout(int space) {
        if(space < 0) {
            throw new CalcLayoutException("Space between components cannot be less than zero.");
        }
        this.space = space;
        locationUsed = new boolean[maxRows + 1][maxColumns + 1];
        component = new HashMap<>();
    }

    @Override
    public void addLayoutComponent(String name, Component comp) {
    }

    @Override
    public void removeLayoutComponent(Component comp) {
    }

    @Override
    public Dimension preferredLayoutSize(Container parent) {
        float maxWidth = 0;
        float maxHeight = 0;
        Insets insets = parent.getInsets();
        for(Component c : parent.getComponents()) {
            maxWidth = (float) Math.max(maxWidth, c.getPreferredSize().width);
            maxHeight = (float) Math.max(maxHeight, c.getPreferredSize().height);
        }
        int newWidth = (int) (maxWidth * maxColumns + (maxColumns - 1) * space) + insets.left + insets.right;
        int newHeight = (int) (maxHeight * maxRows + (maxRows - 1) * space) + insets.top + insets.bottom;
        return new Dimension(newWidth, newHeight);
    }

    @Override
    public Dimension minimumLayoutSize(Container parent) {
        return parent.getPreferredSize();
    }

    @Override
    public void layoutContainer(Container parent) {
        int parentWidth = parent.getWidth();
        int parentHeight = parent.getHeight();

        int componentWidth = (parentWidth - (maxColumns - 1) * space) / maxColumns;
        int componentHeight = (parentHeight - (maxRows - 1) * space) / maxRows;
        
        for(RCPosition coord : component.keySet()) {
            Component component = this.component.get(coord);

            int x = (coord.getColumn() - 1) * (componentWidth + space);
            int y = (coord.getRow() - 1) * (componentHeight + space);

            if (coord.getRow() == extendedRow && coord.getColumn() == extendedColumnLowerBound - 1) {
                int specialWidth = (extendedColumnUpperBound - extendedColumnLowerBound + 2) * componentWidth
                        + (extendedColumnUpperBound - extendedColumnLowerBound + 1) * space;
                component.setBounds(x, y, specialWidth, componentHeight);
                continue;
            }
            component.setBounds(x, y, componentWidth, componentHeight);
        }
    }

    @Override
    public void addLayoutComponent(Component comp, Object constraints) {
        if (constraints instanceof String) {
            setLayoutComponentLocation(comp, (String) constraints);
        } else if (constraints instanceof RCPosition) {
            setLayoutComponentLocation(comp, ((RCPosition) constraints).toString());
        } else {
            throw new CalcLayoutException("Unsupported constraints Object.");
        }
    }

    @Override
    public Dimension maximumLayoutSize(Container target) {
        float maxWidth = 0;
        float maxHeight = 0;
        Insets insets = target.getInsets();
        for(Component c : target.getComponents()) {
            maxWidth = (float) Math.max(maxWidth, c.getMaximumSize().width);
            maxHeight = (float) Math.max(maxHeight, c.getMaximumSize().height);
        }
        int newWidth = (int) (maxWidth * maxColumns + (maxColumns - 1) * space) + insets.left + insets.right;
        int newHeight = (int) (maxHeight * maxRows + (maxRows - 1) * space) + insets.top + insets.bottom;
        return new Dimension(newWidth, newHeight);
    }

    @Override
    public float getLayoutAlignmentX(Container target) {
        return 0;
    }

    @Override
    public float getLayoutAlignmentY(Container target) {
        return 0;
    }

    @Override
    public void invalidateLayout(Container target) {
    }

    private void setLayoutComponentLocation(Component comp, String constraints) {
        Pattern pattern = Pattern.compile("^\\s*\\d+\\s*,\\s*\\d+\\s*$");
        Matcher matcher = pattern.matcher(constraints);

        if (!matcher.matches()) {
            throw new CalcLayoutException("Invalid constrains.");
        }

        String[] location = constraints.replaceAll("\\s", "").split(",");
        int row = Integer.parseInt(location[0]);
        int column = Integer.parseInt(location[1]);

        if (row <= 0 || row > maxRows || column <= 0 || column > maxColumns) {
            throw new CalcLayoutException("Invalid location of new component: [" + row + ", " + column + "]");
        }

        if (row == extendedRow && column >= extendedColumnLowerBound && column <= extendedColumnUpperBound) {
            throw new CalcLayoutException("Invalid location of new component: [" + row + ", " + column + "]");
        }

        if (locationUsed[row][column]) {
            throw new CalcLayoutException("Location " + "[" + row + ", " + column + "]" + " is already used.");
        }

        locationUsed[row][column] = true;
        component.put(new RCPosition(row, column), comp);
    }
}
