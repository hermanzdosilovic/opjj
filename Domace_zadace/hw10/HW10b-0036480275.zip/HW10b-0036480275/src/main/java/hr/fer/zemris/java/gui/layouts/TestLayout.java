package hr.fer.zemris.java.gui.layouts;

import hr.fer.zemris.java.gui.layouts.CalcLayout;
import hr.fer.zemris.java.gui.layouts.RCPosition;

import java.awt.Container;
import java.awt.Dimension;

import javax.swing.JButton;
import javax.swing.JFrame;

public class TestLayout {
    
    public static void addComponentsToPane(Container pane) {
          pane.setLayout(new CalcLayout(5));
          
          JButton button = new JButton("1, 1");
          button.setPreferredSize(new Dimension(40, 70));
          pane.add(button, new RCPosition(1, 1));
//          pane.add(new JButton("1, 2"), new RCPosition(1, 2));
//          pane.add(new JButton("1, 3"), new RCPosition(1, 3));
//          pane.add(new JButton("1, 4"), new RCPosition(1, 4));
//          pane.add(new JButton("1, 5"), new RCPosition(1, 5));
          pane.add(new JButton("1, 6"), new RCPosition(1, 6));
          pane.add(new JButton("1, 7"), new RCPosition(1, 7));
          
          pane.add(new JButton("2, 1"), new RCPosition(2, 1));
          pane.add(new JButton("2, 2"), new RCPosition(2, 2));
          pane.add(new JButton("2, 3"), new RCPosition(2, 3));
          pane.add(new JButton("2, 4"), new RCPosition(2, 4));
          pane.add(new JButton("2, 5"), new RCPosition(2, 5));
          pane.add(new JButton("2, 6"), new RCPosition(2, 6));
          pane.add(new JButton("2, 7"), new RCPosition(2, 7));
          
          pane.add(new JButton("3, 1"), new RCPosition(3, 1));
          pane.add(new JButton("3, 2"), new RCPosition(3, 2));
          pane.add(new JButton("3, 3"), new RCPosition(3, 3));
          pane.add(new JButton("3, 4"), new RCPosition(3, 4));
          pane.add(new JButton("3, 5"), new RCPosition(3, 5));
          pane.add(new JButton("3, 6"), new RCPosition(3, 6));
          pane.add(new JButton("3, 7"), new RCPosition(3, 7));
          
          pane.add(new JButton("4, 1"), new RCPosition(4, 1));
          pane.add(new JButton("4, 2"), new RCPosition(4, 2));
          pane.add(new JButton("4, 3"), new RCPosition(4, 3));
          pane.add(new JButton("4, 4"), new RCPosition(4, 4));
          pane.add(new JButton("4, 5"), new RCPosition(4, 5));
          pane.add(new JButton("4, 6"), new RCPosition(4, 6));
          pane.add(new JButton("4, 7"), new RCPosition(4, 7));
          
          pane.add(new JButton("5, 1"), new RCPosition(5, 1));
          pane.add(new JButton("5, 2"), new RCPosition(5, 2));
          pane.add(new JButton("5, 3"), new RCPosition(5, 3));
          pane.add(new JButton("5, 4"), new RCPosition(5, 4));
          pane.add(new JButton("5, 5"), new RCPosition(5, 5));
          pane.add(new JButton("5, 6"), new RCPosition(5, 6));
          pane.add(new JButton("5, 7"), new RCPosition(5, 7));
          
    }

    /**
     * Create the GUI and show it.  For thread safety,
     * this method should be invoked from the
     * event-dispatching thread.
     */
    private static void createAndShowGUI() {
        //Create and set up the window.
        JFrame frame = new JFrame("Layout Test");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        //Set up the content pane.
        addComponentsToPane(frame.getContentPane());
        
        //Display the window.
        frame.pack();
        frame.setVisible(true);
    }

    public static void main(String[] args) {
        //Schedule a job for the event-dispatching thread:
        //creating and showing this application's GUI.
        javax.swing.SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                createAndShowGUI();
            }
        });
    }
}
