package hr.fer.zemris.java.gui.calc.operation;

import hr.fer.zemris.java.gui.calc.component.CComponent;
import hr.fer.zemris.java.gui.calc.memory.CMemory;

/**
 * Represents unary divide operation.
 * @author Herman Zvonimir Došilović
 * @version 1.0
 */
public class DivideOperation implements COperation {
    
    private CMemory memory;
    
    @Override
    public void execute() {
        memory.saveBuffer();
        float number = memory.popNumber();
        float result = 1 / number;
        memory.pushNumber(result);
        if (result - (int) result != 0) {
            memory.displayBuffer(Float.toString(result));
        } else {
            memory.displayBuffer(Integer.toString((int) result));
        }
        memory.setBuffer("");
    }

    @Override
    public void linkWithMemory(CMemory memory, CComponent component) {
        this.memory = memory;
    }

    @Override
    public void calculate() {
    }

    @Override
    public String getType() {
        return null;
    }

}
