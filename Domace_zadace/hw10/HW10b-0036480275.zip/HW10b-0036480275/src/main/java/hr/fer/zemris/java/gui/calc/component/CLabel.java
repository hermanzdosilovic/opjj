package hr.fer.zemris.java.gui.calc.component;

import hr.fer.zemris.java.gui.calc.memory.CMemory;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;

import javax.swing.BorderFactory;
import javax.swing.JLabel;

/**
 * CLabel represents calculator label component.
 * @author Herman Zvonimir Došilović
 * @version 1.0
 */
public class CLabel extends JLabel implements CComponent {

    private static final long serialVersionUID = 1L;
    
    /**
     * Constructor.
     */
    public CLabel() {
        this("");
    }
    
    /**
     * Constructor.
     * @param text that this component holds and shows.
     */
    public CLabel(String text) {
        super(text, JLabel.RIGHT);
        this.setLayout(new BorderLayout());
        this.setFont(new Font(Font.MONOSPACED, 5, 40));
        this.setBackground(Color.white);
        this.setOpaque(true);
        this.setBorder(BorderFactory.createLineBorder(Color.black));
    }
    
    @Override
    public void initComponent(CMemory memory) {
        memory.initDisplay(this);
        memory.setAndDisplay("0");
    }

    @Override
    public void executeOperation() {
    }
}
