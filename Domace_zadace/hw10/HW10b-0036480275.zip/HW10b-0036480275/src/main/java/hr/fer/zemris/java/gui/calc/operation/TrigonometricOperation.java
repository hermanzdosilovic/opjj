package hr.fer.zemris.java.gui.calc.operation;

import hr.fer.zemris.java.gui.calc.component.CComponent;
import hr.fer.zemris.java.gui.calc.memory.CMemory;

/**
 * Represents stack operation.
 * @author Herman Zvonimir Došilović
 * @version 1.0
 */
public class TrigonometricOperation implements COperation {
    
    private String normal;
    private String inverted;
    private CMemory memory;
    
    public TrigonometricOperation(String type) {
        normal = type;
        inverted = "a" + normal;
    }
    
    @Override
    public void execute() {
        memory.saveBuffer();
        float number = memory.popNumber();
        boolean invert = memory.isInverted();
        float result;
        switch(normal){
            case "sin":
                result = (float)(invert ? Math.asin(number) : Math.sin(number));
                break;
            case "cos":
                result = (float)(invert ? Math.acos(number) : Math.cos(number));
                break;
            case "tan":
                result = (float)(invert ? Math.atan(number) : Math.tan(number));
                break;
            case "ctg":
                result = 1 / (float)(invert ? Math.atan(number) : Math.tan(number));
                break;
            default:
                return;
        }
        memory.pushNumber(result);

        if (result - (int) result != 0) {
            memory.displayBuffer(Float.toString(result));
        } else {
            memory.displayBuffer(Integer.toString((int) result));
        }
        memory.setBuffer("");
    }

    @Override
    public void linkWithMemory(CMemory memory, CComponent component) {
        this.memory = memory;
        this.memory.addInvertibleOperation(component, normal, inverted);
    }

    @Override
    public void calculate() {
    }

    @Override
    public String getType() {
        return null;
    }

}
