package hr.fer.zemris.java.gui.calc;

/**
 * Calculator exception. Used for calculator initializaton errors.
 * @author Herman Zvonimir Došilović
 * @version 1.0
 */
public class CalculatorException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    /**
     * Constructor.
     */
    public CalculatorException() {
        super();
    }

    /**
     * Constructor.
     * @param message error message
     */
    public CalculatorException(String message) {
        super(message);
    }
}
