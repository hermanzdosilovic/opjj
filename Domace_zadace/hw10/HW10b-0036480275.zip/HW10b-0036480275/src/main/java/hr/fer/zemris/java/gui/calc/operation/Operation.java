package hr.fer.zemris.java.gui.calc.operation;

public class Operation {

    public static COperation identifyOperation(String operationName) {
        COperation operation = null;

        int number = -1;
        try {
            number = Integer.parseInt(operationName);
        } catch (NumberFormatException ignorable) {
        }
        if (number != -1) {
            return new NumberOperation(number);
        }

        switch (operationName) {
            case "Inv":
                operation = new InvertOperation();
                break;
            case ".":
                operation = new FloatOperation();
                break;
            case "1/x":
                operation = new DivideOperation();
                break;
            default:
                operation = new BlankOperation();
        }
        
        if (operationName.equals("push") || operationName.equals("pop")) {
            operation = new StackOperation(operationName);
        }
        
        if (operationName.equals("sin") || operationName.equals("cos") || operationName.equals("tan")
                || operationName.equals("ctg")) {
            operation = new TrigonometricOperation(operationName);
        }

        if (operationName.equals("log") || operationName.equals("ln")) {
            operation = new LogarithmOperation(operationName);
        }

        if (operationName.equals("clr") || operationName.equals("res")) {
            operation = new DeleteOperation(operationName);
        }

        if (operationName.equals("+") || operationName.equals("-") || operationName.equals("*")
                || operationName.equals("/") || operationName.equals("=") || operationName.equals("+/-")
                || operationName.equals("x^n")) {
            operation = new ArithmericOperation(operationName);
        }
        return operation;
    }
}
