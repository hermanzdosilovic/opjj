package hr.fer.zemris.java.gui.calc.operation;

import hr.fer.zemris.java.gui.calc.component.CComponent;
import hr.fer.zemris.java.gui.calc.memory.CMemory;

/**
 * Represents number operation.
 * @author Herman Zvonimir Došilović
 * @version 1.0
 */
public class NumberOperation implements COperation {
    
    private CMemory memory;
    private int number;
    
    public NumberOperation(int number) {
        this.number = number;
    }
    
    @Override
    public void execute() {
        String buffer = memory.getBuffer();
        if(buffer.equals("0")) {
            buffer = "";
        }
        buffer += number;
        memory.setAndDisplay(buffer);
    }

    @Override
    public void linkWithMemory(CMemory memory, CComponent component) {
        this.memory = memory;
    }

    @Override
    public void calculate() {
    }

    @Override
    public String getType() {
        return null;
    }

}
