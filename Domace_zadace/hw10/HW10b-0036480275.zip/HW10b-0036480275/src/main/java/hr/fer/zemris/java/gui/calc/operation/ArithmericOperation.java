package hr.fer.zemris.java.gui.calc.operation;

import hr.fer.zemris.java.gui.calc.component.CComponent;
import hr.fer.zemris.java.gui.calc.memory.CMemory;

/**
 * Represents binary arithmetic operations.
 * @author Herman Zvonimir Došilović
 * @version 1.0
 */
public class ArithmericOperation implements COperation {

    private CMemory memory;
    private String type;
    private String normal;
    private String inverted;
    
    public ArithmericOperation(String type) {
        this.type = type;
        normal = type;
        if(normal.equals("x^n")) {
            inverted = "sqrt[n]{x}";
        }
    }

    @Override
    public void execute() {
        if (type.equals("+/-")) {
            if(memory.getBuffer().equals("")) {
                String change = memory.getChange();
                memory.displayBuffer(change);
                memory.pushNumber(Float.parseFloat(change));
                return;
            }
            memory.saveBuffer();
            memory.changeSign();
            return;
        }

        if (memory.getBuffer().equals("") && memory.getOperationSize() == 1 &&
                memory.getSize() != 2) {
            if(type.equals("=")) {
                return;
            }
            memory.popOperation();
            memory.pushOperation(this);
            return;
        }
        
        memory.saveBuffer();
        
        if (memory.getSize() == 0) {
            memory.error("Invalid operation.");
        }

        if (memory.getSize() == 1) {
            memory.pushOperation(this);
            return;
        }

        COperation operation = memory.popOperation();
        operation.calculate();
        memory.pushOperation(this);
    }

    @Override
    public void linkWithMemory(CMemory memory, CComponent component) {
        this.memory = memory;
        if(type.equals("x^n")) {
            memory.addInvertibleOperation(component, normal, inverted);
        }
    }

    @Override
    public void calculate() {
        if(type.equals("=")) {
            return;
        }
        float number2 = memory.popNumber();
        float number1 = memory.popNumber();
        float result;

        switch (type) {
            case "+":
                result = number1 + number2;
                break;
            case "-":
                result = number1 - number2;
                break;
            case "*":
                result = number1 * number2;
                break;
            case "/":
                result = number1 / number2;
                break;
            case "x^n":
                result = (float) Math.pow(number1, memory.isInverted() ? 1 / number2 : number2);
                break;
            default:
                return;
        }

        memory.pushNumber(result);

        if (result - (int) result != 0) {
            memory.displayBuffer(Float.toString(result));
        } else {
            memory.displayBuffer(Integer.toString((int) result));
        }
        memory.setBuffer("");
    }

    public String getType() {
        return type;
    }
}
