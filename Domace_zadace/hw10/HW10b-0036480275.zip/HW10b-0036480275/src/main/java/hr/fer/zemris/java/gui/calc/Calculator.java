package hr.fer.zemris.java.gui.calc;

import hr.fer.zemris.java.gui.calc.component.CButton;
import hr.fer.zemris.java.gui.calc.component.CCheckBox;
import hr.fer.zemris.java.gui.calc.component.CComponent;
import hr.fer.zemris.java.gui.calc.component.CLabel;
import hr.fer.zemris.java.gui.calc.memory.CMemory;
import hr.fer.zemris.java.gui.layouts.CalcLayout;

import javax.swing.JFrame;
import javax.swing.JPanel;

/**
 * This is my first GUI calculator program.
 * @author Herman Zvonimir Došilović
 * @version 1.0
 */
public class Calculator {

    /**
     * Program entry. Does not use command line arguments.
     * @param args command line arguments.
     */
    public static void main(String[] args) {
        javax.swing.SwingUtilities.invokeLater(new Runnable() {

            @Override
            public void run() {
                createAndShowGUI();
            }
        });
    }

    /**
     * Creates and shows GUI.
     */
    private static void createAndShowGUI() {
        JFrame calculator = new JFrame("Calculator");
        calculator.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel mainPanel = initCalculator();

        calculator.add(mainPanel);
        calculator.pack();
        calculator.setVisible(true);
    }

    /**
     * Calculator initialization.
     * @return panel that calculator uses.
     */
    private static JPanel initCalculator() {
        JPanel panel = new JPanel(new CalcLayout(3));

        panel.add(new CLabel(""), "1, 1");
        panel.add(new CButton("="), "1, 6");
        panel.add(new CButton("clr"), "1, 7");

        panel.add(new CButton("1/x"), "2, 1");
        panel.add(new CButton("sin"), "2, 2");
        panel.add(new CButton("7"), "2, 3");
        panel.add(new CButton("8"), "2, 4");
        panel.add(new CButton("9"), "2, 5");
        panel.add(new CButton("/"), "2, 6");
        panel.add(new CButton("res"), "2, 7");

        panel.add(new CButton("log"), "3, 1");
        panel.add(new CButton("cos"), "3, 2");
        panel.add(new CButton("4"), "3, 3");
        panel.add(new CButton("5"), "3, 4");
        panel.add(new CButton("6"), "3, 5");
        panel.add(new CButton("*"), "3, 6");
        panel.add(new CButton("push"), "3, 7");

        panel.add(new CButton("ln"), "4, 1");
        panel.add(new CButton("tan"), "4, 2");
        panel.add(new CButton("1"), "4, 3");
        panel.add(new CButton("2"), "4, 4");
        panel.add(new CButton("3"), "4, 5");
        panel.add(new CButton("-"), "4, 6");
        panel.add(new CButton("pop"), "4, 7");

        panel.add(new CButton("x^n"), "5, 1");
        panel.add(new CButton("ctg"), "5, 2");
        panel.add(new CButton("0"), "5, 3");
        panel.add(new CButton("+/-"), "5, 4");
        panel.add(new CButton("."), "5, 5");
        panel.add(new CButton("+"), "5, 6");
        panel.add(new CCheckBox("Inv"), "5, 7");

        CMemory memory = new CMemory();
        for (int i = 0; i < panel.getComponentCount(); i++) {
            if (!(panel.getComponent(i) instanceof CComponent)) {
                throw new CalculatorException("Invalid component type.");
            }
            CComponent component = (CComponent) panel.getComponent(i);
            component.initComponent(memory);
        }
        return panel;
    }
}
