package hr.fer.zemris.java.gui.calc.memory;

import hr.fer.zemris.java.gui.calc.component.CComponent;
import hr.fer.zemris.java.gui.calc.component.CLabel;
import hr.fer.zemris.java.gui.calc.operation.COperation;

import java.util.HashMap;
import java.util.Map;
import java.util.Stack;

/**
 * Represents calculator memory.
 * @author Herman Zvonimir Došilović
 * @version 1.0
 */
public class CMemory {

    /** CLabel that calculator uses as display. */
    private CLabel display;

    /** Map of invertible components. */
    private Map<CComponent, String[]> invertible;

    /** Invertible flag. */
    private boolean invert;

    /** Display buffer. */
    private String buffer;

    /** Stack that holds numbers. */
    private Stack<Float> numberStack;

    /** Stack that holds operations. */
    private Stack<COperation> operationStack;

    /** Stack that holds memory numbers. */
    private Stack<Float> memoryStack;

    /**
     * Constructor.
     */
    public CMemory() {
        invertible = new HashMap<>();
        numberStack = new Stack<>();
        operationStack = new Stack<>();
        memoryStack = new Stack<>();
    }

    /**
     * Returns size of memory.
     * @return size of memory.
     */
    public int getMemorySize() {
        return memoryStack.size();
    }

    /**
     * Pops number from memory to buffer.
     * @return number from memory.
     */
    public float popMemory() {
        return memoryStack.pop();
    }

    /**
     * Pushes number to memory stack.
     * @param number to push in memory.
     */
    public void pushMemory(float number) {
        memoryStack.push(number);
    }

    /**
     * Returns size of numbers stored in dynamic memory.
     * @return size of numbers stored in dynamic memory.
     */
    public int getSize() {
        return numberStack.size();
    }

    /**
     * Returns number of operators stored in memory.
     * @return number of operators stored in memory.
     */
    public int getOperationSize() {
        return operationStack.size();
    }

    /**
     * Sets buffer to specified String.
     * @param buffer new buffer String
     */
    public void setBuffer(String buffer) {
        this.buffer = buffer;
    }

    /**
     * Returns buffer.
     * @return buffer.
     */
    public String getBuffer() {
        return buffer;
    }

    /**
     * Sets and displays buffer to specified text.
     * @param buffer buffer
     */
    public void setAndDisplay(String buffer) {
        setBuffer(buffer);
        displayBuffer(buffer);
    }

    /**
     * Initialize display.
     * @param display that this calculator uses.
     */
    public void initDisplay(CLabel display) {
        this.display = display;
    }

    /**
     * Sets display text to specified text.
     * @param text to display.
     */
    public void displayBuffer(String text) {
        display.setText(text);
    }

    /**
     * Returns true if invertible functions should be inverted, false otherwise.
     * @return true if invertible functions should be inverted, false otherwise.
     */
    public boolean isInverted() {
        return invert;
    }

    /**
     * Inverts invertible operations.
     */
    public void invertOperations() {
        invert = !invert;
        for (CComponent component : invertible.keySet()) {
            String[] names = invertible.get(component);
            String invert = names[0];
            names[0] = names[1];
            names[1] = invert;
            component.setText(names[0]);
        }
    }

    /**
     * Adds invertible operation to memory.
     * @param component invertible component.
     * @param normal components normal name.
     * @param inverted components invert name.
     */
    public void addInvertibleOperation(CComponent component, String normal, String inverted) {
        invertible.put(component, new String[] { normal, inverted });
    }

    /**
     * Displays errors message to display.
     * @param string errors message.
     */
    public void error(String string) {
        displayBuffer(string);
        reset();
    }

    /**
     * Changes a sign of current number in buffer.
     */
    public void changeSign() {
        setBuffer(getChange());
        displayBuffer(buffer);
    }

    /**
     * Returns number in dynamic memory.
     * @return number in dynamic memory.
     */
    public float popNumber() {
        return numberStack.pop();
    }

    /**
     * Pushes number in dynamic memory.
     * @param number to push in dynamic memory.
     */
    public void pushNumber(float number) {
        numberStack.push(number);
    }

    /**
     * Peeks for number in dynamic memory.
     * @return number on TOS in dynamic memory.
     */
    public float peekNumber() {
        return numberStack.peek();
    }

    /**
     * Saves the current buffer.
     */
    public void saveBuffer() {
        if (buffer.equals("")) {
            return;
        }
        float number = Float.parseFloat(buffer);
        pushNumber(number);
        buffer = "";
    }

    /**
     * Resets calculator. Does not resets memory.
     */
    public void reset() {
        numberStack.clear();
        operationStack.clear();
        buffer = "0";
    }

    /**
     * Pushes operation on operation stack.
     * @param operation to be executed.
     */
    public void pushOperation(COperation operation) {
        operationStack.add(operation);
    }

    /**
     * Removes first operation on stack.
     * @return first operation on stack.
     */
    public COperation popOperation() {
        return operationStack.pop();
    }

    /**
     * Returns changed string.
     * @return changed string.
     */
    public String getChange() {
        float number = popNumber();
        number = -number;
        String newBuffer;
        if (number - (int) number != 0) {
            newBuffer = Float.toString(number);
        } else {
            newBuffer = Integer.toString((int) number);
        }
        return newBuffer;
    }
}
