package hr.fer.zemris.java.gui.calc.component;

import hr.fer.zemris.java.gui.calc.memory.CMemory;

/**
 * Interface CComponent specifies basic operation of one calculator component.
 * @author Herman Zvonimir Došilović
 * @version 1.0
 */
public interface CComponent {

    /**
     * Calculator component can execute some kind of operation.
     */
    void executeOperation();

    /**
     * On initialization of calculator component reference to calculators memory
     * is given. Calculator component can be linked with memory if needed.
     * @param memory calculator memory
     */
    void initComponent(CMemory memory);

    /**
     * Sets text on calculator component. This text is displayed on this component.
     * @param text that calculator component will get.
     */
    void setText(String text);
}
