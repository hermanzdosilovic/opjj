package hr.fer.zemris.java.gui.calc.operation;

import hr.fer.zemris.java.gui.calc.component.CComponent;
import hr.fer.zemris.java.gui.calc.memory.CMemory;

/**
 * Represents stack operation.
 * @author Herman Zvonimir Došilović
 * @version 1.0
 */
public class StackOperation implements COperation {
    
    private CMemory memory;
    private String type;
    
    public StackOperation(String type) {
        this.type = type;
    }
    
    @Override
    public void execute() {
        if(type.equals("pop")) {
            if(memory.getMemorySize() == 0) {
                memory.error("Stack empty!");
                return;
            }
            float number = memory.popMemory();
            String newBuffer;
            if (number - (int) number != 0) {
                newBuffer = Float.toString(number);
            } else {
                newBuffer = Integer.toString((int) number);
            }
            memory.setAndDisplay(newBuffer);
            return;
        }
        try {
            float number = Float.parseFloat(memory.getBuffer());
            memory.pushMemory(number);
        } catch (NumberFormatException e) {
            memory.pushMemory(memory.peekNumber());
        }
    }

    @Override
    public void linkWithMemory(CMemory memory, CComponent component) {
        this.memory = memory;
    }

    @Override
    public void calculate() {
    }

    @Override
    public String getType() {
        return null;
    }

}
