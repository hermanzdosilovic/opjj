package hr.fer.zemris.java.gui.calc.component;

import hr.fer.zemris.java.gui.calc.memory.CMemory;
import hr.fer.zemris.java.gui.calc.operation.COperation;
import hr.fer.zemris.java.gui.calc.operation.Operation;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JCheckBox;

/**
 * Class CCheckBox represents calculator check box component.
 * @author Herman Zvonimir Došilović
 * @version 1.0
 */
public class CCheckBox extends JCheckBox implements CComponent {

    private static final long serialVersionUID = 1L;

    private COperation operation;

    /**
     * Constructor.
     */
    public CCheckBox() {
        this("");
    }

    /**
     * Constructor.
     * @param text that this check box holds and shows.
     */
    public CCheckBox(String text) {
        super(text);
        this.setBackground(Color.YELLOW);
        this.setPreferredSize(new Dimension(110, 60));
        this.setBorder(BorderFactory.createLineBorder(Color.black));
        this.setBorderPainted(true);
    }

    @Override
    public void initComponent(CMemory memory) {
        operation = Operation.identifyOperation(this.getText());
        operation.linkWithMemory(memory, this);
        this.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                CComponent component = (CComponent) e.getSource();
                component.executeOperation();
            }
        });
    }

    @Override
    public void executeOperation() {
        operation.execute();
    }
}
