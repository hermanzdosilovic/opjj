package hr.fer.zemris.java.gui.calc.operation;

import hr.fer.zemris.java.gui.calc.component.CComponent;
import hr.fer.zemris.java.gui.calc.memory.CMemory;

/**
 * Represents functions that every calculator operations must know.
 * @author Herman Zvonimir Došilović
 * @version 1.0
 */
public interface COperation {

    /**
     * Executes operation. Operation must knew how to execute her self.
     */
    void execute();

    /**
     * Link with memory operation.
     * @param memory operation.
     * @param component component.
     */
    void linkWithMemory(CMemory memory, CComponent component);
    
    /**
     * Calculates result if needed.
     */
    void calculate();
    
    /**
     * Returns type of operation.
     * @return type of operation.
     */
    String getType();
}
