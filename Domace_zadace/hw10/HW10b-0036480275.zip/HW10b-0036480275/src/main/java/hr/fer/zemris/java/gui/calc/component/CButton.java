package hr.fer.zemris.java.gui.calc.component;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import hr.fer.zemris.java.gui.calc.memory.CMemory;
import hr.fer.zemris.java.gui.calc.operation.COperation;
import hr.fer.zemris.java.gui.calc.operation.Operation;

import javax.swing.BorderFactory;
import javax.swing.JButton;

/**
 * Class CButton represents calculator button component.
 * @author Herman Zvonimir Došilović
 * @version 1.0
 */
public class CButton extends JButton implements CComponent {

    private static final long serialVersionUID = 1L;
    
    /** Operation that this CButton uses. */
    private COperation operation;
    
    /**
     * Constructor.
     */
    public CButton() {
        this("");
    }
    
    /**
     * Constructor.
     * @param text that button holds and shows.
     */
    public CButton(String text) {
        super(text);
        this.setBackground(Color.ORANGE);
        this.setPreferredSize(new Dimension(110, 60));
        this.setBorder(BorderFactory.createLineBorder(Color.black));
    }

    @Override
    public void initComponent(CMemory memory) {
        operation = Operation.identifyOperation(this.getText());
        operation.linkWithMemory(memory, this);
        this.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                CComponent component = (CComponent) e.getSource();
                component.executeOperation();
            }
        });
    }

    @Override
    public void executeOperation() {
        operation.execute();
    }
}
