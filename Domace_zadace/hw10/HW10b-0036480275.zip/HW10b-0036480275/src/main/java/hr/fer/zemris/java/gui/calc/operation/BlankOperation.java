package hr.fer.zemris.java.gui.calc.operation;

import hr.fer.zemris.java.gui.calc.component.CComponent;
import hr.fer.zemris.java.gui.calc.memory.CMemory;

/**
 * Represents blank operation.
 * @author Herman Zvonimir Došilović
 * @version 1.0
 */
public class BlankOperation implements COperation {

    @Override
    public void execute() {
    }

    @Override
    public void linkWithMemory(CMemory memory, CComponent component) {
    }

    @Override
    public void calculate() {
    }

    @Override
    public String getType() {
        return null;
    }
}

