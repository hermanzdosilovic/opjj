package hr.fer.zemris.java.hw06.part2;

import hr.fer.zemris.java.tecaj_06.rays.Point3D;
import hr.fer.zemris.java.tecaj_06.rays.RayTracerViewer;

public class RayCasterParallel {
	public static void main(String[] args) {
		RayTracerViewer.show(new MojProducer(), new Point3D(10, 0, 0), new Point3D(0, 0, 0),
		        new Point3D(0, 0, 10), 20, 20);
	}
}
