package hr.fer.zemris.java.tecaj_06.rays;

public class Sphere extends GraphicalObject {

	private Point3D center;
	private double radius;
	private double kdr;
	private double kdg;
	private double kdb;
	private double krr;
	private double krg;
	private double krb;
	private double krn;

	public Sphere(Point3D center, double radius, double kdr, double kdg, double kdb, double krr, double krg,
	        double krb, double krn) {
		this.center = center;
		this.radius = radius;
		this.kdr = kdr;
		this.kdg = kdg;
		this.kdb = kdb;
		this.krr = krr;
		this.krg = krg;
		this.krb = krb;
		this.krn = krn;
	}

	@Override
	public RayIntersection findClosestRayIntersection(Ray ray) {

		double A = 1;
		double B = ray.direction.scalarMultiply(2.0).scalarProduct(ray.start.sub(center));
		double C = ray.start.sub(center).scalarProduct(ray.start.sub(center)) - radius * radius;

		if (B * B - 4 * A * C < 10e-19) {
			return null;
		}

		double t1 = (-B - Math.sqrt(B * B - 4 * A * C)) / (2 * A);
		double t2 = (-B + Math.sqrt(B * B - 4 * A * C)) / (2 * A);
		
		Point3D closest;
		if (t1 > 10e-19) {
			closest = new Point3D(ray.direction.x * t1 + ray.start.x, ray.direction.y * t1 + ray.start.y, ray.direction.z
			        * t1 + ray.start.z);
		}
		else if (t2 > 10e-19) {
			closest = new Point3D(ray.direction.x * t2 + ray.start.x, ray.direction.y * t2 + ray.start.y,
			        ray.direction.z * t2 + ray.start.z);
		}
		else {
			return null;
		}

		final Point3D result = closest.copy();

		return new RayIntersection(result, Math.abs(result.sub(ray.start).norm()), true) {

			@Override
			public Point3D getNormal() {
				return result.sub(center).normalize().negate();
			}

			@Override
			public double getKdr() {
				return kdr;
			}

			@Override
			public double getKdg() {
				return kdg;
			}

			@Override
			public double getKdb() {
				return kdb;
			}

			@Override
			public double getKrr() {
				return krr;
			}

			@Override
			public double getKrg() {
				return krg;
			}

			@Override
			public double getKrb() {
				return krb;
			}

			@Override
			public double getKrn() {
				return krn;
			}

		};
	}

}
