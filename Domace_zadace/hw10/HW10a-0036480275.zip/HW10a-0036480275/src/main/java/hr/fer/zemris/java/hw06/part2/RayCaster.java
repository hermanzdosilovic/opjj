package hr.fer.zemris.java.hw06.part2;

import hr.fer.zemris.java.tecaj_06.rays.GraphicalObject;
import hr.fer.zemris.java.tecaj_06.rays.IRayTracerProducer;
import hr.fer.zemris.java.tecaj_06.rays.IRayTracerResultObserver;
import hr.fer.zemris.java.tecaj_06.rays.LightSource;
import hr.fer.zemris.java.tecaj_06.rays.Point3D;
import hr.fer.zemris.java.tecaj_06.rays.Ray;
import hr.fer.zemris.java.tecaj_06.rays.RayIntersection;
import hr.fer.zemris.java.tecaj_06.rays.RayTracerViewer;
import hr.fer.zemris.java.tecaj_06.rays.Scene;

public class RayCaster {
	public static void main(String[] args) {
		RayTracerViewer.show(getIRayTracerProducer(), new Point3D(10, 0, 0), new Point3D(0, 0, 0),
		        new Point3D(0, 0, 10), 20, 20);
	}

	private static IRayTracerProducer getIRayTracerProducer() {
		return new IRayTracerProducer() {
			@Override
			public void produce(Point3D eye, Point3D view, Point3D viewUp, double horizontal, double vertical,
			        int width, int height, long requestNo, IRayTracerResultObserver observer) {
				System.out.println("Započinjem izračune...");
				short[] red = new short[width * height];
				short[] green = new short[width * height];
				short[] blue = new short[width * height];

				Point3D zAxis = view.sub(eye).normalize();
				Point3D yAxis = viewUp.normalize().sub(zAxis.scalarMultiply(zAxis.scalarProduct(viewUp.normalize())))
				        .normalize();
				Point3D xAxis = zAxis.vectorProduct(yAxis).normalize();

				Point3D screenCorner = view.sub(xAxis.scalarMultiply(horizontal / 2)).add(
						yAxis.scalarMultiply(vertical / 2));
				Scene scene = RayTracerViewer.createPredefinedScene();
				short[] rgb = new short[3];
				int offset = 0;
				for (int y = 0; y < height; y++) {
					for (int x = 0; x < width; x++) {
						double xComp = horizontal * x / (double) (width - 1);
						double yComp = vertical * y / (double) (height - 1);
						Point3D screenPoint = screenCorner.add(xAxis.scalarMultiply(xComp)).sub(
								yAxis.scalarMultiply(yComp));
						Ray ray = Ray.fromPoints(eye, screenPoint);
						tracer(scene, ray, rgb);
						red[offset] = (rgb[0] > 255 ? 255 : rgb[0]);
						green[offset] = (rgb[1] > 255 ? 255 : rgb[1]);
						blue[offset] = (rgb[2] > 255 ? 255 : rgb[2]);
						offset++;
					}
				}
				System.out.println("Izračuni gotovi...");
				observer.acceptResult(red, green, blue, requestNo);
				System.out.println("Dojava gotova...");
			}

			private void tracer(Scene scene, Ray ray, short[] rgb) {
				double dist = 1 << 30;
				RayIntersection closestIntersection = null;

				for (GraphicalObject object : scene.getObjects()) {
					RayIntersection rayIntersection = object.findClosestRayIntersection(ray);

					if (rayIntersection != null) {
						if (rayIntersection.getDistance() < dist) {
							closestIntersection = rayIntersection;
							dist = closestIntersection.getDistance();
						}
					}
				}

				if (closestIntersection == null) {
					rgb[0] = rgb[1] = rgb[2] = 0;
					return;
				}

				double colorR = 15;
				double colorG = 15;
				double colorB = 15;
				
				for (LightSource ls : scene.getLights()) {
					Ray rayLs = Ray.fromPoints(ls.getPoint(), closestIntersection.getPoint());

					RayIntersection closestToLight = null;
					dist = 1 << 30;
					for (GraphicalObject object : scene.getObjects()) {
						RayIntersection rayIntersection = object.findClosestRayIntersection(rayLs);

						if (rayIntersection != null) {
							if ((rayIntersection.getDistance()) < dist) {
								closestToLight = rayIntersection;
								dist = closestToLight.getDistance();
							}
						}
					}

					if (closestToLight != null) {
						if (Math.abs(closestToLight.getPoint().sub(ls.getPoint()).norm() - closestIntersection.getPoint()
						        .sub(ls.getPoint()).norm()) > 10e-10) {
							continue;
						}
					}
					
					double angle = rayLs.direction.scalarProduct(closestIntersection.getNormal());
					
					colorR += ls.getR() * closestIntersection.getKdr() * Math.max(angle, 0);
					colorG += ls.getG() * closestIntersection.getKdg() * Math.max(angle, 0);
					colorB += ls.getB() * closestIntersection.getKdb() * Math.max(angle, 0);
					
					Point3D r = closestIntersection.getNormal().
							scalarMultiply(2 * angle).sub(rayLs.direction);
					
					double angle2 = r.scalarProduct(ray.direction);
					double reflexivity = Math.pow(angle2,  closestIntersection.getKrn());
					if(angle2 < 10e-10) {
						reflexivity = 0;
					}
					colorR += ls.getR() * closestIntersection.getKrr() * reflexivity;
					colorG += ls.getG() * closestIntersection.getKrg() * reflexivity;
					colorB += ls.getB() * closestIntersection.getKrb() * reflexivity; 
					
				}
				
				rgb[0] = (short) (colorR);
				rgb[1] = (short) (colorG);
				rgb[2] = (short) (colorB);
			}
		};
	}
}
