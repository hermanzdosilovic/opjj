package hr.fer.zemris.java.hw06.part2;

import hr.fer.zemris.java.tecaj_06.rays.IRayTracerProducer;
import hr.fer.zemris.java.tecaj_06.rays.IRayTracerResultObserver;
import hr.fer.zemris.java.tecaj_06.rays.Point3D;
import hr.fer.zemris.java.tecaj_06.rays.RayTracerViewer;
import hr.fer.zemris.java.tecaj_06.rays.Scene;

import java.util.concurrent.ForkJoinPool;

public class MojProducer implements IRayTracerProducer {

	@Override
	public void produce(Point3D eye, Point3D view, Point3D viewUp, double horizontal, double vertical, int width,
	        int height, long requestNo, IRayTracerResultObserver observer) {
		short[] red = new short[(int) (width * height)];
		short[] green = new short[(int) (width * height)];
		short[] blue = new short[(int) (width * height)];
		Scene scene = RayTracerViewer.createPredefinedScene();
		ForkJoinPool pool = new ForkJoinPool();
		pool.invoke(new PosaoIzracuna(eye, view, viewUp, horizontal, vertical, width, height, requestNo, observer, red, green, blue, 0, 0, scene));
		pool.shutdown();
		observer.acceptResult(red, green, blue, requestNo);
	}

}
