package hr.fer.zemris.java.tecaj_10.notepad;

import java.util.ArrayList;
import java.util.List;

public abstract class AbstractLocalizationProvider implements ILocalizationProvider {

	private List<ILocalizationListener> listeners;

	public AbstractLocalizationProvider() {
		this.listeners = new ArrayList<>();
	}

	public void addLocalizationListener(ILocalizationListener l) {
		if (!listeners.contains(l)) {
			listeners.add(l);
		}
	}
	
	public void removeLocalizationListener(ILocalizationListener l) {
		listeners.remove(l);
	}
	
	public void fire() {
		for(ILocalizationListener l : listeners) {
			l.localizationChanged();
		}
	}

	@Override
    public abstract String getString(String key);
}
