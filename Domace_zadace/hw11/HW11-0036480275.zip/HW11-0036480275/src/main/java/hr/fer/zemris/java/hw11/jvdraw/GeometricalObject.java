package hr.fer.zemris.java.hw11.jvdraw;

import java.awt.Color;
import java.awt.geom.Point2D;

public abstract class GeometricalObject {

	protected Point2D start;
	protected Point2D end;
	protected Color foregroundColor;
	protected Color backgroundColor;

	public GeometricalObject(Point2D start, Point2D end, Color foregroundColor, Color backgroundColor) {
		this.start = start;
		this.end = end;
		this.foregroundColor = foregroundColor;
		this.backgroundColor = backgroundColor;
	}

	public Point2D getStart() {
		return start;
	}

	public void setStart(Point2D start) {
		this.start = start;
	}

	public Point2D getEnd() {
		return end;
	}

	public void setEnd(Point2D end) {
		this.end = end;
	}

	public Color getForegroundColor() {
		return foregroundColor;
	}

	public void setForegroundColor(Color foregroundColor) {
		this.foregroundColor = foregroundColor;
	}

	public Color getBackgroundColor() {
		return backgroundColor;
	}

	public void setBackgroundColor(Color backgroundColor) {
		this.backgroundColor = backgroundColor;
	}

}
