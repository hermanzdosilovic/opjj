package hr.fer.zemris.java.hw11.jvdraw;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Insets;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

import javax.swing.JColorChooser;
import javax.swing.JComponent;

public class JColorArea extends JComponent implements IColorProvider {

	private static final long serialVersionUID = 1L;

	private Color selectedColor;
	private List<ColorChangeListener> listeners;
	private JColorType type;

	public JColorArea(Color selectedColor, JColorType type) {
		super();
		this.selectedColor = selectedColor;
		this.type = type;
		listeners = new CopyOnWriteArrayList<>();
		addMouseListener(new MouseAdapter() {

			@Override
			public void mouseClicked(MouseEvent e) {
				JColorArea source = (JColorArea) e.getSource();
				Color selectedColor = JColorChooser.showDialog(source, "Choose Color", source.getCurrentColor());
				if (selectedColor == null) {
					return;
				}
				source.notifyListeners(selectedColor);
				source.setColor(selectedColor);
				source.repaint();
			}

		});
	}

	@Override
	public Dimension getPreferredSize() {
		return new Dimension(15, 15);
	}

	@Override
	protected void paintComponent(Graphics g) {
		Dimension dim = this.getSize();
		Insets ins = this.getInsets();
		g.setColor(selectedColor);
		g.fillRect(ins.left, ins.top, (int) (dim.getWidth() - ins.right - ins.left),
		        (int) (dim.getHeight() - ins.top - ins.bottom));
	}

	@Override
	public Color getCurrentColor() {
		return selectedColor;
	}

	public void addColorChangeListener(ColorChangeListener l) {
		if (!listeners.contains(l)) {
			listeners.add(l);
			l.newColorSelected(this, selectedColor, selectedColor);
		}
	}

	public void removeColorChangeListener(ColorChangeListener l) {
		listeners.remove(l);
	}

	private void notifyListeners(Color newColor) {
		for (ColorChangeListener l : listeners) {
			l.newColorSelected(this, selectedColor, newColor);
		}
	}

	@Override
	public JColorType getType() {
		return type;
	}

	public void setColor(Color color) {
		this.selectedColor = color;
	}

}
