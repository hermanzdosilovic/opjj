package hr.fer.zemris.java.tecaj_10.notepad;

public interface ILocalizationProvider {

	void addLocalizationListener(ILocalizationListener l);
	void removeLocalizationListener(ILocalizationListener l);
	String getString(String key);
}
