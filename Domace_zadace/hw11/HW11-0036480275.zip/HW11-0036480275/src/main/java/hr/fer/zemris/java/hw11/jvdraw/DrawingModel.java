package hr.fer.zemris.java.hw11.jvdraw;

public interface DrawingModel {

	int getSize();

	GeometricalObject getObject(int index);

	void add(GeometricalObject object);

	void addDrawingModelListener(DrawingModelListener l);

	void removeDrawingModelListener(DrawingModelListener l);

	void removeObject(int index);

	void changeObject(int index, GeometricalObject object);

	void clear();

}
