package hr.fer.zemris.java.hw11.jvdraw;

import java.awt.Color;
import java.awt.geom.Point2D;

public class LineObject extends GeometricalObject {
	
	public LineObject(Point2D start, Point2D end, Color foregroundColor) {
		super(start, end, foregroundColor, null);
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("LINE ").append(start.getX() + " " + start.getY() + " ");
		sb.append(end.getX() + " " + end.getY() + " ");
		sb.append(foregroundColor.getRed() + " ");
		sb.append(foregroundColor.getGreen() + " ");
		sb.append(foregroundColor.getBlue() + " ");
		return sb.toString();
	}

}
