package hr.fer.zemris.java.hw11.jvdraw;

import java.awt.Color;
import java.awt.geom.Point2D;

public class FilledCircle extends GeometricalObject {

	private double radius;

	public FilledCircle(Point2D start, Point2D end, Color foregroundColor, Color backgroundColor) {
		super(start, end, foregroundColor, backgroundColor);
		radius = start.distance(end);
	}

	public double getRadius() {
		return radius;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("FCIRCLE ").append(start.getX() + " " + start.getY() + " ");
		sb.append(end.getX() + " " + end.getY()).append(" " + radius + " ");
		sb.append(foregroundColor.getRed() + " ");
		sb.append(foregroundColor.getGreen() + " ");
		sb.append(foregroundColor.getBlue() + " ");
		sb.append(backgroundColor.getRed() + " ");
		sb.append(backgroundColor.getGreen() + " ");
		sb.append(backgroundColor.getBlue());
		return sb.toString();
	}

}
