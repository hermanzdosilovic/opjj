package hr.fer.zemris.java.hw11.jvdraw;

import javax.swing.AbstractListModel;

public class DrawingObjectListModel extends AbstractListModel<GeometricalObject> implements DrawingModelListener {
	
    private static final long serialVersionUID = 1L;
    private DrawingModel model;
    
    public DrawingObjectListModel(DrawingModel model) {
    	this.model = model;
    }
    
	@Override
    public int getSize() {
	    return model.getSize();
    }

	@Override
    public GeometricalObject getElementAt(int index) {
	    return model.getObject(index);
    }

	@Override
    public void objectsAdded(DrawingModel source, int index0, int index1) {
		this.fireIntervalAdded(source, index0, index1);
    }

	@Override
    public void objectsRemoved(DrawingModel source, int index0, int index1) {
		this.fireIntervalRemoved(source, index0, index1);
    }

	@Override
    public void objectsChanged(DrawingModel source, int index0, int index1) {
	    this.fireContentsChanged(source, index0, index1);
    }

}
