package hr.fer.zemris.java.hw11.jvdraw;

public enum JColorType {

	BACKGROUND,
	FOREGROUND;

}
