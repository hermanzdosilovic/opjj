/**
 * @author Herman Zvonimir Došilović
 * @version 1.0
 */
package hr.fer.zemris.java.hw11.jvdraw;
