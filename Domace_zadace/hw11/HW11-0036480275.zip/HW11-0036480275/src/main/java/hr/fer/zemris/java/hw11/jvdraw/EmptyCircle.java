package hr.fer.zemris.java.hw11.jvdraw;

import java.awt.Color;
import java.awt.geom.Point2D;

public class EmptyCircle extends GeometricalObject {

	private double radius;

	public EmptyCircle(Point2D start, Point2D end, Color foregroundColor) {
		super(start, end, foregroundColor, null);
		radius = start.distance(end);
	}

	public double getRadius() {
		return radius;
	}
	
	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("CIRCLE ").append(start.getX() + " " + start.getY() + " ");
		sb.append(end.getX() + " " + end.getY()).append(" " + radius + " ");
		sb.append(foregroundColor.getRed() + " ");
		sb.append(foregroundColor.getGreen() + " ");
		sb.append(foregroundColor.getBlue());
	    return sb.toString();
	}
}
