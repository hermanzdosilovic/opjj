package hr.fer.zemris.java.hw11.jvdraw;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;
import java.awt.geom.Point2D;

import javax.swing.JToggleButton;

public class DrawingMotion extends MouseAdapter implements MouseMotionListener {

	private Point2D startPoint;
	private Point2D endPoint;
	private int index = -1;
	
	private JColorArea foregroundArea;
	private JColorArea backgroundArea;
	private DrawingModel model;
	private JToggleButton lineButton;
	private JToggleButton emptyCircleButton;
	private JToggleButton filledCircleButton;
	
	public DrawingMotion(JColorArea foregroundArea, JColorArea backgroundArea, DrawingModel model, 
			JToggleButton lineButton, JToggleButton emptyCircleButton, JToggleButton filledCircleButton) {
		this.foregroundArea = foregroundArea;
		this.backgroundArea = backgroundArea;
		this.model = model;
		this.lineButton = lineButton;
		this.emptyCircleButton = emptyCircleButton;
		this.filledCircleButton = filledCircleButton;
		
    }

	@Override
	public void mouseClicked(MouseEvent e) {
		if (startPoint == null) {
			startPoint = e.getPoint();
		} else {
			endPoint = e.getPoint();
			if (endPoint.distance(startPoint) < 10) {
				return;
			}
			model.removeObject(index);
			addObjectToModel();
			index = -1;
			startPoint = null;
		}
	}

	@Override
	public void mouseMoved(MouseEvent e) {
		if (startPoint == null) {
			return;
		}
		endPoint = e.getPoint();
		if (index != -1) {
			model.removeObject(index);
		}
		addObjectToModel();
		index = model.getSize() - 1;
	}

	private void addObjectToModel() {
		if (lineButton.isSelected()) {
			model.add(new LineObject(startPoint, endPoint, foregroundArea.getCurrentColor()));
		} else if (emptyCircleButton.isSelected()) {
			model.add(new EmptyCircle(startPoint, endPoint, foregroundArea.getCurrentColor()));
		} else if (filledCircleButton.isSelected()) {
			model.add(new FilledCircle(startPoint, endPoint, foregroundArea.getCurrentColor(), backgroundArea
			        .getCurrentColor()));
		} else {
			return;
		}
	}
	
}
