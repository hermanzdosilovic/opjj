package hr.fer.zemris.java.hw11.jvdraw;

import java.awt.Color;

import javax.swing.JLabel;

public class JColorLabel extends JLabel implements ColorChangeListener {

    private static final long serialVersionUID = 1L;
    
    private String background;
    private String foreground;
    
	@Override
	public void newColorSelected(IColorProvider source, Color oldColor, Color newColor) {
		if(source.getType() == JColorType.BACKGROUND) {
			background = String.format("background color: (%d, %d, %d)",  newColor.getRed(), newColor.getGreen(), newColor.getBlue());
		}
		else {
			foreground = String.format("Foreground color: (%d, %d, %d)",  newColor.getRed(), newColor.getGreen(), newColor.getBlue());
		}
		setText(foreground + ", " + background);
	}

}
