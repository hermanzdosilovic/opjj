package hr.fer.zemris.java.hw11.jvdraw;

import java.awt.BasicStroke;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

import javax.swing.JComponent;

public class JDrawingCanvas extends JComponent implements DrawingModelListener {

	private static final long serialVersionUID = 1L;
	private List<GeometricalObject> objects = new CopyOnWriteArrayList<>();

	@Override
	public void objectsAdded(DrawingModel source, int index0, int index1) {
		for (int i = index0; i <= index1; i++) {
			objects.add(source.getObject(i));
		}
		this.repaint();
	}

	@Override
	public void objectsRemoved(DrawingModel source, int index0, int index1) {
		for (int i = index0; i <= index1; i++) {
			objects.remove(i); // danger
		}
		this.repaint();
	}

	@Override
	public void objectsChanged(DrawingModel source, int index0, int index1) {
		for(int i = index0; i <= index1; i++) {
			objects.set(i, source.getObject(i));
		}
		this.repaint();
	}

	@Override
	protected void paintComponent(Graphics g) {
		Graphics2D g2 = (Graphics2D) g;

		for (GeometricalObject object : objects) {
			if (object instanceof EmptyCircle) {
				EmptyCircle emptyCircle = (EmptyCircle) (object);
				g2.setStroke(new BasicStroke(1));
				g2.setColor(object.getForegroundColor());

				g2.drawOval((int) (emptyCircle.getStart().getX() - emptyCircle.getRadius()), (int) (emptyCircle
				        .getStart().getY() - emptyCircle.getRadius()), (int) (2 * emptyCircle.getRadius()),
				        (int) (2 * emptyCircle.getRadius()));
			} else if (object instanceof FilledCircle) {
				FilledCircle filledCircle = (FilledCircle) (object);

				g2.setColor(filledCircle.getForegroundColor());
				g2.setStroke(new BasicStroke(2));
				g2.drawOval((int) (filledCircle.getStart().getX() - filledCircle.getRadius()), (int) (filledCircle
				        .getStart().getY() - filledCircle.getRadius()), (int) (2 * filledCircle.getRadius()),
				        (int) (2 * filledCircle.getRadius()));

				g2.setColor(filledCircle.getBackgroundColor());
				g2.fillOval((int) (filledCircle.getStart().getX() - filledCircle.getRadius()), (int) (filledCircle
				        .getStart().getY() - filledCircle.getRadius()), (int) (2 * filledCircle.getRadius()),
				        (int) (2 * filledCircle.getRadius()));
			} else {
				g2.setStroke(new BasicStroke(1));
				g2.setColor(object.getForegroundColor());
				g2.drawLine((int) object.getStart().getX(), (int) object.getStart().getY(), (int) object.getEnd()
				        .getX(), (int) object.getEnd().getY());
			}
		}
	}

}
