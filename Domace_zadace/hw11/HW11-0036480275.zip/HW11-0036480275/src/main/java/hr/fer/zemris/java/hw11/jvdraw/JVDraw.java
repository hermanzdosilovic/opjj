package hr.fer.zemris.java.hw11.jvdraw;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.ButtonGroup;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JToggleButton;
import javax.swing.JToolBar;
import javax.swing.SwingUtilities;

public class JVDraw extends JFrame {

	private static final long serialVersionUID = 1L;

	private final Color initForegroundColor = Color.RED;
	private final Color initBackgroundColor = Color.BLUE;
	private File saved;

	public static void main(String[] args) {
		SwingUtilities.invokeLater(new Runnable() {

			@Override
			public void run() {
				new JVDraw("JVDraw").setVisible(true);
			}
		});
	}

	public JVDraw(String title) {
		setTitle(title);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		createGUI();
	}

	private void createGUI() {
		getContentPane().setLayout(new BorderLayout());

		final JColorArea foregroundArea = new JColorArea(initForegroundColor, JColorType.FOREGROUND);
		final JColorArea backgroundArea = new JColorArea(initBackgroundColor, JColorType.BACKGROUND);
		JColorLabel colorLabel = new JColorLabel();
		foregroundArea.addColorChangeListener(colorLabel);
		backgroundArea.addColorChangeListener(colorLabel);

		final JToggleButton lineButton = new JToggleButton("Line");
		lineButton.setSelected(true);
		final JToggleButton emptyCircleButton = new JToggleButton("Circle");
		final JToggleButton filledCircleButton = new JToggleButton("Filled circle");
		ButtonGroup group = new ButtonGroup();
		group.add(lineButton);
		group.add(emptyCircleButton);
		group.add(filledCircleButton);

		JDrawingCanvas drawingArea = new JDrawingCanvas();
		drawingArea.setPreferredSize(new Dimension(700, 500));
		drawingArea.setBackground(Color.WHITE);

		DrawingMotion drawingMotion = new DrawingMotion(foregroundArea, backgroundArea, model, lineButton,
		        emptyCircleButton, filledCircleButton);
		drawingArea.addMouseListener(drawingMotion);
		drawingArea.addMouseMotionListener(drawingMotion);

		model.addDrawingModelListener(drawingArea);

		JToolBar toolbar = new JToolBar();
		toolbar.setLayout(new GridLayout(1, 5, 1, 0));
		toolbar.add(foregroundArea);
		toolbar.add(backgroundArea);
		toolbar.add(lineButton);
		toolbar.add(emptyCircleButton);
		toolbar.add(filledCircleButton);

		JMenuBar menuBar = createMenuBar();

		JPanel toolBarAndMenuBar = new JPanel(new GridLayout(2, 1));
		toolBarAndMenuBar.add(menuBar);
		toolBarAndMenuBar.add(toolbar);

		DrawingObjectListModel listModel = new DrawingObjectListModel(model);
		JList<GeometricalObject> list = new JList<>(listModel);
		model.addDrawingModelListener(listModel);
		list.addMouseListener(new ListListener(model));

		JScrollPane scrollPane = new JScrollPane(list);
		scrollPane.setPreferredSize(new Dimension(200, 400));

		getContentPane().add(toolBarAndMenuBar, BorderLayout.NORTH);
		getContentPane().add(drawingArea, BorderLayout.CENTER);
		getContentPane().add(scrollPane, BorderLayout.EAST);
		getContentPane().add(colorLabel, BorderLayout.SOUTH);

		pack();
		setVisible(true);
	}

	private DrawingModel model = new DrawingModel() {

		List<GeometricalObject> objects = new CopyOnWriteArrayList<>();
		List<DrawingModelListener> listeners = new CopyOnWriteArrayList<>();

		@Override
		public void removeDrawingModelListener(DrawingModelListener l) {
			listeners.remove(l);
		}

		@Override
		public int getSize() {
			return objects.size();
		}

		@Override
		public GeometricalObject getObject(int index) {
			return objects.get(index);
		}

		@Override
		public void addDrawingModelListener(DrawingModelListener l) {
			listeners.add(l);
		}

		@Override
		public void add(GeometricalObject object) {
			objects.add(object);
			fireIntervalAdded();
		}

		private void fireIntervalAdded() {
			for (DrawingModelListener l : listeners) {
				l.objectsAdded(this, objects.size() - 1, objects.size() - 1);
			}
		}

		@Override
		public void removeObject(int index) {
			objects.remove(index);
			fireIntervalRemoved(index);
		}

		private void fireIntervalRemoved(int index) {
			for (DrawingModelListener l : listeners) {
				l.objectsRemoved(this, index, index);
			}
		}

		@Override
		public void changeObject(int index, GeometricalObject object) {
			objects.set(index, object);
			fireIntervalChanged(index);
		}

		private void fireIntervalChanged(int index) {
			for (DrawingModelListener l : listeners) {
				l.objectsChanged(this, index, objects.size() - 1);
			}
		}

		@Override
        public void clear() {
			while(objects.size() != 0) {
				removeObject(0);
			}
        }
	};

	private JMenuBar createMenuBar() {
		JMenuBar menuBar = new JMenuBar();

		JMenu fileMenu = new JMenu("File");
		openDocumentAction.putValue(Action.NAME, "Open");
		saveDocumentAction.putValue(Action.NAME, "Save");
		saveAsDocumentAction.putValue(Action.NAME, "Save As");
		fileMenu.add(new JMenuItem(openDocumentAction));
		fileMenu.add(new JMenuItem(saveDocumentAction));
		fileMenu.add(new JMenuItem(saveAsDocumentAction));

		menuBar.add(fileMenu);

		return menuBar;
	}

	private Action saveDocumentAction = new AbstractAction() {

		private static final long serialVersionUID = 1L;

		@Override
		public void actionPerformed(ActionEvent e) {
			StringBuilder sb = new StringBuilder();
			for (int i = 0, size = model.getSize(); i < size; i++) {
				sb.append(model.getObject(i).toString() + "\n");
			}
			File file;
			if (saved == null) {
				JFileChooser fc = new JFileChooser();
				fc.setDialogTitle("Save file");
				if (fc.showSaveDialog(JVDraw.this) != JFileChooser.APPROVE_OPTION) {
					return;
				}
				file = fc.getSelectedFile();
				saved = file;
			}
			else {
				file = saved;
			}
			try {
				if (!file.exists()) {
					file.createNewFile();
				}
				file.createNewFile();
				OutputStreamWriter fout = new OutputStreamWriter(new FileOutputStream(file), "UTF-8");
				fout.write(sb.toString());
				fout.close();
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		}
	};

	private Action saveAsDocumentAction = new AbstractAction() {

		private static final long serialVersionUID = 1L;

		@Override
		public void actionPerformed(ActionEvent e) {
			StringBuilder sb = new StringBuilder();
			for (int i = 0, size = model.getSize(); i < size; i++) {
				sb.append(model.getObject(i).toString() + "\n");
			}
			JFileChooser fc = new JFileChooser();
			fc.setDialogTitle("SaveAs file");
			if (fc.showSaveDialog(JVDraw.this) != JFileChooser.APPROVE_OPTION) {
				return;
			}
			File file = fc.getSelectedFile();
			try {
				if (!file.exists()) {
					file.createNewFile();
				}
				file.createNewFile();
				OutputStreamWriter fout = new OutputStreamWriter(new FileOutputStream(file), "UTF-8");
				fout.write(sb.toString());
				fout.close();
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		}
	};

	private Action openDocumentAction = new AbstractAction() {

		private static final long serialVersionUID = 1L;

		@Override
		public void actionPerformed(ActionEvent e) {
			JFileChooser fc = new JFileChooser();
			fc.setDialogTitle("Open file");
			if (fc.showOpenDialog(JVDraw.this) != JFileChooser.APPROVE_OPTION) {
				return;
			}
			File fileName = fc.getSelectedFile();
			Path filePath = fileName.toPath();
			if (!Files.isReadable(filePath)) {
				JOptionPane.showMessageDialog(JVDraw.this, "Datoteka " + fileName.getAbsolutePath() + " ne postoji!",
				        "Pogreška", JOptionPane.ERROR_MESSAGE);
				return;
			}
			byte[] okteti;
			try {
				okteti = Files.readAllBytes(filePath);
			} catch (Exception ex) {
				JOptionPane.showMessageDialog(JVDraw.this,
				        "Pogreška prilikom čitanja datoteke " + fileName.getAbsolutePath() + ".", "Pogreška",
				        JOptionPane.ERROR_MESSAGE);
				return;
			}
			saved = fileName;
			String tekst = new String(okteti, StandardCharsets.UTF_8);
			String[] lines = tekst.split("\\n");
			model.clear();
			List<GeometricalObject> objects = ParseObjects.parse(lines);
			for(GeometricalObject o : objects) {
				model.add(o);
			}
		}

	};
}
