package hr.fer.zemris.java.tecaj_10.notepad;

public interface ILocalizationListener {
	
	void localizationChanged();
}
