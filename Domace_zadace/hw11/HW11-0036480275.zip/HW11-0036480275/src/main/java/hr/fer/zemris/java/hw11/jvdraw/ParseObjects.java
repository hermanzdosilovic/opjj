package hr.fer.zemris.java.hw11.jvdraw;

import java.awt.Color;
import java.awt.Point;
import java.awt.geom.Point2D;
import java.util.ArrayList;
import java.util.List;

public class ParseObjects {

	public static List<GeometricalObject> parse(String[] lines) {
		List<GeometricalObject> list = new ArrayList<>();
		for(String line : lines) {
			line = line.trim();
			String[] args = line.split(" ");
			if(args.length == 0) {
				continue;
			}
			if(!Character.isAlphabetic(args[0].charAt(0))) {
				args[0] = args[0].substring(1);
			}
			if(args[0].equals("LINE")) {
				list.add(createLine(args));
			}
			else if(args[0].equals("CIRCLE")) {
				list.add(createCircle(args));
			}
			else if(args[0].equals("FCIRCLE")){
				list.add(createCircleFilled(args));
			}
		}
	    return list;
    }

	private static GeometricalObject createCircle(String[] args) {
		Point2D startPoint = new Point();
		startPoint.setLocation(Double.parseDouble(args[1]), Double.parseDouble(args[2]));
		
		Point2D endPoint = new Point();
		endPoint.setLocation(Double.parseDouble(args[3]), Double.parseDouble(args[4]));
		
		Color selectedColor = new Color(Integer.parseInt(args[6]), Integer.parseInt(args[7]), Integer.parseInt(args[8]));
		
	    return new EmptyCircle(startPoint, endPoint, selectedColor);
    }
	
	private static GeometricalObject createCircleFilled(String[] args) {
		Point2D startPoint = new Point();
		startPoint.setLocation(Double.parseDouble(args[1]), Double.parseDouble(args[2]));
		
		Point2D endPoint = new Point();
		endPoint.setLocation(Double.parseDouble(args[3]), Double.parseDouble(args[4]));
		
		Color selectedColor = new Color(Integer.parseInt(args[6]), Integer.parseInt(args[7]), Integer.parseInt(args[8]));
		Color backgroundColor = new Color(Integer.parseInt(args[9]), Integer.parseInt(args[10]), Integer.parseInt(args[11]));
	    return new FilledCircle(startPoint, endPoint, selectedColor, backgroundColor);
    }
	
	private static GeometricalObject createLine(String[] args) {
		Point2D startPoint = new Point();
		startPoint.setLocation(Double.parseDouble(args[1]), Double.parseDouble(args[2]));
		
		Point2D endPoint = new Point();
		endPoint.setLocation(Double.parseDouble(args[3]), Double.parseDouble(args[4]));
		
		Color selectedColor = new Color(Integer.parseInt(args[5]), Integer.parseInt(args[6]), Integer.parseInt(args[7]));
		
	    return new LineObject(startPoint, endPoint, selectedColor);
    }

}
