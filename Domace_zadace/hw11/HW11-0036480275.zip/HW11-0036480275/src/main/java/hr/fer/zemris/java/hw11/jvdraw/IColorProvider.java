package hr.fer.zemris.java.hw11.jvdraw;

import java.awt.Color;

public interface IColorProvider {

	public Color getCurrentColor();

	JColorType getType();

}
