package hr.fer.zemris.java.tecaj_10.notepad;

import java.util.Locale;
import java.util.ResourceBundle;

public class LocalizationProvider extends AbstractLocalizationProvider {
	
	private String language = "en";
	private ResourceBundle bundle;
	
	private static LocalizationProvider localizationProvider = new LocalizationProvider();
	
	private LocalizationProvider() {
		bundle = ResourceBundle.getBundle("hr.fer.zemris.java.tecaj_10.notepad.prijevodi", Locale.forLanguageTag(this.language));
	}
	
	public static LocalizationProvider getInstance() {
		return localizationProvider;
	}
	
	public void setLanguage(String language) {
		this.language = language;
		bundle = ResourceBundle.getBundle("hr.fer.zemris.java.tecaj_10.notepad.prijevodi", Locale.forLanguageTag(this.language));
		this.fire();
	}
	
	public String getString(String key) {
		return bundle.getString(key);
	}
}
