package hr.fer.zemris.java.hw11.jvdraw;

import java.awt.Color;
import java.awt.GridLayout;
import java.awt.Point;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.Point2D;

import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class ListListener extends MouseAdapter {

	private DrawingModel model;
	private int index;

	public ListListener(DrawingModel model) {
		this.model = model;
	}

	@SuppressWarnings("unchecked")
	@Override
	public void mouseClicked(MouseEvent e) {
		if (e.getClickCount() != 2) {
			return;
		}
		JList<GeometricalObject> list = (JList<GeometricalObject>) e.getSource();
		index = list.getSelectedIndex();
		if (index == -1) {
			return;
		}
		GeometricalObject object = model.getObject(index);
		if (object instanceof LineObject) {
			changeObject((LineObject) object);
		} else if (object instanceof EmptyCircle) {
			changeObject((EmptyCircle) object);
		} else {
			changeObject((FilledCircle) object);
		}

	}

	private void changeObject(LineObject object) {
		JPanel panel = new JPanel(new GridLayout(5, 2, 2, 2));

		String initStartX = String.format("%f", object.getStart().getX()).replace(",", ".");
		String initStartY = String.format("%f", object.getStart().getY()).replace(",", ".");
		String initEndX = String.format("%f", object.getEnd().getX()).replace(",", ".");
		String initEndY = String.format("%f", object.getEnd().getY()).replace(",", ".");
		Color color = object.getForegroundColor();

		JTextField startXField = new JTextField(initStartX);
		JTextField startYField = new JTextField(initStartY);
		JTextField endXField = new JTextField(initEndX);
		JTextField endYField = new JTextField(initEndY);
		JColorArea colorArea = new JColorArea(color, JColorType.FOREGROUND);

		panel.add(new JLabel("Start x"));
		panel.add(startXField);

		panel.add(new JLabel("Start y"));
		panel.add(startYField);

		panel.add(new JLabel("End x"));
		panel.add(endXField);

		panel.add(new JLabel("End y"));
		panel.add(endYField);

		panel.add(new JLabel("Color"));
		panel.add(colorArea);

		int result = JOptionPane.showConfirmDialog(null, panel, "Edit Line", JOptionPane.OK_CANCEL_OPTION);
		if(result == JOptionPane.CANCEL_OPTION) {
			return;
		}
		
		double startX;
		double startY;
		double endX;
		double endY;
		try {
			startX = Double.parseDouble(startXField.getText());
			startY = Double.parseDouble(startYField.getText());
			endX = Double.parseDouble(endXField.getText());
			endY = Double.parseDouble(endYField.getText());
		} catch (RuntimeException e) {
			JOptionPane.showMessageDialog(null, "Invalid input", "Error", JOptionPane.WARNING_MESSAGE);
			return;
		}
		
		Point2D startPoint = new Point();
		startPoint.setLocation(startX, startY);
		
		Point2D endPoint = new Point();
		endPoint.setLocation(endX, endY);
		
		GeometricalObject line = new LineObject(startPoint, endPoint, colorArea.getCurrentColor());
		model.changeObject(index, line);
	}

	private void changeObject(EmptyCircle object) {
		JPanel panel = new JPanel(new GridLayout(4, 2, 2, 2));

		String initStartX = String.format("%f", object.getStart().getX()).replace(",", ".");
		String initStartY = String.format("%f", object.getStart().getY()).replace(",", ".");
		String initRadius = String.format("%f", object.getRadius()).replace(",", ".");
		Color color = object.getForegroundColor();

		JTextField startXField = new JTextField(initStartX);
		JTextField startYField = new JTextField(initStartY);
		JTextField radiusField = new JTextField(initRadius);
		JColorArea colorArea = new JColorArea(color, JColorType.FOREGROUND);

		panel.add(new JLabel("Start x"));
		panel.add(startXField);

		panel.add(new JLabel("Start y"));
		panel.add(startYField);

		panel.add(new JLabel("Radius"));
		panel.add(radiusField);

		panel.add(new JLabel("Color"));
		panel.add(colorArea);

		int result = JOptionPane.showConfirmDialog(null, panel, "Edit Circle", JOptionPane.OK_CANCEL_OPTION);
		if(result == JOptionPane.CANCEL_OPTION) {
			return;
		}
		
		double startX;
		double startY;
		double radius;
		try {
			startX = Double.parseDouble(startXField.getText());
			startY = Double.parseDouble(startYField.getText());
			radius = Double.parseDouble(radiusField.getText());
		} catch (RuntimeException e) {
			JOptionPane.showMessageDialog(null, "Invalid input", "Error", JOptionPane.WARNING_MESSAGE);
			return;
		}
		
		Point2D startPoint = new Point();
		startPoint.setLocation(startX, startY);
		
		Point2D endPoint = new Point();
		endPoint.setLocation(startX + (int) radius, startY);
		
		GeometricalObject emptyCircle = new EmptyCircle(startPoint, endPoint, colorArea.getCurrentColor());
		model.changeObject(index, emptyCircle);
	}

	private void changeObject(FilledCircle object) {
		JPanel panel = new JPanel(new GridLayout(6, 2, 2, 2));

		String initStartX = String.format("%f", object.getStart().getX()).replace(",", ".");
		String initStartY = String.format("%f", object.getStart().getY()).replace(",", ".");
		String initRadius = String.format("%f", object.getRadius()).replace(",", ".");
		Color colorforeGround = object.getForegroundColor();
		Color colorbackGround = object.getBackgroundColor();
		
		JTextField startXField = new JTextField(initStartX);
		JTextField startYField = new JTextField(initStartY);
		JTextField radiusField = new JTextField(initRadius);
		JColorArea colorAreaforeGround = new JColorArea(colorforeGround, JColorType.FOREGROUND);
		JColorArea colorAreabackGround = new JColorArea(colorbackGround, JColorType.BACKGROUND);
		
		panel.add(new JLabel("Start x"));
		panel.add(startXField);

		panel.add(new JLabel("Start y"));
		panel.add(startYField);

		panel.add(new JLabel("Radius"));
		panel.add(radiusField);

		panel.add(new JLabel("Foreground color"));
		panel.add(colorAreaforeGround);
		
		panel.add(new JLabel("Background color"));
		panel.add(colorAreabackGround);

		int result = JOptionPane.showConfirmDialog(null, panel, "Edit Circle", JOptionPane.OK_CANCEL_OPTION);
		if(result == JOptionPane.CANCEL_OPTION) {
			return;
		}
		
		double startX;
		double startY;
		double radius;
		try {
			startX = Double.parseDouble(startXField.getText());
			startY = Double.parseDouble(startYField.getText());
			radius = Double.parseDouble(radiusField.getText());
		} catch (RuntimeException e) {
			JOptionPane.showMessageDialog(null, "Invalid input", "Error", JOptionPane.WARNING_MESSAGE);
			return;
		}
		
		Point2D startPoint = new Point();
		startPoint.setLocation(startX, startY);
		
		Point2D endPoint = new Point();
		endPoint.setLocation(startX + (int) radius, startY);
		
		GeometricalObject filledCircle = new FilledCircle(startPoint, endPoint, colorAreaforeGround.getCurrentColor(), colorAreabackGround.getCurrentColor());
		model.changeObject(index, filledCircle);
	}
}
