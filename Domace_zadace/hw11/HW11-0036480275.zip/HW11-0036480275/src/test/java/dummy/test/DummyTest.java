package dummy.test;

import junit.framework.Assert;

import org.junit.Test;

@SuppressWarnings("deprecation")
public class DummyTest {
	
	@Test
	public void test() {
		Assert.assertEquals(true, true);
	}
}
