package hr.fer.zemris.java.tecaj_14.dao.jpa;

import hr.fer.zemris.java.tecaj_14.dao.DAOException;

import javax.persistence.EntityManager;

public class JPAEMProvider {

	private static ThreadLocal<LocalData> locals = new ThreadLocal<>();

	public static EntityManager getEntityManager() {
		LocalData ldata = locals.get();
		if(ldata==null) {
			ldata = new LocalData();
			ldata.em = JPAEMFProvider.getEmf().createEntityManager();
			ldata.em.getTransaction().begin();
			locals.set(ldata);
		}
		return ldata.em;
	}

	public static void close() throws DAOException {
		LocalData ldata = locals.get();
		if(ldata==null) {
			return;
		}
		DAOException dex = null;
		try {
			if (ldata.em.getTransaction().isActive()
					&& !ldata.em.getTransaction().getRollbackOnly()) {
				ldata.em.getTransaction().commit();
			} else if (ldata.em.getTransaction().isActive()) {
				ldata.em.getTransaction().rollback();
			}
		} catch(Exception ex) {
			dex = new DAOException("Unable to commit transaction.", ex);
		}
		try {
			if (ldata.em.getTransaction().isActive()
					&& !ldata.em.getTransaction().getRollbackOnly()) {
				ldata.em.getTransaction().commit();
			} else if (ldata.em.getTransaction().isActive()) {
				ldata.em.getTransaction().rollback();
			}
		} catch (Exception ex) {
			dex = new DAOException("Unable to commit transaction.", ex);
		}
		try {
			ldata.em.close();
		} catch(Exception ex) {
			if(dex!=null) {
				dex = new DAOException("Unable to close entity manager.", ex);
			}
		}
		locals.remove();
		if(dex!=null) throw dex;
	}
	
	private static class LocalData {
		EntityManager em;
	}
	
}