package hr.fer.zemris.java.tecaj_14.web.servlets;

import hr.fer.zemris.java.tecaj_14.dao.DAOProvider;
import hr.fer.zemris.java.tecaj_14.model.BlogEntry;
import hr.fer.zemris.java.tecaj_14.model.BlogUser;
import hr.fer.zemris.java.tecaj_14.model.Errors;

import java.io.IOException;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/servleti/author/*")
public class Author extends HttpServlet {

	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String path = req.getPathInfo();
		if (path == null) {
			req.setAttribute("message", "Neispravna adresa.");
			req.getRequestDispatcher("/WEB-INF/pages/Greska.jsp").forward(req, resp);
			return;
		}
		String[] pages = path.substring(1).split("/");

		String author = pages[0];
		BlogUser blogUser = DAOProvider.getDAO().getBlogUser(author);
		if (blogUser == null) {
			req.setAttribute("message", "Ne postoji odabrani autor.");
			req.getRequestDispatcher("/WEB-INF/pages/Greska.jsp").forward(req, resp);
			return;
		}

		if (pages.length == 1) {
			List<BlogEntry> blogEntries = DAOProvider.getDAO().getAllEntriesFromAuthor(blogUser);
			req.setAttribute("entries", blogEntries);
			req.setAttribute("user", blogUser);
			req.getRequestDispatcher("/WEB-INF/pages/Listaj.jsp").forward(req, resp);
			return;
		}

		if (pages.length == 2) {
			if (!pages[1].equals("NEW")) { // odabran je view nekog naslova
				Long eid;
				try {
					eid = Long.parseLong(pages[1]); // dohvati id tog naslova
				} catch (NumberFormatException e) {
					req.setAttribute("message", "Neispravna adresa.");
					req.getRequestDispatcher("/WEB-INF/pages/Greska.jsp").forward(req, resp);
					return;
				}
				BlogEntry blogEntry = DAOProvider.getDAO().getBlogEntry(eid);
				if (blogEntry == null || !blogEntry.getCreator().getNick().equals(author)) {
					req.setAttribute("message", "Ne postoji odabrani naslov.");
					req.getRequestDispatcher("/WEB-INF/pages/Greska.jsp").forward(req, resp);
					return;
				}
				req.setAttribute("blogEntry", blogEntry);
				req.getRequestDispatcher("/WEB-INF/pages/Naslov.jsp").forward(req, resp);
				return;
			}

			String loggedInUser = (String) req.getSession().getAttribute("current.user.nick");
			if (loggedInUser == null || !loggedInUser.equals(author)) {
				req.setAttribute("message", "Nedozvoljen pristup.");
				req.getRequestDispatcher("/WEB-INF/pages/Greska.jsp").forward(req, resp);
				return;
			}
			req.setAttribute("entry", new BlogEntry());
			req.setAttribute("errors", new Errors());
			req.setAttribute("novi", new Boolean(true));
			req.getRequestDispatcher("/WEB-INF/pages/New.jsp").forward(req, resp);
			return;
		}

		if (pages.length == 3) {
			if (!pages[1].equals("EDIT")) {
				req.setAttribute("message", "Neispravna adresa.");
				req.getRequestDispatcher("/WEB-INF/pages/Greska.jsp").forward(req, resp);
				return;
			}
			Long eid;
			try {
				eid = Long.parseLong(pages[2]); // dohvati id tog naslova
			} catch (NumberFormatException e) {
				req.setAttribute("message", "Neispravna adresa.");
				req.getRequestDispatcher("/WEB-INF/pages/Greska.jsp").forward(req, resp);
				return;
			}
			BlogEntry blogEntry = DAOProvider.getDAO().getBlogEntry(eid);
			if (blogEntry == null || !blogEntry.getCreator().getNick().equals(author)) {
				req.setAttribute("message", "Ne postoji odabrani naslov.");
				req.getRequestDispatcher("/WEB-INF/pages/Greska.jsp").forward(req, resp);
				return;
			}
			String loggedInUser = (String) req.getSession().getAttribute("current.user.nick");
			if (loggedInUser == null || !loggedInUser.equals(author)) {
				req.setAttribute("message", "Nedozvoljen pristup.");
				req.getRequestDispatcher("/WEB-INF/pages/Greska.jsp").forward(req, resp);
				return;
			}
			req.setAttribute("id", eid);
			req.setAttribute("entry", blogEntry);
			req.setAttribute("errors", new Errors());
			req.setAttribute("novi", new Boolean(true));
			req.getRequestDispatcher("/WEB-INF/pages/New.jsp").forward(req, resp);
			return;
		}

		req.setAttribute("message", "Neispravna adresa.");
		req.getRequestDispatcher("/WEB-INF/pages/Greska.jsp").forward(req, resp);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String metoda = req.getParameter("metoda");
		if ("Odustani".equals(metoda)) {
			resp.sendRedirect(req.getServletContext().getContextPath() + "/");
			return;
		}

		req.setCharacterEncoding("UTF-8");

		BlogEntry blogEntry = getDataFromHttpRequest(req);
		Errors errors = new Errors();
		validateHttpRequest(blogEntry, errors);
		blogEntry.setCreatedAt(new Date());
		blogEntry.setLastModifiedAt(blogEntry.getCreatedAt());

		req.setAttribute("errors", errors);
		req.setAttribute("entry", blogEntry);

		if (errors.hasErrors()) {
			req.getRequestDispatcher("/WEB-INF/pages/New.jsp").forward(req, resp);
			return;
		}

		BlogUser blogUser = DAOProvider.getDAO().getBlogUser(
				(String) req.getSession().getAttribute("current.user.nick"));
		blogEntry.setCreator(blogUser);
		List<BlogEntry> entries = blogUser.getBlog();
		entries.add(blogEntry);
		blogUser.setBlog(entries);

		if (blogEntry.getId() == null) {
			DAOProvider.getDAO().updateBlogUser(blogUser);
			DAOProvider.getDAO().updateBlogEntry(blogEntry);
		}

		resp.sendRedirect(req.getServletContext().getContextPath() + "/servleti/author/"
				+ (String) req.getSession().getAttribute("current.user.nick"));
	}

	private void validateHttpRequest(BlogEntry blogEntry, Errors errors) {
		if (blogEntry.getTitle().isEmpty()) {
			errors.putErrorMessage("title", "Molimo Vas odaberite naslov.");
		}
		if (blogEntry.getText().isEmpty()) {
			errors.putErrorMessage("tekst", "Molimo Vas ne ostavljajte tekst praznim.");
		}
	}

	private BlogEntry getDataFromHttpRequest(HttpServletRequest req) {
		BlogEntry blogEntry = new BlogEntry();
		if (!req.getParameter("id").equals("")) {
			blogEntry.setId(Long.parseLong(req.getParameter("id")));
		}
		blogEntry.setTitle((String) req.getParameter("title"));
		blogEntry.setText((String) req.getParameter("tekst"));
		return blogEntry;
	}
}
