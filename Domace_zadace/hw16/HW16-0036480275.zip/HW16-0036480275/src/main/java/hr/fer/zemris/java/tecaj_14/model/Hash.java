package hr.fer.zemris.java.tecaj_14.model;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class Hash {
	
	private String passwordHash;

	public void generate(String password) {
		MessageDigest sha;
        try {
            sha = MessageDigest.getInstance("SHA-1");
        }
        catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("No such algorithm.");
        }
        
        sha.update(password.getBytes(StandardCharsets.UTF_8));
        
        byte[] shaData = sha.digest();
        StringBuilder sb = new StringBuilder("");
        for (int i = 0; i < shaData.length; i++) {
            sb.append(Integer.toString((shaData[i] & 0xFF) + 0x100, 16).substring(1));
        }
        
        passwordHash = sb.toString();
	}
	
	public boolean compareHash(String password) {
		Hash hash = new Hash();
		hash.generate(password);
		if(passwordHash.equals(hash.getPasswordHash())) {
			return true;
		}
		return false;
	}
	
	public String getPasswordHash() {
		return passwordHash;
	}

	public void setPasswordHash(String passwordHash) {
		this.passwordHash = passwordHash;
	}
	
}
