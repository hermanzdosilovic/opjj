package hr.fer.zemris.java.tecaj_14.dao.jpa;

import hr.fer.zemris.java.tecaj_14.dao.DAO;
import hr.fer.zemris.java.tecaj_14.dao.DAOException;
import hr.fer.zemris.java.tecaj_14.model.BlogEntry;
import hr.fer.zemris.java.tecaj_14.model.BlogUser;

import java.util.List;

import javax.persistence.EntityManager;

public class JPADAOImpl implements DAO {

	@Override
	public BlogEntry getBlogEntry(Long id) throws DAOException {
		BlogEntry blogEntry = JPAEMProvider.getEntityManager().find(BlogEntry.class, id);
		return blogEntry;
	}

	@Override
	public BlogUser getBlogUser(String nick) throws DAOException {
		EntityManager em = JPAEMProvider.getEntityManager();

		@SuppressWarnings("unchecked")
		List<BlogUser> users = (List<BlogUser>) em.createQuery("select b from BlogUser as b where b.nick=:nick")
				.setParameter("nick", nick).getResultList();

		if (users.size() == 0) {
			return null;
		}

		return users.get(0);
	}

	@Override
	public void updateBlogUser(BlogUser user) throws DAOException {
		EntityManager em = JPAEMProvider.getEntityManager();

		if (user.getId() != null) {
			em.merge(user); // update
		} else {
			em.persist(user); // initial commit
		}

		if (em.getTransaction().isActive() && !em.getTransaction().getRollbackOnly()) {
			em.getTransaction().commit();
		} else if (em.getTransaction().isActive()) {
			em.getTransaction().rollback();
		}
	}

	@Override
	public List<BlogUser> getAllUsers() throws DAOException {
		EntityManager em = JPAEMProvider.getEntityManager();

		@SuppressWarnings("unchecked")
		List<BlogUser> allUsers = (List<BlogUser>) em.createQuery("SELECT b from BlogUser AS b").getResultList();

		return allUsers;
	}

	@Override
	public List<BlogEntry> getAllEntriesFromAuthor(BlogUser author) {
		EntityManager em = JPAEMProvider.getEntityManager();

		@SuppressWarnings("unchecked")
		List<BlogEntry> blogEntries = (List<BlogEntry>) em
				.createQuery("SELECT b from BlogEntry AS b where b.creator=:creator").setParameter("creator", author)
				.getResultList();

		return blogEntries;
	}

	@Override
	public void updateBlogEntry(BlogEntry blogEntry) {
		EntityManager em = JPAEMProvider.getEntityManager();

		if (blogEntry.getId() != null) {
			em.merge(blogEntry); // update
		} else {
			em.persist(blogEntry); // initial commit
		}

		if (em.getTransaction().isActive() && !em.getTransaction().getRollbackOnly()) {
			em.getTransaction().commit();
		} else if (em.getTransaction().isActive()) {
			em.getTransaction().rollback();
		}
	}

}