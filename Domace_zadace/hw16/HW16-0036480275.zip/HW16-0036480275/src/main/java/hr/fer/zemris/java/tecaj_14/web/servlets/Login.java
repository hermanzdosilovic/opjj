package hr.fer.zemris.java.tecaj_14.web.servlets;

import hr.fer.zemris.java.tecaj_14.dao.DAOProvider;
import hr.fer.zemris.java.tecaj_14.model.BlogUser;
import hr.fer.zemris.java.tecaj_14.model.Errors;
import hr.fer.zemris.java.tecaj_14.model.Hash;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * @author Herman Zvonimir Došilović
 * @version 1.0
 */
@WebServlet("/servleti/main")
public class Login extends HttpServlet {

	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		req.setAttribute("username", "");
		req.setAttribute("password", "");
		req.setAttribute("errors", new Errors());
		List<BlogUser> allUsers = DAOProvider.getDAO().getAllUsers();
		req.setAttribute("allUsers", allUsers);
		req.getRequestDispatcher("/WEB-INF/pages/Index.jsp").forward(req, resp);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String metoda = req.getParameter("metoda");
		if ("Odustani".equals(metoda)) {
			resp.sendRedirect(req.getServletContext().getContextPath() + "/");
			return;
		}
		
		Hash hash = new Hash();
		hash.generate(req.getParameter("password"));
		
		BlogUser reqUser = new BlogUser();
		reqUser.setNick(req.getParameter("username"));
		reqUser.setPasswordHash(hash.getPasswordHash());
		BlogUser user = DAOProvider.getDAO().getBlogUser(reqUser.getNick());

		Errors errors = new Errors();
		req.setAttribute("username", reqUser.getNick());
		req.setAttribute("errors", errors);
		List<BlogUser> allUsers = DAOProvider.getDAO().getAllUsers();
		req.setAttribute("allUsers", allUsers);
		
		if (user == null) {
			errors.putErrorMessage("loginError", "Neispravno korisničko ime ili lozinka.");
			req.getRequestDispatcher("/WEB-INF/pages/Index.jsp").forward(req, resp);
			return;
		} else if (!user.getPasswordHash().equals(reqUser.getPasswordHash())) {
			errors.putErrorMessage("loginError", "Neispravno korisničko ime ili lozinka.");
			req.getRequestDispatcher("/WEB-INF/pages/Index.jsp").forward(req, resp);
			return;
		}
		
		req.getSession().setAttribute("current.user.id", user.getId());
		req.getSession().setAttribute("current.user.fn", user.getFirstName());
		req.getSession().setAttribute("current.user.ln", user.getLastName());
		req.getSession().setAttribute("current.user.nick", user.getNick());
		
		req.getRequestDispatcher("/WEB-INF/pages/Index.jsp").forward(req, resp);
	}
}
