package hr.fer.zemris.java.tecaj_14.test;

import org.junit.Test;

public class HwTest {

	@Test
	public void test() {
	}
}
