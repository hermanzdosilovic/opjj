package hr.fer.zemris.java.tecaj.hw3;

import org.junit.Test;
import static org.junit.Assert.*;

public class CStringTest {
	
	@Test
	public void makeNewCString() {
		CString s = new CString("asdfasdf");
		assertEquals("Strings are not the same.", "asdfasdf", s.toString());
	}
	
	@Test
	public void constuctorTest() {
		CString s = new CString("asdfasdf".toCharArray(), 1, 3);
		String g = new String("asdfasdf".toCharArray(), 1, 3);
		assertEquals(s.toString(), g);
	}
	
	@Test
	public void lengthTest() {
		CString s = new CString("asdfasdf");
		String g = new String("asdfasdf");
		assertEquals(s.length(), g.length());
	}
	
	@Test
	public void charAtTest() {
		CString s = new CString("asdfasdf");
		String g = new String("asdfasdf");
		assertEquals(s.charAt(5), g.charAt(5));
	}
	
	@Test
	public void indexOfTest() {
		CString s = new CString("asdfasdf");
		String g = new String("asdfasdf");
		assertEquals(s.indexOf('f'), g.indexOf('f'));
	}
	
	@Test
	public void startsWithTest() {
		CString s = new CString("asdfasdf");
		String g = new String("asdfasdf");
		assertEquals(s.startsWith(new CString("asdf")), g.startsWith("asdf"));
	}
	
	@Test
	public void endsWithTest() {
		CString s = new CString("asdfasdf");
		String g = new String("asdfasdf");
		assertEquals(s.endsWith(new CString("asdf")), g.endsWith("asdf"));
	}
	
	@Test
	public void containsTest() {
		CString s = new CString("asdfasdf");
		String g = new String("asdfasdf");
		assertEquals(s.contains(new CString("asdf")), g.contains("asdf"));
	}
	
	@Test
	public void subStringTest() {
		CString s = new CString("asdfasdf");
		String g = new String("asdfasdf");
		assertEquals(s.substring(1, 6).toString(), g.substring(1, 6));
	}
	
	@Test
	public void leftTest() {
		CString s = new CString("asdfasdf");
		String g = new String("asdfasdf");
		assertEquals(s.left(6).toString(), g.substring(0, 6));
	}
	
	@Test
	public void rightTest() {
		CString s = new CString("asdfasdf");
		String g = new String("asdfasdf");
		assertEquals(s.right(6).toString(), g.substring(g.length() - 6, g.length()));
	}
	
	@Test
	public void addTest() {
		CString s = new CString("asdfasdf");
		String g = new String("asdfasdf");
		s.add(new CString("1234"));
		g.concat("1234");
		assertEquals(s.toString(), g.toString());
	}
	
	@Test
	public void repleceAllCharsTest() {
		CString s = new CString("aasdfsahljdjfljweuou");
		String g = new String  ("aasdfsahljdjfljweuou");
		s = s.replaceAll('l', 'L');
		g = g.replace('l', 'L');
		assertEquals(s.toString(), g);
	}
	
	@Test
	public void repleceAllStringsTest() {
		CString s = new CString("aasdfsahaaljdjaafljweuou");
		String g = new String  ("aasdfsahaaljdjaafljweuou");
		s = s.replaceAll(new CString("aa"), new CString("Lld"));
		g = g.replace("aa", "Lld");
		assertEquals(s.toString(), g);
	}
}
