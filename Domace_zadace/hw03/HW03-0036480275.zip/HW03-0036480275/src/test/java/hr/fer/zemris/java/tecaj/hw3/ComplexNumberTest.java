package hr.fer.zemris.java.tecaj.hw3;

import org.junit.Test;
import static org.junit.Assert.*;

public class ComplexNumberTest {

	@Test
	public void complexNumberDefinedWithJustRealPart() {
		ComplexNumber complexNumberExpected = new ComplexNumber(5.0, 0);
		ComplexNumber complexNumberTest = ComplexNumber.fromReal(5.0);

		assertEquals("Complex numbers are not the same.", complexNumberExpected.toString(),
				complexNumberTest.toString());
	}

	@Test
	public void complexNumberDefinedWithJustImaginaryPart() {
		ComplexNumber complexNumberExpected = new ComplexNumber(0, 5.0);
		ComplexNumber complexNumberTest = ComplexNumber.fromImaginary(5.0);

		assertEquals("Complex numbers are not the same.", complexNumberExpected.toString(),
				complexNumberTest.toString());
	}

	@Test
	public void complexNumberWithDefinedMagnitudeAndAngle() {
		ComplexNumber complexNumberExpected = new ComplexNumber(3.14159265358976, 1.414213562);
		ComplexNumber complexNumberTest = ComplexNumber.fromMaginutdeAndAngle(complexNumberExpected.getMagnitude(),
				complexNumberExpected.getAngle());

		assertEquals("Complex numbers are not the same.", complexNumberExpected.toString(),
				complexNumberTest.toString());
	}

	@Test
	public void getRealPartOfComplexNumber() {
		double real = 8.70239485;
		ComplexNumber complexNumber = new ComplexNumber(8.70239485, 2.3454353);

		assertEquals("Real parts are not the same.", real, complexNumber.getReal(), 10e-8);
	}

	@Test
	public void getImaginaryPartOfComplexNumber() {
		double imaginary = 2.3454353;
		ComplexNumber complexNumber = new ComplexNumber(8.70239485, 2.3454353);

		assertEquals("Imaginary parts are not the same.", imaginary, complexNumber.getImaginary(), 10e-8);
	}

	@Test
	public void getMagnitudeOfComplexNumber() {
		double magnitude = 24.62336356;
		ComplexNumber complexNumber = ComplexNumber.fromMaginutdeAndAngle(magnitude, 5.0);

		assertEquals("Magnitude is not the same.", magnitude, complexNumber.getMagnitude(), 10e-8);
	}

	@Test
	public void getAngleOfComplexNumber() {
		double angle = 2.23423424;
		ComplexNumber complexNumber = ComplexNumber.fromMaginutdeAndAngle(5.0, angle);

		assertEquals("Angle is not the same.", angle, complexNumber.getAngle(), 10e-8);
	}

	@Test
	public void addTwoComplexNumbersTest() {
		ComplexNumber firstComplexNumber = new ComplexNumber(2.3, 4.5343);
		ComplexNumber secondComplexNumber = new ComplexNumber(7.4, 53.44456);
		ComplexNumber resultComplexNumber = firstComplexNumber.add(secondComplexNumber);

		double newReal = firstComplexNumber.getReal() + secondComplexNumber.getReal();
		double newImaginaray = firstComplexNumber.getImaginary() + secondComplexNumber.getImaginary();

		ComplexNumber expectedComplexNumber = new ComplexNumber(newReal, newImaginaray);

		assertEquals("Complex numbers are not the same.", expectedComplexNumber.toString(),
				resultComplexNumber.toString());
	}

	@Test
	public void substractTwoComplexNumbersTest() {
		ComplexNumber firstComplexNumber = new ComplexNumber(2.3, 4.5343);
		ComplexNumber secondComplexNumber = new ComplexNumber(7.4, 53.44456);
		ComplexNumber resultComplexNumber = firstComplexNumber.sub(secondComplexNumber);

		double newReal = firstComplexNumber.getReal() - secondComplexNumber.getReal();
		double newImaginaray = firstComplexNumber.getImaginary() - secondComplexNumber.getImaginary();

		ComplexNumber expectedComplexNumber = new ComplexNumber(newReal, newImaginaray);

		assertEquals("Complex numbers are not the same.", expectedComplexNumber.toString(),
				resultComplexNumber.toString());
	}

	@Test
	public void multiplicateTwoComplexNumbersTest() {
		ComplexNumber firstComplexNumber = new ComplexNumber(23.5, 454.2);
		ComplexNumber secondComplexNumber = new ComplexNumber(234.5, 73.43);
		ComplexNumber resultComplexNumber = firstComplexNumber.mul(secondComplexNumber);

		double newMagnitude = firstComplexNumber.getMagnitude() * secondComplexNumber.getMagnitude();
		double newAngle = firstComplexNumber.getAngle() + secondComplexNumber.getAngle();

		ComplexNumber expectedComplexNumber = ComplexNumber.fromMaginutdeAndAngle(newMagnitude, newAngle);

		assertEquals("Complex numbers are not the same.", expectedComplexNumber.toString(),
				resultComplexNumber.toString());
	}

	@Test
	public void divideTwoComplexNumbersTest() {
		ComplexNumber firstComplexNumber = new ComplexNumber(23.5, 454.2);
		ComplexNumber secondComplexNumber = new ComplexNumber(234.5, 73.43);
		ComplexNumber resultComplexNumber = firstComplexNumber.div(secondComplexNumber);

		double newMagnitude = firstComplexNumber.getMagnitude() / secondComplexNumber.getMagnitude();
		double newAngle = firstComplexNumber.getAngle() - secondComplexNumber.getAngle();

		ComplexNumber expectedComplexNumber = ComplexNumber.fromMaginutdeAndAngle(newMagnitude, newAngle);

		assertEquals("Complex numbers are not the same.", expectedComplexNumber.toString(),
				resultComplexNumber.toString());
	}

	@Test
	public void powerOfComplexNumber() {
		ComplexNumber complexNumberTest = new ComplexNumber(23.54, 623.56);

		int power = 7;

		double newMagnitude = Math.pow(complexNumberTest.getMagnitude(), power);
		double newAngle = complexNumberTest.getAngle() * power;

		ComplexNumber expectedComplexNumber = ComplexNumber.fromMaginutdeAndAngle(newMagnitude, newAngle);

		complexNumberTest = complexNumberTest.power(power);

		assertEquals("Complex numbers are not the same.", expectedComplexNumber.toString(),
				complexNumberTest.toString());
	}

	@Test
	public void rootOfComplexNumber() {
		ComplexNumber complexNumberTest = new ComplexNumber(234.5, 7656.5543);

		int root = 69;

		ComplexNumber[] expectedComplexNumber = new ComplexNumber[root];

		double newMagnitude = Math.pow(complexNumberTest.getMagnitude(), 1 / (double) root);
		double newAngle;

		for (int k = 0; k < root; k++) {
			newAngle = (complexNumberTest.getAngle() + 2 * k * Math.PI) / (double) root;
			expectedComplexNumber[k] = ComplexNumber.fromMaginutdeAndAngle(newMagnitude, newAngle);
		}

		ComplexNumber[] complexNumberTestResult = complexNumberTest.root(root);

		for (int k = 0; k < root; k++) {
			assertEquals("Complex numbers are not the same.", expectedComplexNumber[k].toString(),
					complexNumberTestResult[k].toString());
		}
	}

	@Test
	public void complexNumberToStringRepresentationTest() {
		ComplexNumber complexNumberTest = new ComplexNumber(234.566, 7654.0435);
		String expectedString = complexNumberTest.getReal() + "+" + complexNumberTest.getImaginary() + "i";

		assertEquals("String representation is not the same.", expectedString, complexNumberTest.toString());
	}
	
	@Test(expected=ComplexNumberException.class)
	public void requestedRootIsNegative() {
		ComplexNumber complexNumber = new ComplexNumber(234.5, 2346.66);
		complexNumber.root(-4);
	}
	
	@Test(expected=ComplexNumberException.class)
	public void requestedPowerIsNegative() {
		ComplexNumber complexNumber = new ComplexNumber(234.5, 2346.66);
		complexNumber.power(-4);
	}
	
	@Test(expected=ComplexNumberException.class)
	public void complexNumberWithNegativeMagnitudeDefined() {
		ComplexNumber.fromMaginutdeAndAngle(-56, 25);
	}
}
