package hr.fer.zemris.java.tecaj.hw3;

import org.junit.Test;
import static org.junit.Assert.*;

public class SmartComplexNumberTest {

	@Test
	public void onlyRealNumberTest() {
		SmartComplexNumber complexNumberActual = new SmartComplexNumber("3.45");
		ComplexNumber complexNumberExpected = new ComplexNumber(3.45, 0);

		assertEquals("Complex numbers are not the same.", complexNumberExpected.toString(), complexNumberActual
				.getComplexNumber().toString());
	}

	@Test
	public void onlyImagniaryNumberTest() {
		SmartComplexNumber complexNumberActual = new SmartComplexNumber("3.45i");
		ComplexNumber complexNumberExpected = new ComplexNumber(0, 3.45);

		assertEquals("Complex numbers are not the same.", complexNumberExpected.toString(), complexNumberActual
				.getComplexNumber().toString());
	}

	@Test
	public void onlyNegativeRealNumberTest() {
		SmartComplexNumber complexNumberActual = new SmartComplexNumber("-3.45");
		ComplexNumber complexNumberExpected = new ComplexNumber(-3.45, 0);

		assertEquals("Complex numbers are not the same.", complexNumberExpected.toString(), complexNumberActual
				.getComplexNumber().toString());
	}

	@Test
	public void onlyNegativeImaginaryNumberTest() {
		SmartComplexNumber complexNumberActual = new SmartComplexNumber("-3.45i");
		ComplexNumber complexNumberExpected = new ComplexNumber(0, -3.45);

		assertEquals("Complex numbers are not the same.", complexNumberExpected.toString(), complexNumberActual
				.getComplexNumber().toString());
	}

	@Test(expected = SmartComplexNumberException.class)
	public void emptyStringTest() {
		new SmartComplexNumber("");
	}

	@Test(expected = SmartComplexNumberException.class)
	public void toManyOperatorsTest() {
		new SmartComplexNumber("+-+-+-+");
	}

	@Test(expected = SmartComplexNumberException.class)
	public void illegalCharactersTest() {
		new SmartComplexNumber("asdf");
	}

	@Test(expected = SmartComplexNumberException.class)
	public void toManyImaginaryUnits() {
		new SmartComplexNumber("3i+7i+4i");
	}

	@Test(expected = SmartComplexNumberException.class)
	public void toManyRealParts() {
		new SmartComplexNumber("3+3-2+4i");
	}

	@Test(expected = SmartComplexNumberException.class)
	public void realPartIsValidImaginaryPartIsInvalid() {
		new SmartComplexNumber("-2iii");
	}

	@Test(expected = SmartComplexNumberException.class)
	public void realPartIsInvalidImaginaryPartIsValid() {
		new SmartComplexNumber("-2i+33+4");
	}

	@Test(expected = SmartComplexNumberException.class)
	public void multipleTerms() {
		new SmartComplexNumber("-2i+3+6.4");
	}

	@Test(expected = SmartComplexNumberException.class)
	public void containsUnsuportedCharactersThatAreNotLetters() {
		new SmartComplexNumber("*/2i");
	}
}
