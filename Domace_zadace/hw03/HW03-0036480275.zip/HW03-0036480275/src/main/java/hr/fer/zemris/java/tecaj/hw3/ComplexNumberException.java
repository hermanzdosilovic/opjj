package hr.fer.zemris.java.tecaj.hw3;

/**
 * Thrown when application attempts to use undefined or forbidden complex number operations.
 * 
 * @author Herman Zvonimir Došilović
 * @version 1.0
 */
public class ComplexNumberException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	/**
	 * Constructs a <code>ComplexNumberException</code> with the specified detail message.
	 * 
	 * @param message
	 *            - the detail message.
	 */
	public ComplexNumberException(String message) {
		super(message);
	}
}
