package hr.fer.zemris.java.tecaj.hw3;

import static java.lang.Character.*;

/**
 * This class provides smart converter that converts <code>String</code> representation of complex number to
 * <code>ComplexNumber</code> class.
 * <p>
 * For example valid <code>String</code> representation of complex number are:
 * <ul>
 * <li>1 + 2<i>i</i>
 * <li>3.14 + 1.4142<i>i</i>
 * <li>-7
 * <li>-8<i>i</i>
 * <li>3-4<i>i</i>
 * <li>34.3i + 213
 * <li>-i3
 * <li>i + 2
 * <li>-i - 7
 * </ul>
 * <br>
 * Cases like:
 * <ul>
 * <li>0+0<i>i</i>
 * <li>-0<i>i</i>
 * </ul>
 * are <b>acceptable</b>. <br>
 * <i>empty string</i> is <b>not acceptable</b>.
 * </p>
 * 
 * @author Herman Zvonimir Došilović
 * @version 1.0
 */
public class SmartComplexNumber {

	/** This value is used to store real part of complex number. */
	private double real;

	/** This value is used to store imaginary part of complex number. */
	private double imaginary;

	/** This <code>String</code> is used to store string representation of complex number given by user. */
	private String complexNumber;

	/**
	 * Constructs new <code>SmartComplexNumber</code> and converts it.
	 * 
	 * @param s
	 *            <code>String</code> representation of complex number
	 * @throws SmartComplexNumberException
	 *             if invalid complex number representation is given
	 */
	public SmartComplexNumber(String s) {
		this.complexNumber = s;
		try {
			startConversion();
		}
		catch (SmartComplexNumberException e) {
			throw e;
		}
		catch (RuntimeException e) {
			throw e;
		}
	}

	/**
	 * Starts conversion of <code>String</code> representation of complex number.
	 * 
	 * @throws SmartComplexNumberException
	 *             if invalid complex number representation is given
	 */
	private void startConversion() { // step 1
		complexNumber = complexNumber.replace(" ", "");

		if (complexNumber.compareTo("") == 0) { // empty string is invalid representation of complex number
			throw new SmartComplexNumberException("Illegal String representation of complex number.");
		}

		int countImaginaryUnit = 0;
		boolean containsUnsuportedCharacters = false;
		for (int i = 0; i < complexNumber.length(); i++) {
			if (complexNumber.charAt(i) == 'i') {
				countImaginaryUnit++;
			}
			else if (isLetter(complexNumber.charAt(i))) {
				containsUnsuportedCharacters = true;
				break;
			}
			else if (complexNumber.charAt(i) == '+' || complexNumber.charAt(i) == '-') {
				continue;
			}
			else if (isDigit(complexNumber.charAt(i)) || complexNumber.charAt(i) == '.') {
				continue;
			}
			else {
				containsUnsuportedCharacters = true;
				break;
			}
		}

		if (countImaginaryUnit > 1 || containsUnsuportedCharacters == true) {
			throw new SmartComplexNumberException("Illegal String representation of complex number.");
		}

		complexNumber = getFirstTerm(complexNumber); // step 2
		complexNumber = getSecondTerm(complexNumber); // step 3
		if (complexNumber.compareTo("") != 0) {
			throw new SmartComplexNumberException("Illegal String representation of complex number.");
		}
	}

	/**
	 * Extracts first term from complex number.
	 * 
	 * @param s
	 *            <code>String</code> representation of whole complex number
	 * @throws SmartComplexNumberException
	 *             if invalid complex number representation is given
	 */
	private String getFirstTerm(String s) {
		return getValue(s);
	}

	/**
	 * Extracts second term from complex number.
	 * 
	 * @param s
	 *            <code>String</code> representation of whole complex number
	 * @throws SmartComplexNumberException
	 *             if invalid complex number representation is given
	 */
	private String getSecondTerm(String s) {
		if (s.compareTo("") == 0) {
			return s;
		}
		return getValue(s);
	}

	/**
	 * Returns string without next term that is represented by string. Sets value of next term to right location.
	 * 
	 * @param s
	 *            string representation of current expression
	 * @return string without next term
	 */
	private String getValue(String s) {
		String firstTerm = wrapNextTerm(s);
		if (firstTerm.length() == 1 && (firstTerm.charAt(0) == '+' || firstTerm.charAt(0) == '-')) {
			throw new SmartComplexNumberException("Illegal String representation of complex number.");
		}
		s = s.substring(firstTerm.length());

		int sign = 1;
		if (firstTerm.charAt(0) == '-') {
			sign = -1;
			firstTerm = firstTerm.replace("-", "");
		}
		else if (firstTerm.charAt(0) == '+') {
			firstTerm = firstTerm.replace("+", "");
		}

		if (firstTerm.compareTo("") == 0) {
			return s;
		}

		if (firstTerm.charAt(0) == 'i' && firstTerm.charAt(firstTerm.length() - 1) == 'i' && imaginary == 0) {
			imaginary = sign;
		}
		else if (firstTerm.charAt(0) == 'i' && imaginary == 0) {
			imaginary = Double.parseDouble(firstTerm.substring(1)) * sign;
		}
		else if (firstTerm.charAt(firstTerm.length() - 1) == 'i' && imaginary == 0) {
			imaginary = Double.parseDouble(firstTerm.substring(0, firstTerm.length() - 1)) * sign;
		}
		else if (real == 0) {
			try {
				real = Double.parseDouble(firstTerm) * sign;
			}
			catch (NumberFormatException e) {
				throw new SmartComplexNumberException("Illegal String representation of complex number.");
			}
		}
		else {
			throw new SmartComplexNumberException("Illegal String representation of complex number.");
		}

		return s;
	}

	/**
	 * Wraps next valid term in one string and returns that term
	 * 
	 * @param s
	 *            initial set of terms
	 * @return next term in <i>s</i>
	 */
	private String wrapNextTerm(String s) {
		int countOperators = 0;
		for (int i = 0; i < s.length() && isDigit(s.charAt(i)) == false && s.charAt(i) != 'i'; i++) {
			countOperators++;
		}

		if (countOperators > 1) {
			throw new SmartComplexNumberException("Illegal String representation of complex number.");
		}

		int positionOfnextSign = s.length();
		int i = 0;

		if (s.charAt(0) == '-' || s.charAt(0) == '+') {
			i = 1;
		}

		for (; i < s.length() && s.charAt(i) != '+' && s.charAt(i) != '-'; i++) {
			positionOfnextSign = i;
		}

		if (positionOfnextSign != s.length()) {
			positionOfnextSign++;
		}

		return s.substring(0, positionOfnextSign);
	}

	/**
	 * Returns new <code>ComplexNumber</code> object.
	 * 
	 * @return <code>ComplexNumber</code> object
	 */
	public ComplexNumber getComplexNumber() {
		return new ComplexNumber(real, imaginary);
	}
}
