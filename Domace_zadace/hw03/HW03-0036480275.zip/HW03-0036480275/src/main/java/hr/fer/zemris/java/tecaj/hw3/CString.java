package hr.fer.zemris.java.tecaj.hw3;

/**
 * <code>CString</code> class offers similar functionality as the old official implementation of the <code>String</code>
 * class: it represents unmodifiable strings on which substring methods (and similar) must be executed in O(1)
 * complexity.
 * @author Herman Zvonimir Došilović
 * @version 1.0
 */
public class CString {
	
	private char[] data;
	private int offset;
	private int length;
	
	/**
	 * Constructs new <code>CString</code> with defined data, offset, length
	 * @param data data from which <code>CString</code> will be represented
	 * @param offset position of first included character in data
	 * @param length length of representation
	 */
	public CString(char[] data, int offset, int length) {
		this.data = new char[data.length];
		for(int i = 0; i < data.length; i++) {
			this.data[i] = data[i];
		}
		this.offset = offset;
		this.length = length;
	}
	
	/**
	 * Constructs new <code>CString</code> with array defined.
	 * @param data data from which <code>CString</code> will be represented
	 */
	public CString(char[] data) {
		this(data, 0, data.length);
	}
	
	/**
	 * Constructs new <code>CString</code> with String defined
	 * @param s String from which <code>CString</code> will be represented
	 */
	public CString(String s) {
		this(s.toCharArray());
	}
	
	/**
	 * Returns length of CString
	 * @return length of CString
	 */
	public int length() {
		return length;
	}
	
	/**
	 * Returns char at specified position
	 * @param index position of wanted characted
	 * @throws IndexOutOfBoundsException if index is not in valid range
	 * @return character in CString at position index
	 */
	public char charAt(int index) {
		if(index < 0 || index >= length) {
			throw new IndexOutOfBoundsException("Invalid index.");
		}
		return data[offset + index];
	}
	
	/**
	 * String representation of CString
	 * @return CString as String
	 */
	public String toString() {
		StringBuilder sb = new StringBuilder();
		for(int i = 0; i < length; i++) {
			sb.append(data[offset + i]);
		}
		return sb.toString();
	}
	
	/**
	 * Returns index of first occurrence of char or -1
	 * @param c character to search for
	 * @return index of first occurrence of char or -1 if char is not found
	 */
	public int indexOf(char c) {
		int indexOfChar = -1;
		for(int i = offset; i < length; i++) {
			if(data[i] == c) {
				indexOfChar = i;
				break;
			}
		}
		return indexOfChar;
	}
	
	/**
	 * Returns true if this string begins with given sring, false otherwise
	 * @param s CString to search for
	 * @return true if s starts in this string
	 */
	public boolean startsWith(CString s) {
		boolean starts = true;
		if(s.length() > this.length()) {
			starts = false;
		}
		
		for(int i = 0, j = 0; i < s.length() && j < length; i++, j++) {
			if(s.charAt(i) != this.charAt(j)) {
				starts = false;
			}
		}
		
		return starts;
	}
	
	/**
	 * Returns true if this string ends with given sring, false otherwise
	 * @param s CString to search for
	 * @return true if s ends in this string
	 */
	public boolean endsWith(CString s) {
		boolean ends = true;
		if(s.length() > this.length()) {
			ends = false;
		}
		
		for(int i = s.length() - 1, j = length - 1; i >= 0 && j >= 0; i--, j--) {
			if(s.charAt(i) != this.charAt(j)) {
				ends = false;
			}
		}
		
		return ends;
	}
	
	/**
	 * Returns true if this string contains given sring, false otherwise
	 * @param s CString to search for
	 * @return true if this string contains this string
	 */
	public boolean contains(CString s) {
		boolean exsists = false;
		if(s.length() > this.length()) {
			exsists = false;
		}
		
		if(s.toString().compareTo("") == 0) {
			return true;
		}
		
		int count = 0;
		for(int i = 0; i < length; i++) {
			if(s.charAt(0) == this.charAt(i)) {
				count = 0;
				for(int j = i, k = 0; j < length && k < s.length(); j++, k++) {
					if(s.charAt(k) != this.charAt(j)) {
						break;
					}
					else {
						count++;
					}
				}
				if(count == s.length()) {
					exsists = true;
				}
			}
		}
		
		return exsists;
	}
	
	/**
	 * Returns substring of this string
	 * @param startIndex index to start with
	 * @param endIndex index to end with (does not include)
	 * @return CString representings this substring
	 * @throws IndexOutOfBoundsException if invalid start or end index is given
	 */
	public CString substring(int startIndex, int endIndex) {
		if(startIndex < 0 || startIndex > length) {
			throw new IndexOutOfBoundsException("Wrong start index.");
		}
		
		if(endIndex < 0 || endIndex > length) {
			throw new IndexOutOfBoundsException("Wrong end index.");
		}
		
		if(endIndex < startIndex) {
			throw new IndexOutOfBoundsException();
		}
		
		return new CString(data, offset + startIndex, offset + endIndex - startIndex);
	}
	
	/**
	 * Returns new CString which represents starting part of original string and is of length n
	 * @param n length of substring; n >= 0
	 * @returns CString which represents starting part of original string and is of length n
	 */
	public CString left(int n) {
		if(n > length || n < 0) {
			throw new IndexOutOfBoundsException();
		}
		
		return new CString(data, offset, n);
	}
	
	/**
	 * Returns new CString which represents end part of original string and is of length n
	 * @param n length of substring; n >= 0
	 * @returns CString which represents end part of original string and is of length n
	 */
	public CString right(int n) {
		if(n > length || n < 0) {
			throw new IndexOutOfBoundsException();
		}
		
		return new CString(data, offset + length - n, n);
	}
	
	/**
	 * Creates a new CString which is concetanation of current and given string
	 * @param s string to concatenate
	 * @return new CString
	 */
	public CString add(CString s) {
		return new CString(this.toString() + s.toString());
	}
	
	/**
	 * Replaces all occurrence of old character with new character
	 * @param oldChar what to replace
	 * @param newChar what to put
	 * @return new CString
	 */
	public CString replaceAll(char oldChar, char newChar) {
		String oldString = this.toString();
		char[] oldData = oldString.toCharArray();
		for(int i = 0; i < oldData.length; i++) {
			if(oldData[i] == oldChar) {
				oldData[i] = newChar;
			}
		}
		return new CString(oldData);
	}
	
	/**
	 * Replaces all occurrence of old string with new string
	 * @param oldStr what to replace
	 * @param newStr what to put
	 * @return new CString
	 */
	public CString replaceAll(CString oldStr, CString newStr) {
		StringBuilder sb = new StringBuilder();
		for(int i = 0; i < this.length - oldStr.length(); i++) {
			if(this.substring(i, i + oldStr.length()).toString().compareTo(oldStr.toString()) == 0) {
				sb.append(newStr.toString());
				i += oldStr.length() - 1;
			}
			else {
				sb.append(this.charAt(i));
			}
		}
		for(int i = this.length - oldStr.length(); i < this.length; i++) {
			sb.append(this.charAt(i));
		}
		return new CString(sb.toString());
	}
	
}
