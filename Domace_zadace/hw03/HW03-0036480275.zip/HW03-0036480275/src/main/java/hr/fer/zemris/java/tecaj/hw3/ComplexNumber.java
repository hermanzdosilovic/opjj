package hr.fer.zemris.java.tecaj.hw3;

/**
 * The <code>ComplexNumber</code> class provides standard operations for working with complex numbers.
 * 
 * @author Herman Zvonimir Došilović
 * @version 1.0
 */
public class ComplexNumber {

	/** This value is used to store real part of complex number. */
	private double real;

	/** This value is used to store imaginary part of complex number. */
	private double imaginary;

	/**
	 * Constructs a new complex number with given real and imaginary part.
	 * 
	 * @param real
	 *            real part of complex number
	 * @param imaginary
	 *            imaginary part of complex number
	 */
	public ComplexNumber(double real, double imaginary) {
		this.real = real;
		this.imaginary = imaginary;
	}

	/**
	 * Returns complex number with real part only defined. Imaginary part is 0.
	 * 
	 * @param real
	 *            real part of complex number
	 * @return new complex number with real part only
	 */
	public static ComplexNumber fromReal(double real) {
		return new ComplexNumber(real, 0);
	}

	/**
	 * Return complex number with imaginary part only defined. Real part is 0.
	 * 
	 * @param imaginary
	 *            imaginary part of complex number
	 * @return new complex number with imaginary part only
	 */
	public static ComplexNumber fromImaginary(double imaginary) {
		return new ComplexNumber(0, imaginary);
	}

	/**
	 * Returns complex number which is defined with magnitude and angle (in radians).<br>
	 * Magnitude of complex number <code>z</code> is defined as:
	 * <ul>
	 * <code>|z| := sqrt(Re^2 + Im^2)</code>
	 * </ul>
	 * Angle <b><code>alpha</code></b> of complex number <code>z</code> is defined as:
	 * <ul>
	 * <code><b>alpha</b> := atan(Im / Re)</code>
	 * </ul>
	 * 
	 * @param magnitude
	 *            magnitude of complex number
	 * @param angle
	 *            angle in <b>radians</b> of complex number
	 * @return complex number with real and imaginary part
	 * @throws ComplexNumberException
	 *             if magnitude is negative
	 */
	public static ComplexNumber fromMaginutdeAndAngle(double magnitude, double angle) {
		if (magnitude < 0) {
			throw new ComplexNumberException("Magnitude of complex number must be greater than 0.");
		}

		double newReal = magnitude * Math.cos(angle);
		double newImaginary = magnitude * Math.sin(angle);

		return new ComplexNumber(newReal, newImaginary);
	}

	/**
	 * Returns complex number which is defined with expression <code>String</code>.<br>
	 * Valid expressions for example are:
	 * <ul>
	 * <li>1+2i
	 * <li>-2.3 + 7.5i
	 * <li>9i
	 * <li>2
	 * </ul>
	 * 
	 * @param s
	 *            valid expression
	 * @return complex number with real and imaginary part
	 */
	public static ComplexNumber parse(String s) {
		SmartComplexNumber smartComplexNumber = new SmartComplexNumber(s);
		ComplexNumber complexNumber = smartComplexNumber.getComplexNumber();
		return complexNumber;
	}

	/**
	 * Returns real part of complex number
	 * 
	 * @return real part of this complex number
	 */
	public double getReal() {
		return real;
	}

	/**
	 * Returns imaginary part of complex number
	 * 
	 * @return imaginary part of this complex number
	 */
	public double getImaginary() {
		return imaginary;
	}

	/**
	 * Returns magnitude of complex number<br>
	 * Magnitude of complex number is defined as:
	 * <ul>
	 * <code>sqrt(Re^2 + Im^2)</code>
	 * </ul>
	 * 
	 * @return magnitude of this complex number
	 */
	public double getMagnitude() {
		return Math.sqrt(this.real * this.real + this.imaginary * this.imaginary);
	}

	/**
	 * Returns angle in <b>radinas</b> of complex number Angle of complex number is defined as:
	 * <ul>
	 * <code>angle = atan(Im / Re)</code>
	 * </ul>
	 * 
	 * @return angle in <b>radians</b> of this complex number
	 */
	public double getAngle() {
		return Math.atan2(this.imaginary, this.real);
	}

	/**
	 * Returns string representation of complex number as:
	 * <ul>
	 * <code>Re+Im<b><i>i</i></b></code>
	 * </ul>
	 * 
	 * @return string representation of this complex number
	 */
	@Override
	public String toString() {
		return real + (imaginary < 0 ? "" : "+") + imaginary + "i";
	}

	/**
	 * Adds complex number <code>c</code> to this complex number.
	 * 
	 * @param c
	 *            complex number to add this complex number
	 * @return complex number made by addition of this complex number and <code>c</code>
	 */
	public ComplexNumber add(ComplexNumber c) {
		double newReal = this.real + c.getReal();
		double newImaginary = this.imaginary + c.getImaginary();

		return new ComplexNumber(newReal, newImaginary);
	}

	/**
	 * Substacts complex number <code>c</code> to this complex number.
	 * 
	 * @param c
	 *            complex number to substract
	 * @return complex number made by substraction of this complex number and <code>c</code>
	 */
	public ComplexNumber sub(ComplexNumber c) {
		double newReal = this.real - c.getReal();
		double newImaginary = this.imaginary - c.getImaginary();

		return new ComplexNumber(newReal, newImaginary);
	}

	/**
	 * Multiplicates complex number <code>c</code> to this complex number.
	 * 
	 * @param c
	 *            complex number to multiplicate
	 * @return complex number made by multiplication of this complex number and <code>c</code>
	 */
	public ComplexNumber mul(ComplexNumber c) {
		double newMagnitude = this.getMagnitude() * c.getMagnitude();
		double newAngle = this.getAngle() + c.getAngle();

		return fromMaginutdeAndAngle(newMagnitude, newAngle);
	}

	/**
	 * Divdes complex nubmer <code>c</code> from this complex number.
	 * 
	 * @param c
	 *            complex number to divide
	 * @return complex number made by division of this complex number with <code>c</code>
	 */
	public ComplexNumber div(ComplexNumber c) {
		double newMagnitude = this.getMagnitude() / c.getMagnitude();
		double newAngle = this.getAngle() - c.getAngle();

		return fromMaginutdeAndAngle(newMagnitude, newAngle);
	}

	/**
	 * Returns n-th power of this complex number.
	 * 
	 * @param n
	 *            power of complex number to calculate
	 * @return n-th power of this complex number
	 * @throws ComplexNumberException
	 *             if given power is smaller than 0 (<code>n < 0</code>).
	 */
	public ComplexNumber power(int n) {
		if (n < 0) {
			throw new ComplexNumberException("Invalid argument. Must be greater than or equal to 0");
		}

		double newMagnitude = Math.pow(this.getMagnitude(), n);
		double newAngle = this.getAngle() * n;

		return fromMaginutdeAndAngle(newMagnitude, newAngle);
	}

	/**
	 * Returns n-th root of this complex number.
	 * 
	 * @param n
	 *            n-th root of complex number to calculate
	 * @return n-th root of this complex number
	 * @throws ComplexNumberException
	 *             if given root is smaller than 1 (<code>n <= 0</code>).
	 */
	public ComplexNumber[] root(int n) {
		if (n <= 0) {
			throw new ComplexNumberException("Invalid argument. Must be greater than 0.");
		}

		ComplexNumber[] complexNumber = new ComplexNumber[n];

		double newMagnitude = Math.pow(this.getMagnitude(), 1 / (double) n);
		double newAngle;

		for (int k = 0; k < n; k++) {
			newAngle = (this.getAngle() + 2 * k * Math.PI) / (double) n;
			complexNumber[k] = fromMaginutdeAndAngle(newMagnitude, newAngle);
		}

		return complexNumber;
	}

}
