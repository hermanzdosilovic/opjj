package hr.fer.zemris.java.tecaj.hw3;

import java.util.Iterator;

/**
 * This class provides implementation of integer sequence which is defined with start element, end element and step
 * element.<br>
 * For example <code>IntegerSequence(0, 6, 2)</code> represents sequence <code>0, 2, 4, 6</code>
 * 
 * @author Herman Zvonimir Došilović
 */
public class IntegerSequence implements Iterable<Integer> {

	/** This value is used to store start element in sequence. */
	private int start;

	/** Used to store last (end) element in sequence. */
	private int end;

	/** Used to store step element in sequence. */
	private int step;

	/**
	 * Constructs new sequence which is defined with start, end and step.
	 * 
	 * @param start
	 *            first element of sequence
	 * @param end
	 *            last element of sequence. No element is greater (<code>step > 0</code>) or smaller ({@code step < 0})
	 *            than this element.
	 * @param step
	 *            step element. In each iteration current is greater for step
	 */
	public IntegerSequence(int start, int end, int step) {
		this.start = start;
		this.end = end;
		this.step = step;
	}

	@Override
	public Iterator<Integer> iterator() {
		return new IntegerIterator();
	}

	/**
	 * Class <code>IntegerIterator</code> provides iterator on a <code>IntegerSequence</code> class.
	 * 
	 * @author Herman Zvonimir Došilović
	 */
	private class IntegerIterator implements Iterator<Integer> {

		private int current;

		/**
		 * Constructs new iterator.
		 */
		public IntegerIterator() {
			this.current = start - step;
		}

		@Override
		public boolean hasNext() {
			if (current + step <= end && step > 0) {
				current += step;
				return true;
			}
			else if (current + step >= end && step <= 0) {
				current += step;
				return true;
			}
			else {
				return false;
			}
		}

		@Override
		public Integer next() {
			return current;
		}

		/**
		 * Unsuported operation.
		 * 
		 * @throws RuntimeException
		 *             if called.
		 */
		@Override
		public void remove() {
			throw new RuntimeException("Unsuported operation.");
		}

	}
}