package hr.fer.zemris.java.tecaj_13;

import org.junit.Assert;
import org.junit.Test;

public class ApplicationTest {

	@Test
	public void test() {
		Assert.assertEquals(true, true);
	}

}
