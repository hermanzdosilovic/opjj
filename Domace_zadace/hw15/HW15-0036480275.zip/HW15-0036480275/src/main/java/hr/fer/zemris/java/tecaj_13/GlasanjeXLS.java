package hr.fer.zemris.java.tecaj_13;

import hr.fer.zemris.java.tecaj_13.dao.DAOProvider;
import hr.fer.zemris.java.tecaj_13.model.PollOption;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

/**
 * @author Herman Zvonimir Došilović
 * @version 1.0
 */
@WebServlet("/servleti/glasanje-xls")
public class GlasanjeXLS extends HttpServlet {

	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		try {
			resp.setContentType("application/octet.stream");
			long pollId = (Long) req.getSession().getAttribute("pollID");
			List<PollOption> pollOptions = DAOProvider.getDao().catchPollOptionsWithPollId(pollId, true);
			HSSFWorkbook hwb = new HSSFWorkbook();
			HSSFSheet sheet = hwb.createSheet("rezultati");
			for (int i = 0; i < pollOptions.size(); i++) {
				HSSFRow row = sheet.createRow(i);
				row.createCell(0).setCellValue(pollOptions.get(i).getTitle());
				row.createCell(1).setCellValue(pollOptions.get(i).getVotesCount());
			}

			resp.setHeader("Content-Disposition", "attachment;filename=rezultati.xls");
			hwb.write(resp.getOutputStream());
		} catch (RuntimeException ignorable) {
			req.getRequestDispatcher("/WEB-INF/pages/Error.jsp");
		}
	}
}
