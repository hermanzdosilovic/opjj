package hr.fer.zemris.java.tecaj_13.dao;

import hr.fer.zemris.java.tecaj_13.model.Poll;
import hr.fer.zemris.java.tecaj_13.model.PollOption;

import java.util.List;

/**
 * Sučelje prema podsustavu za perzistenciju podataka.
 * 
 * @author Herman Zvonimir Došilović
 * @version 1.0
 */
public interface DAO {

	public List<Poll> catchPolls() throws DAOException;
	
	public void init() throws DAOException;
	
	public List<PollOption> catchPollOptionsWithPollId(long pollId, boolean sortByVotes) throws DAOException;

	public PollOption getPollOptionWithId(long id);

	public void updatePollOption(PollOption pollOption);

}