package hr.fer.zemris.java.tecaj_13;

import hr.fer.zemris.java.tecaj_13.dao.DAOProvider;
import hr.fer.zemris.java.tecaj_13.model.PollOption;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * @author Herman Zvonimir Došilović
 * @version 1.0
 */
@WebServlet("/servleti/glasanje-rezultati")
public class Results extends HttpServlet {

	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		try {
			long pollID = (Long) req.getSession().getAttribute("pollID");
			List<PollOption> pollOptions = DAOProvider.getDao().catchPollOptionsWithPollId(pollID, true);
			List<PollOption> winners = new ArrayList<>();
			PollOption winner = pollOptions.get(0);
			for (PollOption pollOption : pollOptions) {
				if (pollOption.getVotesCount() == winner.getVotesCount()) {
					winners.add(pollOption);
				}
			}
			req.setAttribute("winners", winners);
			req.setAttribute("pollOptions", pollOptions);
			req.getRequestDispatcher("/WEB-INF/pages/Results.jsp").forward(req, resp);
		} catch (RuntimeException ignorable) {
			req.getRequestDispatcher("/WEB-INF/pages/Error.jsp");
		}
	}
}
