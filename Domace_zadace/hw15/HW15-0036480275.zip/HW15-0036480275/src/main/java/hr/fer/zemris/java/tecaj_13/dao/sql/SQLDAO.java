package hr.fer.zemris.java.tecaj_13.dao.sql;

import hr.fer.zemris.java.tecaj_13.dao.DAO;
import hr.fer.zemris.java.tecaj_13.dao.DAOException;
import hr.fer.zemris.java.tecaj_13.dao.DAOProvider;
import hr.fer.zemris.java.tecaj_13.model.Poll;
import hr.fer.zemris.java.tecaj_13.model.PollOption;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 * @author Herman Zvonimir Došilović
 * @version 1.0
 */
public class SQLDAO implements DAO {

	@Override
	public void init() throws DAOException {
		this.initPolls();
		this.initPollOptions();
	}

	@Override
	public List<Poll> catchPolls() throws DAOException {
		List<Poll> polls = new ArrayList<>();
		Connection con = SQLConnectionProvider.getConnection();
		PreparedStatement pst = null;
		try {
			pst = con.prepareStatement("SELECT * FROM Polls ORDER BY id");
			try {
				ResultSet rs = pst.executeQuery();
				try {
					while (rs != null && rs.next()) {
						Poll poll = new Poll();
						poll.setId(rs.getLong(1));
						poll.setTitle(rs.getString(2));
						poll.setMessage(rs.getString(3));
						polls.add(poll);
					}
				} finally {
					try {
						rs.close();
					} catch (Exception ignorable) {
					}
				}
			} finally {
				try {
					pst.close();
				} catch (Exception ignorable) {
				}
			}
		} catch (Exception ex) {
			throw new DAOException("Error while getting list of polls.", ex);
		}

		return polls;
	}

	@Override
	public List<PollOption> catchPollOptionsWithPollId(long pollId, boolean sortByVotes) throws DAOException {
		List<PollOption> pollOptions = new ArrayList<>();
		Connection con = SQLConnectionProvider.getConnection();
		PreparedStatement pst = null;
		try {
			if (sortByVotes) {
				pst = con
						.prepareStatement("SELECT * FROM PollOptions WHERE pollID=? ORDER BY votesCount DESC, optionTitle, id, optionLink");
			} else {
				pst = con
						.prepareStatement("SELECT * FROM PollOptions WHERE pollID=? ORDER BY optionTitle, id, optionLink");
			}

			pst.setLong(1, pollId);
			try {
				ResultSet rs = pst.executeQuery();
				try {
					while (rs != null && rs.next()) {
						PollOption pollOption = new PollOption();
						pollOption.setId(rs.getLong(1));
						pollOption.setTitle(rs.getString(2));
						pollOption.setLink(rs.getString(3));
						pollOption.setPollId(pollId);
						pollOption.setVotesCount(rs.getLong(5));
						pollOptions.add(pollOption);
					}
				} finally {
					try {
						rs.close();
					} catch (Exception ignorable) {
					}
				}
			} finally {
				try {
					pst.close();
				} catch (Exception ignorable) {
				}
			}
		} catch (Exception ex) {
			throw new DAOException("Error while getting list of polls.", ex);
		}

		return pollOptions;
	}

	private void initPolls() throws DAOException {
		Connection con = SQLConnectionProvider.getConnection();
		PreparedStatement pst = null;

		List<Poll> polls = new ArrayList<>();
		List<Poll> defaultPolls = new ArrayList<>();
		defaultPolls.add(new Poll(1, "Glasanje za omiljeni bend:",
				"Od sljedećih bendova, koji Vam je bend najdraži? Kliknite na link kako biste glasali!"));
		defaultPolls.add(new Poll(2, "Popis mojih najdražih autora.", "Pogledajte moji glazbeni ukus!"));

		try {
			pst = con.prepareStatement("SELECT * FROM Polls");
			try {
				ResultSet rs = pst.executeQuery();
				try {
					while (rs != null && rs.next()) {
						Poll poll = new Poll();
						poll.setId(rs.getLong(1));
						poll.setTitle(rs.getString(2));
						poll.setMessage(rs.getString(3));
						polls.add(poll);
					}
				} finally {
					try {
						rs.close();
					} catch (Exception ignorable) {
					}
				}
			} finally {
				try {
					pst.close();
				} catch (Exception ignorable) {
				}
			}

		} catch (Exception ex) {
			throw new DAOException("Error while getting polls.", ex);
		}
		defaultPolls.removeAll(polls);

		try {
			for (Poll poll : defaultPolls) {
				pst = con.prepareStatement("INSERT INTO Polls (title, message) VALUES (?,?)",
						Statement.RETURN_GENERATED_KEYS);
				pst.setString(1, poll.getTitle());
				pst.setString(2, poll.getMessage());

				int numberOfAffectedRows = pst.executeUpdate(); // Ocekujemo da je numberOfAffectedRows=1
				System.out.println("Broj redaka koji su pogođeni ovim unosom: " + numberOfAffectedRows);

				ResultSet rset = pst.getGeneratedKeys();

				try {
					if (rset != null && rset.next()) {
						long noviID = rset.getLong(1);
						poll.setId(noviID);
						System.out.println("Unos je obavljen i podatci su pohranjeni pod ključem id = " + noviID);
					}
				} finally {
					try {
						rset.close();
					} catch (SQLException ex) {
						ex.printStackTrace();
					}
				}
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			try {
				pst.close();
			} catch (SQLException ex) {
				ex.printStackTrace();
			}
		}
		// try {
		// con.close();
		// } catch (SQLException ex) {
		// ex.printStackTrace();
		// }

	}

	private void initPollOptions() throws DAOException {
		Connection con = SQLConnectionProvider.getConnection();
		PreparedStatement pst = null;
		DAO dao = DAOProvider.getDao();
		List<Poll> polls = dao.catchPolls();
		List<PollOption> pollOptions = new ArrayList<>();
		List<PollOption> defalutPollOptions = new ArrayList<>();

		try {
			pst = con.prepareStatement("SELECT * FROM PollOptions");
			try {
				ResultSet rs = pst.executeQuery();
				try {
					while (rs != null && rs.next()) {
						PollOption pollOption = new PollOption();
						pollOption.setId(rs.getLong(1));
						pollOption.setTitle(rs.getString(2));
						pollOption.setLink(rs.getString(3));
						pollOption.setPollId(rs.getLong(4));
						pollOption.setVotesCount(rs.getLong(5));
						pollOptions.add(pollOption);
					}
				} finally {
					try {
						rs.close();
					} catch (Exception ignorable) {
					}
				}
			} finally {
				try {
					pst.close();
				} catch (Exception ignorable) {
				}
			}

		} catch (Exception ex) {
			throw new DAOException("Error while getting polls.", ex);
		}

		long pollId = getPollIdWithTitle(polls, "Glasanje za omiljeni bend:");

		defalutPollOptions.add(new PollOption(0, "The Beatles",
				"http://www.geocities.com/~goldenoldies/TwistAndShout-Beatles.mid", pollId, 10));
		defalutPollOptions.add(new PollOption(0, "The Platters",
				"http://www.geocities.com/~goldenoldies/SmokeGetsInYourEyes-Platters-ver2.mid", pollId, 11));
		defalutPollOptions.add(new PollOption(0, "The Beach Boys",
				"http://www.geocities.com/~goldenoldies/SurfinUSA-BeachBoys.mid", pollId, 12));
		defalutPollOptions.add(new PollOption(0, "The Four Seasons",
				"http://www.geocities.com/~goldenoldies/BigGirlsDontCry-FourSeasons.mid", pollId, 13));
		defalutPollOptions.add(new PollOption(0, "The Marcels",
				"http://www.geocities.com/~goldenoldies/Bluemoon-Marcels.mid", pollId, 14));
		defalutPollOptions.add(new PollOption(0, "The Everly Brothers",
				"http://www.geocities.com/~goldenoldies/All.I.HaveToDoIsDream-EverlyBrothers.mid", pollId, 15));
		defalutPollOptions.add(new PollOption(0, "The Mamas And The Papas",
				"http://www.geocities.com/~goldenoldies/CaliforniaDreaming-Mamas-Papas.mid", pollId, 15));

		pollId = getPollIdWithTitle(polls, "Popis mojih najdražih autora.");
		defalutPollOptions.add(new PollOption(0, "AC/DC", "https://www.youtube.com/watch?v=v2AC41dglnM", pollId, 10));
		defalutPollOptions
				.add(new PollOption(0, "Bon Jovi", "https://www.youtube.com/watch?v=SRvCvsRp5ho", pollId, 11));
		defalutPollOptions.add(new PollOption(0, "Elvis Presley", "https://www.youtube.com/watch?v=kJ6yAYHsHqg",
				pollId, 12));
		defalutPollOptions.add(new PollOption(0, "Guns N' Roses", "https://www.youtube.com/watch?v=o1tj2zJ2Wvg",
				pollId, 13));
		defalutPollOptions.add(new PollOption(0, "Hugh Laurie", "https://www.youtube.com/watch?v=7tm-9t-ZF2s", pollId,
				14));
		defalutPollOptions.add(new PollOption(0, "Led Zeppelin", "https://www.youtube.com/watch?v=jtN8oBjMr_E", pollId,
				15));
		defalutPollOptions
				.add(new PollOption(0, "Metallica", "https://www.youtube.com/watch?v=CD-E-LDc384", pollId, 16));
		defalutPollOptions.add(new PollOption(0, "Queen", "https://www.youtube.com/watch?v=fJ9rUzIMcZQ", pollId, 17));
		defalutPollOptions.add(new PollOption(0, "Robert Johnson", "https://www.youtube.com/watch?v=O8hqGu-leFc",
				pollId, 17));

		defalutPollOptions.removeAll(pollOptions);
		try {
			for (PollOption pollOption : defalutPollOptions) {
				pst = con.prepareStatement(
						"INSERT INTO PollOptions (optionTitle, optionLink, pollID, votesCount) VALUES (?,?,?,?)",
						Statement.RETURN_GENERATED_KEYS);
				pst.setString(1, pollOption.getTitle());
				pst.setString(2, pollOption.getLink());
				pst.setLong(3, pollOption.getPollId());
				pst.setLong(4, pollOption.getVotesCount());

				int numberOfAffectedRows = pst.executeUpdate(); // Ocekujemo da je numberOfAffectedRows=1
				System.out.println("Broj redaka koji su pogođeni ovim unosom: " + numberOfAffectedRows);

				ResultSet rset = pst.getGeneratedKeys();

				try {
					if (rset != null && rset.next()) {
						long noviID = rset.getLong(1);
						pollOption.setId(noviID);
						System.out.println("Unos je obavljen i podatci su pohranjeni pod ključem id = " + noviID);
					}
				} finally {
					try {
						rset.close();
					} catch (SQLException ex) {
						ex.printStackTrace();
					}
				}
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			try {
				pst.close();
			} catch (SQLException ex) {
				ex.printStackTrace();
			}
		}
		try {
			con.close();
		} catch (SQLException ex) {
			ex.printStackTrace();
		}
	}

	private long getPollIdWithTitle(List<Poll> polls, String title) {
		for (Poll poll : polls) {
			if (poll.getTitle().equals(title)) {
				return poll.getId();
			}
		}
		throw new DAOException("No such title found.");
	}

	@Override
	public PollOption getPollOptionWithId(long id) {
		Connection con = SQLConnectionProvider.getConnection();
		PreparedStatement pst = null;
		PollOption pollOption = null;
		try {
			pst = con.prepareStatement("SELECT * FROM PollOptions WHERE id=?");
			pst.setLong(1, id);
			try {
				ResultSet rs = pst.executeQuery();
				try {
					if (rs != null && rs.next()) {
						pollOption = new PollOption();
						pollOption.setId(rs.getLong(1));
						pollOption.setTitle(rs.getString(2));
						pollOption.setLink(rs.getString(3));
						pollOption.setPollId(rs.getLong(4));
						pollOption.setVotesCount(rs.getLong(5));
					}
				} finally {
					try {
						rs.close();
					} catch (Exception ignorable) {
					}
				}
			} finally {
				try {
					pst.close();
				} catch (Exception ignorable) {
				}
			}

		} catch (Exception ex) {
			throw new DAOException("Error while getting polls.", ex);
		}
		return pollOption;
	}

	@Override
	public void updatePollOption(PollOption pollOption) {
		Connection con = SQLConnectionProvider.getConnection();
		PreparedStatement pst = null;
		try {
			pst = con.prepareStatement("UPDATE PollOptions set votesCount=? WHERE id=?");
			pst.setLong(1, pollOption.getVotesCount());
			pst.setLong(2, pollOption.getId());

			int numberOfAffectedRows = pst.executeUpdate(); // Ocekujemo da je numberOfAffectedRows=1
			System.out.println("Broj redaka koji su pogođeni ovom izmjenom: " + numberOfAffectedRows);
		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			try {
				pst.close();
			} catch (SQLException ex) {
				ex.printStackTrace();
			}
		}
		// try {
		// con.close();
		// } catch (SQLException ex) {
		// ex.printStackTrace();
		// }
	}

}