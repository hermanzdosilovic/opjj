package hr.fer.zemris.java.tecaj_13;

import hr.fer.zemris.java.tecaj_13.dao.DAOProvider;
import hr.fer.zemris.java.tecaj_13.model.PollOption;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PiePlot3D;
import org.jfree.data.general.DefaultPieDataset;
import org.jfree.data.general.PieDataset;
import org.jfree.util.Rotation;

/**
 * @author Herman Zvonimir Došilović
 * @version 1.0
 */
@WebServlet("/servleti/glasanje-grafika")
public class GlasanjeGrafika extends HttpServlet {

	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		try {
			resp.setContentType("image/png");
			PieDataset dataset = createDataset(req);
			JFreeChart chart = createChart(dataset, "");
			ChartUtilities.writeChartAsPNG(resp.getOutputStream(), chart, 700, 500);
		} catch (RuntimeException ignorable) {
			req.getRequestDispatcher("/WEB-INF/pages/Error.jsp");
		}
	}

	private PieDataset createDataset(HttpServletRequest req) throws IOException {
		DefaultPieDataset resultDataset = new DefaultPieDataset();
		long pollId = (Long) req.getSession().getAttribute("pollID");
		List<PollOption> pollOptions = DAOProvider.getDao().catchPollOptionsWithPollId(pollId, true);
		for (PollOption pollOption : pollOptions) {
			resultDataset.setValue(pollOption.getTitle(), pollOption.getVotesCount());
		}
		return resultDataset;
	}

	private JFreeChart createChart(PieDataset dataset, String title) {
		JFreeChart chart = ChartFactory.createPieChart3D(title, // chart title
				dataset, // data
				true, // include legend
				true, false);

		PiePlot3D plot = (PiePlot3D) chart.getPlot();
		plot.setStartAngle(290);
		plot.setDirection(Rotation.CLOCKWISE);
		plot.setForegroundAlpha(0.5f);
		return chart;
	}

}
