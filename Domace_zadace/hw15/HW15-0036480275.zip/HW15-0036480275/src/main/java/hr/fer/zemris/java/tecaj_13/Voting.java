package hr.fer.zemris.java.tecaj_13;

import hr.fer.zemris.java.tecaj_13.dao.DAO;
import hr.fer.zemris.java.tecaj_13.dao.DAOProvider;
import hr.fer.zemris.java.tecaj_13.model.PollOption;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * @author Herman Zvonimir Došilović
 * @version 1.0
 */
@WebServlet("/servleti/glasanje")
public class Voting extends HttpServlet {

	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		try {
			long id = Long.parseLong(req.getParameter("pollID"));
			DAO dao = DAOProvider.getDao();
			List<PollOption> pollOptions = dao.catchPollOptionsWithPollId(id, false);
			req.setAttribute("pollOptions", pollOptions);
			req.getRequestDispatcher("/WEB-INF/pages/Voting.jsp").forward(req, resp);
		} catch (RuntimeException ignorable) {
			req.getRequestDispatcher("/WEB-INF/pages/Error.jsp");
		}
	}
}
