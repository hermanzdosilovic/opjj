package hr.fer.zemris.bool.fimpl.test;

import hr.fer.zemris.bool.BooleanFunction;
import hr.fer.zemris.bool.BooleanValue;
import hr.fer.zemris.bool.BooleanVariable;
import hr.fer.zemris.bool.fimpl.IndexedBF;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;

public class MaskBasedBFTest {

    @Test
    public void mintermtest() {
        BooleanVariable varA = new BooleanVariable("A");
        BooleanVariable varB = new BooleanVariable("B");
        BooleanVariable varC = new BooleanVariable("C");
        BooleanFunction f1 = new IndexedBF("f1", Arrays.asList(varA, varB, varC), true, Arrays.asList(0, 1, 5, 7),
                Arrays.asList(2, 3));
        List<Integer> list = new ArrayList<>(Arrays.asList(0, 1, 5, 7));
        int k = 0;
        for (Integer i : f1.mintermIterable()) { // Ispis: 0, 1, 5, 7
            if (list.get(k++) != i)
                Assert.assertEquals("Mintermi nisu jednaki.", list.get(k), i);
        }
    }

    @Test
    public void maxtermtest() {
        BooleanVariable varA = new BooleanVariable("A");
        BooleanVariable varB = new BooleanVariable("B");
        BooleanVariable varC = new BooleanVariable("C");
        BooleanFunction f1 = new IndexedBF("f1", Arrays.asList(varA, varB, varC), true, Arrays.asList(0, 1, 5, 7),
                Arrays.asList(2, 3));
        List<Integer> list = new ArrayList<>(Arrays.asList(4, 6));
        int k = 0;
        for (Integer i : f1.maxtermIterable()) { // Ispis: 0, 2, 6
            if (list.get(k++) != i)
                Assert.assertEquals("Maxtermi nisu jednaki.", list.get(k), i);
        }
    }

    @Test
    public void dontCareTest() {
        BooleanVariable varA = new BooleanVariable("A");
        BooleanVariable varB = new BooleanVariable("B");
        BooleanVariable varC = new BooleanVariable("C");
        BooleanFunction f1 = new IndexedBF("f1", Arrays.asList(varA, varB, varC), true, Arrays.asList(0, 1, 5, 7),
                Arrays.asList(2, 3));
        List<Integer> list = new ArrayList<>(Arrays.asList(2, 3));
        int k = 0;
        for (Integer i : f1.dontcareIterable()) {
            if (list.get(k++) != i)
                Assert.assertEquals("dontcare nisu jednaki.", list.get(k), i);
        }
    }

    @Test
    public void getValueTest() {
        BooleanVariable varA = new BooleanVariable("A");
        BooleanVariable varB = new BooleanVariable("B");
        BooleanVariable varC = new BooleanVariable("C");
        BooleanFunction f1 = new IndexedBF("f1", Arrays.asList(varA, varB, varC), true, Arrays.asList(0, 1, 5, 7),
                Arrays.asList(2, 3));
        Assert.assertEquals("Values are not the same", f1.getValue(), BooleanValue.FALSE);
    }
}
