package hr.fer.zemris.bool.fimpl.test;

import hr.fer.zemris.bool.BooleanFunction;
import hr.fer.zemris.bool.BooleanValue;
import hr.fer.zemris.bool.BooleanVariable;
import hr.fer.zemris.bool.Masks;
import hr.fer.zemris.bool.fimpl.MaskBasedBF;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;

public class OperatorTreeBFTest {
    
    @Test
    public void mintermtest() {
        BooleanVariable varA = new BooleanVariable("A");
        BooleanVariable varB = new BooleanVariable("B");
        BooleanVariable varC = new BooleanVariable("C");
        BooleanVariable varD = new BooleanVariable("D");
        BooleanFunction f1 = new MaskBasedBF("f1", Arrays.asList(varA, varB, varC, varD), true, Masks.fromStrings(
                "00x0", "1xx1"), Masks.fromStrings("10x0"));
        List<Integer> list = new ArrayList<>(Arrays.asList(0, 2, 9, 11, 13, 15));
        int k = 0;
        for (Integer i : f1.mintermIterable()) { // Ispis: 0, 2, 9, 11, 13, 15
            if(list.get(k++) != i)
                Assert.assertEquals("Mintermi nisu jednaki.", list.get(k), i);
        }
    }
    
    @Test
    public void maxtermtest() {
        BooleanVariable varA = new BooleanVariable("A");
        BooleanVariable varB = new BooleanVariable("B");
        BooleanVariable varC = new BooleanVariable("C");
        BooleanVariable varD = new BooleanVariable("D");
        BooleanFunction f1 = new MaskBasedBF("f1", Arrays.asList(varA, varB, varC, varD), true, Masks.fromStrings(
                "00x0", "1xx1"), Masks.fromStrings("10x0"));
        List<Integer> list = new ArrayList<>(Arrays.asList(1, 3, 4, 5, 6, 7, 12, 14));
        int k = 0;
        for (Integer i : f1.maxtermIterable()) { // Ispis: 1, 3, 4, 5, 6, 7, 12, 14
            if(list.get(k++) != i)
                Assert.assertEquals("Maxtermi nisu jednaki.", list.get(k), i);
        }
    }
    
    @Test
    public void dontCareTest() {
        BooleanVariable varA = new BooleanVariable("A");
        BooleanVariable varB = new BooleanVariable("B");
        BooleanVariable varC = new BooleanVariable("C");
        BooleanVariable varD = new BooleanVariable("D");
        BooleanFunction f1 = new MaskBasedBF("f1", Arrays.asList(varA, varB, varC, varD), true, Masks.fromStrings(
                "00x0", "1xx1"), Masks.fromStrings("10x0"));
        List<Integer> list = new ArrayList<>(Arrays.asList(8, 10));
        int k = 0;
        for (Integer i : f1.dontcareIterable()) {
            if(list.get(k++) != i)
                Assert.assertEquals("Dontcare nisu jednaki.", list.get(k), i);
        }
    }
    
    @Test
    public void getValueTest() {
        BooleanVariable varA = new BooleanVariable("A");
        BooleanVariable varB = new BooleanVariable("B");
        BooleanVariable varC = new BooleanVariable("C");
        BooleanVariable varD = new BooleanVariable("D");
        BooleanFunction f1 = new MaskBasedBF("f1", Arrays.asList(varA, varB, varC, varD), true, Masks.fromStrings(
                "00x0", "1xx1"), Masks.fromStrings("10x0"));
        Assert.assertEquals("Values are not the same", f1.getValue(), BooleanValue.FALSE);
    }
}
