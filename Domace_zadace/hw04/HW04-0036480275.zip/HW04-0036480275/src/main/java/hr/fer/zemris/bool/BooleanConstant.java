package hr.fer.zemris.bool;

import java.util.Collections;
import java.util.List;

/**
 * Class {@code BooleanConstant} provides work with Boolean constants.
 * @author Herman Zvonimir Došilović
 * @version 1.0
 */
public final class BooleanConstant implements BooleanSource {

    public static final BooleanConstant FALSE = new BooleanConstant(BooleanValue.FALSE);
    public static final BooleanConstant TRUE = new BooleanConstant(BooleanValue.TRUE);
    
    /** {@code BooleanValue} that this {@code BooleanConstant} holds. */
    private final BooleanValue value;


    /**
     * Constructs new Boolean Constant with specified value.
     * @param newValue {@code BooleanValue} of new {@code BooleanConstant}.
     */
    private BooleanConstant(final BooleanValue newValue) {
        this.value = newValue;
    }

    /**
     * Returns {@code BooleanValue} that this {@code BooleanConstant} holds.
     * @return {@code BooleanValue} that this {@code BooleanConstant} holds.
     */
    @Override
    public BooleanValue getValue() {
        return this.value;
    }

    /**
     * Returns domain that is empty collection.
     * @return <code>Collections.<i>emptyList</i>()</code>.
     */
    @Override
    public List<BooleanVariable> getDomain() {
        return Collections.emptyList();
    }

}
