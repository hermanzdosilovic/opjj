package hr.fer.zemris.java.tecaj.hw4.db;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Class {@code LineParser} is used to check if line that user entered is valid.<br>
 * Here are some examples of correct lines:
 * <p>
 * <li>query jmbag="00023403020"
 * <li>query jmbag = ""
 * <li>query lastName = "B*"
 * <li>query lastName="ce*b"
 * </p>
 * <br>
 * Here are some examples of incorrect lines:
 * <p>
 * <li>query someothercommand
 * <li>query lastName="b****"
 * </p>
 * @author Herman Zvonimir Došilović
 * @version 1.0
 */
public final class LineParser {

    /**
     * Private constuctor. Never called.
     */
    private LineParser() {
    }

    /**
     * Method check whether line is correct.<br>
     * Here are some examples of correct lines:
     * <p>
     * <li>query jmbag="00023403020"
     * <li>query jmbag = ""
     * <li>query lastName = "B*"
     * <li>query lastName="ce*b"
     * </p>
     * <br>
     * Here are some examples of incorrect lines:
     * <p>
     * <li>query someothercommand
     * <li>query lastName="b****"
     * </p>
     * <br>
     * @param line line to check
     * @return {@code true} if line is valid, {@code false} otherwise.
     */
    public static boolean checkLine(final String line) {
        int numberOfStars = 0;
        for (int i = 0; i < line.length(); i++) {
            if (line.charAt(i) == '*') {
                numberOfStars++;
            }
        }
        if (numberOfStars > 1) {
            return false;
        }

        Pattern p0 = Pattern.compile("^\\s*query\\s*jmbag\\s*\\=\\s*\"\\d*\"\\s*$");
        Pattern p1 = Pattern.compile("^\\s*query\\s*lastName\\s*\\=\\s*\".*\"\\s*$");

        Matcher m0 = p0.matcher(line);
        Matcher m1 = p1.matcher(line);

        return m0.find() | m1.find();
    }

    /**
     * Returns an argument of command.
     * @param line users line from which argument should be extracted.
     * @return argument of command.
     */
    public static String getArgument(final String line) {
        String argument = line;
        argument = argument.substring(argument.indexOf('\"') + 1);
        argument = argument.substring(0, argument.indexOf('\"'));
        argument = argument.replace("*", ".*");
        if (!isJMBAGCommand(line)) {
            argument = "^" + argument + "$";
        }
        return argument;
    }

    /**
     * Checks if command is "jmbag" command.
     * @param line users line from which command should be checked.
     * @return {@code true} if command is "jmbag", {@code false} otherwise.
     */
    public static boolean isJMBAGCommand(final String line) {
        String command = line;
        command = command.substring(0, command.indexOf('\"'));
        return command.contains("jmbag");
    }

}
