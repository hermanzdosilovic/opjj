package hr.fer.zemris.bool.fimpl;

import hr.fer.zemris.bool.BooleanFunction;
import hr.fer.zemris.bool.BooleanValue;
import hr.fer.zemris.bool.BooleanVariable;
import hr.fer.zemris.bool.Mask;
import hr.fer.zemris.bool.MaskValue;

import java.util.ArrayList;
import java.util.List;
import java.util.SortedSet;
import java.util.TreeSet;

public class MaskBasedBF implements BooleanFunction {
    
    private String name;
    private List<BooleanVariable> domain;
    private boolean masksAreMinters;
    private List<Mask> masks;
    private List<Mask> dontCareMasks;

    public MaskBasedBF(String name, List<BooleanVariable> domain, boolean indexesAreMinters, List<Mask> indexes,
            List<Mask> dontCares) {
        if(domain == null) {
            throw new IllegalArgumentException();
        }
        if(indexes == null && dontCares == null) {
            throw new IllegalArgumentException();
        }
        if(domain.size() == 0 || (indexes.size() == 0 && dontCares.size() == 0)) {
            throw new IllegalArgumentException();
        }
        this.name = name;
        this.domain = new ArrayList<>(domain);
        this.masksAreMinters = indexesAreMinters;
        this.masks = new ArrayList<>(indexes);
        this.dontCareMasks = new ArrayList<>(dontCares);
    }
    
    public String getName() {
        return this.name;
    }
    
    public List<BooleanVariable> getDomain() {
        return this.domain;
    }
    
    public Iterable<Integer> mintermIterable() {
        SortedSet<Integer> s = new TreeSet<>();
        for(Mask m : masks) {
            s.addAll(getNumber(m));
        }
        if(masksAreMinters) {
            return s;
        }
        
        SortedSet<Integer> g = new TreeSet<>();
        for(Mask m : dontCareMasks) {
            g.addAll(getNumber(m));
        }
        
        SortedSet<Integer> f = new TreeSet<>(generateNumbers());
        f.removeAll(s);
        f.removeAll(g);
        return f;
    }
    
    public boolean hasMinterm(int index) {
        for(Integer i : mintermIterable()) {
            if(i == index)
                return true;
        }
        return false;
    }
    
    public boolean hasMaxterm(int index) {
        for(Integer i : maxtermIterable()) {
            if(i == index)
                return true;
        }
        return false;
    }
    
    public boolean hadDontCare(int index) {
        if(!hasMaxterm(index) && !hasMinterm(index))
            return true;
        return false;
    }
    
    public Iterable<Integer> dontcareIterable() {
        SortedSet<Integer> s = new TreeSet<Integer>();
        for(Mask m : dontCareMasks) {
            s.addAll(getNumber(m));
        }
        return s;
    }
    
    public Iterable<Integer> maxtermIterable() {
        SortedSet<Integer> s = new TreeSet<>();
        for(Mask m : masks) {
            s.addAll(getNumber(m));
        }
        if(!masksAreMinters) {
            return s;
        }
        
        SortedSet<Integer> g = new TreeSet<>();
        for(Mask m : dontCareMasks) {
            g.addAll(getNumber(m));
        }
        
        SortedSet<Integer> f = new TreeSet<>(generateNumbers());
        f.removeAll(s);
        f.removeAll(g);
        return f;
    }
    
    private SortedSet<Integer> generateNumbers() {
        int B = 1 << domain.size();
        SortedSet<Integer> s = new TreeSet<>();
        for(int i = 0; i < B; i++) {
            s.add(i);
        }
        return s;
    }
    private SortedSet<Integer> getNumber(Mask m) {
        SortedSet<Integer> s = new TreeSet<>();
        List<Character> stringmask = new ArrayList<>();
        for(int i = 0; i < m.getSize(); i++) {
           if(m.getValue(i) == MaskValue.DONT_CARE)
               stringmask.add('x');
           else if(m.getValue(i) == MaskValue.ONE)
               stringmask.add('1');
           else
               stringmask.add('0');
        }
        
        boolean donCare = false;
        for(int i = 0; i < m.getSize(); i++) {
            if(m.getValue(i) == MaskValue.DONT_CARE) {
                stringmask.set(i, '1');
                s.addAll(getNumber(Mask.parse(convert(stringmask.toString()))));
                stringmask.set(i, '0');
                s.addAll(getNumber(Mask.parse(convert(stringmask.toString()))));
                donCare = true;
            }
        }
        
        if(donCare == false) {
            s.add(Integer.parseInt(convert(stringmask.toString()), 2));
        }
        
        return s;
    }
    
    private String convert(String s) {
        return s.toString().replace("[", "").replace("]", "").replace(" ", "").replace(",", "");
    }
    
    public BooleanValue getValue() {
        List<Integer> min = new ArrayList<>();
        if(masksAreMinters) {
            for(Integer m : mintermIterable()) {
                min.add(m);
            }
        } else {
            for(Integer m: maxtermIterable()) {
                min.add(m);
            }
        }
        List<Integer> dontcare = new ArrayList<>();
        for(Integer don : dontcareIterable()) {
            dontcare.add(don);
        }
        return new IndexedBF("", domain, masksAreMinters, min, dontcare).getValue();
    }
    
}
