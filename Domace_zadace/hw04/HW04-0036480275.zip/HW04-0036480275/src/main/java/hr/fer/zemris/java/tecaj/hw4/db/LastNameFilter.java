package hr.fer.zemris.java.tecaj.hw4.db;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Class {@code LastNameFilter} is used to filter students based on their last name.
 * @author Herman Zvonimir Došilović
 * @version 1.0
 */
public class LastNameFilter implements IFilter {

    /** Used to store maskPattern provided by user. */
    private final String maskPattern;

    /**
     * Constructs new {@code LastNameFilter} with specified mask pattern to follow.
     * @param mask mask pattern to follow when filter on students is applied.
     */
    public LastNameFilter(final String mask) {
        maskPattern = mask;
    }

    /**
     * Checks whether {@code StudentRecord} is acceptable with well defined mask pattern.
     * @param record {@StudentRecord} to check.
     * @return {@code true} if student is acceptable, {@code false} otherwise.
     */
    @Override
    public final boolean accepts(final StudentRecord record) {
        Pattern pattern = Pattern.compile(maskPattern);
        Matcher matcher = pattern.matcher(record.getLastName());
        return matcher.find();
    }

}
