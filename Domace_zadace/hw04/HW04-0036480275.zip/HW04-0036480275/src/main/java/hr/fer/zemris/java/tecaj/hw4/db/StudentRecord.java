package hr.fer.zemris.java.tecaj.hw4.db;

/**
 * Class {@code StudentRecord} represents information about one student.
 * @author Herman Zvonimir Došilović
 * @version 1.0
 */
public class StudentRecord {

    /** Used to store student's jmbag. */
    private final String jmbag;

    /** Used to store student's last name. */
    private final String lastName;

    /** Used to store student's first name. */
    private final String firstName;

    /** Used to store student's final grade. */
    private final int finalGrade;

    /**
     * Constructs new student based on given parametes.
     * @param newJmbag student's jmbag.
     * @param newLastName student's last name.
     * @param newFirstName studnet's first name.
     * @param newFinalGrade student's final grade.
     */
    public StudentRecord(final String newJmbag, final String newLastName, final String newFirstName,
            final int newFinalGrade) {
        this.jmbag = newJmbag;
        this.lastName = newLastName;
        this.firstName = newFirstName;
        this.finalGrade = newFinalGrade;
    }

    /**
     * Returns student's jmbag.
     * @return studnet's jmbag.
     */
    public final String getJmbag() {
        return jmbag;
    }

    /**
     * Returns student's last name.
     * @return student's last name.
     */
    public final String getLastName() {
        return lastName;
    }

    /**
     * Returns student's first name.
     * @return student's first name.
     */
    public final String getFirstName() {
        return firstName;
    }

    /**
     * Returns student's final grade.
     * @return studnet's final grade.
     */
    public final int getFinalGrade() {
        return finalGrade;
    }

    /**
     * Returns student's hash code value.
     * @return student's hash code value.
     */
    @Override
    public final int hashCode() {
        return (firstName.hashCode() + lastName.hashCode()) + Integer.parseInt(jmbag);
    }

    /**
     * Checks if this student is equal to student {@code obj}. Students are equal if their jmbags are equal.
     * @param obj student to compare to this student.
     * @return {@code true} is students are equal, {@code false} otherwise.
     */
    @Override
    public final boolean equals(final Object obj) {
        if (!(obj instanceof StudentRecord)) {
            return false;
        }

        StudentRecord student = (StudentRecord) obj;
        return jmbag.compareTo(student.getJmbag()) == 0;
    }

}
