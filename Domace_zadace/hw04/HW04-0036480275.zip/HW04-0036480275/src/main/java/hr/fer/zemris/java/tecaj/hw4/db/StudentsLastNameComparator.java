package hr.fer.zemris.java.tecaj.hw4.db;

import java.io.Serializable;
import java.util.Comparator;

/**
 * Class {@code StudentsLastNameComparator} implements {@code Comparator} which is needed to compare two students.
 * @author Herman Zvonimir Došilović
 * @version 1.0
 */
public class StudentsLastNameComparator implements Comparator<StudentRecord>, Serializable {

    /** Represents serailVersion UID. */
    private static final long serialVersionUID = 1L;

    /**
     * Compares two {@code StudentRecord}.
     * @param student1 first student to compare.
     * @param student2 second student to compare.
     * @return the value 0 if the student2 lastName is equal to student1 lastName; a value less than 0 if student1
     *         lastName is lexicographically less than the student2 lastName; and a value greater than 0 if student1
     *         lastName is lexicographically greater than the student2 lastName.
     */
    @Override
    public final int compare(final StudentRecord student1, final StudentRecord student2) {
        return student1.getLastName().compareTo(student2.getLastName());
    }

}
