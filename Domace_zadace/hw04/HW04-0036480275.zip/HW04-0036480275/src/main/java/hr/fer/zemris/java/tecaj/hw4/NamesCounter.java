package hr.fer.zemris.java.tecaj.hw4;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;

/**
 * Class {@code AboveAverage} is solution of the <i>Problem 3</i> in fourth homework.
 * @author Herman Zvonimir Došilović
 * @version 1.0
 */
public final class NamesCounter {

    /**
     * When executed program starts with this method. Program gets data from standard input, and does not use arguments
     * {@code args}.
     * @param args arguments from command line. <b>Not in use.</b>
     * @throws IOException if unable to read from standard input.
     */
    public static void main(final String[] args) throws IOException {
        Map<String, Integer> names = getNames();
        System.out.println(names);
    }

    /**
     * Returns map of names where {@code key} is a name, and {@code Integer} is a number that represents number of times
     * that name was entered.
     * @return map of names.
     * @throws IOException if unable to read from standard input.
     */
    public static Map<String, Integer> getNames() throws IOException {
        Map<String, Integer> names = new HashMap<>();
        final BufferedReader reader = new BufferedReader(new InputStreamReader(System.in, "UTF-8"));
        int value;
        String line = "";

        while (true) {
            try {
                line = reader.readLine();
                if (line.compareTo("quit") == 0) {
                    break;
                }

                if (names.containsKey(line)) {
                    value = names.get(line);
                } else {
                    value = 0;
                }
                names.put(line, value + 1);
            } catch (IOException e) {
                throw new IOException("Unable to read from standard input.");
            } catch (NullPointerException e) {
                System.out.println("Unable to read from standard input.");
            }
        }

        return names;
    }

    /**
     * Private constructor. Won't be called.
     */
    private NamesCounter() {
    }

}
