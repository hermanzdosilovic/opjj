package hr.fer.zemris.java.tecaj.hw4.db;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Class {@code StudentDB} is used to get information from database.
 * <p>
 * You can use commands like:
 * <p>
 * <li><i>query jmbag="123456"</i> this will give you an student with specified jmbag if exsists.
 * <li><i>query lastName="B*"</i> this will list you all students whose last name starts with 'B' and everything else is
 * any word.
 * <li><i>query lastName="K*ić"</i> this will list you all student whose last name starts with 'K' and ends with "ić".
 * <li><i>query lastName="B**"</i> this is invalid command.
 * </p>
 * <br>
 * For command "jmbag" only digits are allowed.<br>
 * For command "lastName" letters, spaces, and <b>one</b> '*' is allowed.
 * @author Herman Zvonimir Došilović
 * @version 1.0
 */
public final class StudentDB {

    /**
     * Method from where program starts. <b>Does not use arguments from command line.</b>
     * @param args arguments from command line.
     * @throws IOException if unable to read from database.txt.
     */
    public static void main(final String[] args) throws IOException {
        final List<String> fileDatabase = Files.readAllLines(Paths.get("./database.txt"), StandardCharsets.UTF_8);
        final StudentDatabase studentDatabase = new StudentDatabase(fileDatabase);
        final BufferedReader reader = new BufferedReader(new InputStreamReader(System.in, "UTF-8"));
        String newLine;
        String argument;

        List<StudentRecord> students = new ArrayList<>();
        System.out.println("Enter command or type \"quit\" to exit.");
        while (true) {
            System.out.print("> ");
            try {
                newLine = reader.readLine();
                if (newLine.compareTo("quit") == 0) {
                    break;
                }
                if (!LineParser.checkLine(newLine)) {
                    System.out.println("Invalid line.");
                    continue;
                }
                argument = LineParser.getArgument(newLine);
                if (LineParser.isJMBAGCommand(newLine)) {
                    if (studentDatabase.forJMBAG(argument) != null) {
                        students.add(studentDatabase.forJMBAG(argument));
                    }
                } else {
                    students = studentDatabase.filter(new LastNameFilter(argument));
                }
                outputTable(students);
                students.clear();
            } catch (IOException e) {
                throw new IOException("Cannot read from standard input.");
            } catch (NullPointerException e) {
                System.out.println("Invalid line.");
            }
        }
    }

    /**
     * Outputs formated table for given query.
     * @param students list of students to output.
     */
    private static void outputTable(final List<StudentRecord> students) {
        Collections.sort(students, new StudentsLastNameComparator());
        if (students.size() == 0) {
            System.out.println("Record selected: 0");
            return;
        }

        int longestJmbag = 0;
        int longestLastName = 0;
        int longestFirstName = 0;
        int longestFinalGrade = 0;
        int indent;
        for (StudentRecord student : students) {
            if (student.getLastName().length() > longestLastName) {
                longestLastName = student.getLastName().length() + 1;
            }
            if (student.getFirstName().length() > longestFirstName) {
                longestFirstName = student.getFirstName().length() + 1;
            }
            if (student.getJmbag().length() > longestJmbag) {
                longestJmbag = student.getJmbag().length() + 1;
            }
            if (String.format("%d", student.getFinalGrade()).length() > longestFinalGrade) {
                longestFinalGrade = String.format("%d", student.getFinalGrade()).length() + 1;
            }
        }

        printOutFrame(longestJmbag + 1, longestLastName + 1, longestFirstName + 1, longestFinalGrade + 1);
        for (StudentRecord student : students) {
            indent = longestJmbag - student.getJmbag().length();
            System.out.printf("| %s" + "%" + indent + "s", student.getJmbag(), "");

            indent = longestLastName - student.getLastName().length();
            System.out.printf("| %s" + "%" + indent + "s", student.getLastName(), "");

            indent = longestFirstName - student.getFirstName().length();
            System.out.printf("| %s" + "%" + indent + "s", student.getFirstName(), "");

            indent = longestFinalGrade - String.format("%d", student.getFinalGrade()).length();
            System.out.printf("| %s" + "%" + indent + "s|%n", String.format("%d", student.getFinalGrade()), "");
        }
        printOutFrame(longestJmbag + 1, longestLastName + 1, longestFirstName + 1, longestFinalGrade + 1);
        System.out.println("Record selected: " + students.size());
    }

    /**
     * Outputs table frame with given sizes of subframes.
     * @param first length of subframe.
     * @param second length of subframe.
     * @param third length of subframe.
     * @param fourth length of subframe.
     */
    private static void printOutFrame(final int first, final int second, final int third, final int fourth) {
        System.out.printf("+");
        for (int i = 0; i < first; i++) {
            System.out.printf("=");
        }
        System.out.printf("+");
        for (int i = 0; i < second; i++) {
            System.out.printf("=");
        }
        System.out.printf("+");
        for (int i = 0; i < third; i++) {
            System.out.printf("=");
        }
        System.out.printf("+");
        for (int i = 0; i < fourth; i++) {
            System.out.printf("=");
        }
        System.out.printf("+%n");
    }

    /**
     * Private constructor. Never called.
     */
    private StudentDB() {
    }

}
