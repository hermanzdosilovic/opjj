package hr.fer.zemris.java.tecaj.hw4.db;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Class {@code StudentDatabase} represents database of students.
 * @author Herman Zvonimir Došilović
 * @version 1.0
 */
public class StudentDatabase {

    /** Maps students jmbag to its record. */
    private final Map<String, StudentRecord> studentDatabase;

    /**
     * Constructs new students database based on list of lines in some file that represents that database.
     * @param fileDatabase lines of files that represents database.
     */
    public StudentDatabase(final List<String> fileDatabase) {
        studentDatabase = getDatabase(fileDatabase);
    }

    /**
     * Extracts and returns database from given list of lines.
     * @param fileDatabase list of lines that represents database.
     * @return map that maps students jmbag to its record.
     */
    private Map<String, StudentRecord> getDatabase(final List<String> fileDatabase) {
        Map<String, StudentRecord> extractedDatabase = new HashMap<>();
        StudentRecord student;

        for (String record : fileDatabase) {
            try {
                student = getStudent(record);
            } catch (IndexOutOfBoundsException | NumberFormatException e) {
                throw new RuntimeException("Invalid student record.");
            }
            extractedDatabase.put(student.getJmbag(), student);
        }

        return extractedDatabase;
    }

    /**
     * Returns students info from given line.
     * @param newRecord line that represents information of studnet.
     * @return {@code StudentRecord} that represenst that student.
     */
    private StudentRecord getStudent(final String newRecord) {
        String record = newRecord;
        String jmbag = record.substring(0, record.indexOf('\t'));
        record = record.substring(record.indexOf('\t') + 1);

        String lastName = record.substring(0, record.indexOf('\t'));
        record = record.substring(record.indexOf('\t') + 1);

        String firstName = record.substring(0, record.indexOf('\t'));
        record = record.substring(record.indexOf('\t') + 1);

        Integer finalGrade = Integer.parseInt(record);

        return new StudentRecord(jmbag, lastName, firstName, finalGrade);
    }

    /**
     * Returns student based on its jmbag. {@code null} is returned if that student does not exsists.
     * @param jmbag jmbag to search for
     * @return student with given jmbag.
     */
    public final StudentRecord forJMBAG(final String jmbag) {
        return studentDatabase.get(jmbag);
    }

    /**
     * Returns list of students that follow the given rule i.e. filter.
     * @param filter rule for students
     * @return list of students that follow given rule.
     */
    public final List<StudentRecord> filter(final IFilter filter) {
        List<StudentRecord> filteredStudents = new ArrayList<>();

        for (StudentRecord student : studentDatabase.values()) {
            if (filter.accepts(student)) {
                filteredStudents.add(student);
            }
        }

        return filteredStudents;
    }

}
