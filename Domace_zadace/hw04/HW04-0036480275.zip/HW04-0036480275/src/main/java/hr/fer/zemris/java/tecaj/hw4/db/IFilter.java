package hr.fer.zemris.java.tecaj.hw4.db;

/**
 * Interface {@code IFilter}.
 * @author Herman Zvonimir Došilović
 * @version 1.0
 */
public interface IFilter {

    /**
     * Checks whether {@code StudentRecord} is acceptable.
     * @param record {@code StudentRecord} to check.
     * @return {@code true} if {@code StudentRecord} is accepted, {@code false} otherwise.
     */
    boolean accepts(StudentRecord record);

}
