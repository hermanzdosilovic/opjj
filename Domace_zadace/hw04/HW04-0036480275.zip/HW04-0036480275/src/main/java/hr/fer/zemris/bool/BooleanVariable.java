package hr.fer.zemris.bool;

import java.util.Arrays;
import java.util.List;

/**
 * Class {@code BooleanVariable} provides construction of a Boolean variable with associated name.
 * @author Herman Zvonimir Došilović
 * @version 1.0
 */
public class BooleanVariable implements NamedBooleanSource {

    /** {@code BooleanValue} that this {@code BooleanVariable} holds. */
    private BooleanValue value = BooleanValue.FALSE;

    /** Holds name of {@code BooleanVariable}. */
    private final String name;

    /**
     * Constructs new {@code BooleanVariable} with specified name. {@code BooleanValue} of new {@code BooleanVariable}
     * is set to {@code FALSE}. There is a method {@code setValue} to assign new {@code BooleanValue} to this
     * {@code BooleanVariable}.
     * @param newName name of {@code BooleanVariable}.
     */
    public BooleanVariable(final String newName) {
        if (newName == null) { // Maybe you can add variable name check.
            throw new IllegalArgumentException("Name of BooleanVariable can not be null.");
        }

        this.name = newName;
    }

    /**
     * Set new {@code BooleanValue} to this {@code BooleanVariable}.
     * @param newValue new {@code BooleanValue} for this {@code BooleanVariable}.
     */
    public final void setValue(final BooleanValue newValue) {
        this.value = newValue;
    }

    /**
     * Returns {@code BooleanValue} of this {@code BooleanVariable}.
     * @return {@code BooleanValue} of this {@code BooleanVariable}.
     */
    @Override
    public final BooleanValue getValue() {
        return this.value;
    }

    /**
     * Provides an information based on which variables is this {@code BooleanVariable} produced.
     * @return information based on which variables is this {@code BooleanVariable} produced.
     */
    @Override
    public final List<BooleanVariable> getDomain() {
        return Arrays.asList(this);
    }

    /**
     * Returns name of this {@code BooleanVariable}.
     * @return name of this {@code BooleanVariable}.
     */
    @Override
    public final String getName() {
        return this.name;
    }

}
