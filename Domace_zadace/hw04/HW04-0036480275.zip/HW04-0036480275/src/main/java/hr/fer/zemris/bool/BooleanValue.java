package hr.fer.zemris.bool;

/**
 * Class {@code BooleanValue} defines a legal values for a Boolean function.
 * @author Herman Zvonimir Došilović
 * @version 1.0
 */
public enum BooleanValue {

    /** Represents {@code true} in Boolean algebra. */
    TRUE,

    /** Represents {@code false} in Boolean algebra. */
    FALSE,

    /** Represents do not care value in Boolean algebra. */
    DONT_CARE;

    /**
     * Constructs legal values for Boolean function.
     */
    BooleanValue() {
    }

}
